Bill Reminder (PHP + SQLite + SweetAlert2)
ต้องมี PHP 7.4+ ที่เปิด extension pdo_sqlite
รัน: php -S localhost:8000   หรือวางใน C:\xampp\htdocs\
ฐานข้อมูลสร้างอัตโนมัติที่ data/bills.db
