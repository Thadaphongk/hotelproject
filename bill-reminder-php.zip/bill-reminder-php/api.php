<?php
/**
 * Bill Reminder - API (PHP + SQLite via PDO)
 *
 * GET    ?action=year&year=YYYY                 รายจ่ายแยก 12 เดือน
 * GET    ?action=bills&month=YYYY-MM            รายจ่ายของเดือน
 * POST   ?action=bills                          เพิ่มรายจ่าย (months[])
 * PUT    ?action=bills&id=1                     แก้ไขรายจ่าย
 * DELETE ?action=bills&id=1                     ลบรายจ่ายทุกเดือน
 * DELETE ?action=bill_month&bill_id=1&month=..  ยกเลิกรายจ่ายเฉพาะเดือน
 * POST   ?action=payments                       บันทึกการจ่าย
 * DELETE ?action=payments&bill_id=1&month=..    ยกเลิกการจ่าย
 * GET    ?action=budget&year=YYYY               รายรับรายเดือน
 * POST   ?action=budget                         ตั้งรายรับ
 * GET    ?action=savings&year=YYYY              รายการเงินเก็บ
 * POST   ?action=savings                        เพิ่ม/แก้ไขเงินเก็บ
 * DELETE ?action=savings&id=1                   ลบเงินเก็บ
 * GET    ?action=assets                         ทรัพย์สินทั้งหมด + เงินเก็บสะสม
 * POST   ?action=assets                         เพิ่ม/แก้ไขทรัพย์สิน
 * DELETE ?action=assets&id=1                    ลบทรัพย์สิน
 */
declare(strict_types=1);
date_default_timezone_set('Asia/Bangkok');
header('Content-Type: application/json; charset=utf-8');

const DB_FILE = __DIR__ . '/data/bills.db';

function out($data, int $code = 200): void {
    http_response_code($code);
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}
function body(): array {
    $d = json_decode(file_get_contents('php://input') ?: '{}', true);
    return is_array($d) ? $d : [];
}
function validMonth($m): bool {
    return is_string($m) && (bool)preg_match('/^\d{4}-\d{2}$/', $m);
}
function money($v) {
    $f = filter_var($v, FILTER_VALIDATE_FLOAT);
    return ($f === false || $f < 0) ? false : (float)$f;
}

function getDb(): PDO {
    if (!is_dir(dirname(DB_FILE))) mkdir(dirname(DB_FILE), 0775, true);
    $pdo = new PDO('sqlite:' . DB_FILE);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    $pdo->exec('PRAGMA foreign_keys = ON');
    $pdo->exec("
        CREATE TABLE IF NOT EXISTS bills (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            amount REAL NOT NULL DEFAULT 0,
            category TEXT NOT NULL DEFAULT 'อื่นๆ',
            due_day INTEGER NOT NULL CHECK(due_day BETWEEN 1 AND 31),
            note TEXT DEFAULT '',
            active INTEGER NOT NULL DEFAULT 1,
            created_at TEXT DEFAULT (datetime('now','localtime'))
        );
        CREATE TABLE IF NOT EXISTS payments (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            bill_id INTEGER NOT NULL REFERENCES bills(id) ON DELETE CASCADE,
            month TEXT NOT NULL,
            amount REAL NOT NULL,
            paid_date TEXT NOT NULL,
            UNIQUE(bill_id, month)
        );
        CREATE TABLE IF NOT EXISTS bill_months (
            bill_id INTEGER NOT NULL REFERENCES bills(id) ON DELETE CASCADE,
            month TEXT NOT NULL,
            PRIMARY KEY (bill_id, month)
        );
        CREATE TABLE IF NOT EXISTS budgets (
            month TEXT PRIMARY KEY,
            amount REAL NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS savings (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            month TEXT NOT NULL,
            name TEXT NOT NULL,
            amount REAL NOT NULL DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS assets (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category TEXT NOT NULL DEFAULT 'อื่นๆ',
            value REAL NOT NULL DEFAULT 0,
            note TEXT DEFAULT '',
            updated_at TEXT DEFAULT (date('now','localtime'))
        );
        -- ประวัติมูลค่าทรัพย์สิน (ใช้ทำกราฟแนวโน้ม) วันละ 1 ค่า
        CREATE TABLE IF NOT EXISTS asset_history (
            asset_id INTEGER NOT NULL REFERENCES assets(id) ON DELETE CASCADE,
            date     TEXT NOT NULL,
            value    REAL NOT NULL,
            PRIMARY KEY (asset_id, date)
        );
    ");
    return $pdo;
}

function billInput(array $d): array {
    $name = trim((string)($d['name'] ?? ''));
    $amount = money($d['amount'] ?? null);
    $due = filter_var($d['due_day'] ?? null, FILTER_VALIDATE_INT, ['options' => ['min_range' => 1, 'max_range' => 31]]);
    if ($name === '' || $amount === false || $due === false) {
        out(['error' => 'ข้อมูลไม่ครบหรือไม่ถูกต้อง (ชื่อ, จำนวนเงิน, วันที่ 1-31)'], 400);
    }
    return [$name, $amount, (string)($d['category'] ?? 'อื่นๆ'), (int)$due, (string)($d['note'] ?? '')];
}
function monthsInput(array $d): array {
    $m = array_values(array_unique(array_filter((array)($d['months'] ?? []), 'validMonth')));
    if (!$m) out(['error' => 'กรุณาเลือกเดือนที่ต้องจ่ายอย่างน้อย 1 เดือน'], 400);
    sort($m);
    return $m;
}
function saveMonths(PDO $db, int $id, array $months): void {
    $db->prepare('DELETE FROM bill_months WHERE bill_id=?')->execute([$id]);
    $st = $db->prepare('INSERT INTO bill_months(bill_id, month) VALUES (?,?)');
    foreach ($months as $m) $st->execute([$id, $m]);
}
function billsForMonth(PDO $db, string $month): array {
    $st = $db->prepare("
        SELECT b.*, p.id AS payment_id, p.amount AS paid_amount, p.paid_date,
               (SELECT GROUP_CONCAT(month) FROM bill_months WHERE bill_id = b.id) AS months
        FROM bills b
        LEFT JOIN payments p ON p.bill_id = b.id AND p.month = :m
        WHERE b.active = 1
          AND ( EXISTS (SELECT 1 FROM bill_months bm WHERE bm.bill_id = b.id AND bm.month = :m)
                OR NOT EXISTS (SELECT 1 FROM bill_months bm WHERE bm.bill_id = b.id) )
        ORDER BY b.due_day, b.name");
    $st->execute([':m' => $month]);
    $rows = $st->fetchAll();
    foreach ($rows as &$r) {
        $r['id'] = (int)$r['id'];
        $r['amount'] = (float)$r['amount'];
        $r['due_day'] = (int)$r['due_day'];
        $r['payment_id'] = $r['payment_id'] !== null ? (int)$r['payment_id'] : null;
        $r['paid_amount'] = $r['paid_amount'] !== null ? (float)$r['paid_amount'] : null;
        $r['months'] = $r['months'] ? explode(',', $r['months']) : [];
    }
    return $rows;
}
function yearLike(): string {
    return sprintf('%04d', (int)($_GET['year'] ?? date('Y'))) . '-%';
}

/* ===================== Router ===================== */
try {
    $db = getDb();
    $method = $_SERVER['REQUEST_METHOD'];
    $action = $_GET['action'] ?? '';

    switch ("$method $action") {

        /* ----- รายจ่าย ----- */
        case 'GET year':
            $y = (int)($_GET['year'] ?? date('Y'));
            $res = [];
            for ($m = 1; $m <= 12; $m++) {
                $k = sprintf('%04d-%02d', $y, $m);
                $res[] = ['month' => $k, 'bills' => billsForMonth($db, $k)];
            }
            out($res);

        case 'GET bills':
            $m = $_GET['month'] ?? date('Y-m');
            if (!validMonth($m)) out(['error' => 'month ต้องเป็น YYYY-MM'], 400);
            out(billsForMonth($db, $m));

        case 'POST bills':
            $d = body(); $bill = billInput($d); $months = monthsInput($d);
            $db->beginTransaction();
            $db->prepare('INSERT INTO bills(name,amount,category,due_day,note) VALUES (?,?,?,?,?)')->execute($bill);
            $id = (int)$db->lastInsertId();
            saveMonths($db, $id, $months);
            $db->commit();
            out(['id' => $id], 201);

        case 'PUT bills':
            $id = (int)($_GET['id'] ?? 0);
            $d = body(); $bill = billInput($d); $months = monthsInput($d);
            $db->beginTransaction();
            $db->prepare('UPDATE bills SET name=?, amount=?, category=?, due_day=?, note=? WHERE id=?')->execute([...$bill, $id]);
            saveMonths($db, $id, $months);
            $db->commit();
            out(['ok' => true]);

        case 'DELETE bills':
            $db->prepare('DELETE FROM bills WHERE id=?')->execute([(int)($_GET['id'] ?? 0)]);
            out(['ok' => true]);

        case 'DELETE bill_month':
            $id = (int)($_GET['bill_id'] ?? 0);
            $m = $_GET['month'] ?? '';
            if (!validMonth($m)) out(['error' => 'month ไม่ถูกต้อง'], 400);
            $cnt = $db->prepare('SELECT COUNT(*) FROM bill_months WHERE bill_id=?');
            $db->beginTransaction();
            $cnt->execute([$id]);
            if ((int)$cnt->fetchColumn() === 0) {          // ข้อมูลเก่า (ทุกเดือน)
                $y = (int)substr($m, 0, 4);
                $st = $db->prepare('INSERT INTO bill_months(bill_id, month) VALUES (?,?)');
                for ($i = 1; $i <= 12; $i++) {
                    $k = sprintf('%04d-%02d', $y, $i);
                    if ($k !== $m) $st->execute([$id, $k]);
                }
            } else {
                $db->prepare('DELETE FROM bill_months WHERE bill_id=? AND month=?')->execute([$id, $m]);
            }
            $db->prepare('DELETE FROM payments WHERE bill_id=? AND month=?')->execute([$id, $m]);
            $cnt->execute([$id]);
            if ((int)$cnt->fetchColumn() === 0) $db->prepare('DELETE FROM bills WHERE id=?')->execute([$id]);
            $db->commit();
            out(['ok' => true]);

        /* ----- การจ่าย ----- */
        case 'POST payments':
            $d = body();
            $amount = money($d['amount'] ?? null);
            if (!validMonth($d['month'] ?? null) || empty($d['bill_id']) || $amount === false) {
                out(['error' => 'ข้อมูลการจ่ายไม่ถูกต้อง'], 400);
            }
            $db->prepare('INSERT OR REPLACE INTO payments(bill_id,month,amount,paid_date) VALUES (?,?,?,?)')
               ->execute([(int)$d['bill_id'], $d['month'], $amount, $d['paid_date'] ?? date('Y-m-d')]);
            out(['ok' => true], 201);

        case 'DELETE payments':
            $db->prepare('DELETE FROM payments WHERE bill_id=? AND month=?')
               ->execute([(int)($_GET['bill_id'] ?? 0), $_GET['month'] ?? '']);
            out(['ok' => true]);

        /* ----- รายรับ ----- */
        case 'GET budget':
            $st = $db->prepare('SELECT month, amount FROM budgets WHERE month LIKE ? ORDER BY month');
            $st->execute([yearLike()]);
            $rows = $st->fetchAll();
            foreach ($rows as &$r) $r['amount'] = (float)$r['amount'];
            out($rows);

        case 'POST budget':
            $d = body();
            $amount = money($d['amount'] ?? null);
            if (!validMonth($d['month'] ?? null) || $amount === false) out(['error' => 'ยอดเงินไม่ถูกต้อง'], 400);
            $st = $db->prepare('INSERT OR REPLACE INTO budgets(month, amount) VALUES (?,?)');
            $st->execute([$d['month'], $amount]);
            if (!empty($d['apply_rest_of_year'])) {
                [$y, $mm] = array_map('intval', explode('-', $d['month']));
                for ($i = $mm + 1; $i <= 12; $i++) $st->execute([sprintf('%04d-%02d', $y, $i), $amount]);
            }
            out(['ok' => true]);

        /* ----- เงินเก็บ ----- */
        case 'GET savings':
            $st = $db->prepare('SELECT id, month, name, amount FROM savings WHERE month LIKE ? ORDER BY month, id');
            $st->execute([yearLike()]);
            $rows = $st->fetchAll();
            foreach ($rows as &$r) { $r['id'] = (int)$r['id']; $r['amount'] = (float)$r['amount']; }
            out($rows);

        case 'POST savings':
            $d = body();
            $name = trim((string)($d['name'] ?? ''));
            $amount = money($d['amount'] ?? null);
            if (!validMonth($d['month'] ?? null) || $name === '' || $amount === false) out(['error' => 'ข้อมูลเงินเก็บไม่ถูกต้อง'], 400);
            if (!empty($d['id'])) {
                $db->prepare('UPDATE savings SET name=?, amount=? WHERE id=?')->execute([$name, $amount, (int)$d['id']]);
            } else {
                $db->prepare('INSERT INTO savings(month, name, amount) VALUES (?,?,?)')->execute([$d['month'], $name, $amount]);
            }
            out(['ok' => true], 201);

        case 'DELETE savings':
            $db->prepare('DELETE FROM savings WHERE id=?')->execute([(int)($_GET['id'] ?? 0)]);
            out(['ok' => true]);

        /* ----- ทรัพย์สิน ----- */
        case 'GET assets':
            $assets = $db->query('SELECT * FROM assets ORDER BY value DESC, id')->fetchAll();
            foreach ($assets as &$a) { $a['id'] = (int)$a['id']; $a['value'] = (float)$a['value']; }
            unset($a);
            // เงินเก็บสะสมทุกปี แยกตามชื่อ
            $sav = $db->query("SELECT name, SUM(amount) AS total, COUNT(*) AS months,
                                      MIN(month) AS first_month, MAX(month) AS last_month
                               FROM savings GROUP BY name ORDER BY total DESC")->fetchAll();
            foreach ($sav as &$s) { $s['total'] = (float)$s['total']; $s['months'] = (int)$s['months']; }
            unset($s);
            $hist = $db->query('SELECT month, name, amount FROM savings ORDER BY month DESC, id DESC')->fetchAll();
            foreach ($hist as &$h) $h['amount'] = (float)$h['amount'];
            // ประวัติมูลค่า (ถ้ายังไม่มี ใช้ค่าปัจจุบัน ณ วันอัปเดตล่าสุด)
            $ah = $db->query('SELECT asset_id, date, value FROM asset_history ORDER BY date')->fetchAll();
            foreach ($ah as &$h) { $h['asset_id'] = (int)$h['asset_id']; $h['value'] = (float)$h['value']; }
            unset($h);
            $has = array_flip(array_column($ah, 'asset_id'));
            foreach ($assets as $a) {
                if (!isset($has[$a['id']])) $ah[] = ['asset_id' => $a['id'], 'date' => $a['updated_at'], 'value' => $a['value']];
            }
            // รายจ่ายเฉลี่ยต่อเดือน (12 เดือนล่าสุดที่มีการจ่าย)
            $avgExp = (float)$db->query("SELECT AVG(t) FROM (SELECT month, SUM(amount) t FROM payments GROUP BY month ORDER BY month DESC LIMIT 12)")->fetchColumn();
            out(['assets' => $assets, 'savings' => $sav, 'history' => $hist, 'asset_history' => $ah, 'avg_expense' => $avgExp]);

        case 'POST assets':
            $d = body();
            $name = trim((string)($d['name'] ?? ''));
            $value = money($d['value'] ?? null);
            if ($name === '' || $value === false) out(['error' => 'กรุณาใส่ชื่อและมูลค่าให้ถูกต้อง'], 400);
            $cat = (string)($d['category'] ?? 'อื่นๆ');
            $note = (string)($d['note'] ?? '');
            if (!empty($d['id'])) {
                $id = (int)$d['id'];
                $db->prepare("UPDATE assets SET name=?, category=?, value=?, note=?, updated_at=date('now','localtime') WHERE id=?")
                   ->execute([$name, $cat, $value, $note, $id]);
            } else {
                $db->prepare('INSERT INTO assets(name, category, value, note) VALUES (?,?,?,?)')->execute([$name, $cat, $value, $note]);
                $id = (int)$db->lastInsertId();
            }
            $db->prepare("INSERT OR REPLACE INTO asset_history(asset_id, date, value) VALUES (?, date('now','localtime'), ?)")
               ->execute([$id, $value]);
            out(['ok' => true], 201);

        case 'DELETE assets':
            $db->prepare('DELETE FROM assets WHERE id=?')->execute([(int)($_GET['id'] ?? 0)]);
            out(['ok' => true]);

        default:
            out(['error' => 'not found'], 404);
    }
} catch (Throwable $e) {
    if (isset($db) && $db->inTransaction()) $db->rollBack();
    out(['error' => 'Server error: ' . $e->getMessage()], 500);
}
