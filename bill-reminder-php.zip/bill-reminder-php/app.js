/* ===== Bill Reminder - Frontend (PHP API + SweetAlert2) ===== */
const SOON_DAYS = 3;
const TH_MONTHS = ["มกราคม","กุมภาพันธ์","มีนาคม","เมษายน","พฤษภาคม","มิถุนายน",
                   "กรกฎาคม","สิงหาคม","กันยายน","ตุลาคม","พฤศจิกายน","ธันวาคม"];
const TH_SHORT = ["ม.ค.","ก.พ.","มี.ค.","เม.ย.","พ.ค.","มิ.ย.","ก.ค.","ส.ค.","ก.ย.","ต.ค.","พ.ย.","ธ.ค."];
const COLOR = { green: "#16a34a", red: "#ef4444", gray: "#94a3b8", blue: "#4f46e5" };
const SVG_MOON = '<svg viewBox="0 0 24 24"><path d="M20.4 14.5A8.5 8.5 0 1 1 9.5 3.6a7 7 0 0 0 10.9 10.9Z"/></svg>';
const SVG_SUN = '<svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg>';

// หมวดทรัพย์สิน
const ASSET_CATS_BASE = {
  "เงินสด":               { icon: "💵", color: "#22c55e", cash: true, liq: 1 },
  "บัญชีธนาคาร":          { icon: "🏧", color: "#0ea5e9", cash: true, liq: 1 },
  "เงินฝากประจำ":         { icon: "🏦", color: "#06b6d4", liq: 2 },
  "หุ้น":                 { icon: "📈", color: "#8b5cf6", liq: 2 },
  "กองทุนรวม":            { icon: "📊", color: "#a855f7", liq: 2 },
  "กองทุนลดหย่อนภาษี":     { icon: "🧾", color: "#6366f1", liq: 3 },
  "คริปโต":               { icon: "🪙", color: "#f59e0b", liq: 2 },
  "ทองคำ":               { icon: "🥇", color: "#eab308", liq: 2 },
  "พันธบัตร / สลากออมสิน": { icon: "📜", color: "#14b8a6", liq: 2 },
  "ประกันชีวิต (มูลค่าเวนคืน)": { icon: "🛡️", color: "#3b82f6", liq: 3 },
  "กองทุนสำรองเลี้ยงชีพ / ประกันสังคม": { icon: "👴", color: "#0284c7", liq: 3 },
  "เงินให้ยืม (ลูกหนี้)":    { icon: "🤝", color: "#ec4899", liq: 3 },
  "อสังหาริมทรัพย์":       { icon: "🏠", color: "#f97316", liq: 3 },
  "ยานพาหนะ":            { icon: "🚗", color: "#64748b", liq: 3 },
  "ของสะสม / ของมีค่า":    { icon: "💎", color: "#d946ef", liq: 3 },
  "อื่นๆ":                 { icon: "📦", color: "#94a3b8", liq: 2 },
};
// ประเภทเดิม (เวอร์ชันก่อน) → map ให้ยังแสดงถูก
const LEGACY_CATS = { "หุ้น / กองทุน": "หุ้น" };
const PALETTE = ["#0ea5e9","#f43f5e","#84cc16","#a16207","#7c3aed","#059669","#db2777","#ea580c"];
let customCats = JSON.parse(localStorage.getItem("customCats") || "{}");   // ประเภทที่ผู้ใช้สร้างเอง
const ASSET_CATS = new Proxy({}, {
  get: (_, k) => ASSET_CATS_BASE[k] || ASSET_CATS_BASE[LEGACY_CATS[k]] || customCats[k],
  ownKeys: () => [...Object.keys(ASSET_CATS_BASE), ...Object.keys(customCats)],
  getOwnPropertyDescriptor: () => ({ enumerable: true, configurable: true }),
});
const catOf = (name) => (ASSET_CATS[name] ? name : LEGACY_CATS[name] || "อื่นๆ");
const SAVING_COLOR = "#16a34a";

/* ---------- State ---------- */
let year = new Date().getFullYear();
let page = ["calendar", "savings", "assets"].includes(location.hash.slice(1)) ? location.hash.slice(1) : "calendar";
let filter = "all";
let months = [];        // [{month, bills}]
let entries = {};       // "id|YYYY-MM" → bill
let budgets = {};       // "YYYY-MM" → รายรับ
let savingsData = {};   // "YYYY-MM" → [{id,name,amount}]
let assetsData = { assets: [], savings: [], history: [] };
let savingGoal = +(localStorage.getItem("savingGoal") || 20);

/* ---------- Utils ---------- */
const $ = (s) => document.querySelector(s);
const fmt = (n) => "฿" + Number(n).toLocaleString("th-TH", { maximumFractionDigits: 2 });
const sfmt = (n) => (n < 0 ? "-" : "") + fmt(Math.abs(n));
const pad = (n) => String(n).padStart(2, "0");
const monthKey = (d) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}`;
const thMonth = (mk) => { const [y, m] = mk.split("-").map(Number); return `${TH_MONTHS[m - 1]} ${y + 543}`; };
const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;" }[c]));
const amountOf = (b) => (b.payment_id ? b.paid_amount : b.amount);
const allBills = () => months.flatMap((mo) => mo.bills);
const savedOf = (mk) => (savingsData[mk] || []).reduce((s, x) => s + x.amount, 0);
const expOf = (mk) => (months.find((m) => m.month === mk)?.bills || []).reduce((s, b) => s + amountOf(b), 0);
const pctClass = (p) => (p >= savingGoal ? "good" : p >= 0 ? "mid" : "bad");

async function api(url, method = "GET", body) {
  const res = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: body ? JSON.stringify(body) : undefined });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "เกิดข้อผิดพลาด");
  return data;
}

const Toast = Swal.mixin({ toast: true, position: "top-end", showConfirmButton: false, timer: 2200, timerProgressBar: true });
const toast = (msg, icon = "success") => Toast.fire({ icon, title: msg });
const showError = (msg) => Swal.fire({ icon: "error", title: "เกิดข้อผิดพลาด", text: msg });
async function confirmBox(title, html, okText = "ยืนยัน", icon = "warning") {
  const r = await Swal.fire({ title, html, icon, showCancelButton: true, reverseButtons: true,
    confirmButtonText: okText, cancelButtonText: "ยกเลิก", confirmButtonColor: COLOR.red, cancelButtonColor: COLOR.gray, focusCancel: true });
  return r.isConfirmed;
}

/* ---------- สถานะรายจ่าย ---------- */
function getStatus(bill, mk) {
  const [y, m] = mk.split("-").map(Number);
  const due = new Date(y, m - 1, Math.min(bill.due_day, new Date(y, m, 0).getDate()));
  if (bill.payment_id) return { key: "paid", text: "จ่ายแล้ว", due };
  const today = new Date(); today.setHours(0, 0, 0, 0);
  const diff = Math.round((due - today) / 86400000);
  if (diff < 0) return { key: "overdue", text: `เลยกำหนด ${-diff} วัน`, due };
  if (diff === 0) return { key: "soon", text: "ครบกำหนดวันนี้!", due };
  if (diff <= SOON_DAYS) return { key: "soon", text: `อีก ${diff} วัน`, due };
  return { key: "upcoming", text: `อีก ${diff} วัน`, due };
}

/* ================= โหลดข้อมูล ================= */
async function reloadSavings() {
  savingsData = {};
  (await api(`api.php?action=savings&year=${year}`)).forEach((r) => (savingsData[r.month] ||= []).push(r));
}
async function reloadAssets() { assetsData = Object.assign({ assets: [], savings: [], history: [], asset_history: [], avg_expense: 0 }, await api("api.php?action=assets")); }

async function load() {
  $("#yearLabel").textContent = `ปี ${year + 543}`;
  try {
    const [ym, bg] = await Promise.all([
      api(`api.php?action=year&year=${year}`),
      api(`api.php?action=budget&year=${year}`),
      reloadSavings(),
      reloadAssets(),
    ]);
    months = ym;
    budgets = Object.fromEntries(bg.map((r) => [r.month, r.amount]));
    entries = {};
    months.forEach((mo) => mo.bills.forEach((b) => {
      b._month = mo.month;
      b.status = getStatus(b, mo.month);
      entries[`${b.id}|${mo.month}`] = b;
    }));
    render();
  } catch (e) {
    console.error(e);
    $("#yearView").innerHTML = `<div class="empty" style="grid-column:1/-1">⚠️ เชื่อมต่อเซิร์ฟเวอร์ไม่ได้ — ตรวจสอบว่าเปิด PHP server และเปิดใช้ pdo_sqlite แล้ว</div>`;
  }
}

/* ================= Render ================= */
function render() {
  ["calendar", "savings", "assets"].forEach((p) => ($(`#${p}Page`).hidden = p !== page));
  document.querySelectorAll(".nav-link").forEach((a) => a.classList.toggle("active", a.dataset.page === page));
  $("#yearNav").hidden = page === "assets";
  $("#addBtn .add-text").textContent = page === "assets" ? "เพิ่มทรัพย์สิน" : "เพิ่มรายการ";
  renderHeader();
  if (page === "calendar") { renderSummary(); renderAlerts(); renderYear(); }
  if (page === "savings") renderSavings();
  if (page === "assets") renderAssets();
  requestAnimationFrame(countUp);
}

/* ---------- Header / โปรไฟล์ / แจ้งเตือน ---------- */
let userName = localStorage.getItem("userName") || "ผู้ใช้งาน";
function renderHeader() {
  const initial = (userName.trim()[0] || "B").toUpperCase();
  const photo = localStorage.getItem("userPhoto");
  ["#avatarBig", "#avatarSmall"].forEach((id) => {
    const el = $(id);
    el.classList.toggle("has-photo", !!photo);
    el.style.backgroundImage = photo ? `url(${photo})` : "";
    el.textContent = photo ? "" : initial;
  });
  $("#userName").textContent = userName;
  $("#userSub").textContent = new Date().toLocaleDateString("th-TH", { weekday: "long", day: "numeric", month: "long" });
  $("#pageTitle").textContent = `ยินดีต้อนรับกลับมา, ${userName}!`;
  const list = allBills();
  const od = list.filter((b) => b.status?.key === "overdue").length;
  const sn = list.filter((b) => b.status?.key === "soon").length;
  ["#bellCount", "#bellCount2"].forEach((id) => { $(id).textContent = od + sn; $(id).hidden = !(od + sn); });
}
/* ---------- รูปโปรไฟล์ ---------- */
function resizeImage(file, size = 256) {
  return new Promise((resolve, reject) => {
    const img = new Image();
    img.onload = () => {
      const c = document.createElement("canvas");
      c.width = c.height = size;
      const s = Math.min(img.width, img.height);             // ครอปเป็นสี่เหลี่ยมจัตุรัสตรงกลาง
      c.getContext("2d").drawImage(img, (img.width - s) / 2, (img.height - s) / 2, s, s, 0, 0, size, size);
      URL.revokeObjectURL(img.src);
      resolve(c.toDataURL("image/jpeg", 0.85));
    };
    img.onerror = reject;
    img.src = URL.createObjectURL(file);
  });
}
async function changePhoto() {
  const has = !!localStorage.getItem("userPhoto");
  const r = await Swal.fire({
    title: "รูปโปรไฟล์",
    html: `<div class="pf-preview" style="${has ? `background-image:url(${localStorage.getItem("userPhoto")})` : ""}">${has ? "" : esc((userName.trim()[0] || "B").toUpperCase())}</div>`,
    showDenyButton: has, showCancelButton: true, reverseButtons: true,
    confirmButtonText: "📷 เลือกรูปใหม่", denyButtonText: "ลบรูป", cancelButtonText: "ปิด",
    confirmButtonColor: COLOR.blue, denyButtonColor: COLOR.red, cancelButtonColor: COLOR.gray,
  });
  if (r.isConfirmed) $("#avatarFile").click();
  if (r.isDenied) { localStorage.removeItem("userPhoto"); renderHeader(); toast("ลบรูปโปรไฟล์แล้ว"); }
}

async function editName() {
  const { value } = await Swal.fire({
    title: "ชื่อของคุณ", html: `<div class="swal-form"><input id="swName" value="${esc(userName)}" maxlength="30"></div>`,
    showCancelButton: true, reverseButtons: true, confirmButtonText: "บันทึก", cancelButtonText: "ยกเลิก",
    confirmButtonColor: COLOR.blue, cancelButtonColor: COLOR.gray,
    didOpen: () => $("#swName").select(), preConfirm: () => $("#swName").value.trim() || "ผู้ใช้งาน",
  });
  if (!value) return;
  userName = value; localStorage.setItem("userName", value); renderHeader();
}
function showNotifications() {
  const urgent = allBills().filter((b) => ["overdue", "soon"].includes(b.status.key));
  Swal.fire({
    title: "🔔 การแจ้งเตือน", width: 520,
    html: urgent.length ? `<div class="day-list">${urgent.map((b) => `
      <div class="day-item ${b.status.key}"><div class="t"><b>${esc(b.name)}</b><small>${thMonth(b._month)} · ${b.status.text}</small></div>
      <span class="amt">${fmt(b.amount)}</span></div>`).join("")}</div>` : `<div class="mempty">ไม่มีรายการที่ต้องระวัง 🎉</div>`,
    confirmButtonText: "ปิด", confirmButtonColor: COLOR.gray,
  });
}

/* ---------- ทักทาย + วันที่ ---------- */
function greet() {
  const h = new Date().getHours();
  const g = h < 12 ? "อรุณสวัสดิ์ ☀️" : h < 17 ? "สวัสดีตอนบ่าย 🌤️" : "สวัสดีตอนเย็น 🌙";
  return `${g} ${new Date().toLocaleDateString("th-TH", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}`;
}

/* ---------- ตัวเลขวิ่ง (count-up) ---------- */
function countUp() {
  const els = document.querySelectorAll(".page:not([hidden]) .value");
  els.forEach((el) => {
    const txt = el.textContent.trim();
    const m = txt.match(/^(-?)฿([\d,]+(?:\.\d+)?)$/);
    if (!m) return;
    const target = parseFloat(m[2].replace(/,/g, "")) * (m[1] ? -1 : 1);
    if (el.dataset.shown === txt) return;              // ค่าเดิม ไม่ต้องวิ่งใหม่
    el.dataset.shown = txt;
    const start = performance.now(), dur = 700;
    const step = (t) => {
      const k = Math.min(1, (t - start) / dur), e = 1 - Math.pow(1 - k, 3);
      el.textContent = sfmt(Math.round(target * e));
      if (k < 1) requestAnimationFrame(step); else el.textContent = txt;
    };
    requestAnimationFrame(step);
  });
}

/* ---------- โหมดมืด / สว่าง ---------- */
function applyTheme(t) {
  document.documentElement.dataset.theme = t;
  localStorage.setItem("theme", t);
  const ico = t === "dark" ? SVG_SUN : SVG_MOON;
  $("#themeIco").innerHTML = ico;
  $("#themeBtn2").innerHTML = ico;
  document.querySelector('meta[name="theme-color"]').content = t === "dark" ? "#0f172a" : "#111827";
}
const toggleTheme = () => {
  applyTheme(document.documentElement.dataset.theme === "dark" ? "light" : "dark");
  if (page === "assets") renderAnalysis();
};

function applyFilter(list) {
  const q = $("#search").value.trim().toLowerCase();
  return list.filter((b) => {
    if (q && !b.name.toLowerCase().includes(q)) return false;
    if (filter === "all") return true;
    if (filter === "pending") return !b.payment_id;
    return b.status.key === filter;
  });
}

/* ---------- ปฏิทินรายจ่าย ---------- */
function renderSummary() {
  const list = allBills();
  const total = list.reduce((s, b) => s + b.amount, 0);
  const paidList = list.filter((b) => b.payment_id);
  const paid = paidList.reduce((s, b) => s + b.paid_amount, 0);
  const pct = total ? Math.min(100, Math.round((paid / total) * 100)) : 0;

  const card = $("#balanceCard");
  const vals = Object.values(budgets);
  card.classList.remove("negative", "unset");
  if (!vals.length) {
    card.classList.add("unset");
    $("#sumBalance").textContent = "ยังไม่ได้ตั้ง";
    $("#balanceSub").textContent = "คลิกเพื่อตั้งรายรับ";
  } else {
    const bal = vals.reduce((a, b) => a + b, 0) - paid;
    if (bal < 0) card.classList.add("negative");
    $("#sumBalance").textContent = sfmt(bal);
    $("#balanceSub").innerHTML = `รายรับทั้งปี: <b>${fmt(vals.reduce((a, b) => a + b, 0))}</b>`;
  }
  $("#sumPaid").textContent = fmt(paid);
  $("#sumRemain").textContent = fmt(Math.max(0, total - paid));
  $("#progressText").textContent = pct + "%";
  $("#progressBar").style.width = pct + "%";
  $("#countText").textContent = `${paidList.length} / ${list.length} รายการ`;
  $("#paidCount").textContent = paidList.length;
  $("#overdueCount").textContent = list.filter((b) => b.status.key === "overdue").length;
}

function renderAlerts() {
  const list = allBills();
  const overdue = list.filter((b) => b.status.key === "overdue");
  const soon = list.filter((b) => b.status.key === "soon");
  const label = (b) => `${esc(b.name)} (${TH_SHORT[+b._month.slice(5) - 1]})`;
  let html = "";
  if (overdue.length) html += `<div class="alert danger"><span class="ico">🚨</span><div><b>เลยกำหนดชำระ ${overdue.length} รายการ</b> (${fmt(overdue.reduce((s, b) => s + b.amount, 0))}) — ${overdue.map(label).join(", ")}</div></div>`;
  if (soon.length) html += `<div class="alert warn"><span class="ico">⏰</span><div><b>ใกล้ครบกำหนดภายใน ${SOON_DAYS} วัน</b> — ${soon.map((b) => `${label(b)} ${b.status.text}`).join(", ")}</div></div>`;
  $("#alerts").innerHTML = html;
}

function renderTabs() {
  const list = allBills();
  const count = {
    all: list.length,
    overdue: list.filter((b) => b.status.key === "overdue").length,
    soon: list.filter((b) => b.status.key === "soon").length,
    pending: list.filter((b) => !b.payment_id).length,
    paid: list.filter((b) => b.payment_id).length,
  };
  const labels = { all: "ทั้งหมด", overdue: "เลยกำหนด", soon: "ใกล้ครบกำหนด", pending: "ยังไม่จ่าย", paid: "จ่ายแล้ว" };
  document.querySelectorAll(".tab").forEach((t) => {
    t.classList.toggle("active", t.dataset.filter === filter);
    t.innerHTML = `${labels[t.dataset.filter]} <span class="badge">${count[t.dataset.filter]}</span>`;
  });
}

function renderYear() {
  const nowKey = monthKey(new Date());
  $("#yearView").innerHTML = months.map((mo) => {
    const list = applyFilter(mo.bills);
    const unpaid = list.filter((b) => !b.payment_id);
    const due = unpaid.reduce((s, b) => s + b.amount, 0);
    let state = "none", amt = `<span class="cal-amt muted">—</span>`;
    if (list.length && !unpaid.length) { state = "done"; amt = `<span class="cal-amt done">✓ จ่ายครบ</span>`; }
    else if (unpaid.length) {
      state = unpaid.some((b) => b.status.key === "overdue") ? "overdue" : unpaid.some((b) => b.status.key === "soon") ? "soon" : "due";
      amt = `<span class="cal-amt">${fmt(due)}</span>`;
    }
    const isNow = mo.month === nowKey;
    return `<button class="cal-month ${state} ${isNow ? "now" : ""} ${mo.month < nowKey ? "past" : ""}" data-month="${mo.month}">
      <span class="nm">${TH_MONTHS[+mo.month.slice(5) - 1]}${isNow ? `<i class="tag">เดือนนี้</i>` : ""}</span>
      ${amt}
      ${state === "overdue" ? `<span class="cal-flag">🚨 เลยกำหนด</span>` : state === "soon" ? `<span class="cal-flag">⏰ ใกล้ครบกำหนด</span>` : ""}
    </button>`;
  }).join("");
}

async function openMonth(mk) {
  const list = applyFilter(months.find((x) => x.month === mk)?.bills || []);
  const total = list.reduce((s, b) => s + b.amount, 0);
  const paid = list.filter((b) => b.payment_id).reduce((s, b) => s + b.paid_amount, 0);
  const due = list.filter((b) => !b.payment_id).reduce((s, b) => s + b.amount, 0);
  const r = await Swal.fire({
    title: `📅 ${thMonth(mk)}`, width: 580,
    html: list.length ? `
      <div class="pop-sum">
        <div><span>ทั้งหมด</span><b>${fmt(total)}</b></div>
        <div class="g"><span>จ่ายแล้ว</span><b>${fmt(paid)}</b></div>
        <div class="r"><span>ต้องจ่าย</span><b>${fmt(due)}</b></div>
      </div>
      <div class="day-list">${list.map((b) => `
        <div class="day-item ${b.status.key}">
          <div class="t"><b class="edit-link" data-edit="${b.id}|${mk}" title="คลิกเพื่อแก้ไข">${esc(b.name)}</b><small>วันที่ ${b.due_day} · ${b.status.text}</small></div>
          <span class="amt">${fmt(amountOf(b))}</span>
          ${b.payment_id
            ? `<button class="btn unpay sm" data-unpay="${b.id}|${mk}">ยกเลิกจ่าย</button>`
            : `<button class="btn pay sm" data-pay="${b.id}|${mk}">จ่าย</button>
               <button class="btn cancel sm" data-cancel="${b.id}|${mk}">ยกเลิก</button>`}
        </div>`).join("")}</div>`
      : `<div class="mempty">เดือนนี้ไม่มีรายจ่าย</div>`,
    confirmButtonText: "+ เพิ่มรายจ่ายเดือนนี้", confirmButtonColor: COLOR.blue, showCloseButton: true,
    didOpen: (popup) => {
      popup.querySelector(".swal2-html-container").onclick = (e) => {
        const g = (a) => e.target.closest(`[data-${a}]`)?.dataset[a];
        if (g("pay")) markPaid(entries[g("pay")]);
        if (g("unpay")) unPaid(entries[g("unpay")]);
        if (g("cancel")) cancelBill(entries[g("cancel")]);
        if (g("edit")) { Swal.close(); openDialog(entries[g("edit")]); }
      };
    },
  });
  if (r.isConfirmed) openDialog(null, mk);
}

async function markPaid(b) {
  const dueText = b.status.due.toLocaleDateString("th-TH", { day: "numeric", month: "short", year: "numeric" });
  const { value } = await Swal.fire({
    title: "ยืนยันการชำระเงิน", icon: "question",
    html: `<div>รายการ <b>${esc(b.name)}</b> · ${thMonth(b._month)}</div>
      <div class="swal-form">
        <div class="info"><div><span>ยอดที่ตั้งไว้</span><b>${fmt(b.amount)}</b></div><div><span>ครบกำหนด</span><b>${dueText}</b></div></div>
        <label>ยอดที่จ่ายจริง (บาท)<input id="swAmt" class="big green" type="number" min="0" step="0.01" value="${b.amount}"></label>
        <label>วันที่จ่าย<input id="swDate" type="date" value="${new Date().toLocaleDateString("sv-SE")}"></label>
      </div>`,
    showCancelButton: true, reverseButtons: true, confirmButtonText: "ยืนยันจ่าย", cancelButtonText: "ยกเลิก",
    confirmButtonColor: COLOR.green, cancelButtonColor: COLOR.gray,
    didOpen: () => $("#swAmt").select(),
    preConfirm: () => {
      const amount = parseFloat($("#swAmt").value), paid_date = $("#swDate").value;
      if (isNaN(amount) || amount < 0) return Swal.showValidationMessage("กรุณาใส่จำนวนเงินให้ถูกต้อง");
      if (!paid_date) return Swal.showValidationMessage("กรุณาเลือกวันที่จ่าย");
      return { amount, paid_date };
    },
  });
  if (!value) return;
  try {
    await api("api.php?action=payments", "POST", { bill_id: b.id, month: b._month, ...value });
    Swal.fire({ icon: "success", title: "บันทึกเรียบร้อย", html: `จ่าย <b>${esc(b.name)}</b> จำนวน <b>${fmt(value.amount)}</b> แล้ว`, timer: 1800, showConfirmButton: false });
    load();
  } catch (err) { showError(err.message); }
}

async function unPaid(b) {
  if (!(await confirmBox("ยกเลิกสถานะจ่ายแล้ว?", `รายการ <b>${esc(b.name)}</b> (${thMonth(b._month)}) จะกลับเป็น "ยังไม่จ่าย"`, "ใช่, ยกเลิกการจ่าย"))) return;
  try { await api(`api.php?action=payments&bill_id=${b.id}&month=${b._month}`, "DELETE"); toast("ยกเลิกสถานะจ่ายแล้ว"); load(); }
  catch (err) { showError(err.message); }
}

async function cancelBill(b) {
  const r = await Swal.fire({
    title: "ยกเลิกรายจ่ายนี้?", html: `<b>${esc(b.name)}</b> · ${fmt(b.amount)}<br>${thMonth(b._month)}`, icon: "warning",
    showDenyButton: true, showCancelButton: true,
    confirmButtonText: "ยกเลิกเฉพาะเดือนนี้", denyButtonText: "ลบทุกเดือน", cancelButtonText: "ปิด",
    confirmButtonColor: COLOR.red, denyButtonColor: "#7f1d1d", cancelButtonColor: COLOR.gray,
  });
  try {
    if (r.isConfirmed) { await api(`api.php?action=bill_month&bill_id=${b.id}&month=${b._month}`, "DELETE"); toast(`ยกเลิก "${b.name}" เดือน${TH_MONTHS[+b._month.slice(5) - 1]}แล้ว`); }
    else if (r.isDenied) { await api(`api.php?action=bills&id=${b.id}`, "DELETE"); toast(`ลบ "${b.name}" ทุกเดือนแล้ว`); }
    else return;
    load();
  } catch (err) { showError(err.message); }
}

/* ---------- ฟอร์มรายจ่าย + เลือกเดือน ---------- */
let picked = new Set(), pickYear = year, editing = null;
function renderPicker() {
  $("#mpYear").textContent = pickYear + 543;
  $("#mpGrid").innerHTML = TH_SHORT.map((n, i) => {
    const mk = `${pickYear}-${pad(i + 1)}`;
    return `<button type="button" class="mchip ${picked.has(mk) ? "on" : ""}" data-mk="${mk}">${n}</button>`;
  }).join("");
  const inYear = [...picked].filter((k) => k.startsWith(pickYear + "-")).length;
  const other = picked.size - inYear;
  $("#mpCount").textContent = `เลือก ${inYear} เดือน` + (other ? ` (+${other} เดือนในปีอื่น)` : "");
}
function openDialog(bill, presetMonth) {
  editing = bill;
  $("#dialogTitle").textContent = bill ? "แก้ไขรายการ" : "เพิ่มรายการค่าใช้จ่าย";
  $("#billId").value = bill?.id ?? "";
  $("#fName").value = bill?.name ?? "";
  $("#fAmount").value = bill?.amount ?? "";
  $("#fDueDay").value = bill?.due_day ?? "";
  $("#deleteBtn").style.display = bill ? "" : "none";
  const now = new Date();
  const base = presetMonth || bill?._month || (now.getFullYear() === year ? monthKey(now) : `${year}-01`);
  pickYear = +base.slice(0, 4);
  if (bill) {
    picked = new Set(bill.months || []);
    if (!picked.size) for (let i = 1; i <= 12; i++) picked.add(`${pickYear}-${pad(i)}`);
  } else picked = new Set([base]);
  renderPicker();
  $("#billDialog").showModal();
}
async function saveBill(e) {
  e.preventDefault();
  if (!picked.size) {
    $("#billDialog").close();
    await Swal.fire({ icon: "warning", title: "กรุณาเลือกเดือนที่ต้องจ่าย", text: "อย่างน้อย 1 เดือน" });
    return $("#billDialog").showModal();
  }
  const id = $("#billId").value;
  const body = { name: $("#fName").value, amount: $("#fAmount").value, due_day: $("#fDueDay").value,
    category: editing?.category ?? "อื่นๆ", note: editing?.note ?? "", months: [...picked].sort() };
  try {
    if (id) await api(`api.php?action=bills&id=${id}`, "PUT", body);
    else await api("api.php?action=bills", "POST", body);
    $("#billDialog").close();
    toast(id ? "แก้ไขเรียบร้อย" : `เพิ่มรายการ ${picked.size} เดือนเรียบร้อย`);
    load();
  } catch (err) { $("#billDialog").close(); showError(err.message); }
}
async function deleteBill() {
  const id = $("#billId").value, name = $("#fName").value;
  $("#billDialog").close();
  if (!(await confirmBox("ลบรายการนี้?", `<b>${esc(name)}</b><br>ทุกเดือนและประวัติการจ่ายจะถูกลบด้วย`, "ใช่, ลบเลย", "error"))) return;
  try { await api(`api.php?action=bills&id=${id}`, "DELETE"); toast("ลบรายการแล้ว"); load(); }
  catch (err) { showError(err.message); }
}

/* ================= หน้าเงินคงเหลือ ================= */
function renderSavings() {
  const nowKey = monthKey(new Date());
  let income = 0, expense = 0, saved = 0;
  $("#svMonths").innerHTML = months.map((mo) => {
    const mk = mo.month, inc = budgets[mk], exp = expOf(mk), sv = savedOf(mk);
    const items = savingsData[mk] || [];
    const isNow = mk === nowKey;
    const name = `<span class="nm">${TH_MONTHS[+mk.slice(5) - 1]}${isNow ? `<i class="tag">เดือนนี้</i>` : ""}</span>`;
    if (inc == null) return `<button class="sv-card unset ${isNow ? "now" : ""}" data-month="${mk}">${name}<span class="sv-amt">ยังไม่ตั้งรายรับ</span><span class="hint">+ ตั้งรายรับ</span></button>`;
    income += inc; expense += exp; saved += sv;
    const free = inc - exp - sv;
    const rate = inc ? Math.round((sv / inc) * 100) : 0;
    const w = (v) => (inc ? Math.max(0, Math.min(100, (v / inc) * 100)) : 0);
    const cls = free < 0 ? "bad" : pctClass(rate);
    return `<button class="sv-card ${cls} ${isNow ? "now" : ""}" data-month="${mk}">
      ${name}
      <span class="sv-amt">${fmt(sv)}</span>
      <div class="mini"><div class="e" style="width:${w(exp)}%"></div><div class="s" style="width:${w(sv)}%"></div></div>
      <span class="pct ${cls}">เก็บ ${rate}%${items.length ? ` · ${items.length} รายการ` : ""}</span>
      <span class="free ${free < 0 ? "neg" : ""}">เหลือ ${sfmt(free)}</span>
    </button>`;
  }).join("");

  const free = income - expense - saved;
  const rate = income ? Math.round((saved / income) * 100) : 0;
  const sD = income ? Math.max(0, Math.min(100, (saved / income) * 100)) : 0;
  const eD = income ? Math.max(0, Math.min(100 - sD, (expense / income) * 100)) : 0;
  $("#svIncome").textContent = fmt(income);
  $("#svExpense").textContent = fmt(expense);
  $("#svSaving").textContent = fmt(saved);
  $("#svFree").textContent = sfmt(free);
  $("#svFree").style.color = free < 0 ? "var(--red)" : "";
  $("#svRate").textContent = income ? rate + "%" : "—";
  $("#svExpPct").textContent = income ? Math.round(eD) + "%" : "—";
  $("#svSavPct").textContent = income ? Math.round(sD) + "%" : "—";
  $("#svFreePct").textContent = income ? Math.max(0, Math.round(100 - sD - eD)) + "%" : "—";
  $("#svDonut").style.background = income
    ? `conic-gradient(var(--green) 0 ${sD}%, #f87171 ${sD}% ${sD + eD}%, #cbd5e1 ${sD + eD}% 100%)`
    : `conic-gradient(var(--line) 0 100%)`;
  $("#svGoal").textContent = savingGoal + "%";
  $("#svGoalText").textContent = !income ? "ตั้งรายรับเพื่อเริ่มคำนวณ"
    : rate >= savingGoal ? `✅ ถึงเป้าแล้ว (เก็บได้ ${rate}%)` : `ยังขาดอีก ${fmt(Math.ceil((income * savingGoal) / 100 - saved))}`;
}

async function openSavingMonth(mk) {
  const inc = budgets[mk];
  if (inc == null) { if (await budgetForm(mk)) openSavingMonth(mk); return; }
  const exp = expOf(mk), items = savingsData[mk] || [], sv = savedOf(mk);
  const free = inc - exp - sv;
  const rate = inc ? Math.round((sv / inc) * 100) : 0;
  const w = (v) => (inc ? Math.max(0, Math.min(100, (v / inc) * 100)) : 0);
  const names = [...new Set(Object.values(savingsData).flat().map((x) => x.name).concat(assetsData.savings.map((s) => s.name)))];

  await Swal.fire({
    title: `💰 ${thMonth(mk)}`, width: 580,
    html: `
      <div class="pop-sum">
        <div><span>รายรับ</span><b>${fmt(inc)}</b></div>
        <div class="r"><span>รายจ่าย</span><b>${fmt(exp)}</b></div>
        <div class="g"><span>เงินเก็บ</span><b>${fmt(sv)}</b></div>
        <div class="free-box ${free > 0 ? "can" : ""}" ${free > 0 ? `data-split="1" title="คลิกเพื่อแบ่งเป็นเงินเก็บ"` : ""}>
          <span>เหลือ</span><b style="color:${free < 0 ? "var(--red)" : "var(--primary)"}">${sfmt(free)}</b>
          ${free > 0 ? `<small class="split-hint">🐷 แบ่งเป็นเงินเก็บ</small>` : ""}
        </div>
      </div>
      <div class="pop-bar"><div class="e" style="width:${w(exp)}%"></div><div class="s" style="width:${w(sv)}%"></div></div>
      <div style="display:flex;justify-content:space-between;font-size:12px">
        <span>🟥 รายจ่าย · 🟩 เงินเก็บ · ⬜ เหลือ</span>
        <span class="pct ${pctClass(rate)}">เก็บ ${rate}% · เป้า ${savingGoal}%</span>
      </div>

      <div class="items-head"><b>💵 รายรับ</b></div>
      <div class="day-list">
        <div class="day-item upcoming">
          <div class="t"><b>รายรับเดือนนี้</b><small>เงินเดือน / รายได้รวม</small></div>
          <span class="amt">${fmt(inc)}</span>
          <button class="btn unpay sm" data-incedit="1">แก้ไข</button>
        </div>
      </div>

      <div class="items-head"><b>🐷 รายการเงินเก็บ</b></div>
      <div class="day-list">
        ${items.length ? items.map((x) => `
          <div class="day-item paid">
            <div class="t"><b>${esc(x.name)}</b><small>${inc ? Math.round((x.amount / inc) * 100) : 0}% ของรายรับ</small></div>
            <span class="amt">${fmt(x.amount)}</span>
            <button class="btn unpay sm" data-sedit="${x.id}">แก้ไข</button>
            <button class="btn cancel sm" data-sdel="${x.id}">ลบ</button>
          </div>`).join("") : `<div class="mempty">ยังไม่มีรายการเงินเก็บ</div>`}
      </div>
      <form id="svAddForm" class="sv-add">
        <input id="svName" placeholder="ชื่อ เช่น เงินฉุกเฉิน, ลงทุน" list="svNames" required>
        <input id="svAmt" type="number" min="0" step="0.01" placeholder="จำนวนเงิน" value="${free > 0 ? free : ""}" required>
        <button class="btn pay sm" type="submit">+ เพิ่ม</button>
        <datalist id="svNames">${names.map((n) => `<option value="${esc(n)}">`).join("")}</datalist>
      </form>`,
    confirmButtonText: "ปิด", confirmButtonColor: COLOR.gray,
    didOpen: (popup) => {
      popup.querySelector("#svAddForm").onsubmit = async (e) => {
        e.preventDefault();
        const name = $("#svName").value.trim(), amount = parseFloat($("#svAmt").value);
        if (!name || isNaN(amount) || amount < 0) return;
        await saveSaving({ month: mk, name, amount });
        openSavingMonth(mk);
      };
      popup.querySelector(".swal2-html-container").addEventListener("click", async (e) => {
        const g = (a) => e.target.closest(`[data-${a}]`)?.dataset[a];
        if (g("split")) { await splitToSavings(mk, free); return openSavingMonth(mk); }
        if (g("incedit")) { await budgetForm(mk); return openSavingMonth(mk); }
        if (g("sdel")) {
          await api(`api.php?action=savings&id=${g("sdel")}`, "DELETE");
          await reloadSavings(); await reloadAssets(); renderSavings(); return openSavingMonth(mk);
        }
        if (g("sedit")) {
          const x = items.find((i) => i.id === +g("sedit"));
          const { value } = await Swal.fire({
            title: "แก้ไขเงินเก็บ",
            html: `<div class="swal-form"><label>ชื่อ<input id="eName" value="${esc(x.name)}"></label>
              <label>จำนวนเงิน (บาท)<input id="eAmt" class="big green" type="number" min="0" step="0.01" value="${x.amount}"></label></div>`,
            showCancelButton: true, reverseButtons: true, confirmButtonText: "บันทึก", cancelButtonText: "ยกเลิก",
            confirmButtonColor: COLOR.blue, cancelButtonColor: COLOR.gray,
            preConfirm: () => {
              const name = $("#eName").value.trim(), amount = parseFloat($("#eAmt").value);
              if (!name || isNaN(amount) || amount < 0) return Swal.showValidationMessage("ข้อมูลไม่ถูกต้อง");
              return { name, amount };
            },
          });
          if (value) await saveSaving({ id: x.id, month: mk, ...value });
          openSavingMonth(mk);
        }
      });
    },
  });
}

async function saveSaving(data) {
  try {
    await api("api.php?action=savings", "POST", data);
    await reloadSavings(); await reloadAssets();
    renderSavings();
    toast("บันทึกเงินเก็บแล้ว");
  } catch (err) { showError(err.message); }
}

async function splitToSavings(mk, free) {
  const freq = {};
  Object.values(savingsData).flat().forEach((x) => (freq[x.name] = (freq[x.name] || 0) + 1));
  assetsData.savings.forEach((s) => (freq[s.name] = (freq[s.name] || 0) + s.months));
  let names = Object.keys(freq).sort((a, b) => freq[b] - freq[a]).slice(0, 4);
  if (!names.length) names = ["เงินฉุกเฉิน", "ลงทุน"];
  const row = (n = "", a = "") => `<div class="split-row">
      <input class="sp-name" placeholder="ชื่อ เช่น เงินฉุกเฉิน" value="${esc(n)}" list="spNames">
      <input class="sp-pct" type="number" min="0" max="100" step="1" placeholder="%">
      <input class="sp-amt" type="number" min="0" step="0.01" placeholder="บาท" value="${a}">
      <button type="button" class="sp-del" title="ลบแถว">✕</button></div>`;
  const each = Math.floor((free / names.length) * 100) / 100;

  const { value } = await Swal.fire({
    title: "🐷 แบ่งเงินที่เหลือเป็นเงินเก็บ", width: 580,
    html: `<div class="split-top">เงินที่เหลือ ${thMonth(mk)} <b>${fmt(free)}</b></div>
      <div class="split-head"><span>ชื่อเงินเก็บ</span><span>%</span><span>จำนวน (บาท)</span><span></span></div>
      <div id="spRows">${names.map((n, i) => row(n, i === names.length - 1 ? +(free - each * (names.length - 1)).toFixed(2) : each)).join("")}</div>
      <div class="split-tools"><button type="button" class="link-btn" id="spAdd">+ เพิ่มแถว</button><button type="button" class="link-btn" id="spEven">แบ่งเท่า ๆ กัน</button></div>
      <div class="split-sum"><span>แบ่งแล้ว <b id="spUsed">฿0</b></span><span>คงเหลือหลังแบ่ง <b id="spLeft">฿0</b></span></div>
      <datalist id="spNames">${Object.keys(freq).map((n) => `<option value="${esc(n)}">`).join("")}</datalist>`,
    showCancelButton: true, reverseButtons: true, confirmButtonText: "บันทึกเงินเก็บ", cancelButtonText: "ยกเลิก",
    confirmButtonColor: COLOR.green, cancelButtonColor: COLOR.gray,
    didOpen: (popup) => {
      const rows = popup.querySelector("#spRows");
      const pctFromAmt = (r) => { r.querySelector(".sp-pct").value = free ? Math.round(((+r.querySelector(".sp-amt").value || 0) / free) * 100) : 0; };
      const update = () => {
        const used = [...rows.querySelectorAll(".sp-amt")].reduce((s, i) => s + (+i.value || 0), 0);
        const left = free - used;
        popup.querySelector("#spUsed").textContent = fmt(used);
        const el = popup.querySelector("#spLeft");
        el.textContent = sfmt(left);
        el.style.color = left < -0.001 ? "var(--red)" : Math.abs(left) < 0.01 ? "var(--green)" : "var(--primary)";
      };
      rows.querySelectorAll(".split-row").forEach(pctFromAmt);
      rows.addEventListener("input", (e) => {
        const r = e.target.closest(".split-row");
        if (e.target.classList.contains("sp-pct")) r.querySelector(".sp-amt").value = Math.round(free * (+e.target.value || 0)) / 100;
        else if (e.target.classList.contains("sp-amt")) pctFromAmt(r);
        update();
      });
      rows.addEventListener("click", (e) => { if (e.target.closest(".sp-del")) { e.target.closest(".split-row").remove(); update(); } });
      popup.querySelector("#spAdd").onclick = () => { rows.insertAdjacentHTML("beforeend", row()); update(); };
      popup.querySelector("#spEven").onclick = () => {
        const rs = [...rows.querySelectorAll(".split-row")];
        if (!rs.length) return;
        const e1 = Math.floor((free / rs.length) * 100) / 100;
        rs.forEach((r, i) => { r.querySelector(".sp-amt").value = i === rs.length - 1 ? +(free - e1 * (rs.length - 1)).toFixed(2) : e1; pctFromAmt(r); });
        update();
      };
      update();
    },
    preConfirm: () => {
      const items = [...document.querySelectorAll("#spRows .split-row")]
        .map((r) => ({ name: r.querySelector(".sp-name").value.trim(), amount: +r.querySelector(".sp-amt").value || 0 }))
        .filter((x) => x.amount > 0);
      if (!items.length) return Swal.showValidationMessage("กรุณาใส่จำนวนเงินอย่างน้อย 1 รายการ");
      if (items.some((x) => !x.name)) return Swal.showValidationMessage("กรุณาใส่ชื่อเงินเก็บให้ครบ");
      const used = items.reduce((s, x) => s + x.amount, 0);
      if (used > free + 0.001) return Swal.showValidationMessage(`แบ่งเกินเงินที่เหลือ ${fmt(used - free)}`);
      return items;
    },
  });
  if (!value) return;
  try {
    const existing = savingsData[mk] || [];
    for (const it of value) {
      const ex = existing.find((x) => x.name === it.name);
      await api("api.php?action=savings", "POST", ex ? { id: ex.id, month: mk, name: it.name, amount: ex.amount + it.amount } : { month: mk, ...it });
    }
    await reloadSavings(); await reloadAssets();
    renderSavings();
    toast(`แบ่งเป็นเงินเก็บ ${value.length} รายการแล้ว`);
  } catch (err) { showError(err.message); }
}

/* ---------- รายรับ / เป้าหมาย ---------- */
async function editBudget() {
  const now = new Date();
  const def = now.getFullYear() === year ? now.getMonth() + 1 : 1;
  const opts = TH_MONTHS.map((n, i) => {
    const k = `${year}-${pad(i + 1)}`;
    return `<option value="${k}" ${i + 1 === def ? "selected" : ""}>${n} ${year + 543}${budgets[k] != null ? ` (${fmt(budgets[k])})` : ""}</option>`;
  }).join("");
  const { value: mk } = await Swal.fire({
    title: "เลือกเดือนที่จะตั้งรายรับ", html: `<div class="swal-form"><select id="swMonth">${opts}</select></div>`,
    icon: "question", showCancelButton: true, reverseButtons: true, confirmButtonText: "ถัดไป", cancelButtonText: "ยกเลิก",
    confirmButtonColor: COLOR.blue, cancelButtonColor: COLOR.gray, preConfirm: () => $("#swMonth").value,
  });
  if (mk) budgetForm(mk);
}
async function budgetForm(mk) {
  const { value } = await Swal.fire({
    title: "รายรับของเดือน",
    html: `<div>${thMonth(mk)}</div><div class="swal-form">
        <input id="swBudget" class="big" type="number" min="0" step="0.01" value="${budgets[mk] ?? ""}" placeholder="เช่น 25000">
        <label class="chk"><input id="swRest" type="checkbox"> ใช้ยอดนี้กับเดือนที่เหลือของปีด้วย</label></div>`,
    icon: "info", showCancelButton: true, reverseButtons: true, confirmButtonText: "บันทึก", cancelButtonText: "ยกเลิก",
    confirmButtonColor: COLOR.blue, cancelButtonColor: COLOR.gray,
    didOpen: () => $("#swBudget").focus(),
    preConfirm: () => {
      const amount = parseFloat($("#swBudget").value);
      if (isNaN(amount) || amount < 0) return Swal.showValidationMessage("กรุณาใส่ยอดเงินให้ถูกต้อง");
      return { amount, apply_rest_of_year: $("#swRest").checked };
    },
  });
  if (!value) return false;
  try {
    await api("api.php?action=budget", "POST", { month: mk, ...value });
    toast("บันทึกรายรับเรียบร้อย");
    await load();
    return true;
  } catch (err) { showError(err.message); return false; }
}
async function editGoal() {
  const { value } = await Swal.fire({
    title: "เป้าหมายเงินเก็บ",
    html: `<div>ต้องการเก็บเงินกี่ % ของรายรับ</div><div class="swal-form"><input id="swGoal" class="big" type="number" min="0" max="100" value="${savingGoal}"></div>`,
    icon: "info", showCancelButton: true, reverseButtons: true, confirmButtonText: "บันทึก", cancelButtonText: "ยกเลิก",
    confirmButtonColor: COLOR.blue, cancelButtonColor: COLOR.gray,
    didOpen: () => $("#swGoal").select(),
    preConfirm: () => {
      const v = parseInt($("#swGoal").value, 10);
      if (isNaN(v) || v < 0 || v > 100) return Swal.showValidationMessage("ใส่ตัวเลข 0 - 100");
      return v;
    },
  });
  if (value == null) return;
  savingGoal = value;
  localStorage.setItem("savingGoal", value);
  renderSavings();
  toast("บันทึกเป้าหมายเรียบร้อย");
}

/* ================= หน้าทรัพย์สิน ================= */
function renderAssets() {
  const { assets, savings } = assetsData;
  const savTotal = savings.reduce((s, x) => s + x.total, 0);
  const cash = assets.filter((a) => ASSET_CATS[a.category]?.cash).reduce((s, a) => s + a.value, 0);
  const other = assets.filter((a) => !ASSET_CATS[a.category]?.cash).reduce((s, a) => s + a.value, 0);
  const total = savTotal + cash + other;
  const pctOf = (v) => (total ? Math.round((v / total) * 1000) / 10 : 0);

  $("#asTotal").textContent = fmt(total);
  $("#asSub").textContent = `เงินเก็บ ${savings.length} ประเภท · ทรัพย์สิน ${assets.length} รายการ`;
  $("#asSaving").textContent = fmt(savTotal);
  $("#asCash").textContent = fmt(cash);
  $("#asOther").textContent = fmt(other);

  // donut ตามหมวด
  const parts = [{ name: "เงินเก็บสะสม", icon: "🐷", color: SAVING_COLOR, value: savTotal }];
  Object.entries(ASSET_CATS).forEach(([cat, c]) => {
    const v = assets.filter((a) => catOf(a.category) === cat).reduce((s, a) => s + a.value, 0);
    parts.push({ name: cat, icon: c.icon, color: c.color, value: v });
  });
  const shown = parts.filter((p) => p.value > 0);
  let acc = 0;
  $("#asDonut").style.background = total
    ? `conic-gradient(${shown.map((p) => { const a = acc; acc += (p.value / total) * 100; return `${p.color} ${a}% ${acc}%`; }).join(",")})`
    : `conic-gradient(var(--line) 0 100%)`;
  $("#asCount").textContent = savings.length + assets.length;
  $("#asLegend").innerHTML = shown.length
    ? shown.map((p) => `<span><i class="dot" style="background:${p.color}"></i>${p.icon} ${p.name}<b>${pctOf(p.value)}%</b></span>`).join("")
    : `<span style="justify-content:center">ยังไม่มีข้อมูล</span>`;

  // เงินเก็บสะสม
  $("#asSavingList").innerHTML = savings.length ? savings.map((s) => `
    <div class="day-item paid edit-link" data-saving="${esc(s.name)}" title="คลิกเพื่อดูประวัติ">
      <span class="as-ico" style="background:var(--green-bg)">🐷</span>
      <div class="t"><b>${esc(s.name)}</b><small>สะสม ${s.months} ครั้ง · ${thMonth(s.first_month)}${s.first_month !== s.last_month ? ` – ${thMonth(s.last_month)}` : ""}</small></div>
      <span class="as-pct">${pctOf(s.total)}%</span>
      <span class="amt">${fmt(s.total)}</span>
    </div>`).join("")
    : `<div class="mempty">ยังไม่มีเงินเก็บ — เพิ่มได้ที่เมนู 💰 เงินคงเหลือ</div>`;

  // ทรัพย์สิน
  $("#asList").innerHTML = assets.length ? assets.map((a) => {
    const c = ASSET_CATS[a.category] || ASSET_CATS["อื่นๆ"];
    return `<div class="day-item" style="border-color:${c.color}">
      <span class="as-ico" style="background:${c.color}22">${c.icon}</span>
      <div class="t"><b>${esc(a.name)}</b><small>${esc(a.category)}${a.note ? ` · ${esc(a.note)}` : ""} · อัปเดต ${new Date(a.updated_at).toLocaleDateString("th-TH")}</small></div>
      <span class="as-pct">${pctOf(a.value)}%</span>
      <span class="amt">${fmt(a.value)}</span>
      <button class="btn unpay sm" data-aedit="${a.id}">แก้ไข</button>
      <button class="btn cancel sm" data-adel="${a.id}">ลบ</button>
    </div>`;
  }).join("") : `<div class="mempty">ยังไม่มีทรัพย์สิน — กด "+ เพิ่มทรัพย์สิน" เพื่อเพิ่มเงินสด บัญชีธนาคาร ทอง หุ้น ฯลฯ</div>`;
  renderAnalysis();
}

/* ================= วิเคราะห์ทรัพย์สิน (Chart.js) ================= */
const charts = {};
const LIQ = { 1: { name: "สูง (ใช้ได้ทันที)", color: "#22c55e" }, 2: { name: "ปานกลาง (ขายได้ใน 1-7 วัน)", color: "#f59e0b" }, 3: { name: "ต่ำ / ระยะยาว", color: "#ef4444" } };
const short = (v) => {
  const a = Math.abs(v);
  return (v < 0 ? "-" : "") + (a >= 1e6 ? (a / 1e6).toFixed(a >= 1e7 ? 0 : 1) + "M" : a >= 1e3 ? (a / 1e3).toFixed(a >= 1e5 ? 0 : 1) + "K" : a.toFixed(0));
};
function chartTheme() {
  const dark = document.documentElement.dataset.theme === "dark";
  return { text: dark ? "#94a3b8" : "#64748b", grid: dark ? "rgba(148,163,184,.12)" : "rgba(100,116,139,.12)", card: dark ? "#1e293b" : "#fff" };
}
function drawChart(id, config) {
  if (!window.Chart) return;
  charts[id]?.destroy();
  const t = chartTheme();
  Chart.defaults.font.family = "'Prompt', system-ui, sans-serif";
  Chart.defaults.color = t.text;
  config.options = Object.assign({ responsive: true, maintainAspectRatio: false, animation: { duration: 700 } }, config.options || {});
  config.options.plugins = Object.assign({
    legend: { labels: { usePointStyle: true, pointStyle: "circle", boxWidth: 8, padding: 14 } },
    tooltip: { padding: 10, cornerRadius: 10, callbacks: { label: (c) => ` ${c.dataset.label || c.label}: ${fmt(c.parsed.y ?? c.parsed.x ?? c.parsed)}` } },
  }, config.options.plugins || {});
  charts[id] = new Chart(document.getElementById(id), config);
}

function netWorthSeries() {
  const { assets, history, asset_history } = assetsData;
  // ช่วงเดือน: ตั้งแต่ข้อมูลแรก ถึงเดือนนี้ (อย่างน้อย 6 เดือน ไม่เกิน 24 เดือน)
  const firstDates = [...history.map((h) => h.month), ...asset_history.map((h) => h.date.slice(0, 7))].sort();
  const now = new Date();
  let start = firstDates[0] ? new Date(+firstDates[0].slice(0, 4), +firstDates[0].slice(5) - 1, 1) : new Date(now.getFullYear(), now.getMonth() - 5, 1);
  const minStart = new Date(now.getFullYear(), now.getMonth() - 23, 1);
  const sixAgo = new Date(now.getFullYear(), now.getMonth() - 5, 1);
  if (start < minStart) start = minStart;
  if (start > sixAgo) start = sixAgo;
  const labels = [], sav = [], ast = [];
  for (let d = new Date(start); d <= now; d.setMonth(d.getMonth() + 1)) {
    const mk = monthKey(d), end = `${mk}-31`;
    labels.push(`${TH_SHORT[d.getMonth()]} ${String(d.getFullYear() + 543).slice(2)}`);
    sav.push(history.filter((h) => h.month <= mk).reduce((s, h) => s + h.amount, 0));
    ast.push(assets.reduce((s, a) => {
      const hs = asset_history.filter((h) => h.asset_id === a.id && h.date <= end);
      return s + (hs.length ? hs[hs.length - 1].value : 0);
    }, 0));
  }
  return { labels, sav, ast };
}

function renderAnalysis() {
  const { assets, savings, history } = assetsData;
  const t = chartTheme();
  const savTotal = savings.reduce((s, x) => s + x.total, 0);
  const total = savTotal + assets.reduce((s, a) => s + a.value, 0);

  /* --- ตามประเภท --- */
  const byCat = {};
  if (savTotal) byCat["เงินเก็บสะสม"] = { v: savTotal, color: SAVING_COLOR, icon: "🐷", liq: 1 };
  assets.forEach((a) => {
    const k = catOf(a.category), c = ASSET_CATS[k];
    (byCat[k] ||= { v: 0, color: c.color, icon: c.icon, liq: c.liq || 2 }).v += a.value;
  });
  const cats = Object.entries(byCat).sort((a, b) => b[1].v - a[1].v);

  /* --- สภาพคล่อง --- */
  const liq = { 1: 0, 2: 0, 3: 0 };
  cats.forEach(([, c]) => (liq[c.liq] += c.v));

  /* --- Insights --- */
  const avgExp = assetsData.avg_expense || 0;
  const emerg = savings.filter((x) => /ฉุกเฉิน|emergency/i.test(x.name)).reduce((s, x) => s + x.total, 0);
  const liquidNow = liq[1];
  const runway = avgExp ? liquidNow / avgExp : null;
  const top = cats[0];
  const topPct = top && total ? Math.round((top[1].v / total) * 100) : 0;
  const series = netWorthSeries();
  const tot = series.sav.map((v, i) => v + series.ast[i]);
  const prev = tot.length > 1 ? tot[tot.length - 2] : 0, last = tot[tot.length - 1] || 0;
  const growth = prev ? Math.round(((last - prev) / prev) * 1000) / 10 : null;
  const liqPct = total ? Math.round((liquidNow / total) * 100) : 0;

  const ins = [];
  ins.push(runway == null
    ? { cls: "info", i: "🛟", big: "—", t: "เงินสำรองฉุกเฉิน", s: "ยังไม่มีข้อมูลรายจ่าย — บันทึกการจ่ายในหน้าปฏิทินเพื่อคำนวณ" }
    : { cls: runway >= 6 ? "good" : runway >= 3 ? "mid" : "bad", i: "🛟", big: `${runway.toFixed(1)} เดือน`, t: "เงินสำรองฉุกเฉิน",
        s: `เงินสภาพคล่องสูงพอใช้จ่าย ~${runway.toFixed(1)} เดือน (แนะนำ 3–6 เดือน · รายจ่ายเฉลี่ย ${fmt(Math.round(avgExp))}/เดือน)` });
  ins.push({ cls: liqPct >= 20 ? "good" : liqPct >= 10 ? "mid" : "bad", i: "💧", big: `${liqPct}%`, t: "สัดส่วนสภาพคล่องสูง",
    s: liqPct >= 20 ? "มีเงินพร้อมใช้เพียงพอ" : "ทรัพย์สินส่วนใหญ่เปลี่ยนเป็นเงินสดได้ช้า ควรเพิ่มเงินสำรอง" });
  ins.push(top
    ? { cls: topPct > 60 ? "bad" : topPct > 40 ? "mid" : "good", i: top[1].icon, big: `${topPct}%`, t: `กระจุกที่ "${top[0]}"`,
        s: topPct > 60 ? "ความเสี่ยงกระจุกตัวสูง ลองกระจายไปประเภทอื่น" : topPct > 40 ? "กระจายพอใช้ ยังเพิ่มความหลากหลายได้" : `กระจายดี มี ${cats.length} ประเภท` }
    : { cls: "info", i: "📦", big: "0", t: "การกระจายทรัพย์สิน", s: "ยังไม่มีทรัพย์สิน" });
  ins.push(growth == null
    ? { cls: "info", i: "📈", big: "—", t: "การเติบโตเดือนนี้", s: "ต้องมีข้อมูลอย่างน้อย 2 เดือน" }
    : { cls: growth >= 0 ? "good" : "bad", i: growth >= 0 ? "📈" : "📉", big: `${growth >= 0 ? "+" : ""}${growth}%`, t: "การเติบโตเทียบเดือนก่อน",
        s: `${growth >= 0 ? "เพิ่มขึ้น" : "ลดลง"} ${fmt(Math.abs(last - prev))} · ปัจจุบัน ${fmt(last)}` });
  if (emerg) ins[0].s += ` · กองเงินฉุกเฉิน ${fmt(emerg)}`;

  $("#asInsights").innerHTML = ins.map((x) => `<div class="ins ${x.cls}"><span class="ii">${x.i}</span>
    <div><span>${esc(x.t)}</span><b>${x.big}</b><small>${x.s}</small></div></div>`).join("");

  /* --- กราฟ 1: แนวโน้ม --- */
  drawChart("chTrend", {
    type: "line",
    data: { labels: series.labels, datasets: [
      { label: "ทรัพย์สินรวม", data: tot, borderColor: "#4f46e5", backgroundColor: "rgba(79,70,229,.12)", fill: true, tension: .35, borderWidth: 3, pointRadius: 3, pointHoverRadius: 6 },
      { label: "เงินเก็บสะสม", data: series.sav, borderColor: "#22c55e", borderDash: [6, 4], tension: .35, borderWidth: 2, pointRadius: 0 },
      { label: "ทรัพย์สินอื่น", data: series.ast, borderColor: "#f59e0b", borderDash: [2, 4], tension: .35, borderWidth: 2, pointRadius: 0 },
    ] },
    options: { interaction: { mode: "index", intersect: false },
      scales: { y: { beginAtZero: true, grid: { color: t.grid }, ticks: { callback: (v) => "฿" + short(v) } }, x: { grid: { display: false } } } },
  });

  /* --- กราฟ 2: ตามประเภท (แท่งแนวนอน) --- */
  drawChart("chCat", {
    type: "bar",
    data: { labels: cats.map(([k, c]) => `${c.icon} ${k}`), datasets: [{ label: "มูลค่า", data: cats.map(([, c]) => c.v),
      backgroundColor: cats.map(([, c]) => c.color), borderRadius: 8, barThickness: 18 }] },
    options: { indexAxis: "y", plugins: { legend: { display: false },
        tooltip: { callbacks: { label: (c) => ` ${fmt(c.parsed.x)} (${total ? Math.round((c.parsed.x / total) * 100) : 0}%)` } } },
      scales: { x: { beginAtZero: true, grid: { color: t.grid }, ticks: { callback: (v) => "฿" + short(v) } }, y: { grid: { display: false } } } },
  });

  /* --- กราฟ 3: สภาพคล่อง --- */
  drawChart("chLiq", {
    type: "doughnut",
    data: { labels: [1, 2, 3].map((l) => LIQ[l].name), datasets: [{ data: [liq[1], liq[2], liq[3]],
      backgroundColor: [1, 2, 3].map((l) => LIQ[l].color), borderColor: t.card, borderWidth: 4, hoverOffset: 8 }] },
    options: { cutout: "66%", plugins: { legend: { position: "bottom" },
      tooltip: { callbacks: { label: (c) => ` ${fmt(c.parsed)} (${total ? Math.round((c.parsed / total) * 100) : 0}%)` } } } },
  });

  /* --- กราฟ 4: เงินเก็บรายเดือน stacked --- */
  const now = new Date(), months12 = [];
  for (let i = 11; i >= 0; i--) months12.push(monthKey(new Date(now.getFullYear(), now.getMonth() - i, 1)));
  const names = [...new Set(history.map((h) => h.name))];
  const sc = ["#22c55e", "#3b82f6", "#f59e0b", "#a855f7", "#ec4899", "#14b8a6", "#ef4444", "#64748b"];
  drawChart("chSave", {
    type: "bar",
    data: { labels: months12.map((m) => TH_SHORT[+m.slice(5) - 1]),
      datasets: names.map((n, i) => ({ label: n, data: months12.map((m) => history.filter((h) => h.month === m && h.name === n).reduce((s, h) => s + h.amount, 0)),
        backgroundColor: sc[i % sc.length], borderRadius: 4, stack: "s" })) },
    options: { interaction: { mode: "index", intersect: false },
      scales: { x: { stacked: true, grid: { display: false } }, y: { stacked: true, beginAtZero: true, grid: { color: t.grid }, ticks: { callback: (v) => "฿" + short(v) } } } },
  });
}

async function assetForm(a) {
  const groups = { 1: "สภาพคล่องสูง", 2: "สภาพคล่องปานกลาง", 3: "สภาพคล่องต่ำ / ระยะยาว" };
  const cur = a ? catOf(a.category) : "บัญชีธนาคาร";
  let opts = Object.entries(groups).map(([lv, label]) => `<optgroup label="${label}">${
    Object.entries(ASSET_CATS_BASE).filter(([, c]) => c.liq === +lv)
      .map(([k, c]) => `<option value="${k}" ${cur === k ? "selected" : ""}>${c.icon} ${k}</option>`).join("")}</optgroup>`).join("");
  const cust = Object.entries(customCats);
  if (cust.length) opts += `<optgroup label="ประเภทของฉัน">${cust.map(([k, c]) => `<option value="${esc(k)}" ${cur === k ? "selected" : ""}>${c.icon} ${esc(k)}</option>`).join("")}</optgroup>`;
  opts += `<option value="__new">＋ สร้างประเภทใหม่...</option>`;
  const { value } = await Swal.fire({
    title: a ? "แก้ไขทรัพย์สิน" : "เพิ่มทรัพย์สิน",
    html: `<div class="swal-form">
      <label>ประเภท<select id="aCat">${opts}</select></label>
      <div id="aNewWrap" class="row" style="display:none">
        <label style="flex:0 0 74px">ไอคอน<input id="aNewIco" value="⭐" maxlength="4" style="text-align:center"></label>
        <label style="flex:1">ชื่อประเภทใหม่<input id="aNewCat" placeholder="เช่น หุ้นต่างประเทศ, NFT"></label>
        <label style="flex:0 0 130px">สภาพคล่อง<select id="aNewLiq"><option value="1">สูง</option><option value="2" selected>ปานกลาง</option><option value="3">ต่ำ</option></select></label>
      </div>
      <label>ชื่อ<input id="aName" value="${esc(a?.name ?? "")}" placeholder="เช่น บัญชีออมทรัพย์ KBank, ทองคำ 1 บาท"></label>
      <label>มูลค่าปัจจุบัน (บาท)<input id="aVal" class="big green" type="number" min="0" step="0.01" value="${a?.value ?? ""}"></label>
      <label>หมายเหตุ<input id="aNote" value="${esc(a?.note ?? "")}" placeholder="(ไม่บังคับ)"></label></div>`,
    showCancelButton: true, reverseButtons: true, confirmButtonText: "บันทึก", cancelButtonText: "ยกเลิก",
    confirmButtonColor: COLOR.green, cancelButtonColor: COLOR.gray,
    didOpen: () => {
      $("#aName").focus();
      $("#aCat").onchange = () => ($("#aNewWrap").style.display = $("#aCat").value === "__new" ? "flex" : "none");
    },
    preConfirm: () => {
      let category = $("#aCat").value;
      if (category === "__new") {
        category = $("#aNewCat").value.trim();
        if (!category) return Swal.showValidationMessage("กรุณาใส่ชื่อประเภทใหม่");
        if (!ASSET_CATS[category]) {
          customCats[category] = { icon: $("#aNewIco").value.trim() || "⭐", color: PALETTE[Object.keys(customCats).length % PALETTE.length], liq: +$("#aNewLiq").value };
          localStorage.setItem("customCats", JSON.stringify(customCats));
        }
      }
      const name = $("#aName").value.trim(), val = parseFloat($("#aVal").value);
      if (!name) return Swal.showValidationMessage("กรุณาใส่ชื่อ");
      if (isNaN(val) || val < 0) return Swal.showValidationMessage("กรุณาใส่มูลค่าให้ถูกต้อง");
      return { id: a?.id, name, value: val, category, note: $("#aNote").value.trim() };
    },
  });
  if (!value) return;
  try {
    await api("api.php?action=assets", "POST", value);
    await reloadAssets(); renderAssets();
    toast(a ? "แก้ไขทรัพย์สินแล้ว" : "เพิ่มทรัพย์สินแล้ว");
  } catch (err) { showError(err.message); }
}

async function showSavingHistory(name) {
  const rows = assetsData.history.filter((h) => h.name === name);
  const total = rows.reduce((s, h) => s + h.amount, 0);
  Swal.fire({
    title: `🐷 ${esc(name)}`, width: 480,
    html: `<div class="pop-sum"><div class="g"><span>ยอดสะสม</span><b>${fmt(total)}</b></div><div><span>จำนวนครั้ง</span><b>${rows.length}</b></div></div>
      <div class="day-list">${rows.map((h) => `<div class="day-item paid"><div class="t"><b>${thMonth(h.month)}</b></div><span class="amt">+${fmt(h.amount)}</span></div>`).join("")}</div>`,
    confirmButtonText: "ปิด", confirmButtonColor: COLOR.gray,
  });
}

/* ================= Events ================= */
const onNav = (e) => {
  const a = e.target.closest(".nav-link");
  if (!a) return;
  e.preventDefault();
  page = a.dataset.page;
  history.replaceState(null, "", "#" + page);
  document.body.classList.remove("side-open");
  window.scrollTo({ top: 0, behavior: "smooth" });
  render();
};
$("#navMenu").onclick = onNav;
$("#pillNav").onclick = onNav;
$("#profileBox").onclick = (e) => (e.target.closest(".avatar-wrap") ? changePhoto() : editName());
$("#avatarSmall").onclick = changePhoto;
$("#avatarFile").onchange = async (e) => {
  const f = e.target.files[0];
  e.target.value = "";
  if (!f) return;
  if (!f.type.startsWith("image/")) return showError("กรุณาเลือกไฟล์รูปภาพ");
  try {
    localStorage.setItem("userPhoto", await resizeImage(f));
    renderHeader();
    toast("เปลี่ยนรูปโปรไฟล์แล้ว");
  } catch { showError("ไม่สามารถอ่านรูปนี้ได้"); }
};
$("#bellBtn").onclick = showNotifications;
$("#bellBtn2").onclick = showNotifications;
$("#heroIncome").onclick = editBudget;
$("#sideAdd").onclick = (e) => { e.preventDefault(); document.body.classList.remove("side-open"); openDialog(null); };
$("#sideIncome").onclick = (e) => { e.preventDefault(); document.body.classList.remove("side-open"); editBudget(); };
$("#menuBtn").onclick = () => {
  if (innerWidth <= 960) document.body.classList.toggle("side-open");
  else document.body.classList.toggle("side-closed");
};
$("#sideOverlay").onclick = () => document.body.classList.remove("side-open");
$("#fullBtn").onclick = () => (document.fullscreenElement ? document.exitFullscreen() : document.documentElement.requestFullscreen?.());
$("#bottomNav").onclick = onNav;
$("#themeBtn").onclick = toggleTheme;
$("#themeBtn2").onclick = toggleTheme;
$("#prevYear").onclick = () => { year--; load(); };
$("#nextYear").onclick = () => { year++; load(); };
$("#addBtn").onclick = () => (page === "assets" ? assetForm(null) : openDialog(null));
$("#balanceCard").onclick = editBudget;
$("#incomeCard").onclick = editBudget;
$("#goalCard").onclick = editGoal;
$("#cancelBtn").onclick = () => $("#billDialog").close();
$("#deleteBtn").onclick = deleteBill;
$("#billForm").onsubmit = saveBill;
$("#search").oninput = renderYear;
$("#yearView").onclick = (e) => { const c = e.target.closest("[data-month]"); if (c) openMonth(c.dataset.month); };
$("#svMonths").onclick = (e) => { const c = e.target.closest("[data-month]"); if (c) openSavingMonth(c.dataset.month); };
$("#mpGrid").onclick = (e) => {
  const c = e.target.closest(".mchip");
  if (!c) return;
  picked.has(c.dataset.mk) ? picked.delete(c.dataset.mk) : picked.add(c.dataset.mk);
  renderPicker();
};
$("#mpPrev").onclick = () => { pickYear--; renderPicker(); };
$("#mpNext").onclick = () => { pickYear++; renderPicker(); };
$("#mpAll").onclick = () => { for (let i = 1; i <= 12; i++) picked.add(`${pickYear}-${pad(i)}`); renderPicker(); };
$("#mpClear").onclick = () => { [...picked].filter((k) => k.startsWith(pickYear + "-")).forEach((k) => picked.delete(k)); renderPicker(); };
$("#addAssetBtn").onclick = () => assetForm(null);
$("#asList").onclick = async (e) => {
  const ed = e.target.closest("[data-aedit]"), del = e.target.closest("[data-adel]");
  if (ed) assetForm(assetsData.assets.find((a) => a.id === +ed.dataset.aedit));
  if (del) {
    const a = assetsData.assets.find((x) => x.id === +del.dataset.adel);
    if (!(await confirmBox("ลบทรัพย์สินนี้?", `<b>${esc(a.name)}</b> · ${fmt(a.value)}`, "ใช่, ลบเลย", "error"))) return;
    try { await api(`api.php?action=assets&id=${a.id}`, "DELETE"); await reloadAssets(); renderAssets(); toast("ลบทรัพย์สินแล้ว"); }
    catch (err) { showError(err.message); }
  }
};
$("#asSavingList").onclick = (e) => { const s = e.target.closest("[data-saving]"); if (s) showSavingHistory(s.dataset.saving); };

/* ---------- Browser Notification (วันละครั้ง) ---------- */
async function browserNotify() {
  if (!("Notification" in window)) return;
  if (Notification.permission === "default") await Notification.requestPermission();
  if (Notification.permission !== "granted") return;
  const key = new Date().toDateString();
  if (localStorage.getItem("lastNotify") === key) return;
  const urgent = allBills().filter((b) => ["overdue", "soon"].includes(b.status.key));
  if (!urgent.length) return;
  new Notification("💸 Bill Reminder", { body: urgent.map((b) => `• ${b.name} ${fmt(b.amount)} — ${b.status.text}`).join("\n") });
  localStorage.setItem("lastNotify", key);
}

/* ---------- Start ---------- */
applyTheme(localStorage.getItem("theme") || (matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light"));
history.replaceState(null, "", "#" + page);
load().then(browserNotify);
setInterval(load, 60 * 60 * 1000);
