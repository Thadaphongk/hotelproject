# WIP Academic Demo — Project Context

This repository is a standalone academic demonstration of a WIP monitoring system. It is intentionally disconnected from all company databases, servers, accounts, network resources, and production data.

## Stack

- React + Vite
- Tailwind CSS
- Express REST API
- Synthetic in-memory demo data

## Main modules

- WIP Monitor / Machine Queue
- WIP by Part Name
- Dashboard
- Demo Lot Search
- Line Information
- Return / Issue Lot
- Move Lot
- Sequence Lot
- Hold Lot
- Daily Check
- Activity Logs
- Admin / Role & Permission Demo
- Profile

## Demo data conventions

- Machines: `DEMO-MC-A01`, `DEMO-MC-B01`, etc.
- Lines: `LINE-A`, `LINE-B`, `LINE-C`
- Lots: `LOT-DEMO-001`, `LOT-DEMO-002`, etc.
- Users: `DEMO-ADMIN`, `DEMO-OP01`, etc.
- Technical values: generic `Spec A` through `Spec U`

All identifiers and values are synthetic and created only for this academic build.
