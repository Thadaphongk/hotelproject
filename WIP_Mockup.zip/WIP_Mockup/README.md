# WIP Academic Demo

Standalone academic/demo version of a Work-In-Process monitoring web application.

## Privacy and data source

- Uses synthetic demo data only.
- Does not require a company database, VPN, internal server, internal account, or internal API.
- The local REST API stores changes in memory and resets when the server restarts.
- Runtime data requests use the local `/api` path only.
- The demo server binds to `127.0.0.1:3000`.

## Features synchronized in October 2026

Guest read-only navigation, page-level permissions, permission requests and Admin Console review/delete, 5-minute employee-code autofill, Move Lot Machine Queue preview, and synthetic image guides for Move/Return/Sequence/Hold are included. See `ACADEMIC_SYNC_REPORT.md` for scope and QA status.

## Demo accounts

- `DEMO-ADMIN` - full demo permissions
- `DEMO-STAFF01` - staff/support demo permissions
- `DEMO-OP01` - operator demo permissions
- `DEMO-VIEW01` - view-only demo permissions
- `DEMO-NEW01` - access-request workflow demo

No password is used in this academic build. All accounts are synthetic and exist only inside this project.

## Normal run

```bash
npm install
npm run build
npm start
```

Open `http://127.0.0.1:3000`.

On Windows, after dependencies are installed, `start-demo.bat` will build automatically when `dist` is missing and then start the demo server.

## Frontend development

Use two terminals.

Terminal 1 - local demo API:

```bash
npm start
```

Terminal 2 - Vite frontend:

```bash
npm run dev
```

Vite proxies `/api` to the local demo backend on `127.0.0.1:3000`.

## Architecture

```text
React + Vite Frontend
        ->
Local Express Demo REST API
        ->
Synthetic In-Memory Data
```

The REST API, validation, role/permission concepts, queue logic, search/filter UI, charts, modal flows, mock save/update/delete operations, and responsive UX/UI are retained for demonstration purposes.

See `SANITIZATION_REPORT.md` for the audit, sanitization scope, and verification status.
