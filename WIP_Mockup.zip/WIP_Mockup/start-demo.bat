@echo off
setlocal
cd /d "%~dp0"

echo Starting WIP Academic Demo...

if not exist "node_modules" (
  echo Dependencies are not installed.
  echo Please run: npm install
  pause
  exit /b 1
)

if not exist "dist\index.html" (
  echo Building demo frontend...
  call npm run build
  if errorlevel 1 (
    echo Build failed.
    pause
    exit /b 1
  )
)

call npm start
endlocal
