# Academic Demo synchronization — 23 October 2026

## Source comparisons

- Demo reference supplied: `WIP_Academic_Demo(1).zip`.
- Newer production reference supplied: dated 23 October 2026.
- Work was performed only in a separate Academic Demo copy. The production source archive was not changed and no files from its backend, database, environment settings, screenshots or logs were redistributed.

## Feature parity updates

| Capability | Demo implementation | Notes |
| --- | --- | --- |
| Page-level permissions | Updated access control, sidebar and App page guard | Permission `admin` is not equivalent to full ADMIN role. |
| Guest mode | Dashboard, WIP Monitor, WIP by Part Name, LOT Search and Return Lot read-only | Guest My Profile opens Login. Save on Return Lot opens Login. |
| Admin access management | Pending permission requests, edit permission, delete demo users | Demo Admin cannot delete itself. All operations use synthetic in-memory records. |
| User Profile | Request missing permissions and show request state | Admin reviews via the Demo Admin Console. |
| Employee confirmation | Temporary 5-minute confirmation helper | Stored in browser `sessionStorage` for Demo User ID; cleared on expiry. |
| Move Lot | Added Machine Queue preview / machine select / refresh above form | Queue refreshes after move; destination queue includes moved synthetic lots. |
| Move criteria | Separate fullscreen framed modal with an original 4-frame looping GIF | Generated for the Demo; contains no production screenshot. |
| Access request | Grouped access reasons + free-text “Other” reason | Demo registration remains simulated. |
| Return / Sequence / Hold / Move guide | Shared guide Modal and newly made synthetic example drawings | Production manual screenshots were NOT copied to this archive. |
| Line Information | Existing synthetic Line/Machine mapping remains | It is not connected to any production view or database. |
| LOT Search build compatibility | Restored `updateRecentLotSearches` alias in mock machine queue utility | Fixes stale Academic Demo import that previously caused a Vite missing export error. |

## Data and privacy

- Data source: synthetic arrays in `src/demo/demoData.js`, exposed by a local Express demonstration API only.
- No production server implementation, SQL logic, database file, `.env`, private connection string, production log, or original guide screenshot was added.
- New media is original SVG illustrations and a locally created GIF with synthetic identifiers (for example, `DEMO-MC-A01` and `LOT-DEMO-001`).
- All Data Write actions are demonstrations. Demo API data resets when Node server restarts.

## Validation performed

- 48 JS/JSX modules: TypeScript syntax parser — **PASS**, import paths and named/default exports — **PASS**.
- Demo REST route simulation: **15/15 PASS** (permission requests, grants, deletion, guest save rejection, mock move Queue, Line Info permissions).
- Client-side browser QA — **NOT RUN**; requires local install and actual browser.
- Production Vite build — **NOT VERIFIED**; npm dependency installation timed out in this execution environment. Run `npm install` and `npm run build` on local machine.
- Runtime browser Network tab test — **NOT RUN**. Source was checked for references to private hosts and SQL connectors, but review Network in the final local build before distribution.

## Deliberate limitations and remaining QA

- These are synthetic replacements, not copied production guide screenshots, manufacturing logic or technical rules. The academic demo demonstrates the workflow, not actual factory-specific process decisions.
- The demo login uses synthetic identifiers without passwords, so its session and permissions are for **education/demonstration**, not production-grade identity/security.
- No production credentials, database schema or company assets should be reintroduced when applying updates.
- The original Demo still contains its own styling and generic mock-data conventions. Production-only business detail was not imported automatically.

## Installation

Apply the changed-file ZIP **only** to the supplied Academic Demo version, never to the real production project. Paths in the ZIP start at the Academic Demo root.

```bash
npm install
npm run build
npm start
```

Open `http://127.0.0.1:3000`.

### Recommended manual acceptance test

1. Open as Guest: inspect public pages and click Return Lot Save and My Profile — Login should appear.
2. Login `DEMO-VIEW01`, request a missing permission in My Profile.
3. Login `DEMO-ADMIN`, approve permissions in Admin Console. Login as viewer again; page access should match permissions.
4. Login `DEMO-OP01`, move a synthetic LOT, then inspect the destination Machine Queue.
5. Test Return Lot, Sequence Lot and Hold Lot including confirmation popups, and open their picture guides.
6. Confirm all four guide groups use synthetic data; view the animated GIF in Move Lot criteria.
7. Inspect Browser Network requests; only local API/static resources should appear.
