import { useEffect, useState } from "react";
import MainLayout from "./components/layout/MainLayout";
import Dashboard from "./pages/Dashboard";
import Machines from "./pages/Machines";
import QueueBoard from "./pages/QueueBoard";
import PartGroupWip from "./pages/PartGroupWip";
import LineInformation from "./pages/LineInformation";
import Logs from "./pages/Logs";
import Profile from "./pages/Profile";
import AdminPanel from "./pages/AdminPanel";
import Auth from "./pages/Auth";
import DailyCheck from "./pages/DailyCheck";
import MachineDebug from "./pages/MachineDebug";
import ReturnLot from "./pages/ReturnLot";
import MoveLot from "./pages/MoveLot";
import HoldLot from "./pages/HoldLot";
import SequenceLot from "./pages/SequenceLot";
import { DEFAULT_DISPLAY_SETTINGS } from "./components/layout/DisplaySettingsModal";
import { getRequestStatus } from "./services/api";
import {
  canAccessPage,
  getFirstAccessiblePage,
  isGuestPublicPage,
} from "./utils/accessControl";

export default function App() {
  const [active, setActive] = useState(() => {
    const savedPage = window.sessionStorage.getItem("wip_demo_active_page");
    const storedUser = window.localStorage.getItem("wip_demo_user");

    // Guest เปิดระบบที่ Dashboard เป็นค่าเริ่มต้น และไม่ถูกบังคับเข้า Login
    // จากหน้าที่ค้างใน session ก่อนหน้า
    if (!storedUser) {
      return savedPage && isGuestPublicPage(savedPage)
        ? savedPage
        : "dashboard";
    }

    return savedPage || "queue";
  });
  const [isSidebarOpen, setIsSidebarOpen] = useState(window.innerWidth >= 768);
  const [showAuth, setShowAuth] = useState(false); // เพิ่ม State สำหรับบังคับโชว์หน้า Auth
  const [user, setUser] = useState(() => {
    const stored = window.localStorage.getItem("wip_demo_user");
    return stored ? JSON.parse(stored) : null;
  });
  const [theme, setTheme] = useState(() => {
    const stored = window.localStorage.getItem("wip_demo_theme");
    return stored || "light";
  });
  const [displaySettings, setDisplaySettings] = useState(() => {
    try {
      const stored = window.localStorage.getItem("wip_demo_display_settings");
      const parsed = stored ? JSON.parse(stored) : {};

      return {
        ...DEFAULT_DISPLAY_SETTINGS,
        ...parsed,
      };
    } catch {
      return DEFAULT_DISPLAY_SETTINGS;
    }
  });

  const currentEmployeeId = String(
    user?.id || user?.empCode || user?.employeeId || "",
  )
    .trim()
    .toUpperCase();

  const hasLoggedInUser = Boolean(user);
  const isSystemAccount = Boolean(user?.systemAccount);

  useEffect(() => {
    if (user) {
      window.localStorage.setItem("wip_demo_user", JSON.stringify(user));
    } else {
      window.localStorage.removeItem("wip_demo_user");
    }
  }, [user]);

  useEffect(() => {
    if (!hasLoggedInUser || !currentEmployeeId) return undefined;

    // System / Bootstrap Admin ไม่ได้ผูกกับ user-access JSON แบบผู้ใช้ทั่วไป
    if (isSystemAccount) {
      return undefined;
    }

    let cancelled = false;

    const syncCurrentAccess = async () => {
      try {
        const access = await getRequestStatus(currentEmployeeId);
        if (cancelled) return;

        const accessStatus = String(
          access?.statusRaw || access?.status || "",
        ).toUpperCase();

        // หาก Admin ลบ/ปิดสิทธิ์ User ที่กำลัง Login อยู่ ให้สิทธิ์มีผลกับ session นี้ด้วย
        if (!access || accessStatus !== "APPROVED") {
          setUser(null);
          setShowAuth(true);
          return;
        }

        setUser((currentUser) => {
          if (!currentUser) return currentUser;

          const nextPermissions = access.permissions || {};
          const nextRole = access.role || currentUser.role || "USER";
          // isAdmin หมายถึง Role ADMIN จริงเท่านั้น
          // Permission "admin" ใช้สำหรับเปิด Admin Console และไม่ควรทำให้ User
          // ข้าม Permission ของทุกหน้าโดยอัตโนมัติ
          const nextIsAdmin = String(nextRole).toUpperCase() === "ADMIN";

          const samePermissions =
            JSON.stringify(currentUser.permissions || {}) ===
            JSON.stringify(nextPermissions);

          if (
            samePermissions &&
            currentUser.role === nextRole &&
            Boolean(currentUser.isAdmin) === nextIsAdmin
          ) {
            return currentUser;
          }

          return {
            ...currentUser,
            role: nextRole,
            permissions: nextPermissions,
            isAdmin: nextIsAdmin,
            accessStatus: "APPROVED",
          };
        });
      } catch (error) {
        // Network/DB สะดุดชั่วคราวไม่ควรบังคับ Logout ผู้ใช้งานทันที
        console.error("Sync current user access error:", error);
      }
    };

    syncCurrentAccess();
    const intervalId = window.setInterval(syncCurrentAccess, 30000);
    window.addEventListener("focus", syncCurrentAccess);

    return () => {
      cancelled = true;
      window.clearInterval(intervalId);
      window.removeEventListener("focus", syncCurrentAccess);
    };
  }, [currentEmployeeId, hasLoggedInUser, isSystemAccount]);

  useEffect(() => {
    // จำหน้าที่กำลังใช้งานไว้ใน Tab นี้ เพื่อไม่ให้ Save/Refresh แล้วเด้งกลับหน้าอื่น
    window.sessionStorage.setItem("wip_demo_active_page", active);
  }, [active]);

  useEffect(() => {
    window.document.documentElement.classList.toggle("dark", theme === "dark");
    window.localStorage.setItem("wip_demo_theme", theme);
  }, [theme]);

  useEffect(() => {
    const root = window.document.documentElement;

    root.dataset.appFont = displaySettings.fontFamily;
    root.dataset.appFontSize = displaySettings.fontSize;
    root.dataset.tableDensity = displaySettings.tableDensity;

    window.localStorage.setItem(
      "wip_demo_display_settings",
      JSON.stringify(displaySettings),
    );
  }, [displaySettings]);

  const navigateToPage = (pageKey) => {
    if (!user) {
      if (isGuestPublicPage(pageKey)) {
        setActive(pageKey);
        return;
      }

      // หน้า My Profile และหน้าที่ต้องใช้สิทธิ์จะพา Guest ไป Login
      // โดยเก็บหน้าปลายทางไว้ เพื่อ Login สำเร็จแล้วกลับมาตรวจ Permission ต่อ
      setActive(pageKey);
      setShowAuth(true);
      return;
    }

    if (canAccessPage(user, pageKey)) {
      setActive(pageKey);
      return;
    }

    setActive(getFirstAccessiblePage(user));
  };

  useEffect(() => {
    if (!user) return;

    // กรณี Admin เพิ่งถอน Permission ขณะที่ User อยู่ในหน้านั้น
    // หรือ SessionStorage จำหน้าที่ User ไม่มีสิทธิ์ไว้ จะพาไปหน้าที่เข้าได้ทันที
    if (!canAccessPage(user, active)) {
      setActive(getFirstAccessiblePage(user));
    }
  }, [active, user]);

  const pageTitles = {
    dashboard: "Dashboard",
    machines: "LOT Search",
    queue: "WIP Monitor",
    partGroup: "WIP ตาม Part Name",
    lineInfo: "Line Information",
    returnLot: "แจ้งปัญหา / เดินงานข้าม Lot",
    moveLot: "ย้าย Lot งาน",
    sequence: "จัดลำดับงาน",
    hold: "พักงาน",
    dailyCheck: "Daily Check",
    machineDebug: "Machine Debug",
    logs: "Logs",
    admin: "Admin Console",
    profile: "My Profile",
  };

  const renderPage = () => {
    // ตรวจ Permission ซ้ำที่ระดับ Content ด้วย เพื่อป้องกันการเปิดหน้าจาก
    // SessionStorage / setActive / DevTools แม้เมนูใน Sidebar จะถูกซ่อนไว้แล้ว
    if (!canAccessPage(user, active)) {
      return user ? (
        <Profile user={user} setActive={navigateToPage} />
      ) : (
        <Dashboard setActive={navigateToPage} />
      );
    }

    switch (active) {
      case "machines":
        return <Machines user={user} />;

      case "queue":
        return <QueueBoard user={user} />;

      case "partGroup":
        return <PartGroupWip />;

      case "lineInfo":
        return <LineInformation user={user} />;

      case "returnLot":
        return (
          <ReturnLot
            user={user}
            onRequestLogin={() => {
              setActive("returnLot");
              setShowAuth(true);
            }}
          />
        );

      case "moveLot":
        return <MoveLot user={user} />;

      case "sequence":
        return <SequenceLot user={user} />;

      case "hold":
        return <HoldLot user={user} />;

      case "dailyCheck":
        return <DailyCheck user={user} />;

      case "machineDebug":
        return <MachineDebug />;

      case "logs":
        return <Logs user={user} />;

      case "admin":
        return <AdminPanel user={user} />;

      case "profile":
        return <Profile user={user} setActive={navigateToPage} />;

      case "dashboard":
      default:
        return <Dashboard setActive={navigateToPage} />;
    }
  };

  const handleLogout = () => {
    // เก็บ active page เดิมไว้ เพื่อให้ Login สำเร็จแล้วกลับมาหน้าเดิม
    setUser(null);
    setShowAuth(true);
  };

  // Guest เปิดดูหน้าข้อมูลหลักได้ แต่หน้าจัดการอื่นและ My Profile ต้อง Login
  const isPublicPage = isGuestPublicPage(active);
  const needsLogin = !isPublicPage && !user;

  // ถ้าหน้ากำลังจะไปต้องล็อกอิน หรือ ผู้ใช้กดปุ่ม "ล็อกอิน" จาก Dashboard
  if (needsLogin || showAuth) {
    return (
      <Auth
        onLogin={(loggedInUser) => {
          setUser(loggedInUser);
          setShowAuth(false);

          if (!canAccessPage(loggedInUser, active)) {
            setActive(getFirstAccessiblePage(loggedInUser));
          }
        }}
        theme={theme}
        onThemeToggle={() =>
          setTheme((current) => (current === "light" ? "dark" : "light"))
        }
        onCancel={() => {
          setShowAuth(false);

          // ถ้ายกเลิก Login จากหน้าที่ต้องใช้สิทธิ์ ให้กลับ Dashboard
          // แต่ถ้า Login ถูกเปิดจาก Return Lot / หน้าสาธารณะ ให้คงหน้าเดิมไว้
          if (!isGuestPublicPage(active)) {
            setActive("dashboard");
          }
        }}
      />
    );
  }

  // สร้างข้อมูลจำลองกรณีเป็น Guest (ผู้เยี่ยมชม)
  const displayUser = user || {
    name: "Guest",
    dept: "Public",
    position: "View Only",
    isAdmin: false,
  };

  return (
    <MainLayout
      active={active}
      setActive={navigateToPage}
      isSidebarOpen={isSidebarOpen}
      setIsSidebarOpen={setIsSidebarOpen}
      title={pageTitles[active]}
      user={displayUser}
      isLoggedIn={!!user}
      theme={theme}
      onThemeToggle={() =>
        setTheme((current) => (current === "light" ? "dark" : "light"))
      }
      displaySettings={displaySettings}
      onDisplaySettingsChange={setDisplaySettings}
      onDisplaySettingsReset={() =>
        setDisplaySettings({ ...DEFAULT_DISPLAY_SETTINGS })
      }
      onLogout={user ? handleLogout : () => setShowAuth(true)} // ถ้าเป็น Guest กดปุ่ม Profile ให้แสดงหน้าเข้าสู่ระบบ
    >
      {renderPage()}
    </MainLayout>
  );
}
