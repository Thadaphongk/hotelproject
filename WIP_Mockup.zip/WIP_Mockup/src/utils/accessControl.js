const normalizeRole = (value) =>
  String(value || "")
    .trim()
    .toUpperCase();

export const PAGE_PERMISSION_MAP = Object.freeze({
  dashboard: "dashboard",
  queue: "queue",
  // WIP By Part Name เป็นอีกมุมมองของข้อมูล WIP เดียวกับ WIP Monitor
  // จึงใช้สิทธิ์ queue ร่วมกัน โดยไม่เพิ่ม Permission ใหม่ให้ผู้ดูแลต้องจัดการซ้ำ
  partGroup: "queue",
  machines: "lotSearch",
  lineInfo: "lineInfo",
  returnLot: "returnLot",
  moveLot: "moveLot",
  sequence: "sequence",
  hold: "hold",
  dailyCheck: "dailyCheck",
  machineDebug: "machineDebug",
  logs: "logs",
  admin: "admin",
});

export const isFullAdmin = (user) => {
  if (!user) return false;

  return Boolean(user.systemAccount) || normalizeRole(user.role) === "ADMIN";
};

export const hasPermission = (user, permissionKey) => {
  if (!user || !permissionKey) return false;
  if (isFullAdmin(user)) return true;

  return user.permissions?.[permissionKey] === true;
};

export const GUEST_PUBLIC_PAGES = Object.freeze([
  "queue",
  "partGroup",
  "dashboard",
  "machines",
  "returnLot",
]);

export const isGuestPublicPage = (pageKey) =>
  GUEST_PUBLIC_PAGES.includes(pageKey);

export const canAccessPage = (user, pageKey) => {
  // Guest ดูข้อมูลหลักได้แบบ Read-only ตาม Flow ของระบบ
  // หน้า Return Lot เปิดดูได้ แต่การบันทึกต้อง Login ก่อน
  if (!user) return isGuestPublicPage(pageKey);

  // Profile เป็นหน้าบัญชีของผู้ใช้ทุกคนที่ Login แล้ว จึงไม่ต้องมี Permission แยก
  if (pageKey === "profile") return true;

  const permissionKey = PAGE_PERMISSION_MAP[pageKey];
  if (!permissionKey) return false;

  return hasPermission(user, permissionKey);
};

export const getFirstAccessiblePage = (user) => {
  if (!user) return "dashboard";

  const priority = [
    "dashboard",
    "queue",
    "machines",
    "lineInfo",
    "returnLot",
    "moveLot",
    "sequence",
    "hold",
    "dailyCheck",
    "logs",
    "machineDebug",
    "admin",
  ];

  return priority.find((pageKey) => canAccessPage(user, pageKey)) || "profile";
};
