const STORAGE_KEY = "wip_demo.employeeVerification.v1";

export const EMPLOYEE_VERIFICATION_TTL_MS = 5 * 60 * 1000;

export const normalizeEmployeeCode = (value) =>
  String(value ?? "")
    .trim()
    .toUpperCase();

const getSessionStorage = () => {
  if (typeof window === "undefined") return null;

  try {
    return window.sessionStorage;
  } catch {
    return null;
  }
};

const readStoredVerification = () => {
  const storage = getSessionStorage();
  if (!storage) return null;

  try {
    const rawValue = storage.getItem(STORAGE_KEY);
    if (!rawValue) return null;

    const parsed = JSON.parse(rawValue);
    const employeeCode = normalizeEmployeeCode(parsed?.employeeCode);
    const verifiedAt = Number(parsed?.verifiedAt || 0);
    const expiresAt = Number(parsed?.expiresAt || 0);

    if (!employeeCode || !verifiedAt || !expiresAt) {
      storage.removeItem(STORAGE_KEY);
      return null;
    }

    return {
      employeeCode,
      verifiedAt,
      expiresAt,
    };
  } catch {
    storage.removeItem(STORAGE_KEY);
    return null;
  }
};

export const clearEmployeeVerification = () => {
  const storage = getSessionStorage();
  if (!storage) return;

  try {
    storage.removeItem(STORAGE_KEY);
  } catch {
    // Ignore browser storage errors. The confirmation dialog still works normally.
  }
};

export const getEmployeeVerification = (expectedEmployeeCode) => {
  const expectedCode = normalizeEmployeeCode(expectedEmployeeCode);
  if (!expectedCode) {
    clearEmployeeVerification();
    return null;
  }

  const stored = readStoredVerification();
  if (!stored) return null;

  const now = Date.now();
  const isExpired = stored.expiresAt <= now;
  const isDifferentEmployee = stored.employeeCode !== expectedCode;

  if (isExpired || isDifferentEmployee) {
    clearEmployeeVerification();
    return null;
  }

  return {
    ...stored,
    remainingMs: Math.max(0, stored.expiresAt - now),
  };
};

export const rememberEmployeeVerification = (
  employeeCode,
  ttlMs = EMPLOYEE_VERIFICATION_TTL_MS,
) => {
  const normalizedCode = normalizeEmployeeCode(employeeCode);
  const storage = getSessionStorage();

  if (!normalizedCode || !storage) return null;

  const verifiedAt = Date.now();
  const safeTtlMs = Number.isFinite(Number(ttlMs))
    ? Math.max(1, Number(ttlMs))
    : EMPLOYEE_VERIFICATION_TTL_MS;
  const expiresAt = verifiedAt + safeTtlMs;

  const verification = {
    employeeCode: normalizedCode,
    verifiedAt,
    expiresAt,
  };

  try {
    storage.setItem(STORAGE_KEY, JSON.stringify(verification));
    return verification;
  } catch {
    return null;
  }
};
