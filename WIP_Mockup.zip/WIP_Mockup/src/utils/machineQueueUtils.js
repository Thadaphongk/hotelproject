export const machineNameMap = {};

export const setMachineNameMap = (mapping = {}) => {
  Object.keys(machineNameMap).forEach((key) => delete machineNameMap[key]);

  for (const [line, machine] of Object.entries(mapping || {})) {
    const cleanLine = String(line ?? "").trim().toUpperCase();
    const cleanMachine = String(machine ?? "").trim().toUpperCase();
    if (cleanLine && cleanMachine) machineNameMap[cleanLine] = cleanMachine;
  }

  return { ...machineNameMap };
};

export const formatMachineName = (name) => {
  if (!name) return "N/A";
  const trimmed = String(name).trim().toUpperCase();
  return machineNameMap[trimmed] || trimmed;
};

export const formatDisplayMachineName = (name) => {
  const value = String(name ?? "").trim().toUpperCase();
  return value || "N/A";
};

export const frontendHiddenMachines = [];
export const isFrontendVisibleMachine = () => true;

export const queueTargetMachines = [
  "DEMO-MC-A01",
  "DEMO-MC-A02",
  "DEMO-MC-B01",
  "DEMO-MC-B02",
  "DEMO-MC-C01",
  "DEMO-MC-C02",
];

export const searchTargetMachines = [...queueTargetMachines];
export const isQueueTargetMachine = (machineName) =>
  queueTargetMachines.includes(formatMachineName(machineName));
export const isSearchTargetMachine = (machineName) =>
  searchTargetMachines.includes(formatMachineName(machineName));
export const targetMachines = queueTargetMachines;
export const isTargetMachine = isQueueTargetMachine;
export const monitorTargetMachines = queueTargetMachines;
export const isMonitorTargetMachine = isQueueTargetMachine;

export const sortLotsByQueue = (lots = []) =>
  [...lots].sort((a, b) => {
    const queueA = Number(a?.queueNo);
    const queueB = Number(b?.queueNo);
    return (Number.isFinite(queueA) ? queueA : 999) -
      (Number.isFinite(queueB) ? queueB : 999);
  });

export const setupCompareFields = Array.from({ length: 21 }, (_, index) => {
  const letter = String.fromCharCode(65 + index);
  return {
    key: `spec${letter}`,
    label: `Spec ${letter}`,
    group: index < 10 ? "technician" : "operator",
  };
});

export const isBlankSetupValue = (value) => {
  const text = String(value ?? "").trim();
  return (
    text === "" ||
    text === "-" ||
    text.toLowerCase() === "null" ||
    text.toLowerCase() === "undefined"
  );
};

export const normalizeSetupValue = (value) => {
  if (isBlankSetupValue(value)) return "";
  const text = String(value ?? "").trim();
  if (/^-?\d+(\.\d+)?$/.test(text)) return String(Number(text));
  return text.replace(/\s+/g, " ").toUpperCase();
};

export const formatSetupValue = (value) =>
  isBlankSetupValue(value) ? "-" : String(value).trim();

export const getSetupInfo = (previousLot, currentLot) => {
  const details = setupCompareFields.map((field) => {
    const previousValue = previousLot ? previousLot[field.key] : "";
    const currentValue = currentLot ? currentLot[field.key] : "";
    const isDifferent = previousLot
      ? normalizeSetupValue(previousValue) !== normalizeSetupValue(currentValue)
      : false;

    return {
      ...field,
      previousValue,
      currentValue,
      previousDisplay: formatSetupValue(previousValue),
      currentDisplay: formatSetupValue(currentValue),
      isDifferent,
    };
  });

  const hasPreviousLot = Boolean(previousLot);
  const hasDiff = hasPreviousLot && details.some((item) => item.isDifferent);

  return {
    code: hasPreviousLot ? (hasDiff ? "CHANGE" : "MATCH") : "-",
    hasDiff,
    hasPreviousLot,
    details,
  };
};

export const getStatusInfo = (lot) => {
  const queueId = parseInt(lot?.queueNo, 10);
  const process = String(lot?.processStatus || "").trim().toUpperCase();
  const mcStatus = String(lot?.machineStatus || "").trim().toUpperCase();
  const stopText = String(lot?.stopCode ?? "").trim();
  const hasStopCode = stopText !== "" && stopText !== "-";
  const hasActiveData = [lot?.startTime, lot?.inputQty, lot?.outputQty, lot?.operatorId]
    .some((value) => {
      const text = String(value ?? "").trim();
      return text !== "" && text !== "-";
    });

  if (queueId === 2) {
    return { label: "รอผลิต", colors: "bg-amber-600 text-white dark:bg-amber-600 dark:text-white" };
  }
  if (queueId > 2) {
    return { label: "รอหน้าเครื่อง", colors: "bg-slate-600 text-white dark:bg-slate-600 dark:text-white" };
  }
  if (hasStopCode) {
    return { label: "เครื่องหยุดทำงาน", colors: "bg-rose-600 text-white dark:bg-rose-600 dark:text-white" };
  }
  if (process === "ACTIVE" || mcStatus === "RUN" || hasActiveData) {
    return { label: "กำลังผลิต", colors: "bg-emerald-600 text-white dark:bg-emerald-600 dark:text-white" };
  }
  return { label: "รอผลิต", colors: "bg-amber-600 text-white dark:bg-amber-600 dark:text-white" };
};

export const RECENT_LOT_STORAGE_KEY = "wip_demo_recent_lot_searches";

export const getRecentLotSearches = () => {
  if (typeof window === "undefined") return [];
  try {
    const stored = window.localStorage.getItem(RECENT_LOT_STORAGE_KEY);
    if (!stored) return [];
    const parsed = JSON.parse(stored);
    if (!Array.isArray(parsed)) return [];
    return parsed.map((lot) => String(lot || "").trim().toUpperCase()).filter(Boolean).slice(0, 10);
  } catch {
    return [];
  }
};

export const addRecentLotSearch = (lotNo) => {
  if (typeof window === "undefined") return [];
  const clean = String(lotNo || "").trim().toUpperCase();
  if (!clean) return getRecentLotSearches();
  const next = [clean, ...getRecentLotSearches().filter((lot) => lot !== clean)].slice(0, 10);
  window.localStorage.setItem(RECENT_LOT_STORAGE_KEY, JSON.stringify(next));
  return next;
};

// Compatible with Machines.jsx recent-search workflow.
export const updateRecentLotSearches = addRecentLotSearch;

export const clearRecentLotSearches = () => {
  if (typeof window !== "undefined") window.localStorage.removeItem(RECENT_LOT_STORAGE_KEY);
};
