export const formatDateOnly = (value) => {
  const text = String(value ?? "").trim();

  if (
    !text ||
    text === "-" ||
    text.toLowerCase() === "null" ||
    text.toLowerCase() === "undefined"
  ) {
    return "-";
  }

  const match = text.match(/^(\d{4}-\d{2}-\d{2})/);

  return match ? match[1] : text;
};