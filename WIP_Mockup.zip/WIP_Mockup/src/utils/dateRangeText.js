export const formatThaiDisplayDate = (value) => {
  const text = String(value || "").trim();

  if (!/^\d{4}-\d{2}-\d{2}$/.test(text)) return "";

  const [year, month, day] = text.split("-");
  const buddhistYear = Number(year) + 543;

  return `${day}-${month}-${buddhistYear}`;
};

export const getDateRangeText = (dateFrom, dateTo) => {
  const fromText = formatThaiDisplayDate(dateFrom);
  const toText = formatThaiDisplayDate(dateTo);

  if (fromText && toText) {
    return `ช่วงวันที่ที่เลือก: ${fromText} - ${toText}`;
  }

  if (fromText) {
    return `ช่วงวันที่ที่เลือก: ตั้งแต่ ${fromText} เป็นต้นไป`;
  }

  if (toText) {
    return `ช่วงวันที่ที่เลือก: ถึงวันที่ ${toText}`;
  }

  return "ยังไม่ได้เลือกช่วงวันที่";
};

export const hasChartFilter = ({
  search = "",
  dateFrom = "",
  dateTo = "",
  machine = "",
} = {}) => {
  return Boolean(
    String(search || "").trim() ||
      String(dateFrom || "").trim() ||
      String(dateTo || "").trim() ||
      String(machine || "").trim(),
  );
};

export const DATE_RANGE_ERROR_MESSAGE =
  "วันที่เริ่มต้นต้องไม่มากกว่าวันที่สิ้นสุด กรุณาเลือกช่วงวันที่ใหม่อีกครั้ง";

export const isInvalidDateRange = (dateFrom, dateTo) => {
  return Boolean(dateFrom && dateTo && dateFrom > dateTo);
};

export const getEffectiveDateRange = (dateMode, dateFrom, dateTo) => {
  if (dateMode === "single") {
    return {
      dateFrom: dateFrom || "",
      dateTo: dateFrom || "",
    };
  }

  return {
    dateFrom: dateFrom || "",
    dateTo: dateTo || "",
  };
};

export const isInvalidDateModeRange = (dateMode, dateFrom, dateTo) => {
  if (dateMode !== "range") return false;

  return Boolean(dateFrom && dateTo && dateFrom > dateTo);
};

export const hasDateFilterForChart = ({ dateMode, dateFrom, dateTo }) => {
  if (dateMode === "single") {
    return Boolean(dateFrom);
  }

  return Boolean(dateFrom || dateTo);
};

export const getDateModeRangeText = ({ dateMode, dateFrom, dateTo }) => {
  const fromText = formatThaiDisplayDate(dateFrom);
  const toText = formatThaiDisplayDate(dateTo);

  if (dateMode === "single") {
    if (fromText) return `วันที่ที่เลือก: ${fromText}`;
    return "ยังไม่ได้เลือกวันที่";
  }

  if (fromText && toText) {
    return `ช่วงวันที่ที่เลือก: ${fromText} - ${toText}`;
  }

  if (fromText) {
    return `ช่วงวันที่ที่เลือก: ตั้งแต่ ${fromText} เป็นต้นไป`;
  }

  if (toText) {
    return `ช่วงวันที่ที่เลือก: ถึงวันที่ ${toText}`;
  }

  return "ยังไม่ได้เลือกช่วงวันที่";
};

export const getTimeTextFromDateTime = (value) => {
  const text = String(value || "").trim();
  if (!text) return "";

  const match = text.match(/(\d{2}):(\d{2}):(\d{2})/);
  if (match) return `${match[1]}:${match[2]}:${match[3]}`;

  return "";
};

const normalizeDateTimeForCompare = (value) => {
  const text = String(value || "").trim();
  if (!text) return "";

  const sqlMatch = text.match(
    /^(\d{4})-(\d{2})-(\d{2})[ T](\d{2}):(\d{2}):(\d{2})/,
  );

  if (sqlMatch) {
    return `${sqlMatch[1]}-${sqlMatch[2]}-${sqlMatch[3]} ${sqlMatch[4]}:${sqlMatch[5]}:${sqlMatch[6]}`;
  }

  const displayMatch = text.match(
    /^(\d{2})\/(\d{2})\/(\d{4}),?\s+(\d{2}):(\d{2}):(\d{2})/,
  );

  if (displayMatch) {
    return `${displayMatch[3]}-${displayMatch[2]}-${displayMatch[1]} ${displayMatch[4]}:${displayMatch[5]}:${displayMatch[6]}`;
  }

  return text;
};

export const getLatestTimeText = (rows, getDateTime) => {
  let latestKey = "";
  let latestValue = "";

  for (const row of rows || []) {
    const value = getDateTime(row);
    const key = normalizeDateTimeForCompare(value);

    if (!key) continue;

    if (!latestKey || key > latestKey) {
      latestKey = key;
      latestValue = value;
    }
  }

  const timeText = getTimeTextFromDateTime(latestValue);

  return timeText ? `ข้อมูลล่าสุด: ${timeText}` : "ข้อมูลล่าสุด: -";
};

export const getCurrentTimeText = () => {
  const now = new Date();

  const hours = String(now.getHours()).padStart(2, "0");
  const minutes = String(now.getMinutes()).padStart(2, "0");
  const seconds = String(now.getSeconds()).padStart(2, "0");

  return `ข้อมูลล่าสุด: ${hours}:${minutes}:${seconds}`;
};