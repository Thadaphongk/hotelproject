const API_BASE_URL = "/api";

const apiFetch = async (path, options = {}) => {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {}),
    },
    ...options,
  });

  const data = await response.json().catch(() => null);

  if (!response.ok) {
    const error = new Error(
      data?.message || `Request failed with status ${response.status}`,
    );

    error.status = response.status;
    error.code = data?.code;
    error.data = data;

    throw error;
  }

  return data;
};

export async function getSortLots(machine) {
  const cleanMachine = String(machine || "").trim().toUpperCase();

  if (!cleanMachine) {
    return {
      ok: true,
      machine: "",
      queueMachine: "",
      total: 0,
      rows: [],
    };
  }

  return apiFetch(`/sort-lots/${encodeURIComponent(cleanMachine)}`);
}

export async function saveSortLots({
  machine,
  lots,
  empCode,
  empName,
}) {
  return apiFetch("/sort-lots", {
    method: "POST",
    body: JSON.stringify({
      machine,
      lots,
      empCode,
      empName,
    }),
  });
}

export async function clearSortLots({ machine, empCode }) {
  const cleanMachine = String(machine || "").trim().toUpperCase();

  return apiFetch(`/sort-lots/${encodeURIComponent(cleanMachine)}`, {
    method: "DELETE",
    body: JSON.stringify({ empCode }),
  });
}
