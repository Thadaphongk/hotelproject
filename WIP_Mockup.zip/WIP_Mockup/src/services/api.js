import { setMachineNameMap } from "../utils/machineQueueUtils";

const API_BASE_URL = "/api";

async function apiFetch(url, options = {}) {
  const response = await fetch(`${API_BASE_URL}${url}`, {
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {}),
    },
    ...options,
  });

  if (
    response.status === 204 ||
    response.headers.get("content-length") === "0"
  ) {
    return null;
  }

  const data = await response.json().catch(() => null);

  if (!response.ok) {
    const error = new Error(
      data?.message || "เกิดข้อผิดพลาดในการสื่อสารกับเซิร์ฟเวอร์",
    );

    error.status = response.status;
    error.code = data?.code;
    error.data = data;

    throw error;
  }

  return data;
}

export async function fetchEmployee(empCode) {
  const cleanEmpCode = String(empCode || "")
    .trim()
    .toUpperCase();

  if (!cleanEmpCode) return null;

  try {
    const response = await fetch(
      `${API_BASE_URL}/user-access/employee/${encodeURIComponent(cleanEmpCode)}`,
    );

    const data = await response.json().catch(() => null);

    if (!response.ok) {
      if (data?.code === "EMPLOYEE_NOT_FOUND" || response.status === 404) {
        return null;
      }

      throw new Error(data?.message || "โหลดข้อมูล Demo Userไม่สำเร็จ");
    }

    const employee = data.employee;

    if (!employee) return null;

    const englishName = String(employee.empName || "").trim();

    const thaiName = String(employee.empName_TH || "").trim();

    return {
      id: employee.empCode,
      empCode: employee.empCode,

      name: englishName || thaiName || "-",
      empName: englishName,
      empName_TH: thaiName,
      thaiName,

      displayName:
        englishName && thaiName
          ? `${englishName} (${thaiName})`
          : englishName || thaiName || "-",

      dept: employee.department || "-",
      department: employee.department || "",

      position: employee.position || "-",

      approved: String(data.access?.status || "").toUpperCase() === "APPROVED",

      access: data.access || null,
    };
  } catch (error) {
    console.error("fetchEmployee error:", error);
    throw error;
  }
}

export async function loginEmployee(employeeId) {
  const normalized = employeeId?.trim().toUpperCase();
  if (!normalized) {
    throw new Error("กรุณาใส่ Demo User ID");
  }

  return await apiFetch("/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ employeeId: normalized }),
  });
}

export async function getRequestStatus(empCode) {
  const cleanEmpCode = String(empCode || "")
    .trim()
    .toUpperCase();

  if (!cleanEmpCode) return null;

  const response = await fetch(
    `${API_BASE_URL}/user-access/status/${encodeURIComponent(cleanEmpCode)}`,
  );

  const data = await response.json().catch(() => null);

  if (!response.ok) {
    throw new Error(data?.message || "โหลดสถานะคำขอไม่สำเร็จ");
  }

  const access = data.access;

  if (!access) return null;

  return {
    ...access,

    // Auth.jsx เดิมเช็ก pending / rejected ตัวเล็ก
    status: String(access.status || "").toLowerCase(),

    // เก็บค่าเดิมไว้ด้วย เผื่อใช้ภายหลัง
    statusRaw: access.status,
  };
}

export async function submitAccessRequest(empCode, reason) {
  const cleanEmpCode = String(empCode || "")
    .trim()
    .toUpperCase();

  const response = await fetch(`${API_BASE_URL}/user-access/register`, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      empCode: cleanEmpCode,
      requestReason: reason,
    }),
  });

  const data = await response.json().catch(() => null);

  if (!response.ok) {
    const error = new Error(data?.message || "ส่งคำขอไม่สำเร็จ");
    error.status = response.status;
    error.code = data?.code;
    error.data = data;
    throw error;
  }

  return data.access;
}

export async function getPendingRequests() {
  try {
    const data = await apiFetch("/user-access/requests?status=PENDING");
    return data?.rows || [];
  } catch (error) {
    console.error("Get pending register requests error:", error);
    return [];
  }
}

export async function getApprovedUsers() {
  const data = await apiFetch("/user-access/requests?status=APPROVED");
  return data?.rows || [];
}

export async function updateApprovedUserAccess(
  empCode,
  { updatedBy = "", role = "VIEWER", permissions = {} } = {},
) {
  const normalized = String(empCode || "")
    .trim()
    .toUpperCase();

  if (!normalized) return null;

  return apiFetch(
    `/user-access/users/${encodeURIComponent(normalized)}`,
    {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        updatedBy,
        role,
        permissions,
      }),
    },
  );
}

// Academic demo: these endpoints operate on synthetic in-memory access records only.
export async function getPendingPermissionRequests() {
  const result = await apiFetch("/user-access/permission-requests?status=PENDING");
  return result?.rows || [];
}

export async function submitPermissionRequest(empCode, { permissions = {}, requestReason = "" } = {}) {
  const id = String(empCode || "").trim().toUpperCase();
  if (!id) throw new Error("กรุณา Login ก่อนส่งคำขอ");
  const data = await apiFetch(`/user-access/users/${encodeURIComponent(id)}/permission-request`, {
    method: "POST",
    body: JSON.stringify({ requestedBy: id, permissions, requestReason }),
  });
  return data?.access || null;
}

export async function deleteApprovedUser(empCode, { deletedBy = "" } = {}) {
  const id = String(empCode || "").trim().toUpperCase();
  if (!id) throw new Error("ไม่พบ Demo User ID");
  return apiFetch(`/user-access/users/${encodeURIComponent(id)}`, {
    method: "DELETE", body: JSON.stringify({ deletedBy }),
  });
}

export async function approveRequest(
  empCode,
  { approvedBy = "", role = "VIEWER", permissions = {} } = {},
) {
  const normalized = String(empCode || "")
    .trim()
    .toUpperCase();

  if (!normalized) return null;

  return apiFetch(
    `/user-access/requests/${encodeURIComponent(normalized)}/approve`,
    {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        approvedBy,
        role,
        permissions,
      }),
    },
  );
}

export async function rejectRequest(empCode, { rejectReason = "" } = {}) {
  const normalized = String(empCode || "")
    .trim()
    .toUpperCase();

  if (!normalized) return null;

  return apiFetch(
    `/user-access/requests/${encodeURIComponent(normalized)}/reject`,
    {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        rejectReason,
      }),
    },
  );
}


let machineLineMapCache = null;
let machineLineMapCacheTime = 0;

export const getMachineLineMap = async ({ force = false } = {}) => {
  const now = Date.now();

  if (
    !force &&
    machineLineMapCache &&
    now - machineLineMapCacheTime < 30000
  ) {
    setMachineNameMap(machineLineMapCache);
    return machineLineMapCache;
  }

  const response = await fetch(`${API_BASE_URL}/machine-line-map`, {
    cache: "no-store",
  });

  const data = await response.json().catch(() => null);

  if (!response.ok) {
    throw new Error(data?.message || "Failed to fetch machine line mapping");
  }

  const mapping = data?.mapping || {};
  machineLineMapCache = mapping;
  machineLineMapCacheTime = Date.now();
  setMachineNameMap(mapping);

  return mapping;
};

export async function getLineInformation({ empCode = "" } = {}) {
  const normalizedEmpCode = String(empCode || "")
    .trim()
    .toUpperCase();

  if (!normalizedEmpCode) {
    throw new Error("กรุณาเข้าสู่ระบบก่อนดู Line Information");
  }

  return apiFetch("/line-information", {
    method: "GET",
    headers: {
      "X-Employee-Id": normalizedEmpCode,
    },
  });
}

const machinesCache = new Map();
const machinesInFlight = new Map();

let machinesCacheVersion = 0;

export const clearMachinesCache = () => {
  machinesCacheVersion += 1;
  machinesCache.clear();
  machinesInFlight.clear();
};

const getMachinesCacheKey = (options = {}) => {
  const params = new URLSearchParams();

  if (options.includeTechnical) {
    params.set("includeTechnical", "1");
  }

  if (options.includeMoveLot) {
    params.set("includeMoveLot", "1");
  }

  if (options.preservePhysical) {
    params.set("preservePhysical", "1");
  }

  return params.toString();
};

export const getMachines = async (options = {}) => {
  const params = new URLSearchParams();

  if (options.includeTechnical) {
    params.set("includeTechnical", "1");
  }

  if (options.includeMoveLot) {
    params.set("includeMoveLot", "1");
  }

  if (options.preservePhysical) {
    params.set("preservePhysical", "1");
  }

  // ล้าง Technical Cache เฉพาะตอนระบุโดยตรงเท่านั้น
  if (options.refreshTechnical) {
    params.set("refreshTechnical", "1");
  }

  const queryString = params.toString();
  const cacheKey = getMachinesCacheKey(options);

  // โหลด Mapping Line -> Machine ล่าสุดจาก demo mapping service ควบคู่กับข้อมูล Queue
  // หาก Mapping API มีปัญหา ให้ Queue หลักยังโหลดต่อได้ตามปกติ
  const lineMapPromise = getMachineLineMap({ force: Boolean(options.force) }).catch(
    (error) => {
      console.warn("Load machine line mapping failed:", error);
      return null;
    },
  );

  /*
   * force = ต้องการ Snapshot ล่าสุดจริง ๆ
   * - ทิ้ง resolved cache ของ key นี้
   * - ตัด reference ของ in-flight เดิมออก
   * - เพิ่ม version เพื่อกัน request เก่าที่จบช้ากว่า
   *   กลับมาเขียน cache ทับข้อมูลใหม่
   */
  if (options.force) {
    machinesCacheVersion += 1;
    machinesCache.delete(cacheKey);
    machinesInFlight.delete(cacheKey);
  }

  const ttlMs = options.includeTechnical ? 30000 : 10000;
  const now = Date.now();

  const cached = machinesCache.get(cacheKey);

  if (!options.force && cached && now - cached.time < ttlMs) {
    await lineMapPromise;
    return cached.data;
  }

  if (!options.force && machinesInFlight.has(cacheKey)) {
    const data = await machinesInFlight.get(cacheKey);
    await lineMapPromise;
    return data;
  }

  const requestVersion = machinesCacheVersion;

  const requestPromise = fetch(
    `${API_BASE_URL}/machines${queryString ? `?${queryString}` : ""}`,
    {
      // Machine Queue เป็นข้อมูลสด: อย่าให้ browser HTTP cache เก็บ response เก่า
      cache: "no-store",
    },
  )
    .then(async (response) => {
      const data = await response.json().catch(() => null);

      if (!response.ok) {
        throw new Error(data?.message || "Failed to fetch machines");
      }

      if (requestVersion === machinesCacheVersion) {
        machinesCache.set(cacheKey, {
          time: Date.now(),
          data,
        });
      }

      return data;
    })
    .finally(() => {
      if (machinesInFlight.get(cacheKey) === requestPromise) {
        machinesInFlight.delete(cacheKey);
      }
    });

  machinesInFlight.set(cacheKey, requestPromise);

  const data = await requestPromise;
  await lineMapPromise;
  return data;
};

export async function getStopLots({
  search = "",
  date = "",
  dateFrom = "",
  dateTo = "",
} = {}) {
  const params = new URLSearchParams();

  if (search) params.set("search", search);

  if (dateFrom) params.set("dateFrom", dateFrom);
  if (dateTo) params.set("dateTo", dateTo);

  // รองรับของเดิมชั่วคราว
  if (!dateFrom && !dateTo && date) {
    params.set("date", date);
  }

  return apiFetch(`/stop-lots?${params.toString()}`);
}

export async function createStopLot({ lotId, empCode, empName, reason }) {
  const data = await apiFetch("/stop-lots", {
    method: "POST",
    body: JSON.stringify({
      lotId,
      empCode,
      empName,
      reason,
    }),
  });

  // Hold สำเร็จแล้ว Snapshot ของ Machine Queue เดิมใช้ต่อไม่ได้
  clearMachinesCache();

  return data;
}

export async function clearStopLot({ id, empCode }) {
  const data = await apiFetch(`/stop-lots/${encodeURIComponent(id)}/clear`, {
    method: "PATCH",
    body: JSON.stringify({
      empCode,
    }),
  });

  // Clear Hold แล้ว Lot อาจกลับเข้าคิวได้ทันที ถ้ายังอยู่ใน demo queue
  clearMachinesCache();

  return data;
}
