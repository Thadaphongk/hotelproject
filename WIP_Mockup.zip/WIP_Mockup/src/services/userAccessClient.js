const API_BASE_URL = "/api";

const apiFetch = async (path, options = {}) => {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {}),
    },
    ...options,
  });

  const data = await response.json().catch(() => null);

  if (!response.ok) {
    const error = new Error(
      data?.message || `Request failed with status ${response.status}`,
    );

    error.status = response.status;
    error.code = data?.code;
    error.data = data;

    throw error;
  }

  return data;
};

export async function checkRegisterEmployee(empCode) {
  const cleanEmpCode = String(empCode || "").trim();

  return apiFetch(`/user-access/employee/${encodeURIComponent(cleanEmpCode)}`);
}

export async function getUserAccessStatus(empCode) {
  const cleanEmpCode = String(empCode || "").trim();

  return apiFetch(`/user-access/status/${encodeURIComponent(cleanEmpCode)}`);
}

export async function createRegisterRequest({ empCode, requestReason }) {
  return apiFetch("/user-access/register", {
    method: "POST",
    body: JSON.stringify({
      empCode,
      requestReason,
    }),
  });
}