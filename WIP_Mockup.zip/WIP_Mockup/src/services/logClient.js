const API_BASE_URL = "/api";

const pad2 = (value) => String(value).padStart(2, "0");

const getTodayDateKey = () => {
  const now = new Date();
  return `${now.getFullYear()}-${pad2(now.getMonth() + 1)}-${pad2(
    now.getDate()
  )}`;
};

const getStoredUser = () => {
  try {
    const stored = window.localStorage.getItem("wip_demo_user");
    if (!stored) return null;

    return JSON.parse(stored);
  } catch {
    return null;
  }
};

const getEffectiveUser = (user) => {
  return user || getStoredUser();
};

const getUserId = (user) => {
  const effectiveUser = getEffectiveUser(user);

  return String(
    effectiveUser?.id ||
      effectiveUser?.empCode ||
      effectiveUser?.employeeId ||
      "GUEST"
  )
    .trim()
    .toUpperCase();
};

const getUserName = (user) => {
  const effectiveUser = getEffectiveUser(user);

  return String(
    effectiveUser?.name ||
      effectiveUser?.empName ||
      effectiveUser?.empName_TH ||
      "Guest"
  ).trim();
};

export async function writeActivityLog({
  user = null,
  type = "ACTIVITY",
  level = "INFO",
  page = "-",
  action = "-",
  machine = "",
  lot = "",
  result = "",
  message = "",
  meta = {},
} = {}) {
  try {
    const payload = {
      date: getTodayDateKey(),
      time: new Date().toISOString(),
      type,
      level,
      userId: getUserId(user),
      userName: getUserName(user),
      page,
      action,
      machine,
      lot,
      result,
      message,
      meta,
    };

    await fetch(`${API_BASE_URL}/logs`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });

    return true;
  } catch (error) {
    console.warn("Failed to write activity log:", error);
    return false;
  }
}

export async function getActivityLogs({
  date = getTodayDateKey(),
  type = "",
  level = "",
  userId = "",
  machine = "",
  lot = "",
  search = "",
} = {}) {
  const params = new URLSearchParams();

  if (date) params.set("date", date);
  if (type) params.set("type", type);
  if (level) params.set("level", level);
  if (userId) params.set("userId", userId);
  if (machine) params.set("machine", machine);
  if (lot) params.set("lot", lot);
  if (search) params.set("search", search);

  const response = await fetch(`${API_BASE_URL}/logs?${params.toString()}`);

  if (!response.ok) {
    throw new Error("Failed to fetch logs");
  }

  const data = await response.json();

  return {
    ...data,
    logs: data.rows || data.logs || [],
  };
}

export async function writeLog(logInput = {}) {
  return writeActivityLog(logInput);
}

export async function writeLogs(logInputs = [], options = {}) {
  try {
    const logs = Array.isArray(logInputs) ? logInputs : [];

    if (logs.length === 0) {
      return false;
    }

    const user = options.user || null;

    const payload = {
      logs: logs.map((item) => ({
        date: item.date || getTodayDateKey(),
        time: item.time || new Date().toISOString(),

        type: item.type || "ACTIVITY",
        level: item.level || "INFO",

        userId: item.userId || getUserId(item.user || user),
        userName: item.userName || getUserName(item.user || user),

        page: item.page || "-",
        action: item.action || "-",

        machine: item.machine || "",
        lot: item.lot || "",

        result: item.result || "",
        message: item.message || "",

        meta: item.meta && typeof item.meta === "object" ? item.meta : {},
      })),
    };

    await fetch(`${API_BASE_URL}/logs/bulk`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });

    return true;
  } catch (error) {
    console.warn("Failed to write bulk activity logs:", error);
    return false;
  }
}