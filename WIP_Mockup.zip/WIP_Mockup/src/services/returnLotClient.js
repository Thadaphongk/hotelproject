const API_BASE_URL = "/api";

const apiFetch = async (path, options = {}) => {
  const response = await fetch(`${API_BASE_URL}${path}`, {
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {}),
    },
    ...options,
  });

  const data = await response.json().catch(() => null);

  if (!response.ok) {
    const error = new Error(
      data?.message || `Request failed with status ${response.status}`,
    );

    error.status = response.status;
    error.code = data?.code;
    error.data = data;

    throw error;
  }

  return data;
};

export async function getReturnLots({
  line = "DEMO",
  search = "",
  date = "",
  dateFrom = "",
  dateTo = "",
} = {}) {
  const params = new URLSearchParams();

  if (line) params.set("line", line);
  if (search) params.set("search", search);

  if (dateFrom) params.set("dateFrom", dateFrom);
  if (dateTo) params.set("dateTo", dateTo);

  // รองรับของเดิมชั่วคราว
  if (!dateFrom && !dateTo && date) {
    params.set("date", date);
  }

  return apiFetch(`/return-lots?${params.toString()}`);
}

export async function createReturnLot({
  lotId,
  idemp,
  empName,
  reason,
  line = "DEMO",
}) {
  return apiFetch("/return-lots", {
    method: "POST",
    body: JSON.stringify({
      lotId,
      idemp,
      empName,
      reason,
      line,
    }),
  });
}