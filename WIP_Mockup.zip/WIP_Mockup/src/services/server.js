import express from "express";
import path from "path";
import { fileURLToPath } from "url";
import {
  DEMO_LINE_MAPPING,
  DEMO_MACHINE_OPTIONS,
  clone,
  demoEmployees,
  demoLineInformation,
  initialActivityLogs,
  initialMachines,
  initialMoveHistory,
  initialReturnHistory,
  initialStopHistory,
  initialUserAccess,
  toLocalDate,
  toLocalDateTime,
  viewerPermissions,
} from "../demo/demoData.js";

const app = express();
const host = "127.0.0.1";
const port = 3000;

app.use(express.json({ limit: "1mb" }));

let machines = clone(initialMachines);
let userAccess = clone(initialUserAccess);
let moveHistory = clone(initialMoveHistory);
let returnHistory = clone(initialReturnHistory);
let stopHistory = clone(initialStopHistory);
let activityLogs = clone(initialActivityLogs);
let verificationRows = [];
const manualSequences = new Map();

const normalize = (value) => String(value ?? "").trim().toUpperCase();
const nowText = () => toLocalDateTime(new Date());
const makeId = (prefix) => `${prefix}-${Date.now()}-${Math.floor(Math.random() * 1000)}`;

const findEmployee = (empCode) =>
  demoEmployees.find((item) => normalize(item.empCode) === normalize(empCode)) || null;

const findAccess = (empCode) =>
  userAccess.find((item) => normalize(item.empCode) === normalize(empCode)) || null;

const employeePayload = (employee) => ({
  ...employee,
  id: employee.empCode,
  employeeId: employee.empCode,
  name: employee.empName,
  thaiName: employee.empName_TH,
  displayName:
    employee.empName && employee.empName_TH
      ? `${employee.empName} (${employee.empName_TH})`
      : employee.empName || employee.empName_TH,
  dept: employee.department,
  approved: normalize(findAccess(employee.empCode)?.status) === "APPROVED",
});

const accessPayload = (access) => {
  if (!access) return null;
  const employee = findEmployee(access.empCode) || {};
  return {
    ...access,
    empName: employee.empName || "Demo User",
    name: employee.empName || "Demo User",
    empName_TH: employee.empName_TH || "",
    department: employee.department || "Demo Department",
    dept: employee.department || "Demo Department",
    position: employee.position || "Demo Role",
    permissionRequest: access.permissionRequest || null,
    employeeId: access.empCode,
  };
};

const findLot = (lotId) => {
  const wanted = normalize(lotId);
  for (const machine of machines) {
    const lot = (machine.lots || []).find((item) => normalize(item.lotId) === wanted);
    if (lot) return { machine, lot };
  }
  return null;
};

const isActiveHold = (lotId) =>
  stopHistory.some((row) => row.active && normalize(row.lotId) === normalize(lotId));

const sortLots = (machineName, lots) => {
  const saved = manualSequences.get(normalize(machineName));
  const rank = new Map((saved || []).map((lotId, index) => [normalize(lotId), index]));

  return [...lots]
    .sort((a, b) => {
      const aRank = rank.has(normalize(a.lotId)) ? rank.get(normalize(a.lotId)) : 9999;
      const bRank = rank.has(normalize(b.lotId)) ? rank.get(normalize(b.lotId)) : 9999;
      if (aRank !== bRank) return aRank - bRank;
      return Number(a.queueNo || 999) - Number(b.queueNo || 999);
    })
    .map((lot, index) => ({ ...lot, queueNo: index + 1, manualSequence: rank.has(normalize(lot.lotId)) ? index + 1 : "" }));
};

const getMachineSnapshot = () => {
  // Display moved lots under their current demo destination, never duplicate source rows.
  const allLots = machines.flatMap((machine) => (machine.lots || []).map((lot) => ({ ...lot, initialMachine: machine.machineName })));
  return machines.map((machine) => ({
    ...clone(machine),
    lots: sortLots(machine.machineName, allLots
      .filter((lot) => normalize(lot.targetMachine || lot.initialMachine) === normalize(machine.machineName))
      .filter((lot) => !isActiveHold(lot.lotId))
      .map((lot) => ({ ...lot, machineName: machine.machineName, queueMachine: machine.machineName }))),
  }));
};

const dateInRange = (value, from, to) => {
  const date = String(value || "").slice(0, 10);
  if (!date) return true;
  if (from && date < from) return false;
  if (to && date > to) return false;
  return true;
};

const filterHistory = (rows, query, searchFields = []) => {
  const search = normalize(query.search);
  const from = query.dateFrom || query.date || "";
  const to = query.dateTo || query.date || "";
  return rows.filter((row) => {
    const dateValue = row.dateTime || row.createdAt || row.time || row.date || "";
    if (!dateInRange(dateValue, from, to)) return false;
    if (!search) return true;
    return searchFields.some((field) => normalize(row[field]).includes(search));
  });
};

app.get("/api/health", (_req, res) => {
  res.json({ ok: true, mode: "ACADEMIC_DEMO", dataSource: "synthetic-memory" });
});

app.get("/api/employees/:employeeId", (req, res) => {
  const employee = findEmployee(req.params.employeeId);
  if (!employee) return res.status(404).json({ code: "EMPLOYEE_NOT_FOUND", message: "Demo user not found" });
  return res.json(employeePayload(employee));
});

app.post("/api/login", (req, res) => {
  const empCode = normalize(req.body?.employeeId);
  if (!empCode) return res.status(400).json({ message: "กรุณาใส่ Demo User ID" });

  const employee = findEmployee(empCode);
  if (!employee) return res.status(404).json({ code: "EMPLOYEE_NOT_FOUND", message: "ไม่พบ Demo User ID นี้" });

  const access = findAccess(empCode);
  if (!access) return res.status(403).json({ code: "REGISTER_REQUIRED", message: "Demo user นี้ยังไม่ได้ขอสิทธิ์" });

  const status = normalize(access.status);
  const statusCode = {
    PENDING: "PENDING_APPROVAL",
    REJECTED: "ACCESS_REJECTED",
    DISABLED: "ACCESS_DISABLED",
  }[status];

  if (status !== "APPROVED") {
    return res.status(403).json({ code: statusCode || "ACCESS_NOT_APPROVED", message: "Demo user นี้ยังไม่ได้รับอนุมัติ", access: accessPayload(access) });
  }

  return res.json({
    ...employeePayload(employee),
    role: access.role,
    permissions: access.permissions || viewerPermissions,
    isAdmin: normalize(access.role) === "ADMIN",
    access: accessPayload(access),
  });
});

app.get("/api/user-access/employee/:empCode", (req, res) => {
  const employee = findEmployee(req.params.empCode);
  if (!employee) return res.status(404).json({ code: "EMPLOYEE_NOT_FOUND", message: "Demo user not found" });
  res.json({ employee: employeePayload(employee), access: accessPayload(findAccess(employee.empCode)) });
});

app.get("/api/user-access/status/:empCode", (req, res) => {
  res.json({ access: accessPayload(findAccess(req.params.empCode)) });
});

app.post("/api/user-access/register", (req, res) => {
  const empCode = normalize(req.body?.empCode);
  const employee = findEmployee(empCode);
  if (!employee) return res.status(404).json({ code: "EMPLOYEE_NOT_FOUND", message: "Demo user not found" });

  let access = findAccess(empCode);
  if (!access) {
    access = {
      empCode,
      status: "PENDING",
      role: "VIEWER",
      permissions: clone(viewerPermissions),
      requestReason: String(req.body?.requestReason || "Demo access request"),
      requestedAt: nowText(),
    };
    userAccess.push(access);
  } else {
    access.status = "PENDING";
    access.requestReason = String(req.body?.requestReason || access.requestReason || "Demo access request");
    access.requestedAt = nowText();
  }
  res.status(201).json({ ok: true, access: accessPayload(access) });
});

app.get("/api/user-access/requests", (req, res) => {
  const status = normalize(req.query.status);
  const rows = userAccess
    .filter((item) => !status || normalize(item.status) === status)
    .map(accessPayload);
  res.json({ ok: true, total: rows.length, rows });
});

app.patch("/api/user-access/requests/:empCode/approve", (req, res) => {
  const access = findAccess(req.params.empCode);
  if (!access) return res.status(404).json({ message: "Demo access request not found" });
  access.status = "APPROVED";
  access.role = normalize(req.body?.role || "VIEWER");
  access.permissions = { ...viewerPermissions, ...(req.body?.permissions || {}) };
  access.approvedBy = normalize(req.body?.approvedBy || "DEMO-ADMIN");
  access.approvedAt = nowText();
  res.json({ ok: true, access: accessPayload(access) });
});

app.patch("/api/user-access/requests/:empCode/reject", (req, res) => {
  const access = findAccess(req.params.empCode);
  if (!access) return res.status(404).json({ message: "Demo access request not found" });
  access.status = "REJECTED";
  access.rejectReason = String(req.body?.rejectReason || "Rejected in demo");
  access.updatedAt = nowText();
  res.json({ ok: true, access: accessPayload(access) });
});

app.patch("/api/user-access/users/:empCode", (req, res) => {
  const access = findAccess(req.params.empCode);
  if (!access) return res.status(404).json({ message: "Demo user access not found" });
  access.role = normalize(req.body?.role || access.role || "VIEWER");
  access.permissions = { ...viewerPermissions, ...(req.body?.permissions || access.permissions || {}) };
  access.updatedBy = normalize(req.body?.updatedBy || "DEMO-ADMIN");
  access.updatedAt = nowText();
  if (access.permissionRequest?.status === "PENDING") {
    access.permissionRequest.status = "REVIEWED";
    access.permissionRequest.reviewedBy = access.updatedBy;
    access.permissionRequest.reviewedAt = access.updatedAt;
  }
  res.json({ ok: true, access: accessPayload(access) });
});

// Permission request and deletion are simulations; no real account or DB is modified.
app.get("/api/user-access/permission-requests", (req, res) => {
  const status = normalize(req.query.status);
  const rows = userAccess.filter((row) => row.permissionRequest && (!status || normalize(row.permissionRequest.status) === status)).map(accessPayload);
  res.json({ ok: true, total: rows.length, rows });
});

app.post("/api/user-access/users/:empCode/permission-request", (req, res) => {
  const access = findAccess(req.params.empCode);
  if (!access || normalize(access.status) !== "APPROVED") return res.status(404).json({ code: "USER_NOT_APPROVED", message: "ไม่พบ Demo User ที่ได้รับอนุมัติ" });
  if (normalize(access.role) === "ADMIN") return res.status(400).json({ message: "Demo Admin มีสิทธิ์ครบแล้ว" });
  if (access.permissionRequest?.status === "PENDING") return res.status(409).json({ code: "ALREADY_PENDING", message: "มีคำขอสิทธิ์รอตรวจสอบอยู่แล้ว" });
  const requested = req.body?.permissions || {};
  const allowedKeys = Object.keys(viewerPermissions);
  const selected = Object.fromEntries(allowedKeys.filter((key) => requested[key] === true && access.permissions?.[key] !== true).map((key) => [key, true]));
  if (!Object.keys(selected).length) return res.status(400).json({ message: "กรุณาเลือกสิทธิ์ที่ยังไม่ได้รับ" });
  access.permissionRequest = { status: "PENDING", permissions: selected, requestReason: String(req.body?.requestReason || "").slice(0, 500), requestedAt: nowText(), requestedBy: access.empCode };
  res.status(201).json({ ok: true, access: accessPayload(access) });
});

app.delete("/api/user-access/users/:empCode", (req, res) => {
  const empCode = normalize(req.params.empCode);
  const actor = normalize(req.body?.deletedBy);
  if (!findAccess(empCode)) return res.status(404).json({ message: "ไม่พบบัญชีสาธิต" });
  if (!actor || normalize(findAccess(actor)?.role) !== "ADMIN") return res.status(403).json({ message: "เฉพาะ Demo Admin เท่านั้นที่ลบได้" });
  if (actor === empCode || empCode === "DEMO-ADMIN") return res.status(400).json({ message: "ไม่อนุญาตให้ลบ Admin หลักหรือบัญชีตนเอง" });
  userAccess = userAccess.filter((row) => normalize(row.empCode) !== empCode);
  res.json({ ok: true, deleted: empCode, deletedBy: actor });
});

app.get("/api/machine-line-map", (_req, res) => {
  res.json({ ok: true, source: "Synthetic demo mapping", mapping: clone(DEMO_LINE_MAPPING), updatedAt: demoLineInformation[0]?.updatedAt || nowText() });
});

app.get("/api/line-information", (req, res) => {
  const empCode = normalize(req.headers["x-employee-id"]);
  const access = findAccess(empCode);
  if (!access || !access.permissions?.lineInfo) {
    return res.status(403).json({ code: "FORBIDDEN", message: "Demo account นี้ไม่มีสิทธิ์ดู Line Information" });
  }
  res.json({ ok: true, source: "Synthetic demo mapping", rows: clone(demoLineInformation), updatedAt: demoLineInformation[0]?.updatedAt || nowText() });
});

app.get("/api/machines", (_req, res) => {
  res.json(getMachineSnapshot());
});

app.get("/api/move-lots/lookup/:lotId", (req, res) => {
  const match = findLot(req.params.lotId);
  if (!match) return res.status(404).json({ code: "LOT_NOT_FOUND", message: "ไม่พบ Demo Lot นี้" });
  const lastMove = [...moveHistory].reverse().find((row) => normalize(row.lotId) === normalize(match.lot.lotId));
  const lot = match.lot;
  res.json({
    ok: true,
    lot: {
      lotId: lot.lotId,
      partName: lot.partName,
      fromMachine: lot.targetMachine || match.machine.machineName,
      currentMachine: lot.targetMachine || match.machine.machineName,
      originalMachine: lot.originalMachine || match.machine.machineName,
      machineLine: lot.lineName,
      wipMachine: lot.queueMachine,
      statusProcess: lot.processStatus,
      mcStatus: lot.machineStatus,
      lossCode: lot.stopCode || "-",
      isMoved: Boolean(lastMove),
    },
  });
});

app.get("/api/move-lots", (req, res) => {
  const rows = filterHistory(moveHistory, req.query, ["lotId", "partName", "fromMachine", "toMachine", "reason", "emp", "name"])
    .filter((row) => !req.query.machine || normalize(row.fromMachine) === normalize(req.query.machine) || normalize(row.toMachine) === normalize(req.query.machine));
  res.json({ ok: true, total: rows.length, rows: clone(rows) });
});

app.post("/api/move-lots", (req, res) => {
  const lotId = normalize(req.body?.lotId);
  const found = findLot(lotId);
  if (!found) return res.status(404).json({ code: "LOT_NOT_FOUND", message: "ไม่พบ Demo Lot นี้" });

  const toMachine = normalize(req.body?.toMachine);
  if (!DEMO_MACHINE_OPTIONS.includes(toMachine)) return res.status(400).json({ message: "เครื่องปลายทางไม่อยู่ใน Demo Machine List" });
  const fromMachine = normalize(req.body?.fromMachine || found.machine.machineName);
  if (fromMachine === toMachine) return res.status(400).json({ message: "เครื่องต้นทางและปลายทางต้องไม่เหมือนกัน" });

  const record = {
    id: makeId("MOVE-DEMO"),
    lotId: found.lot.lotId,
    partName: found.lot.partName,
    fromMachine,
    toMachine,
    reason: String(req.body?.reason || "Demo move"),
    etc: String(req.body?.etc || ""),
    emp: normalize(req.body?.emp || "DEMO-OP01"),
    name: String(req.body?.name || "Demo User"),
    line: "DEMO",
    dateTime: nowText(),
  };
  moveHistory.unshift(record);
  found.lot.originalMachine = found.lot.originalMachine || fromMachine;
  found.lot.targetMachine = toMachine;
  found.lot.displayMachine = toMachine;
  found.lot.moveStatus = "MOVED";
  res.status(201).json({ ok: true, record: clone(record) });
});

app.get("/api/return-lots", (req, res) => {
  const rows = filterHistory(returnHistory, req.query, ["lotId", "issueReason", "reportedBy", "reportedByName"]);
  res.json({ ok: true, total: rows.length, rows: clone(rows) });
});

app.post("/api/return-lots", (req, res) => {
  const employeeId = normalize(req.body?.empCode || req.body?.idemp || req.body?.reportedBy || req.body?.employeeId);
  if (!employeeId || normalize(findAccess(employeeId)?.status) !== "APPROVED" || !(findAccess(employeeId)?.permissions?.returnLot || normalize(findAccess(employeeId)?.role) === "ADMIN")) return res.status(403).json({ message: "กรุณาเข้าสู่ระบบ Demo ด้วยบัญชีที่มีสิทธิ์ Return Lot" });
  const lotId = normalize(req.body?.lotId);
  if (!findLot(lotId)) return res.status(404).json({ code: "LOT_NOT_FOUND", message: "ไม่พบ Demo Lot นี้" });
  const row = {
    id: makeId("RETURN-DEMO"),
    lotId,
    issueReason: String(req.body?.reason || "Demo return reason"),
    reportedBy: normalize(req.body?.idemp || "DEMO-OP01"),
    reportedByName: String(req.body?.empName || "Demo User"),
    lineName: "DEMO",
    createdAt: nowText(),
  };
  returnHistory.unshift(row);
  res.status(201).json({ ok: true, record: clone(row) });
});

app.get("/api/stop-lots", (req, res) => {
  const rows = filterHistory(stopHistory.filter((row) => row.active), req.query, ["lotId", "holdReason", "createdBy", "createdByName"]);
  res.json({ ok: true, total: rows.length, rows: clone(rows) });
});

app.post("/api/stop-lots", (req, res) => {
  const lotId = normalize(req.body?.lotId);
  if (!findLot(lotId)) return res.status(404).json({ code: "LOT_NOT_FOUND", message: "ไม่พบ Demo Lot นี้" });
  if (isActiveHold(lotId)) return res.status(409).json({ message: "Demo Lot นี้อยู่ในสถานะพักอยู่แล้ว" });
  const row = {
    id: makeId("HOLD-DEMO"),
    lotId,
    holdReason: String(req.body?.reason || "Demo hold reason"),
    createdBy: normalize(req.body?.empCode || "DEMO-OP01"),
    createdByName: String(req.body?.empName || "Demo User"),
    createdAt: nowText(),
    active: true,
  };
  stopHistory.unshift(row);
  res.status(201).json({ ok: true, record: clone(row) });
});

app.patch("/api/stop-lots/:id/clear", (req, res) => {
  const row = stopHistory.find((item) => item.id === req.params.id && item.active);
  if (!row) return res.status(404).json({ message: "Demo hold record not found" });
  row.active = false;
  row.clearedBy = normalize(req.body?.empCode || "DEMO-OP01");
  row.clearedAt = nowText();
  res.json({ ok: true, record: clone(row) });
});

app.get("/api/sort-lots/:machine", (req, res) => {
  const machineName = normalize(req.params.machine);
  const machine = getMachineSnapshot().find((item) => normalize(item.machineName) === machineName);
  if (!machine) return res.status(404).json({ message: "Demo machine not found" });
  res.json({ ok: true, machine: machineName, queueMachine: machineName, total: machine.lots.length, rows: clone(machine.lots) });
});

app.post("/api/sort-lots", (req, res) => {
  const machineName = normalize(req.body?.machine);
  const lotIds = Array.isArray(req.body?.lots)
    ? req.body.lots.map((item) => normalize(typeof item === "string" ? item : item?.lotId)).filter(Boolean)
    : [];
  const machine = machines.find((item) => normalize(item.machineName) === machineName);
  if (!machine) return res.status(404).json({ message: "Demo machine not found" });
  const valid = new Set((machine.lots || []).map((item) => normalize(item.lotId)));
  if (lotIds.some((id) => !/^LOT-DEMO-\d{3}$/.test(id) || !valid.has(id))) {
    return res.status(400).json({ message: "ลำดับมี Demo Lot ที่ไม่อยู่ในเครื่องนี้" });
  }
  manualSequences.set(machineName, lotIds);
  const rows = sortLots(machineName, machine.lots || []);
  res.json({ ok: true, machine: machineName, total: rows.length, rows: clone(rows), savedBy: normalize(req.body?.empCode || "DEMO-OP01"), savedAt: nowText() });
});

app.delete("/api/sort-lots/:machine", (req, res) => {
  const machineName = normalize(req.params.machine);
  manualSequences.delete(machineName);
  res.json({ ok: true, machine: machineName, clearedBy: normalize(req.body?.empCode || "DEMO-OP01"), clearedAt: nowText() });
});

app.get("/api/machine-verifications", (req, res) => {
  const date = String(req.query.date || toLocalDate(new Date()));
  const rows = verificationRows.filter((row) => row.date === date);
  res.json({ ok: true, date, total: rows.length, rows: clone(rows) });
});

app.post("/api/machine-verifications/bulk", (req, res) => {
  const rows = Array.isArray(req.body?.rows) ? req.body.rows : [];
  const date = String(req.body?.date || rows[0]?.date || toLocalDate(new Date()));
  verificationRows = verificationRows.filter((row) => row.date !== date);
  verificationRows.push(...rows.map((row) => ({ ...row, date, savedAt: nowText() })));
  res.json({ ok: true, date, total: rows.length, rows: clone(rows) });
});

app.get("/api/logs", (req, res) => {
  const rows = filterHistory(activityLogs, req.query, ["userId", "userName", "page", "action", "machine", "lot", "message", "type", "level"])
    .filter((row) => !req.query.type || normalize(row.type) === normalize(req.query.type))
    .filter((row) => !req.query.level || normalize(row.level) === normalize(req.query.level))
    .filter((row) => !req.query.userId || normalize(row.userId) === normalize(req.query.userId))
    .filter((row) => !req.query.machine || normalize(row.machine) === normalize(req.query.machine))
    .filter((row) => !req.query.lot || normalize(row.lot) === normalize(req.query.lot));
  res.json({ ok: true, total: rows.length, rows: clone(rows) });
});

app.post("/api/logs", (req, res) => {
  const row = { id: makeId("LOG-DEMO"), ...req.body, date: req.body?.date || toLocalDate(new Date()), time: req.body?.time || new Date().toISOString() };
  activityLogs.unshift(row);
  res.status(201).json({ ok: true, record: clone(row) });
});

app.post("/api/logs/bulk", (req, res) => {
  const rows = Array.isArray(req.body?.logs) ? req.body.logs : [];
  const added = rows.map((item) => ({ id: makeId("LOG-DEMO"), ...item, date: item.date || toLocalDate(new Date()), time: item.time || new Date().toISOString() }));
  activityLogs.unshift(...added);
  res.status(201).json({ ok: true, total: added.length, rows: clone(added) });
});

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const distDir = path.resolve(__dirname, "../../dist");
app.use(express.static(distDir));
app.get("/{*splat}", (_req, res) => res.sendFile(path.join(distDir, "index.html")));

app.listen(port, host, () => {
  console.log(`WIP Academic Demo listening on http://${host}:${port}`);
});
