export const APP_VERSION = "v1.0.0-demo";
export const APP_BUILD_LABEL = "ACADEMIC DEMO";
