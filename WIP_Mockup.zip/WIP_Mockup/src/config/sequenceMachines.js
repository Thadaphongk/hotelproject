export const SEQUENCE_MACHINE_OPTIONS = [
  { display: "DEMO-MC-A01", queue: "DEMO-MC-A01" },
  { display: "DEMO-MC-A02", queue: "DEMO-MC-A02" },
  { display: "DEMO-MC-B01", queue: "DEMO-MC-B01" },
  { display: "DEMO-MC-B02", queue: "DEMO-MC-B02" },
  { display: "DEMO-MC-C01", queue: "DEMO-MC-C01" },
  { display: "DEMO-MC-C02", queue: "DEMO-MC-C02" },
];

export const SEQUENCE_DISPLAY_MACHINES = SEQUENCE_MACHINE_OPTIONS.map(
  (item) => item.display,
);

export const SEQUENCE_QUEUE_MACHINES = SEQUENCE_MACHINE_OPTIONS.map(
  (item) => item.queue,
);

export const normalizeMachineCode = (value) =>
  String(value ?? "")
    .trim()
    .toUpperCase()
    .replace(/\s+/g, "");

export const toQueueMachineCode = (value) => {
  const clean = normalizeMachineCode(value);
  return SEQUENCE_QUEUE_MACHINES.includes(clean) ? clean : "";
};

export const toDisplayMachineCode = (value) => toQueueMachineCode(value);

export const getSequenceMachine = (value) => {
  const queueMachine = toQueueMachineCode(value);
  return (
    SEQUENCE_MACHINE_OPTIONS.find((item) => item.queue === queueMachine) || null
  );
};

export const isAllowedSequenceMachine = (value) =>
  Boolean(getSequenceMachine(value));
