import DemoGuideButton from "../components/DemoGuideButton";
import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  ChevronDown,
  Download,
  Eraser,
  History,
  PauseCircle,
  RefreshCw,
  Save,
  Search,
  Trash2,
} from "lucide-react";
import { clearStopLot, createStopLot, getStopLots } from "../services/api";
import HorizontalBarChart from "../components/HorizontalBarChart";
import ChartFilterPlaceholder from "../components/ChartFilterPlaceholder";
import CenterAlert from "../components/CenterAlert";
import DateModeFilter from "../components/DateModeFilter";
import {
  DATE_RANGE_ERROR_MESSAGE,
  getCurrentTimeText,
  getDateModeRangeText,
  getEffectiveDateRange,
  hasDateFilterForChart,
  isInvalidDateModeRange,
} from "../utils/dateRangeText";

const reasonOptions = [
  "Quality review",
  "Planned maintenance",
  "Material unavailable",
  "Setup verification",
  "Demo process change",
  "Operator unavailable",
  "Training scenario",
  "อื่นๆ",
];

const getEmpCode = (user) =>
  String(user?.empCode || user?.id || user?.employeeId || "").trim();

const getEmpName = (user) =>
  String(user?.name || user?.empName || user?.displayName || "").trim();

const exportCsv = (rows) => {
  const headers = [
    "No",
    "lotId",
    "Reason",
    "EmpName",
    "operatorId",
    "createdAt",
  ];

  const body = rows.map((row, index) => [
    index + 1,
    row.lotId || "",
    row.holdReason || "",
    row.createdByName || "",
    row.createdBy || "",
    row.createdAt || "",
  ]);

  const csv = [headers, ...body]
    .map((line) =>
      line
        .map((cell) => {
          const text = String(cell ?? "");
          return `"${text.replace(/"/g, '""')}"`;
        })
        .join(","),
    )
    .join("\r\n");

  const blob = new Blob(["\ufeff" + csv], {
    type: "text/csv;charset=utf-8;",
  });

  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");

  link.href = url;
  link.download = `hold-lot-history-${new Date()
    .toISOString()
    .slice(0, 10)}.csv`;

  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);

  URL.revokeObjectURL(url);
};

const buildReasonSummary = (rows) => {
  const map = new Map();

  for (const row of rows || []) {
    const label = String(row.holdReason || row.reason || "-").trim();
    if (!label || label === "-") continue;

    map.set(label, (map.get(label) || 0) + 1);
  }

  return [...map.entries()]
    .map(([label, value]) => ({ label, value }))
    .sort((a, b) => b.value - a.value);
};

export default function HoldLot({ user }) {
  const [lotId, setLotno] = useState("");
  const [reason, setReason] = useState("");
  const [customReason, setCustomReason] = useState("");
  const [reasonDropdownOpen, setReasonDropdownOpen] = useState(false);
  const reasonDropdownRef = useRef(null);

  const [rows, setRows] = useState([]);
  const [search, setSearch] = useState("");
  const [dateMode, setDateMode] = useState("single");
  const [filterDateFrom, setFilterDateFrom] = useState("");
  const [filterDateTo, setFilterDateTo] = useState("");

  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [clearingId, setClearingId] = useState(null);

  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [dateAlertMessage, setDateAlertMessage] = useState("");
  const [alertMessage, setAlertMessage] = useState("");
  const [successTitle, setSuccessTitle] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [confirmAction, setConfirmAction] = useState(null);
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (
        reasonDropdownRef.current &&
        !reasonDropdownRef.current.contains(event.target)
      ) {
        setReasonDropdownOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const resetForm = () => {
    setLotno("");
    setReason("");
    setCustomReason("");
  };

  const empCode = getEmpCode(user);
  const empName = getEmpName(user);

  const finalReason = reason === "อื่นๆ" ? customReason : reason;

  const reasonSummary = useMemo(() => buildReasonSummary(rows), [rows]);

  const [currentDataTimeText, setCurrentDataTimeText] = useState(() =>
    getCurrentTimeText(),
  );

  const canShowCharts = hasDateFilterForChart({
    dateMode,
    dateFrom: filterDateFrom,
    dateTo: filterDateTo,
  });

  const dateRangeInvalid = isInvalidDateModeRange(
    dateMode,
    filterDateFrom,
    filterDateTo,
  );

  const dateRangeText = getDateModeRangeText({
    dateMode,
    dateFrom: filterDateFrom,
    dateTo: filterDateTo,
  });

  const handleFilterDateFromChange = (value) => {
    setFilterDateFrom(value);

    if (dateMode === "single") {
      setFilterDateTo("");
      return;
    }

    if (filterDateTo && value && value > filterDateTo) {
      setFilterDateTo("");
      setDateAlertMessage(
        "วันที่เริ่มต้นมากกว่าวันที่สิ้นสุด ระบบจึงล้างวันที่สิ้นสุดให้ กรุณาเลือกใหม่อีกครั้ง",
      );
    }
  };

  const handleFilterDateToChange = (value) => {
    if (
      dateMode === "range" &&
      filterDateFrom &&
      value &&
      value < filterDateFrom
    ) {
      setDateAlertMessage(DATE_RANGE_ERROR_MESSAGE);
      return;
    }

    setFilterDateTo(value);
  };

  const handleDateModeChange = (nextMode) => {
    setDateMode(nextMode);
    setError("");
    setDateAlertMessage("");

    if (nextMode === "single") {
      setFilterDateTo("");
    }
  };

  const loadRows = async (override = {}) => {
    const nextSearch = override.search ?? search;
    const nextDateMode = override.dateMode ?? dateMode;
    const nextDateFrom = override.dateFrom ?? filterDateFrom;
    const nextDateTo = override.dateTo ?? filterDateTo;

    const effectiveDateRange = getEffectiveDateRange(
      nextDateMode,
      nextDateFrom,
      nextDateTo,
    );

    setLoading(true);
    setError("");

    if (isInvalidDateModeRange(nextDateMode, nextDateFrom, nextDateTo)) {
      setRows([]);
      setError(DATE_RANGE_ERROR_MESSAGE);
      setDateAlertMessage(DATE_RANGE_ERROR_MESSAGE);
      setLoading(false);
      return;
    }

    try {
      const data = await getStopLots({
        search: nextSearch,
        dateFrom: effectiveDateRange.dateFrom,
        dateTo: effectiveDateRange.dateTo,
      });

      setRows(data.rows || []);
    } catch (err) {
      console.error("Load stop lots error:", err);
      setError(err.message || "โหลดประวัติพักงานไม่สำเร็จ");
    } finally {
      setLoading(false);
    }
  };

  const handleClearFilters = async () => {
    setSearch("");
    setDateMode("single");
    setFilterDateFrom("");
    setFilterDateTo("");

    await loadRows({
      search: "",
      dateMode: "single",
      dateFrom: "",
      dateTo: "",
    });
  };

  useEffect(() => {
    const timer = window.setInterval(() => {
      setCurrentDataTimeText(getCurrentTimeText());
    }, 1000);

    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    loadRows();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dateMode, filterDateFrom, filterDateTo]);

  const submitHoldLotRecord = async ({
    lotId: cleanLotno,
    reason: reasonText,
  }) => {
    setSaving(true);

    try {
      const data = await createStopLot({
        lotId: cleanLotno,
        empCode,
        empName,
        reason: reasonText,
      });

      const successText = `บันทึกพัก Lot สำเร็จ\nLot No: ${cleanLotno}`;
      setMessage(data.message || "บันทึกพัก Lot เรียบร้อยแล้ว");
      setSuccessTitle("บันทึกข้อมูลสำเร็จ");
      setSuccessMessage(successText);
      setLotno("");
      setReason("");
      setCustomReason("");

      try {
        await loadRows();
      } catch (refreshError) {
        console.error("Refresh hold lot rows after save error:", refreshError);
      }
    } catch (err) {
      console.error("Create stop lot error:", err);

      if (err.code === "LOT_NOT_FOUND" || err.status === 404) {
        setAlertMessage(err.message || "ไม่พบ Lot No นี้ในฐานข้อมูล");
        return;
      }

      setAlertMessage(err.message || "บันทึกพัก Lot ไม่สำเร็จ");
    } finally {
      setSaving(false);
    }
  };

  const clearHoldLotRecord = async (row) => {
    setClearingId(row.id);
    setMessage("");
    setError("");

    try {
      const data = await clearStopLot({
        id: row.id,
        empCode,
      });

      const clearedLotno = row?.lotId || row?.lotId || "-";
      const successText = `Clear พัก Lot สำเร็จ\nLot No: ${clearedLotno}`;

      setMessage(data.message || "Clear รายการพัก Lot เรียบร้อยแล้ว");
      setSuccessTitle("Clear พัก Lot สำเร็จ");
      setSuccessMessage(successText);

      try {
        await loadRows();
      } catch (refreshError) {
        console.error(
          "Refresh hold lot rows after clear error:",
          refreshError,
        );
      }
    } catch (err) {
      console.error("Clear stop lot error:", err);
      setAlertMessage(err.message || "Clear รายการพัก Lot ไม่สำเร็จ");
    } finally {
      setClearingId(null);
    }
  };

  const handleConfirmAction = async () => {
    const action = confirmAction;
    if (!action) return;

    setConfirmAction(null);

    if (action.type === "SAVE") {
      await submitHoldLotRecord({
        lotId: action.lotId,
        reason: action.reason,
      });
      return;
    }

    if (action.type === "CLEAR") {
      await clearHoldLotRecord(action.row);
    }
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    const cleanLotno = lotId.trim().toUpperCase();
    const reasonText = finalReason.trim();

    setMessage("");
    setError("");
    setAlertMessage("");

    if (!empCode || !empName) {
      setAlertMessage("ไม่พบข้อมูลผู้ใช้งาน กรุณา Login ใหม่");
      return;
    }

    if (!cleanLotno) {
      setAlertMessage("กรุณากรอก Lot No");
      return;
    }

    if (!reasonText) {
      setAlertMessage("กรุณาเลือกหรือกรอกเหตุผลการพัก Lot");
      return;
    }

    setConfirmAction({
      type: "SAVE",
      lotId: cleanLotno,
      reason: reasonText,
    });
  };

  const handleClear = async (row) => {
    setConfirmAction({
      type: "CLEAR",
      row,
    });
  };

  return (
    <div className="space-y-6 pt-6">
      <div className="flex justify-end"><DemoGuideButton kind="hold" /></div>
      <section className="relative rounded-[2rem] border border-slate-300 bg-white shadow-md dark:border-slate-700 dark:bg-slate-900 dark:shadow-black/30">
        <div className="relative overflow-hidden rounded-t-[2rem] bg-gradient-to-br from-cyan-50 via-white to-slate-100 px-6 py-5 dark:from-slate-900 dark:via-slate-950 dark:to-cyan-950/30">
          <div className="absolute right-[-60px] top-[-60px] h-44 w-44 rounded-full bg-cyan-400/20 blur-3xl" />

          <div className="relative flex items-center justify-start gap-5 text-left">
            <span className="flex h-16 w-16 shrink-0 items-center justify-center rounded-2xl bg-cyan-600 text-white shadow-lg shadow-cyan-600/20">
              <PauseCircle size={34} />
            </span>

            <div className="min-w-0">
              <p className="text-sm font-black uppercase tracking-[0.22em] text-cyan-700 dark:text-cyan-300">
                Hold Lot Management
              </p>

              <h2 className="mt-1 text-3xl font-black tracking-tight text-slate-950 dark:text-white lg:text-4xl">
                พักงาน / Hold Lot ชั่วคราว
              </h2>

              <p className="mt-2 text-base font-bold text-slate-600 dark:text-slate-300 lg:text-lg">
                บันทึก Lot ที่ต้องหยุดเดินงานชั่วคราว
              </p>
            </div>
          </div>
        </div>

        <form
          onSubmit={handleSubmit}
          className="grid gap-5 bg-cyan-50/30 p-6 dark:bg-slate-900 xl:grid-cols-2"
        >
          <div className="xl:col-span-2 flex items-start gap-3 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm font-bold text-amber-900 dark:border-amber-900/60 dark:bg-amber-950/30 dark:text-amber-200">
            <AlertTriangle size={18} className="mt-0.5 shrink-0" />
            <p>
              Hold ได้เฉพาะ Lot ที่รอผลิตเท่านั้น เมื่อ Hold แล้ว Lot จะถูกซ่อนจากคิวชั่วคราว
              และจะกลับมาเมื่อกด Clear หากข้อมูลยังอยู่ใน Demo Queue Data ส่วน Lot ที่กำลังผลิตอยู่
              ไม่สามารถ Hold ได้
            </p>
          </div>

          <div>
            <label className="text-sm font-black text-slate-700 dark:text-slate-200">
              Demo User ID
            </label>
            <input
              value={empCode}
              readOnly
              className="mt-2 h-14 w-full rounded-2xl border border-slate-300 bg-slate-100 px-4 text-lg font-bold text-slate-700 outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
            />
          </div>

          <div>
            <label className="text-sm font-black text-slate-700 dark:text-slate-200">
              ชื่อ-นามสกุล
            </label>
            <input
              value={empName}
              readOnly
              className="mt-2 h-14 w-full rounded-2xl border border-slate-300 bg-slate-100 px-4 text-lg font-bold text-slate-700 outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
            />
          </div>

          <div>
            <label className="text-sm font-black text-slate-700 dark:text-slate-200">
              LOT NO
            </label>
            <input
              value={lotId}
              onChange={(event) => setLotno(event.target.value.toUpperCase())}
              placeholder="กรอก Lot No..."
              className="mt-2 h-13 w-full rounded-2xl border border-slate-300 bg-white px-4 text-base font-black text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
            />
          </div>

          <div>
            <label className="text-sm font-black text-slate-700 dark:text-slate-200">
              เหตุผลการพัก Lot
            </label>

            <div ref={reasonDropdownRef} className="relative mt-2">
              <button
                type="button"
                onClick={() => setReasonDropdownOpen((open) => !open)}
                className={`flex h-14 w-full items-center justify-between gap-3 rounded-2xl border bg-white px-4 text-left text-base font-black outline-none transition dark:bg-slate-900 ${
                  reasonDropdownOpen
                    ? "border-cyan-500 ring-2 ring-cyan-100 dark:border-cyan-400 dark:ring-cyan-950/60"
                    : "border-slate-300 hover:border-cyan-400 dark:border-slate-700"
                }`}
              >
                <span
                  className={`truncate ${
                    reason
                      ? "text-slate-900 dark:text-slate-100"
                      : "text-slate-400 dark:text-slate-500"
                  }`}
                >
                  {reason || "กรุณาเลือกเหตุผลการพัก Lot"}
                </span>

                <ChevronDown
                  size={20}
                  className={`shrink-0 text-slate-500 transition ${
                    reasonDropdownOpen ? "rotate-180" : ""
                  }`}
                  aria-hidden="true"
                />
              </button>

              {reasonDropdownOpen ? (
                <div className="absolute left-0 right-0 z-[200] mt-2 max-h-80 overflow-y-auto rounded-2xl border border-slate-200 bg-white p-2 shadow-2xl ring-1 ring-slate-900/5 dark:border-slate-700 dark:bg-slate-950">
                  {reasonOptions.map((item) => {
                    const selected = reason === item;

                    return (
                      <button
                        key={item}
                        type="button"
                        onClick={() => {
                          setReason(item);
                          setReasonDropdownOpen(false);

                          if (item !== "อื่นๆ") {
                            setCustomReason("");
                          }
                        }}
                        className={`flex w-full items-center justify-between gap-3 rounded-xl px-4 py-3 text-left text-sm font-black transition ${
                          selected
                            ? "bg-cyan-600 text-white"
                            : "text-slate-700 hover:bg-cyan-50 hover:text-cyan-700 dark:text-slate-200 dark:hover:bg-cyan-950/40 dark:hover:text-cyan-300"
                        }`}
                      >
                        <span>{item}</span>

                        {selected ? (
                          <span className="text-xs font-black">เลือกแล้ว</span>
                        ) : null}
                      </button>
                    );
                  })}
                </div>
              ) : null}
            </div>

            {reason === "อื่นๆ" ? (
              <textarea
                value={customReason}
                onChange={(event) => setCustomReason(event.target.value)}
                rows={3}
                placeholder="กรอกเหตุผลเพิ่มเติม..."
                className="mt-3 w-full rounded-2xl border border-slate-300 bg-white px-4 py-3 text-base font-bold text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
              />
            ) : null}
          </div>

          <div className="xl:col-span-2 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-center">
            <button
              type="submit"
              disabled={saving}
              className="inline-flex h-14 items-center justify-center gap-2 rounded-2xl bg-emerald-600 px-8 text-lg font-black text-white shadow-sm transition hover:bg-emerald-700 disabled:opacity-50"
            >
              <Save size={20} />
              {saving ? "Saving..." : "Save"}
            </button>

            <button
              type="button"
              onClick={resetForm}
              disabled={saving}
              className="inline-flex h-14 items-center justify-center gap-2 rounded-2xl bg-slate-600 px-8 text-lg font-black text-white shadow-sm transition hover:bg-slate-700 disabled:opacity-50"
            >
              <Eraser size={20} />
              Clear
            </button>
          </div>
        </form>
      </section>

      {message ? (
        <div className="flex items-start gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-sm font-bold text-emerald-700 dark:border-emerald-900/60 dark:bg-emerald-950/30 dark:text-emerald-300">
          <CheckCircle2 size={19} className="mt-0.5 shrink-0" />
          <span>{message}</span>
        </div>
      ) : null}

      {error ? (
        <div className="flex items-start gap-3 rounded-2xl border border-rose-200 bg-rose-50 p-4 text-sm font-bold text-rose-700 dark:border-rose-900/60 dark:bg-rose-950/30 dark:text-rose-300">
          <AlertTriangle size={19} className="mt-0.5 shrink-0" />
          <span>{error}</span>
        </div>
      ) : null}

      <section className="overflow-hidden rounded-[2rem] border border-slate-300 bg-white shadow-md dark:border-slate-700 dark:bg-slate-900 dark:shadow-black/30">
        <div className="bg-gradient-to-r from-cyan-950 via-slate-950 to-indigo-950 px-6 py-5 text-white">
          <div className="flex items-center justify-center gap-3 text-center">
            <History size={26} className="shrink-0 text-cyan-300" />

            <div>
              <h3 className="text-2xl font-black">ประวัติการพัก LOT</h3>

              <p className="mt-1 text-sm font-bold text-cyan-100">
                จำนวนรายการ Active ทั้งหมด {rows.length} รายการ
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-5 bg-slate-50/70 p-6 dark:bg-slate-950/40">
          <div className="flex flex-col gap-3">
            <DateModeFilter
              dateMode={dateMode}
              onDateModeChange={handleDateModeChange}
              dateFrom={filterDateFrom}
              onDateFromChange={handleFilterDateFromChange}
              dateTo={filterDateTo}
              onDateToChange={handleFilterDateToChange}
              helperText={dateRangeText}
              actions={
                <>
                  <button
                    type="button"
                    onClick={() => loadRows()}
                    disabled={loading}
                    className="inline-flex h-12 min-w-[140px] items-center justify-center gap-2 rounded-2xl bg-cyan-600 px-6 text-sm font-black text-white transition hover:bg-cyan-700 disabled:opacity-50"
                  >
                    <Search size={17} />
                    {loading ? "Loading..." : "Search"}
                  </button>

                  <button
                    type="button"
                    onClick={() => loadRows()}
                    disabled={loading}
                    className="inline-flex h-12 min-w-[140px] items-center justify-center gap-2 rounded-2xl bg-sky-600 px-6 text-sm font-black text-white transition hover:bg-sky-700 disabled:opacity-50"
                  >
                    <RefreshCw
                      size={17}
                      className={loading ? "animate-spin" : ""}
                    />
                    Refresh
                  </button>

                  <button
                    type="button"
                    onClick={handleClearFilters}
                    className="inline-flex h-12 min-w-[150px] items-center justify-center gap-2 rounded-2xl bg-slate-600 px-6 text-sm font-black text-white transition hover:bg-slate-700"
                  >
                    <Eraser size={17} />
                    Clear Filter
                  </button>
                </>
              }
            />
          </div>

          <div>
            {dateRangeInvalid ? (
              <ChartFilterPlaceholder
                title="กรุณากรอกช่วงวันที่ให้ถูกต้อง"
                description="วันที่เริ่มต้นต้องไม่มากกว่าวันที่สิ้นสุด กรุณาเลือกช่วงวันที่ใหม่อีกครั้ง"
              />
            ) : canShowCharts ? (
              <HorizontalBarChart
                title="สรุปเหตุผลการพัก Lot"
                subtitle="นับจากข้อมูลประวัติที่กำลังแสดงอยู่ตาม filter ปัจจุบัน"
                items={reasonSummary}
                emptyText="ยังไม่มีข้อมูลเหตุผลสำหรับแสดงกราฟ"
                maxItems={8}
                labelWidth="minmax(260px, 360px)"
                wrapLabels={true}
                showValues={true}
                headerRightText={currentDataTimeText}
              />
            ) : (
              <ChartFilterPlaceholder />
            )}
          </div>

          <div className="flex flex-col gap-3 rounded-3xl border border-slate-200 bg-white p-5 dark:border-slate-700 dark:bg-slate-900 lg:flex-row lg:items-center lg:justify-between">
            <div>
              <h4 className="text-xl font-black text-slate-950 dark:text-white">
                รายการประวัติการหยุด LOT
              </h4>
              <p className="mt-1 text-sm font-bold text-slate-500 dark:text-slate-400">
                กรอกคําค้นหาแล้วกดปุ่ม Search หรือกด Enter เพื่อค้นหา
              </p>
            </div>

            <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
              <input
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                onKeyDown={(event) => {
                  if (event.key === "Enter") loadRows();
                }}
                placeholder="ค้นหา Lot / เหตุผล / รหัส / ชื่อ..."
                className="h-12 w-full rounded-2xl border border-slate-300 bg-white px-4 text-sm font-bold text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 sm:w-[360px]"
              />

              <button
                type="button"
                onClick={loadRows}
                disabled={loading}
                className="inline-flex h-12 items-center justify-center gap-2 rounded-2xl bg-cyan-600 px-6 text-sm font-black text-white transition hover:bg-cyan-700 disabled:opacity-50"
              >
                <Search size={17} />
                {loading ? "Loading..." : "Search"}
              </button>

              <button
                type="button"
                onClick={() => exportCsv(rows)}
                disabled={rows.length === 0}
                className="inline-flex h-12 items-center justify-center gap-2 rounded-2xl bg-emerald-600 px-6 text-sm font-black text-white transition hover:bg-emerald-700 disabled:opacity-50"
              >
                <Download size={17} />
                Export CSV
              </button>
            </div>
          </div>

          <div className="overflow-x-auto rounded-3xl border border-slate-200 bg-white dark:border-slate-700 dark:bg-slate-900">
            <table className="w-full min-w-[1000px] text-left text-sm">
              <thead className="bg-slate-950 text-xs uppercase text-white">
                <tr>
                  <th className="px-4 py-3 text-center">ลำดับ</th>
                  <th className="px-4 py-3">lotId</th>
                  <th className="px-4 py-3">เหตุผลการพัก Lot</th>
                  <th className="px-4 py-3">ชื่อ-นามสกุล</th>
                  <th className="px-4 py-3">Demo User ID</th>
                  <th className="px-4 py-3">วัน เวลา</th>
                  <th className="px-4 py-3 text-center">Clear</th>
                </tr>
              </thead>

              <tbody>
                {rows.length === 0 ? (
                  <tr>
                    <td
                      colSpan={7}
                      className="px-4 py-10 text-center font-bold text-slate-500 dark:text-slate-400"
                    >
                      ไม่มีข้อมูลพัก Lot ที่ Active อยู่
                    </td>
                  </tr>
                ) : (
                  rows.map((row, index) => (
                    <tr
                      key={row.id}
                      className="border-b border-slate-100 odd:bg-white even:bg-slate-50 dark:border-slate-800 dark:odd:bg-slate-900 dark:even:bg-slate-950"
                    >
                      <td className="px-4 py-3 text-center font-bold text-slate-600 dark:text-slate-300">
                        {index + 1}
                      </td>
                      <td className="px-4 py-3 font-black text-slate-900 dark:text-slate-100">
                        {row.lotId || "-"}
                      </td>
                      <td className="px-4 py-3 font-bold text-slate-700 dark:text-slate-200">
                        {row.holdReason || "-"}
                      </td>
                      <td className="px-4 py-3 text-slate-600 dark:text-slate-300">
                        {row.createdByName || "-"}
                      </td>
                      <td className="px-4 py-3 text-slate-600 dark:text-slate-300">
                        {row.createdBy || "-"}
                      </td>
                      <td className="px-4 py-3 text-slate-600 dark:text-slate-300">
                        {row.createdAt || "-"}
                      </td>
                      <td className="px-4 py-3 text-center">
                        <button
                          type="button"
                          onClick={() => handleClear(row)}
                          disabled={clearingId === row.id}
                          className="inline-flex items-center gap-2 rounded-xl bg-rose-100 px-4 py-2 text-xs font-black text-rose-700 transition hover:bg-rose-200 disabled:opacity-50 dark:bg-rose-950/40 dark:text-rose-300"
                        >
                          <Trash2 size={15} />
                          {clearingId === row.id ? "Clearing..." : "Clear"}
                        </button>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </div>
      </section>
      <CenterAlert
        open={Boolean(dateAlertMessage)}
        title="กรุณาตรวจสอบช่วงวันที่"
        message={dateAlertMessage}
        onClose={() => setDateAlertMessage("")}
      />
      <CenterAlert
        open={Boolean(alertMessage)}
        title="ไม่สามารถบันทึกข้อมูลได้"
        message={alertMessage}
        variant="danger"
        onClose={() => setAlertMessage("")}
      />

      <CenterAlert
        open={Boolean(successMessage)}
        title={successTitle || "ดำเนินการสำเร็จ"}
        message={successMessage}
        variant="success"
        confirmText="ตกลง"
        onClose={() => {
          setSuccessTitle("");
          setSuccessMessage("");
        }}
      />

      <CenterAlert
        open={Boolean(confirmAction)}
        title={
          confirmAction?.type === "CLEAR"
            ? "ยืนยันการ Clear พัก Lot"
            : "ยืนยันการบันทึกพัก Lot"
        }
        message={
          confirmAction?.type === "CLEAR"
            ? `ต้องการ Clear รายการพัก Lot ${confirmAction?.row?.lotId || "-"} ใช่หรือไม่?`
            : confirmAction
              ? `กรุณาทวนข้อมูลก่อนบันทึกพัก Lot\nLot No: ${confirmAction.lotId}\nเหตุผล: ${confirmAction.reason}`
              : ""
        }
        variant={confirmAction?.type === "CLEAR" ? "warning" : "info"}
        confirmText="ยืนยัน"
        cancelText="ยกเลิก"
        requireEmployeeCode={
          confirmAction?.type === "SAVE" || confirmAction?.type === "CLEAR"
        }
        expectedEmployeeCode={empCode}
        onClose={() => setConfirmAction(null)}
        onConfirm={handleConfirmAction}
      />
    </div>
  );
}
