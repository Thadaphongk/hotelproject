import { useEffect, useRef, useState } from "react";
import {
  AlertTriangle,
  Clock3,
  Factory,
  Info,
  ListOrdered,
  RefreshCw,
  Table2,
} from "lucide-react";
import { getMachines } from "../services/api";
import { writeActivityLog } from "../services/logClient";
import {
  formatMachineName,
  isQueueTargetMachine,
} from "../utils/machineQueueUtils";
import MachineQueueTable from "../components/MachineQueueTable";

export default function QueueBoard({ user }) {
  const [machines, setMachines] = useState([]);
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState(null);
  const [filterStatus, setFilterStatus] = useState("ALL");
  const [error, setError] = useState(null);
  const [showLegendInfo, setShowLegendInfo] = useState(false);
  const legendRef = useRef(null);
  const loadRequestSeqRef = useRef(0);
  const loadInFlightRef = useRef(false);
  const [selectedMachineName, setSelectedMachineName] = useState(() => {
    return new URLSearchParams(window.location.search).get("machine");
  });

  const loadData = async ({ reason = "AUTO" } = {}) => {
    /*
     * Auto refresh ไม่ควรยิงซ้อนถ้า request รอบก่อนยังไม่จบ
     * Manual refresh ยังอนุญาตให้ขอ Snapshot ใหม่ได้ทันที
     */
    if (reason === "AUTO" && loadInFlightRef.current) {
      return;
    }

    /*
     * QueueBoard เป็นหน้าข้อมูลสด จึงบังคับขอ Snapshot ใหม่ทุกครั้ง
     * และใช้ sequence กัน request เก่าที่จบช้ากว่าเขียน state ทับข้อมูลใหม่
     */
    const requestSeq = ++loadRequestSeqRef.current;
    loadInFlightRef.current = true;

    setLoading(true);
    setError(null);

    try {
      const data = await getMachines({
        includeTechnical: true,
        includeMoveLot: true,
        force: true,
      });

      // ถ้ามี request ใหม่กว่าเริ่มไปแล้ว ไม่ใช้ response เก่านี้
      if (requestSeq !== loadRequestSeqRef.current) {
        return;
      }

      // แปลงชื่อเป็นชื่อใหม่ และคัดเฉพาะเครื่องที่หน้า Queue ใช้งาน
      const fullData = (data || [])
        .map((m) => ({ ...m, machineName: formatMachineName(m.machineName) }))
        .filter((m) => isQueueTargetMachine(m.machineName));

      // เรียงลำดับชื่อเครื่องจักร
      const sortedData = fullData.sort((a, b) => {
        return (a.machineName || "").localeCompare(b.machineName || "");
      });

      setMachines(sortedData);
      setLastUpdated(new Date());

      if (reason === "MANUAL") {
        writeActivityLog({
          user,
          type: "MACHINE_QUEUE",
          level: "INFO",
          page: "Machine Queue",
          action: "REFRESH",
          result: "SUCCESS",
          message: `Manual refresh Machine Queue: ${sortedData.length} machine(s)`,
          meta: {
            machineCount: sortedData.length,
            machines: sortedData.map((machine) => machine.machineName),
          },
        });
      }
    } catch (error) {
      // request เก่าที่ถูก request ใหม่แซง ไม่ควรเปลี่ยนสถานะหน้า
      if (requestSeq !== loadRequestSeqRef.current) {
        return;
      }

      writeActivityLog({
        user,
        type: "API_ERROR",
        level: "ERROR",
        page: "Machine Queue",
        action: "LOAD_QUEUE_ERROR",
        result: "ERROR",
        message: error?.message || "Error fetching machines queue",
      });
      console.error("Error fetching machines queue:", error);
      setError("ไม่สามารถโหลดข้อมูลได้ กรุณาลองใหม่อีกครั้ง");
    } finally {
      if (requestSeq === loadRequestSeqRef.current) {
        loadInFlightRef.current = false;
        setLoading(false);
      }
    }
  };

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (legendRef.current && !legendRef.current.contains(event.target)) {
        setShowLegendInfo(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  useEffect(() => {
    loadData({ reason: "AUTO" });

    const intervalId = setInterval(() => {
      loadData({ reason: "AUTO" });
    }, 60000);
  }, []);

  // กรองเครื่องจักรตามสถานะที่เลือก (ดูจากคิวที่ 1 เป็นหลัก)
  const filteredMachines = machines.filter((machine) => {
    if (filterStatus === "ALL") return true;

    const firstLot = machine.lots?.[0];
    if (!firstLot) return false;

    const isCurrentMachineLot =
      String(firstLot.sourceType || "")
        .trim()
        .toUpperCase() === "CURRENT";

    const mcStatus = String(firstLot.machineStatus || "")
      .trim()
      .toUpperCase();

    const hasLossCode =
      isCurrentMachineLot &&
      firstLot.stopCode &&
      String(firstLot.stopCode).trim() !== "-";

    const isStoppedCurrent =
      isCurrentMachineLot &&
      (hasLossCode || (mcStatus && mcStatus !== "RUN"));

    const isRunStatus = isCurrentMachineLot && !isStoppedCurrent;

    if (filterStatus === "STOPPED") return isStoppedCurrent;
    if (filterStatus === "RUNNING") return isRunStatus;

    return true;
  });

  // หาข้อมูลของเครื่องที่กำลังเลือกอยู่
  const selectedMachineData = filteredMachines.find(
    (m) => m.machineName === selectedMachineName,
  );

  const selectedLots = selectedMachineData?.lots || [];

  // ฟังก์ชันสลับการเลือกเครื่องจักร
  const handleSelectMachine = (machineName) => {
    setSelectedMachineName((prev) =>
      prev === machineName ? null : machineName,
    );
  };

  // ฟังก์ชันเช็คสถานะและสร้างสี Badge ตามเงื่อนไขใหม่

  return (
    <div className="space-y-6 pt-6 flex flex-col h-full">
      {/* Header Section */}
      <div className="relative flex flex-col justify-between gap-4 overflow-hidden rounded-[2rem] border border-slate-300 bg-gradient-to-br from-cyan-50 via-white to-slate-100 p-5 shadow-lg dark:border-slate-700 dark:from-slate-900 dark:via-slate-950 dark:to-cyan-950/30 sm:p-6 lg:flex-row lg:items-center">
        <div className="absolute right-[-70px] top-[-70px] h-48 w-48 rounded-full bg-cyan-400/20 blur-3xl" />
        <div className="relative flex min-w-0 flex-1 items-start gap-4">
          <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-cyan-600 text-white shadow-lg shadow-cyan-600/20">
            <ListOrdered size={28} strokeWidth={2.2} />
          </div>
          <div>
            <p className="text-xs font-black uppercase tracking-[0.22em] text-cyan-700 dark:text-cyan-300">
              Machine Queue
            </p>
            <h1 className="mt-1 truncate whitespace-nowrap text-2xl font-black tracking-tight text-slate-900 sm:text-3xl dark:text-white">
              WIP Monitor
            </h1>
            <p className="mt-1 text-xs font-semibold text-slate-600 sm:text-sm dark:text-slate-300">
              กระดานแสดงคิวงานและสถานะ Lot ปัจจุบันของแต่ละเครื่องจักร
            </p>
          </div>
        </div>
        <div className="relative flex w-full flex-col items-stretch gap-3 sm:flex-row sm:items-center sm:justify-between sm:gap-4 lg:w-auto">
          {/* <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value)}
            className="w-full sm:w-auto h-11 sm:h-12 rounded-2xl border border-slate-300 bg-slate-50 px-3 sm:px-4 py-2 text-xs sm:text-sm font-semibold text-slate-700 outline-none transition hover:bg-slate-100 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-600 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700 dark:focus:border-cyan-400"
          >
            <option value="ALL">ดูทั้งหมด (All)</option>
            <option value="RUNNING">🟢 กำลังรัน (Running)</option>
            <option value="STOPPED">🔴 หยุดเครื่อง (Stop/Loss)</option>
          </select> */}

          <div className="flex items-center justify-between sm:justify-end gap-3 sm:gap-4 w-full sm:w-auto">
            <div className="flex items-center gap-2 text-slate-500 dark:text-slate-400">
              <Clock3 size={17} className="shrink-0" />

              <div className="flex flex-col">
                <span className="text-xs font-semibold sm:text-sm">
                  อัปเดตล่าสุด:{" "}
                  {lastUpdated ? lastUpdated.toLocaleTimeString("th-TH") : "-"}
                </span>

                <span className="text-[11px] font-medium text-slate-400 dark:text-slate-500">
                  อัปเดตอัตโนมัติทุก 1 นาที
                </span>
              </div>
            </div>
            <button
              onClick={() => loadData({ reason: "MANUAL" })}
              disabled={loading}
              className="inline-flex h-11 shrink-0 items-center justify-center gap-2 rounded-2xl bg-cyan-600 px-4 text-xs font-black text-white transition hover:bg-cyan-700 disabled:opacity-50 sm:h-12 sm:px-6 sm:text-sm"
            >
              <RefreshCw size={17} className={loading ? "animate-spin" : ""} />
              {loading ? "กำลังโหลด..." : "Refresh"}
            </button>
          </div>
        </div>
      </div>

      {/* Board Section */}
      {loading && machines.length === 0 ? (
        <div className="py-12 text-center text-slate-500">
          กำลังโหลดตารางคิวงาน...
        </div>
      ) : error ? (
        <div className="flex items-center justify-center gap-2 py-12 text-center font-semibold text-rose-500">
          <AlertTriangle size={20} />
          {error}
        </div>
      ) : filteredMachines.length === 0 ? (
        <div className="py-12 text-center text-slate-500">
          ไม่พบเครื่องจักรในสถานะที่เลือก
        </div>
      ) : (
        <div className="flex flex-col gap-3 pb-6 w-full">
          {/* 1. Machine Selector Section (แสดงปุ่มรายชื่อเครื่องทั้งหมด) */}
          <section className="rounded-3xl border border-slate-300 bg-white/90 p-5 shadow-[0_14px_40px_rgba(15,23,42,0.12)] backdrop-blur-md dark:border-slate-700 dark:bg-slate-950/55 dark:shadow-[0_18px_55px_rgba(0,0,0,0.55)]">
            <div className="mb-4 flex items-center gap-2">
              <Factory size={18} className="text-cyan-600 dark:text-cyan-300" />

              <p className="text-sm font-bold text-slate-600 dark:text-slate-300">
                เลือกเครื่องจักรเพื่อดูคิวงาน
              </p>

              <div ref={legendRef} className="relative">
                <button
                  type="button"
                  onClick={() => setShowLegendInfo((prev) => !prev)}
                  title="สัญลักษณ์และสถานะ"
                  className="flex h-7 w-7 items-center justify-center rounded-full bg-slate-200 text-slate-600 transition hover:bg-slate-300 dark:bg-slate-800 dark:text-slate-400 dark:hover:bg-slate-700"
                >
                  <Info size={18} />
                </button>

                {showLegendInfo && (
                  <div className="absolute left-0 top-9 z-50 w-64 rounded-xl border border-slate-200 bg-white p-3 shadow-xl dark:border-slate-700 dark:bg-slate-800">
                    <h4 className="mb-2 text-sm font-bold text-slate-500 dark:text-slate-400">
                      สัญลักษณ์และสถานะ
                    </h4>

                    <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300">
                      <li className="flex items-center gap-2">
                        <span className="h-3 w-3 shrink-0 rounded-full bg-emerald-500" />
                        <b>Running:</b> กำลังเดินเครื่อง
                      </li>

                      <li className="flex items-center gap-2">
                        <span className="h-3 w-3 shrink-0 rounded-full bg-rose-500" />
                        <b>Stop/Loss:</b> เครื่องหยุด/มี Stop Code
                      </li>

                      <li className="flex items-center gap-2">
                        <span className="h-3 w-3 shrink-0 rounded-full bg-amber-500" />
                        <b>Waiting:</b> กำลังรอการผลิต
                      </li>

                      <li className="flex items-center gap-2">
                        <span className="h-3 w-3 shrink-0 rounded-full bg-slate-400" />
                        <b>No Data:</b> ไม่มีข้อมูลในฐานข้อมูล
                      </li>
                    </ul>
                  </div>
                )}
              </div>
            </div>
            {/* UI LOCK: Machine Queue selector = icon + machine name only; status is left strip. Do not change without approval. */}
            <div
              className="mx-auto grid w-full gap-3"
              style={{
                gridTemplateColumns:
                  "repeat(auto-fit, minmax(min(100%, 320px), 1fr))",
              }}
            >
              {filteredMachines.map((machine) => {
                const isSelected = selectedMachineName === machine.machineName;

                // แถบสีเครื่องยึด CURRENT จริงเท่านั้น
                // ถ้า demo runtime data ค้าง แต่ Lot ย้ายไป Process อื่นแล้ว
                // Backend จะไม่ส่งแถวนั้นเป็น CURRENT และเครื่องจะแสดง Waiting
                const firstLot = machine.lots?.[0];
                const isCurrentMachineLot =
                  String(firstLot?.sourceType || "")
                    .trim()
                    .toUpperCase() === "CURRENT";

                const mcStatus = String(firstLot?.machineStatus || "")
                  .trim()
                  .toUpperCase();

                const hasLossCode =
                  isCurrentMachineLot &&
                  firstLot?.stopCode &&
                  String(firstLot.stopCode).trim() !== "-";

                const isStoppedCurrent =
                  isCurrentMachineLot &&
                  (hasLossCode || (mcStatus && mcStatus !== "RUN"));

                const isRunStatus =
                  isCurrentMachineLot && !isStoppedCurrent;

                let statusStripClass =
                  "bg-slate-500 shadow-[0_0_4px_rgba(100,116,139,0.6)]";

                if (firstLot) {
                  if (isStoppedCurrent) {
                    statusStripClass =
                      "bg-rose-500 shadow-[0_0_4px_rgba(244,63,94,0.75)]";
                  } else if (isRunStatus) {
                    statusStripClass =
                      "bg-emerald-500 shadow-[0_0_4px_rgba(16,185,129,0.75)]";
                  } else {
                    // ไม่มี Current Lot ที่ยังอยู่ ACTIVE/WAITING = มีแต่คิวรอผลิต
                    statusStripClass =
                      "bg-amber-400 shadow-[0_0_4px_rgba(251,191,36,0.65)]";
                  }
                }

                return (
                  <button
                    key={machine.machineName}
                    type="button"
                    onClick={() => handleSelectMachine(machine.machineName)}
                    title={formatMachineName(machine.machineName)}
                    aria-label={`Select ${formatMachineName(machine.machineName)}`}
                    className={[
                      "group relative flex min-h-[86px] w-full items-center overflow-hidden rounded-3xl border p-3 text-left transition-all duration-200 sm:min-h-[96px] sm:p-4",
                      "bg-[#E8EEF6] text-slate-200 ring-0 ring-black/20",
                      "border-black/30 shadow-[0_10px_20px_rgba(15,23,42,0.16)]",
                      "hover:-translate-y-0.5 hover:border-[#8EA4C1] hover:bg-[#DDE7F3] hover:shadow-[0_16px_40px_rgba(15,23,42,0.22)]",
                      "dark:bg-[#142033] dark:text-slate-50 dark:ring-white/35",
                      "dark:border-[#41516A] dark:shadow-[0_16px_44px_rgba(0,0,0,0.55)]",
                      "dark:hover:border-[#64748B] dark:hover:bg-[#17263B] dark:hover:shadow-[0_20px_52px_rgba(0,0,0,0.75)]",
                      isSelected
                        ? "!border-cyan-500 ring-4 ring-cyan-500/25 dark:!border-cyan-400 scale-[1.01]"
                        : "",
                    ].join(" ")}
                  >
                    <span
                      className={`absolute left-0 top-0 h-full w-2.5 ${statusStripClass}`}
                    />
                    <span
                      className={`absolute left-0 top-0 h-full w-12 bg-gradient-to-r ${hasLossCode ? "from-rose-500/20" : isRunStatus ? "from-emerald-500/20" : firstLot ? "from-amber-400/16" : "from-slate-500/16"} to-transparent`}
                    />

                    <div className="flex min-w-0 items-center gap-4 pl-2 sm:gap-5">
                      <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-white ring-1 ring-w shadow-[0_6px_18px_rgba(15,23,42,0.14)] sm:h-16 sm:w-16 dark:bg-white dark:ring-white">
                        <img
                          src="/icons/line_process01.gif"
                          alt=""
                          draggable="false"
                          className="h-10 w-10 object-contain sm:h-11 sm:w-11"
                        />
                      </div>

                      <span className="whitespace-nowrap text-[clamp(1.55rem,2.1vw,2.35rem)] font-black leading-none tracking-tight text-slate-950 dark:text-slate-50">
                        {formatMachineName(machine.machineName)}
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>
          </section>

          {/* 2. Queue Details Section (ตารางแสดงคิว) */}
          {!selectedMachineData ? (
            <div className="rounded-3xl border border-dashed border-slate-300 bg-slate-50 p-12 text-center text-slate-500 dark:border-slate-700 dark:bg-slate-900/50 dark:text-slate-400">
              กรุณาเลือกเครื่องจักรด้านบนเพื่อดูข้อมูลคิว
            </div>
          ) : (
            <div className="rounded-3xl border border-slate-300 bg-white shadow-md overflow-hidden flex flex-col dark:border-slate-700 dark:bg-slate-900 dark:shadow-black/30">
              <div className="border-b border-slate-100 p-6 dark:border-slate-800">
                <h3 className="inline-flex items-center gap-2 text-xl font-bold text-slate-900 dark:text-slate-100">
                  <Table2
                    size={21}
                    className="text-cyan-600 dark:text-cyan-300"
                  />
                  Queue Details:{" "}
                  {formatMachineName(selectedMachineData.machineName)}
                </h3>
                <p className="mt-1 text-sm font-medium text-cyan-600 dark:text-cyan-400">
                  จำนวนคิวทั้งหมด: {selectedLots.length} รายการ
                </p>
              </div>

              <MachineQueueTable
                lots={selectedMachineData.lots || []}
                machineName={selectedMachineData.machineName}
                loading={false}
                emptyMessage="ไม่พบข้อมูลคิวของเครื่องนี้"
              />
            </div>
          )}
        </div>
      )}
    </div>
  );
}
