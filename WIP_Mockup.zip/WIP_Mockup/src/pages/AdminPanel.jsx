import { Fragment, useEffect, useMemo, useState } from "react";
import {
  AlertTriangle,
  BellRing,
  CheckCircle2,
  CircleHelp,
  KeyRound,
  Pencil,
  RefreshCw,
  Save,
  Search,
  ShieldCheck,
  Trash2,
  UserCog,
  UserRoundCheck,
  UserRoundX,
  UsersRound,
  X,
} from "lucide-react";
import {
  getPendingRequests,
  getPendingPermissionRequests,
  getApprovedUsers,
  approveRequest,
  rejectRequest,
  updateApprovedUserAccess,
  deleteApprovedUser,
} from "../services/api";
import CenterAlert from "../components/CenterAlert";

const permissionItems = [
  {
    key: "dashboard",
    label: "Dashboard",
    description: "ดูภาพรวมสถานะเครื่องจักร",
  },
  {
    key: "queue",
    label: "Machine Queue",
    description: "ดูคิวงานรายเครื่อง",
  },
  {
    key: "lotSearch",
    label: "LOT Search",
    description: "ค้นหา Lot",
  },
  {
    key: "lineInfo",
    label: "Line Information",
    description: "ดูข้อมูล Mapping จำลอง",
  },
  {
    key: "returnLot",
    label: "Return Lot",
    description: "แจ้งปัญหา / เดินงานข้าม Lot",
  },
  {
    key: "moveLot",
    label: "Move Lot",
    description: "ย้าย Lot งาน",
  },
  {
    key: "dailyCheck",
    label: "Daily Check",
    description: "ตรวจสอบข้อมูลประจำวัน",
  },
  {
    key: "logs",
    label: "Logs",
    description: "ดูกิจกรรมผู้ใช้งาน",
  },
  {
    key: "machineDebug",
    label: "Machine Debug",
    description: "ตรวจสอบข้อมูลสำหรับ Debug",
  },
  {
    key: "admin",
    label: "Admin Console",
    description: "จัดการสิทธิ์ผู้ใช้งาน",
  },
  {
    key: "sequence",
    label: "จัดลำดับงาน",
    description: "กำหนดลำดับ Lot ที่รอเข้าเครื่อง",
  },
  {
    key: "hold",
    label: "พักงาน",
    description: "พัก Lot งาน",
  },
];

const permissionPresets = {
  VIEWER: {
    dashboard: true,
    queue: true,
    lotSearch: true,
    lineInfo: false,
    returnLot: false,
    moveLot: false,
    dailyCheck: false,
    logs: false,
    machineDebug: false,
    admin: false,
    sequence: false,
    hold: false,
  },
  OPERATOR: {
    dashboard: true,
    queue: true,
    lotSearch: true,
    lineInfo: true,
    returnLot: true,
    moveLot: true,
    dailyCheck: false,
    logs: false,
    machineDebug: false,
    admin: false,
    sequence: true,
    hold: true,
  },
  TL: {
    dashboard: true,
    queue: true,
    lotSearch: true,
    lineInfo: true,
    returnLot: true,
    moveLot: true,
    dailyCheck: true,
    logs: true,
    machineDebug: false,
    admin: false,
    sequence: true,
    hold: true,
  },
  ADMIN: {
    dashboard: true,
    queue: true,
    lotSearch: true,
    lineInfo: true,
    returnLot: true,
    moveLot: true,
    dailyCheck: true,
    logs: true,
    machineDebug: true,
    admin: true,
    sequence: true,
    hold: true,
  },
};

const roleOptions = [
  { value: "VIEWER", label: "Viewer" },
  { value: "OPERATOR", label: "Operator" },
  { value: "TL", label: "TL / Staff" },
  { value: "ADMIN", label: "Admin" },
];

const normalizeEmpCode = (value) =>
  String(value || "")
    .trim()
    .toUpperCase();

const normalizeRole = (value) => {
  const role = String(value || "VIEWER")
    .trim()
    .toUpperCase();

  return permissionPresets[role] ? role : "VIEWER";
};

const getRequestEmpCode = (request) =>
  normalizeEmpCode(request.empCode || request.employeeId);

const buildInitialSetting = () => ({
  role: "VIEWER",
  permissions: { ...permissionPresets.VIEWER },
  rejectReason: "",
});

const buildApprovedSetting = (access) => {
  const role = normalizeRole(access?.role);

  return {
    role,
    permissions: {
      ...permissionPresets.VIEWER,
      ...(access?.permissions || {}),
    },
  };
};

const getPermissionCount = (permissions) =>
  permissionItems.reduce(
    (total, item) => total + (permissions?.[item.key] ? 1 : 0),
    0,
  );

const getRoleLabel = (role) =>
  roleOptions.find((item) => item.value === normalizeRole(role))?.label ||
  role ||
  "-";

const getRequestedPermissionLabels = (permissionRequest) =>
  permissionItems
    .filter((item) => Boolean(permissionRequest?.permissions?.[item.key]))
    .map((item) => item.label);

const restoreViewport = (scrollY) => {
  if (typeof window === "undefined") return;

  // รอให้ React render ข้อมูลชุดใหม่เสร็จก่อน แล้วค่อยคืนตำแหน่งเดิม
  window.requestAnimationFrame(() => {
    window.requestAnimationFrame(() => {
      window.scrollTo({ top: scrollY, left: 0, behavior: "auto" });
    });
  });
};

function PermissionChecklist({ permissions, onToggle }) {
  return (
    <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
      {permissionItems.map((item) => {
        const checked = Boolean(permissions?.[item.key]);

        return (
          <label
            key={item.key}
            className={[
              "flex cursor-pointer items-start gap-3 rounded-2xl border p-3 transition",
              checked
                ? "border-emerald-200 bg-emerald-50 dark:border-emerald-900/60 dark:bg-emerald-950/25"
                : "border-slate-200 bg-white hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:hover:bg-slate-800/70",
            ].join(" ")}
          >
            <input
              type="checkbox"
              checked={checked}
              onChange={() => onToggle(item.key)}
              className="mt-1 h-4 w-4 rounded border-slate-300 text-cyan-600 focus:ring-cyan-500"
            />

            <span>
              <span className="block text-sm font-black text-slate-900 dark:text-slate-100">
                {item.label}
              </span>
              <span className="mt-0.5 block text-xs font-bold text-slate-500 dark:text-slate-400">
                {item.description}
              </span>
            </span>
          </label>
        );
      })}
    </div>
  );
}

export default function AdminPanel({ user }) {
  const [requests, setRequests] = useState([]);
  const [permissionRequests, setPermissionRequests] = useState([]);
  const [approvedUsers, setApprovedUsers] = useState([]);
  const [settings, setSettings] = useState({});
  const [approvedSettings, setApprovedSettings] = useState({});
  const [editingEmpCode, setEditingEmpCode] = useState("");
  const [searchText, setSearchText] = useState("");
  const [loading, setLoading] = useState(false);
  const [actionLoading, setActionLoading] = useState("");
  const [notification, setNotification] = useState("");
  const [error, setError] = useState("");
  const [deleteTarget, setDeleteTarget] = useState(null);

  const adminEmpCode = normalizeEmpCode(user?.empCode || user?.id || "SYSTEM");

  const loadAdminData = async () => {
    setLoading(true);
    setError("");

    try {
      const [pending, pendingPermissions, approved] = await Promise.all([
        getPendingRequests(),
        getPendingPermissionRequests(),
        getApprovedUsers(),
      ]);

      setRequests(pending);
      setPermissionRequests(pendingPermissions);
      setApprovedUsers(approved);

      const nextSettings = {};
      for (const request of pending) {
        const empCode = getRequestEmpCode(request);
        if (!empCode) continue;
        nextSettings[empCode] = buildInitialSetting();
      }
      setSettings(nextSettings);

      const nextApprovedSettings = {};
      for (const access of approved) {
        const empCode = getRequestEmpCode(access);
        if (!empCode) continue;
        nextApprovedSettings[empCode] = buildApprovedSetting(access);
      }
      setApprovedSettings(nextApprovedSettings);
    } catch (err) {
      console.error("Load admin access data error:", err);
      setError(err.message || "โหลดข้อมูลสิทธิ์ผู้ใช้งานไม่สำเร็จ");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadAdminData();
  }, []);

  const filteredApprovedUsers = useMemo(() => {
    const query = String(searchText || "")
      .trim()
      .toLowerCase();

    if (!query) return approvedUsers;

    return approvedUsers.filter((access) => {
      const searchable = [
        access.empCode,
        access.empName,
        access.department,
        access.position,
        access.role,
      ]
        .join(" ")
        .toLowerCase();

      return searchable.includes(query);
    });
  }, [approvedUsers, searchText]);

  const handlePendingRoleChange = (empCode, role) => {
    setSettings((prev) => ({
      ...prev,
      [empCode]: {
        ...(prev[empCode] || buildInitialSetting()),
        role,
        permissions: {
          ...(permissionPresets[role] || permissionPresets.VIEWER),
        },
      },
    }));
  };

  const handlePendingTogglePermission = (empCode, key) => {
    setSettings((prev) => {
      const current = prev[empCode] || buildInitialSetting();

      return {
        ...prev,
        [empCode]: {
          ...current,
          permissions: {
            ...current.permissions,
            [key]: !current.permissions?.[key],
          },
        },
      };
    });
  };

  const handleRejectReasonChange = (empCode, rejectReason) => {
    setSettings((prev) => ({
      ...prev,
      [empCode]: {
        ...(prev[empCode] || buildInitialSetting()),
        rejectReason,
      },
    }));
  };

  const handleApprove = async (event, request) => {
    event?.preventDefault();
    event?.stopPropagation();

    const scrollY = window.scrollY;
    const empCode = getRequestEmpCode(request);
    if (!empCode) return;

    const current = settings[empCode] || buildInitialSetting();

    setActionLoading(`approve-${empCode}`);
    setError("");
    setNotification("");

    try {
      await approveRequest(empCode, {
        approvedBy: adminEmpCode,
        role: current.role,
        permissions: current.permissions,
      });

      setNotification(`อนุมัติคำขอสำหรับ ${empCode} เรียบร้อยแล้ว`);
      await loadAdminData();
      restoreViewport(scrollY);
    } catch (err) {
      console.error("Approve request error:", err);
      setError(err.message || `อนุมัติคำขอสำหรับ ${empCode} ไม่สำเร็จ`);
    } finally {
      setActionLoading("");
    }
  };

  const handleReject = async (event, request) => {
    event?.preventDefault();
    event?.stopPropagation();

    const scrollY = window.scrollY;
    const empCode = getRequestEmpCode(request);
    if (!empCode) return;

    const current = settings[empCode] || buildInitialSetting();

    setActionLoading(`reject-${empCode}`);
    setError("");
    setNotification("");

    try {
      await rejectRequest(empCode, {
        rejectReason: current.rejectReason || "Admin rejected",
      });

      setNotification(`ปฏิเสธคำขอสำหรับ ${empCode} เรียบร้อยแล้ว`);
      await loadAdminData();
      restoreViewport(scrollY);
    } catch (err) {
      console.error("Reject request error:", err);
      setError(err.message || `ปฏิเสธคำขอสำหรับ ${empCode} ไม่สำเร็จ`);
    } finally {
      setActionLoading("");
    }
  };

  const handleStartEdit = (access) => {
    const empCode = getRequestEmpCode(access);
    if (!empCode) return;

    setApprovedSettings((prev) => ({
      ...prev,
      [empCode]: buildApprovedSetting(access),
    }));
    setEditingEmpCode(empCode);
    setError("");
    setNotification("");
  };

  const handleCancelEdit = (access) => {
    const empCode = getRequestEmpCode(access);

    setApprovedSettings((prev) => ({
      ...prev,
      [empCode]: buildApprovedSetting(access),
    }));
    setEditingEmpCode("");
  };

  const handleApprovedRoleChange = (empCode, role) => {
    setApprovedSettings((prev) => ({
      ...prev,
      [empCode]: {
        ...(prev[empCode] || buildApprovedSetting({ role })),
        role,
        // เมื่อเปลี่ยน Role ให้ใช้ Preset ของ Role นั้นเป็นค่าเริ่มต้น
        // จากนั้น Admin ยังสามารถติ๊ก/เอาติ๊กออกทีละ Permission ได้ก่อน Save
        permissions: {
          ...(permissionPresets[role] || permissionPresets.VIEWER),
        },
      },
    }));
  };

  const handleApprovedTogglePermission = (empCode, key) => {
    setApprovedSettings((prev) => {
      const current = prev[empCode] || buildApprovedSetting({});

      return {
        ...prev,
        [empCode]: {
          ...current,
          permissions: {
            ...current.permissions,
            [key]: !current.permissions?.[key],
          },
        },
      };
    });
  };

  const handleSaveApprovedUser = async (event, access) => {
    event?.preventDefault();
    event?.stopPropagation();

    const scrollY = window.scrollY;
    const empCode = getRequestEmpCode(access);
    if (!empCode) return;

    const current = approvedSettings[empCode] || buildApprovedSetting(access);

    setActionLoading(`save-${empCode}`);
    setError("");
    setNotification("");

    try {
      await updateApprovedUserAccess(empCode, {
        updatedBy: adminEmpCode,
        role: current.role,
        permissions: current.permissions,
      });

      setNotification(`บันทึก Role และ Permission ของ ${empCode} เรียบร้อยแล้ว`);

      // คงแถวแก้ไขเดิมไว้ ไม่ยุบตาราง/เด้งตำแหน่งหลัง Save
      setEditingEmpCode(empCode);
      await loadAdminData();
      restoreViewport(scrollY);
    } catch (err) {
      console.error("Update approved user access error:", err);
      setError(err.message || `แก้ไขสิทธิ์ของ ${empCode} ไม่สำเร็จ`);
    } finally {
      setActionLoading("");
    }
  };

  const handleOpenPermissionRequestEditor = (request) => {
    const empCode = getRequestEmpCode(request);
    if (!empCode) return;

    const access = approvedUsers.find(
      (item) => getRequestEmpCode(item) === empCode,
    );

    if (!access) {
      setError(`ไม่พบผู้ใช้งาน ${empCode} ในรายการที่อนุมัติแล้ว`);
      return;
    }

    const baseSetting = buildApprovedSetting(access);
    const requestedPermissions = request.permissionRequest?.permissions || {};
    const nextPermissions = { ...baseSetting.permissions };

    for (const item of permissionItems) {
      if (requestedPermissions[item.key]) {
        nextPermissions[item.key] = true;
      }
    }

    setApprovedSettings((prev) => ({
      ...prev,
      [empCode]: {
        ...baseSetting,
        permissions: nextPermissions,
      },
    }));
    setEditingEmpCode(empCode);
    setSearchText(empCode);
    setError("");
    setNotification(
      `เปิดรายการ ${empCode} และเลือกสิทธิ์ที่ขอไว้ให้แล้ว กรุณาตรวจสอบก่อนกดบันทึก`,
    );

    window.setTimeout(() => {
      document
        .getElementById("approved-users-section")
        ?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 50);
  };

  const handleAskDeleteUser = (access) => {
    const empCode = getRequestEmpCode(access);
    if (!empCode || empCode === adminEmpCode) return;

    setDeleteTarget(access);
    setError("");
    setNotification("");
  };

  const handleConfirmDeleteUser = async () => {
    if (!deleteTarget || actionLoading) return;

    const scrollY = window.scrollY;
    const empCode = getRequestEmpCode(deleteTarget);
    if (!empCode) return;

    setActionLoading(`delete-${empCode}`);
    setError("");
    setNotification("");

    try {
      await deleteApprovedUser(empCode, { deletedBy: adminEmpCode });

      if (editingEmpCode === empCode) {
        setEditingEmpCode("");
      }

      setDeleteTarget(null);
      setNotification(
        `ลบผู้ใช้งาน ${empCode} ออกจากรายการสิทธิ์เรียบร้อยแล้ว`,
      );
      await loadAdminData();
      restoreViewport(scrollY);
    } catch (err) {
      console.error("Delete approved user error:", err);
      setError(err.message || `ลบผู้ใช้งาน ${empCode} ไม่สำเร็จ`);
    } finally {
      setActionLoading("");
    }
  };

  return (
    <div className="space-y-6 pt-6">
      <section className="relative overflow-hidden rounded-[2rem] border border-slate-300 bg-gradient-to-br from-cyan-50 via-white to-slate-100 p-6 shadow-lg dark:border-slate-700 dark:from-slate-900 dark:via-slate-950 dark:to-cyan-950/30">
        <div className="absolute right-[-80px] top-[-80px] h-56 w-56 rounded-full bg-cyan-400/20 blur-3xl" />
        <div className="absolute bottom-[-90px] left-[-90px] h-52 w-52 rounded-full bg-indigo-400/10 blur-3xl" />

        <div className="relative flex flex-col gap-5 sm:flex-row sm:items-center sm:justify-between">
          <div className="flex items-start gap-4">
            <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-cyan-600 text-white shadow-lg shadow-cyan-600/20">
              <UserCog size={28} strokeWidth={2.2} />
            </div>

            <div>
              <p className="text-xs font-black uppercase tracking-[0.22em] text-cyan-700 dark:text-cyan-300">
                Access Management
              </p>
              <h1 className="mt-1 text-2xl font-black tracking-tight text-slate-900 sm:text-3xl dark:text-white">
                Admin Console
              </h1>
              <p className="mt-2 max-w-3xl text-sm font-semibold text-slate-600 dark:text-slate-300">
                อนุมัติคำขอเข้าใช้งาน และตรวจสอบ Role / Permission ของพนักงานที่ได้รับสิทธิ์แล้ว
              </p>
            </div>
          </div>

          <button
            type="button"
            onClick={loadAdminData}
            disabled={loading || Boolean(actionLoading)}
            className="inline-flex h-12 items-center justify-center gap-2 rounded-2xl bg-cyan-600 px-5 text-sm font-black text-white shadow-sm transition hover:bg-cyan-700 disabled:opacity-50"
          >
            <RefreshCw size={18} className={loading ? "animate-spin" : ""} />
            {loading ? "กำลังโหลด..." : "Refresh"}
          </button>
        </div>
      </section>

      <section className="mx-auto w-full max-w-4xl overflow-hidden rounded-[2rem] border border-slate-200 bg-white/95 shadow-md dark:border-slate-700 dark:bg-slate-900/95">
        <div className="border-b border-slate-100 px-5 py-3 text-center dark:border-slate-800">
          <p className="text-xs font-black uppercase tracking-[0.2em] text-slate-400 dark:text-slate-500">
            User Access Summary
          </p>
        </div>

        <div className="grid lg:grid-cols-3">
          <div className="flex items-center justify-center gap-5 px-6 py-5 lg:border-r lg:border-slate-200 dark:lg:border-slate-700">
            <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-amber-100 text-amber-600 dark:bg-amber-950/50 dark:text-amber-300">
              <UserRoundCheck size={28} strokeWidth={2.2} />
            </div>
            <div className="min-w-[150px]">
              <p className="text-sm font-black text-amber-700 dark:text-amber-300">
                Register รออนุมัติ
              </p>
              <div className="mt-1 flex items-end gap-2">
                <span className="text-4xl font-black leading-none text-slate-950 dark:text-white">
                  {requests.length}
                </span>
                <span className="pb-0.5 text-xs font-bold text-slate-400">รายการ</span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-center gap-5 border-t border-slate-200 px-6 py-5 lg:border-r lg:border-t-0 dark:border-slate-700">
            <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-cyan-100 text-cyan-600 dark:bg-cyan-950/50 dark:text-cyan-300">
              <BellRing size={28} strokeWidth={2.2} />
            </div>
            <div className="min-w-[160px]">
              <p className="text-sm font-black text-cyan-700 dark:text-cyan-300">
                คำขอสิทธิ์เพิ่มเติม
              </p>
              <div className="mt-1 flex items-end gap-2">
                <span className="text-4xl font-black leading-none text-slate-950 dark:text-white">
                  {permissionRequests.length}
                </span>
                <span className="pb-0.5 text-xs font-bold text-slate-400">รายการ</span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-center gap-5 border-t border-slate-200 px-6 py-5 lg:border-t-0 dark:border-slate-700">
            <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-emerald-100 text-emerald-600 dark:bg-emerald-950/50 dark:text-emerald-300">
              <UsersRound size={28} strokeWidth={2.2} />
            </div>
            <div className="min-w-[190px]">
              <p className="text-sm font-black text-emerald-700 dark:text-emerald-300">
                ผู้ใช้งานที่อนุมัติแล้ว
              </p>
              <div className="mt-1 flex items-end gap-2">
                <span className="text-4xl font-black leading-none text-slate-950 dark:text-white">
                  {approvedUsers.length}
                </span>
                <span className="pb-0.5 text-xs font-bold text-slate-400">คน</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {notification ? (
        <div className="flex items-start gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-sm font-bold text-emerald-700 dark:border-emerald-900/60 dark:bg-emerald-950/30 dark:text-emerald-300">
          <CheckCircle2 size={19} className="mt-0.5 shrink-0" />
          <span>{notification}</span>
        </div>
      ) : null}

      {error ? (
        <div className="flex items-start gap-3 rounded-2xl border border-rose-200 bg-rose-50 p-4 text-sm font-bold text-rose-700 dark:border-rose-900/60 dark:bg-rose-950/30 dark:text-rose-300">
          <AlertTriangle size={19} className="mt-0.5 shrink-0" />
          <span>{error}</span>
        </div>
      ) : null}

      <section className="rounded-[2rem] border border-slate-300 bg-white shadow-md dark:border-slate-700 dark:bg-slate-900">
        <div className="flex flex-col gap-3 border-b border-slate-200 p-5 sm:flex-row sm:items-center sm:justify-between dark:border-slate-700">
          <div>
            <h2 className="text-xl font-black text-slate-950 dark:text-white">
              คำขอ Register ที่รออนุมัติ
            </h2>
            <p className="mt-1 text-sm font-semibold text-slate-500 dark:text-slate-400">
              กำหนด Role และ Permission ก่อนกดอนุมัติ
            </p>
          </div>
          <span className="w-fit rounded-full bg-amber-100 px-4 py-2 text-xs font-black text-amber-700 dark:bg-amber-950/40 dark:text-amber-300">
            {requests.length} Pending
          </span>
        </div>

        <div className="p-5">
          {loading && requests.length === 0 ? (
            <div className="rounded-3xl border border-slate-200 bg-slate-50 p-8 text-center font-bold text-slate-500 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-400">
              กำลังโหลดคำขอ...
            </div>
          ) : requests.length === 0 ? (
            <div className="rounded-3xl border border-dashed border-slate-300 bg-slate-50 p-8 text-center text-slate-600 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-300">
              ไม่มีคำขอรออนุมัติในขณะนี้
            </div>
          ) : (
            <div className="space-y-5">
              {requests.map((request) => {
                const empCode = getRequestEmpCode(request);
                const current = settings[empCode] || buildInitialSetting();

                return (
                  <div
                    key={empCode}
                    className="rounded-3xl border border-slate-200 bg-slate-50 p-5 dark:border-slate-700 dark:bg-slate-950"
                  >
                    <div className="flex flex-col gap-4 xl:flex-row xl:items-start xl:justify-between">
                      <div>
                        <div className="flex flex-wrap items-center gap-3">
                          <span className="rounded-2xl bg-slate-900 px-4 py-2 text-sm font-black text-white dark:bg-white dark:text-slate-950">
                            {empCode}
                          </span>
                          <span className="rounded-full bg-amber-100 px-4 py-2 text-xs font-black text-amber-700 ring-1 ring-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:ring-amber-900/60">
                            {request.status || "PENDING"}
                          </span>
                        </div>

                        <h3 className="mt-4 text-2xl font-black text-slate-950 dark:text-white">
                          {request.empName || request.name || "-"}
                        </h3>
                        <p className="mt-1 text-sm font-bold text-slate-500 dark:text-slate-400">
                          {request.department || request.dept || "-"} /{" "}
                          {request.position || "-"}
                        </p>
                        <p className="mt-2 text-xs font-bold text-slate-400 dark:text-slate-500">
                          Requested At: {request.requestedAt || "-"}
                        </p>
                      </div>

                      <div className="flex flex-wrap gap-3">
                        <button
                          type="button"
                          onClick={(event) => handleApprove(event, request)}
                          disabled={Boolean(actionLoading)}
                          className="inline-flex items-center gap-2 rounded-2xl bg-emerald-600 px-5 py-3 text-sm font-black text-white transition hover:bg-emerald-700 disabled:opacity-50"
                        >
                          <UserRoundCheck size={18} />
                          {actionLoading === `approve-${empCode}`
                            ? "กำลังอนุมัติ..."
                            : "อนุมัติ"}
                        </button>

                        <button
                          type="button"
                          onClick={(event) => handleReject(event, request)}
                          disabled={Boolean(actionLoading)}
                          className="inline-flex items-center gap-2 rounded-2xl bg-rose-600 px-5 py-3 text-sm font-black text-white transition hover:bg-rose-700 disabled:opacity-50"
                        >
                          <UserRoundX size={18} />
                          {actionLoading === `reject-${empCode}`
                            ? "กำลังปฏิเสธ..."
                            : "ปฏิเสธ"}
                        </button>
                      </div>
                    </div>

                    <div className="mt-5 rounded-2xl bg-white p-4 text-slate-700 dark:bg-slate-900 dark:text-slate-200">
                      <p className="inline-flex items-center gap-2 text-base font-black text-slate-900 dark:text-slate-100">
                        <CircleHelp size={19} className="text-amber-500" />
                        เหตุผลการขอใช้งาน
                      </p>
                      <p className="mt-2 text-sm font-semibold">
                        {request.requestReason || request.reasonLabel || "-"}
                      </p>
                    </div>

                    <div className="mt-5 grid gap-4 xl:grid-cols-[250px_1fr]">
                      <div className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-slate-900">
                        <label className="inline-flex items-center gap-2 text-sm font-black text-slate-700 dark:text-slate-200">
                          <KeyRound size={16} className="text-cyan-600 dark:text-cyan-300" />
                          Role / Preset
                        </label>

                        <select
                          value={current.role}
                          onChange={(event) =>
                            handlePendingRoleChange(empCode, event.target.value)
                          }
                          className="mt-2 h-12 w-full rounded-2xl border border-slate-300 bg-white px-4 text-sm font-bold text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                        >
                          {roleOptions.map((role) => (
                            <option key={role.value} value={role.value}>
                              {role.label}
                            </option>
                          ))}
                        </select>

                        <div className="mt-4">
                          <label className="text-sm font-black text-slate-700 dark:text-slate-200">
                            เหตุผลกรณีปฏิเสธ
                          </label>
                          <textarea
                            value={current.rejectReason}
                            onChange={(event) =>
                              handleRejectReasonChange(empCode, event.target.value)
                            }
                            rows={3}
                            placeholder="เช่น สิทธิ์ไม่ตรงกับงานที่รับผิดชอบ..."
                            className="mt-2 w-full rounded-2xl border border-slate-300 bg-white px-4 py-3 text-sm font-bold text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                          />
                        </div>
                      </div>

                      <div className="rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-slate-900">
                        <div className="mb-3">
                          <h4 className="inline-flex items-center gap-2 text-sm font-black text-slate-800 dark:text-slate-100">
                            <ShieldCheck size={17} className="text-cyan-600 dark:text-cyan-300" />
                            Permission รายหน้า
                          </h4>
                        </div>

                        <PermissionChecklist
                          permissions={current.permissions}
                          onToggle={(key) =>
                            handlePendingTogglePermission(empCode, key)
                          }
                        />
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </section>

      <section className="rounded-[2rem] border border-cyan-200 bg-white shadow-md dark:border-cyan-900/60 dark:bg-slate-900">
        <div className="flex flex-col gap-3 border-b border-cyan-100 p-5 sm:flex-row sm:items-center sm:justify-between dark:border-cyan-900/40">
          <div>
            <div className="flex items-center gap-3">
              <BellRing size={22} className="text-cyan-600" />
              <h2 className="text-xl font-black text-slate-950 dark:text-white">
                คำขอสิทธิ์เพิ่มเติม
              </h2>
            </div>
            <p className="mt-1 text-sm font-semibold text-slate-500 dark:text-slate-400">
              คำขอจากผู้ใช้งานที่ได้รับอนุมัติแล้วและต้องการเข้าใช้งานหน้าเพิ่มเติม
            </p>
          </div>
          <span className="w-fit rounded-full bg-cyan-100 px-4 py-2 text-xs font-black text-cyan-700 dark:bg-cyan-950/40 dark:text-cyan-300">
            {permissionRequests.length} Pending
          </span>
        </div>

        <div className="p-5">
          {loading && permissionRequests.length === 0 ? (
            <div className="rounded-3xl border border-slate-200 bg-slate-50 p-8 text-center font-bold text-slate-500 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-400">
              กำลังโหลดคำขอสิทธิ์...
            </div>
          ) : permissionRequests.length === 0 ? (
            <div className="rounded-3xl border border-dashed border-slate-300 bg-slate-50 p-8 text-center text-slate-600 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-300">
              ไม่มีคำขอสิทธิ์เพิ่มเติมในขณะนี้
            </div>
          ) : (
            <div className="grid gap-4 xl:grid-cols-2">
              {permissionRequests.map((request) => {
                const empCode = getRequestEmpCode(request);
                const labels = getRequestedPermissionLabels(
                  request.permissionRequest,
                );

                return (
                  <div
                    key={`permission-${empCode}`}
                    className="rounded-3xl border border-cyan-200 bg-cyan-50/50 p-5 dark:border-cyan-900/50 dark:bg-cyan-950/15"
                  >
                    <div className="flex flex-col gap-4 sm:flex-row sm:items-start sm:justify-between">
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="rounded-xl bg-slate-900 px-3 py-1.5 font-mono text-xs font-black text-white dark:bg-white dark:text-slate-950">
                            {empCode}
                          </span>
                          <span className="rounded-full bg-amber-100 px-3 py-1.5 text-xs font-black text-amber-700 dark:bg-amber-950/40 dark:text-amber-300">
                            รอตรวจสอบ
                          </span>
                        </div>

                        <h3 className="mt-3 text-xl font-black text-slate-950 dark:text-white">
                          {request.empName || "-"}
                        </h3>
                        <p className="mt-1 text-sm font-semibold text-slate-500 dark:text-slate-400">
                          {request.department || "-"} / {request.position || "-"}
                        </p>
                      </div>

                      <button
                        type="button"
                        onClick={() => handleOpenPermissionRequestEditor(request)}
                        disabled={Boolean(actionLoading)}
                        className="inline-flex shrink-0 items-center justify-center gap-2 rounded-2xl bg-cyan-600 px-4 py-2.5 text-sm font-black text-white transition hover:bg-cyan-700 disabled:opacity-50"
                      >
                        <Pencil size={16} />
                        เปิดแก้ไขสิทธิ์
                      </button>
                    </div>

                    <div className="mt-4 rounded-2xl border border-cyan-100 bg-white p-4 dark:border-cyan-900/40 dark:bg-slate-900">
                      <p className="text-xs font-black uppercase tracking-[0.12em] text-slate-400">
                        Requested Permission
                      </p>
                      <div className="mt-2 flex flex-wrap gap-2">
                        {labels.length > 0 ? (
                          labels.map((label) => (
                            <span
                              key={`${empCode}-${label}`}
                              className="rounded-full bg-cyan-100 px-3 py-1.5 text-xs font-black text-cyan-800 dark:bg-cyan-950/50 dark:text-cyan-200"
                            >
                              {label}
                            </span>
                          ))
                        ) : (
                          <span className="text-sm font-semibold text-slate-500">
                            ไม่พบรายการสิทธิ์
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="mt-3 text-sm font-semibold text-slate-600 dark:text-slate-300">
                      <span className="font-black">เหตุผล:</span>{" "}
                      {request.permissionRequest?.requestReason || "-"}
                    </div>
                    <p className="mt-2 text-xs font-bold text-slate-400">
                      ส่งเมื่อ {request.permissionRequest?.requestedAt || "-"}
                    </p>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </section>

      <section id="approved-users-section" className="scroll-mt-6 overflow-hidden rounded-[2rem] border border-slate-300 bg-white shadow-md dark:border-slate-700 dark:bg-slate-900">
        <div className="flex flex-col gap-4 border-b border-slate-200 p-5 lg:flex-row lg:items-center lg:justify-between dark:border-slate-700">
          <div>
            <div className="flex items-center gap-3">
              <UsersRound size={23} className="text-emerald-600" />
              <h2 className="text-xl font-black text-slate-950 dark:text-white">
                ผู้ใช้งานที่อนุมัติแล้ว
              </h2>
            </div>
            <p className="mt-1 text-sm font-semibold text-slate-500 dark:text-slate-400">
              ดู Role / Permission ปัจจุบัน และกดแก้ไขสิทธิ์ได้จากตารางนี้
            </p>
          </div>

          <div className="relative w-full lg:w-80">
            <Search
              size={18}
              className="pointer-events-none absolute left-4 top-1/2 -translate-y-1/2 text-slate-400"
            />
            <input
              value={searchText}
              onChange={(event) => setSearchText(event.target.value)}
              placeholder="ชื่อ-นามสกุล / รหัสพนักงาน"
              className="h-12 w-full rounded-2xl border border-slate-300 bg-white pl-11 pr-4 text-sm font-bold text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
            />
          </div>
        </div>

        {loading && approvedUsers.length === 0 ? (
          <div className="p-8 text-center font-bold text-slate-500 dark:text-slate-400">
            กำลังโหลดรายชื่อผู้ใช้งาน...
          </div>
        ) : filteredApprovedUsers.length === 0 ? (
          <div className="p-8 text-center font-bold text-slate-500 dark:text-slate-400">
            ไม่พบผู้ใช้งานที่ตรงกับการค้นหา
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-[1160px] w-full border-collapse text-left">
              <thead className="bg-slate-100 dark:bg-slate-950">
                <tr className="border-b border-slate-200 dark:border-slate-700">
                  <th className="px-5 py-4 text-sm font-black uppercase tracking-wide text-slate-500">ชื่อ / รหัสพนักงาน</th>
                  <th className="px-4 py-4 text-sm font-black uppercase tracking-wide text-slate-500">แผนก / ตำแหน่ง</th>
                  <th className="px-4 py-4 text-sm font-black uppercase tracking-wide text-slate-500">Role</th>
                  <th className="px-4 py-4 text-sm font-black uppercase tracking-wide text-slate-500">Permission</th>
                  <th className="px-4 py-4 text-sm font-black uppercase tracking-wide text-slate-500">อนุมัติโดย / เวลา</th>
                  <th className="px-5 py-4 text-sm font-black uppercase tracking-wide text-slate-500">จัดการ</th>
                </tr>
              </thead>

              <tbody>
                {filteredApprovedUsers.map((access) => {
                  const empCode = getRequestEmpCode(access);
                  const editing = editingEmpCode === empCode;
                  const current =
                    approvedSettings[empCode] || buildApprovedSetting(access);
                  const permissionCount = getPermissionCount(access.permissions);

                  return (
                    <Fragment key={empCode}>
                      <tr
                        className="border-b border-slate-100 bg-white align-top transition hover:bg-slate-50 dark:border-slate-800 dark:bg-slate-900 dark:hover:bg-slate-800/60"
                      >
                        <td className="px-5 py-4">
                          <div className="font-black text-slate-950 dark:text-white">
                            {access.empName || "-"}
                          </div>
                          <div className="mt-1 font-mono text-sm font-black text-cyan-700 dark:text-cyan-300">
                            {empCode}
                          </div>
                        </td>
                        <td className="px-4 py-4">
                          <div className="text-sm font-bold text-slate-700 dark:text-slate-200">
                            {access.department || "-"}
                          </div>
                          <div className="mt-1 text-xs font-semibold text-slate-500 dark:text-slate-400">
                            {access.position || "-"}
                          </div>
                        </td>
                        <td className="px-4 py-4">
                          <span className="inline-flex rounded-full bg-cyan-100 px-3 py-1.5 text-xs font-black text-cyan-800 dark:bg-cyan-950/50 dark:text-cyan-200">
                            {getRoleLabel(access.role)}
                          </span>
                        </td>
                        <td className="px-4 py-4">
                          <div className="text-sm font-black text-slate-800 dark:text-slate-100">
                            {permissionCount} / {permissionItems.length} สิทธิ์
                          </div>
                        </td>
                        <td className="px-4 py-4">
                          <div className="text-sm font-bold text-slate-700 dark:text-slate-200">
                            {access.approvedBy || "-"}
                          </div>
                          <div className="mt-1 text-xs font-semibold text-slate-500 dark:text-slate-400">
                            {access.approvedAt || "-"}
                          </div>
                        </td>
                        <td className="px-5 py-4 text-left">
                          <div className="flex flex-wrap items-center gap-2">
                            <button
                              type="button"
                              onClick={() =>
                                editing
                                  ? handleCancelEdit(access)
                                  : handleStartEdit(access)
                              }
                              disabled={Boolean(actionLoading)}
                              className={[
                                "inline-flex items-center gap-2 rounded-xl px-4 py-2.5 text-sm font-black transition disabled:opacity-50",
                                editing
                                  ? "border border-slate-300 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
                                  : "bg-cyan-600 text-white hover:bg-cyan-700",
                              ].join(" ")}
                            >
                              {editing ? <X size={16} /> : <Pencil size={16} />}
                              {editing ? "ยกเลิก" : "แก้ไขสิทธิ์"}
                            </button>

                            <button
                              type="button"
                              onClick={() => handleAskDeleteUser(access)}
                              disabled={
                                Boolean(actionLoading) || empCode === adminEmpCode
                              }
                              title={
                                empCode === adminEmpCode
                                  ? "ไม่สามารถลบบัญชีที่กำลัง Login อยู่ได้"
                                  : "ลบผู้ใช้งานออกจากระบบสิทธิ์"
                              }
                              className="inline-flex items-center gap-2 rounded-xl border border-rose-200 bg-rose-50 px-4 py-2.5 text-sm font-black text-rose-700 transition hover:bg-rose-100 disabled:cursor-not-allowed disabled:opacity-40 dark:border-rose-900/60 dark:bg-rose-950/30 dark:text-rose-300 dark:hover:bg-rose-950/50"
                            >
                              <Trash2 size={16} />
                              ลบ
                            </button>
                          </div>
                        </td>
                      </tr>

                      {editing ? (
                        <tr key={`${empCode}-editor`} className="border-b border-cyan-200 bg-cyan-50/60 dark:border-cyan-900/60 dark:bg-cyan-950/15">
                          <td colSpan={6} className="px-5 py-5">
                            <div className="grid gap-4 xl:grid-cols-[250px_1fr]">
                              <div className="rounded-2xl border border-cyan-200 bg-white p-4 dark:border-cyan-900/60 dark:bg-slate-900">
                                <label className="inline-flex items-center gap-2 text-sm font-black text-slate-700 dark:text-slate-200">
                                  <KeyRound size={16} className="text-cyan-600" />
                                  Role
                                </label>
                                <select
                                  value={current.role}
                                  onChange={(event) =>
                                    handleApprovedRoleChange(
                                      empCode,
                                      event.target.value,
                                    )
                                  }
                                  className="mt-2 h-12 w-full rounded-2xl border border-slate-300 bg-white px-4 text-sm font-bold text-slate-900 outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100"
                                >
                                  {roleOptions.map((role) => (
                                    <option key={role.value} value={role.value}>
                                      {role.label}
                                    </option>
                                  ))}
                                </select>

                                <p className="mt-3 text-xs font-semibold leading-5 text-slate-500 dark:text-slate-400">
                                  สามารถเปลี่ยน Role ของผู้ใช้งานได้
                                </p>
                              </div>

                              <div className="rounded-2xl border border-cyan-200 bg-white p-4 dark:border-cyan-900/60 dark:bg-slate-900">
                                <div className="mb-3 flex items-center justify-between gap-3">
                                  <div>
                                    <h4 className="inline-flex items-center gap-2 text-sm font-black text-slate-800 dark:text-slate-100">
                                      <ShieldCheck size={17} className="text-cyan-600" />
                                      Permission ของ {empCode}
                                    </h4>
                                    <p className="mt-1 text-xs font-semibold text-slate-500 dark:text-slate-400">
                                      เลือก Checklist ได้ทีละหน้า
                                    </p>
                                  </div>
                                  <span className="rounded-full bg-emerald-100 px-3 py-1.5 text-xs font-black text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300">
                                    {getPermissionCount(current.permissions)} / {permissionItems.length}
                                  </span>
                                </div>

                                <PermissionChecklist
                                  permissions={current.permissions}
                                  onToggle={(key) =>
                                    handleApprovedTogglePermission(empCode, key)
                                  }
                                />

                                <div className="mt-4 flex justify-end">
                                  <button
                                    type="button"
                                    onClick={(event) => handleSaveApprovedUser(event, access)}
                                    disabled={Boolean(actionLoading)}
                                    className="inline-flex items-center gap-2 rounded-2xl bg-emerald-600 px-5 py-3 text-sm font-black text-white transition hover:bg-emerald-700 disabled:opacity-50"
                                  >
                                    <Save size={17} />
                                    {actionLoading === `save-${empCode}`
                                      ? "กำลังบันทึก..."
                                      : "บันทึก Role / Permission"}
                                  </button>
                                </div>
                              </div>
                            </div>
                          </td>
                        </tr>
                      ) : null}
                    </Fragment>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </section>

      <CenterAlert
        open={Boolean(deleteTarget)}
        title="ยืนยันการลบผู้ใช้งาน"
        message={
          deleteTarget
            ? `ต้องการลบ ${deleteTarget.empName || "ผู้ใช้งาน"} (${getRequestEmpCode(
                deleteTarget,
              )}) ออกจากรายการสิทธิ์หรือไม่? หลังลบ ผู้ใช้งานจะต้องส่งคำขอ Register ใหม่หากต้องการเข้าใช้งานระบบอีกครั้ง`
            : ""
        }
        variant="danger"
        confirmText={
          actionLoading?.startsWith("delete-") ? "กำลังลบ..." : "ลบผู้ใช้งาน"
        }
        cancelText="ยกเลิก"
        onClose={() => {
          if (!actionLoading) setDeleteTarget(null);
        }}
        onConfirm={handleConfirmDeleteUser}
      />
    </div>
  );
}
