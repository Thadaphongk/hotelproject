import { Fragment, useEffect, useMemo, useState } from "react";
import {
  Activity,
  Bug,
  Clock3,
  Copy,
  Database,
  Download,
  Filter,
  Layers3,
  RefreshCw,
  RotateCcw,
  Rows3,
  Search,
  ServerCog,
  TableProperties,
  TriangleAlert,
} from "lucide-react";
import { formatDisplayMachineName } from "../utils/machineQueueUtils";

const API_BASE_URL = "";

const apiUrl = (path) => `${API_BASE_URL}${path}`;

const columns = [
  "Machine",
  "queueNo",
  "lotId",
  "queueMachine",
  "actualMachine",
  "lineName",
  "unitName",
  "sourceType",
  "machineStatus",
  "stopCode",
  "processStatus",
  "startTime",
  "inputDate",
  "inputDate",
  "sortGroup",
  "sortNo",
  "plannedQty",
  "partName",
  "trackingNo",
];

const normalize = (value) =>
  String(value ?? "")
    .trim()
    .toUpperCase();

const hasValue = (value) => {
  const text = String(value ?? "").trim();
  return (
    text !== "" &&
    text !== "-" &&
    text.toLowerCase() !== "null" &&
    text.toLowerCase() !== "undefined"
  );
};

const flattenMachines = (machines) => {
  if (!Array.isArray(machines)) return [];

  return machines.flatMap((machine) => {
    const lots =
      Array.isArray(machine.lots) && machine.lots.length > 0
        ? machine.lots
        : [machine];

    return lots.map((lot, index) => ({
      machineName: machine.machineName || lot.machineName || "-",
      queueNo: lot.queueNo ?? index + 1,
      lotId: lot.lotId || lot.lotId || "-",
      queueMachine: lot.queueMachine || "-",
      actualMachine: lot.actualMachine || "-",
      lineName: lot.lineName || "-",
      unitName: lot.unitName || "-",
      sourceType: lot.sourceType || "-",
      machineStatus: lot.machineStatus || "-",
      stopCode: lot.stopCode || "-",
      processStatus: lot.processStatus || "-",
      startTime: lot.startTime || "-",
      inputDate: lot.inputDate || "-",
      inputDate: lot.inputDate || "-",
      sortGroup: lot.sortGroup ?? "-",
      sortNo: lot.sortNo ?? "-",
      plannedQty: lot.plannedQty ?? "-",
      partName: lot.partName || lot.partName || "-",
      trackingNo: lot.trackingNo || lot.trackingNo || "-",
      __raw: lot,
    }));
  });
};

const csvEscape = (value) => {
  const text = String(value ?? "");
  if (/[",\n]/.test(text)) return `"${text.replace(/"/g, '""')}"`;
  return text;
};

export default function MachineDebug() {
  const [machines, setMachines] = useState([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [message, setMessage] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);

  const [machineFilter, setMachineFilter] = useState("ALL");
  const [sourceFilter, setSourceFilter] = useState("ALL");
  const [statusFilter, setStatusFilter] = useState("ALL");
  const [lotSearch, setLotSearch] = useState("");

  const rows = useMemo(() => flattenMachines(machines), [machines]);

  const machineOptions = useMemo(() => {
    return [
      "ALL",
      ...Array.from(new Set(rows.map((row) => row.machineName))).sort(),
    ];
  }, [rows]);

  const sourceOptions = useMemo(() => {
    return [
      "ALL",
      ...Array.from(new Set(rows.map((row) => row.sourceType))).sort(),
    ];
  }, [rows]);

  const statusOptions = useMemo(() => {
    return [
      "ALL",
      ...Array.from(new Set(rows.map((row) => row.machineStatus))).sort(),
    ];
  }, [rows]);

  const filteredRows = useMemo(() => {
    const searchText = normalize(lotSearch);

    return rows.filter((row) => {
      if (machineFilter !== "ALL" && row.machineName !== machineFilter)
        return false;
      if (sourceFilter !== "ALL" && row.sourceType !== sourceFilter)
        return false;
      if (statusFilter !== "ALL" && row.machineStatus !== statusFilter)
        return false;

      if (searchText) {
        const lot = normalize(row.lotId);
        const part = normalize(row.partName);
        const insp = normalize(row.trackingNo);
        if (
          !lot.includes(searchText) &&
          !part.includes(searchText) &&
          !insp.includes(searchText)
        ) {
          return false;
        }
      }

      return true;
    });
  }, [rows, machineFilter, sourceFilter, statusFilter, lotSearch]);

  const machineGroups = useMemo(() => {
    const groups = [];
    const groupMap = new Map();

    filteredRows.forEach((row) => {
      const machine = row.machineName || "-";
      let group = groupMap.get(machine);

      if (!group) {
        group = {
          machine,
          rows: [],
          currentCount: 0,
          activeCount: 0,
          waitingCount: 0,
          runCount: 0,
          stopCount: 0,
        };
        groupMap.set(machine, group);
        groups.push(group);
      }

      group.rows.push(row);
      if (normalize(row.sourceType) === "CURRENT") group.currentCount += 1;
      if (normalize(row.processStatus) === "ACTIVE") group.activeCount += 1;
      if (normalize(row.processStatus) === "WAITING") group.waitingCount += 1;
      if (normalize(row.machineStatus) === "RUN") group.runCount += 1;
      if (normalize(row.machineStatus) === "STOP") group.stopCount += 1;
    });

    return groups;
  }, [filteredRows]);

  const fetchMachines = async () => {
    setLoading(true);
    setError(null);
    setMessage(null);

    try {
      const res = await fetch(apiUrl("/api/machines"));
      if (!res.ok) throw new Error("Failed to fetch /api/machines");
      const payload = await res.json();
      setMachines(Array.isArray(payload) ? payload : []);
      setLastUpdated(new Date());
    } catch (err) {
      console.error(err);
      setError(err.message || "Failed to load machine debug data");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchMachines();
  }, []);

  const copyJson = async () => {
    try {
      await navigator.clipboard.writeText(
        JSON.stringify(filteredRows, null, 2),
      );
      setMessage(`Copied ${filteredRows.length} rows to clipboard`);
    } catch (err) {
      console.error(err);
      setError("Copy JSON failed. Browser may block clipboard access.");
    }
  };

  const exportCsv = () => {
    const lines = [
      columns.join(","),
      ...filteredRows.map((row) =>
        columns.map((column) => csvEscape(row[column])).join(","),
      ),
    ];

    const blob = new Blob(["\uFEFF" + lines.join("\r\n")], {
      type: "text/csv;charset=utf-8;",
    });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = "machine-debug.csv";
    link.click();
    URL.revokeObjectURL(link.href);
  };

  const clearFilters = () => {
    setMachineFilter("ALL");
    setSourceFilter("ALL");
    setStatusFilter("ALL");
    setLotSearch("");
  };

  const stopCount = rows.filter(
    (row) => hasValue(row.stopCode) || normalize(row.machineStatus) === "STOP",
  ).length;
  const runCount = rows.filter(
    (row) => normalize(row.machineStatus) === "RUN" && !hasValue(row.stopCode),
  ).length;

  return (
    <div className="min-h-full  p-4 text-slate-950 dark:text-slate-50 sm:p-6">
      <div className="mx-auto flex max-w-8xl flex-col gap-4">
        <section className="relative overflow-hidden rounded-[2rem] border border-slate-300 bg-gradient-to-br from-indigo-50 via-white to-slate-100 p-5 shadow-lg dark:border-slate-700 dark:from-slate-900 dark:via-slate-950 dark:to-indigo-950/30">
          <div className="absolute right-[-70px] top-[-80px] h-52 w-52 rounded-full bg-indigo-400/20 blur-3xl" />

          <div className="relative flex flex-col gap-5 xl:flex-row xl:items-end xl:justify-between">
            <div className="flex items-start gap-4">
              <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-indigo-600 text-white shadow-lg shadow-indigo-600/20">
                <Bug size={28} strokeWidth={2.2} />
              </div>

              <div>
                <p className="text-xs font-black uppercase tracking-[0.22em] text-indigo-700 dark:text-indigo-300">
                  Machine Debug
                </p>
                <h1 className="mt-1 text-2xl font-black tracking-tight text-slate-900 sm:text-3xl dark:text-white">
                  Raw Machine Data Table
                </h1>
                <p className="mt-2 max-w-4xl text-sm font-medium text-slate-600 dark:text-slate-300">
                  ตรวจข้อมูลจาก /api/machines แบบ flatten machine.lots เพื่อดูว่า
                  Lot, Machine, sourceType, Status และ LossCode มาจากจุดใด
                </p>

                <div className="mt-3 flex flex-wrap gap-2">
                  <span className="inline-flex items-center gap-2 rounded-full bg-indigo-100 px-3 py-1.5 text-xs font-black text-indigo-800 dark:bg-indigo-950/60 dark:text-indigo-300">
                    <ServerCog size={14} />
                    /api/machines
                  </span>
                  <span className="inline-flex items-center gap-2 rounded-full bg-slate-200/80 px-3 py-1.5 text-xs font-black text-slate-700 dark:bg-slate-800 dark:text-slate-300">
                    <Database size={14} />
                    Raw Frontend Debug
                  </span>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap gap-3">
              <button
                type="button"
                onClick={fetchMachines}
                disabled={loading}
                className="inline-flex h-11 items-center gap-2 rounded-xl bg-slate-900 px-4 font-bold text-white shadow-sm transition hover:bg-slate-700 disabled:cursor-not-allowed disabled:opacity-60 dark:bg-slate-100 dark:text-slate-950 dark:hover:bg-white"
              >
                <RefreshCw size={17} className={loading ? "animate-spin" : ""} />
                {loading ? "Loading..." : "Refresh"}
              </button>
              <button
                type="button"
                onClick={copyJson}
                className="inline-flex h-11 items-center gap-2 rounded-xl bg-indigo-600 px-4 font-bold text-white shadow-sm shadow-indigo-600/20 transition hover:bg-indigo-500"
              >
                <Copy size={17} />
                Copy JSON
              </button>
              <button
                type="button"
                onClick={exportCsv}
                className="inline-flex h-11 items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 font-bold text-slate-700 shadow-sm transition hover:border-indigo-300 hover:bg-indigo-50 hover:text-indigo-700 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200 dark:hover:bg-slate-900"
              >
                <Download size={17} />
                Export CSV
              </button>
            </div>
          </div>

          <div className="relative mt-5 grid gap-3 sm:grid-cols-4">
            <SummaryCard
              label="Machines"
              value={machines.length}
              icon={ServerCog}
            />
            <SummaryCard
              label="Raw Rows"
              value={rows.length}
              icon={Rows3}
            />
            <SummaryCard
              label="Running Rows"
              value={runCount}
              tone="run"
              icon={Activity}
            />
            <SummaryCard
              label="Stop/Loss Rows"
              value={stopCount}
              tone="stop"
              icon={TriangleAlert}
            />
          </div>

          <div className="mt-5 grid gap-3 md:grid-cols-4">
            <FilterSelect
              label="Machine"
              value={machineFilter}
              onChange={setMachineFilter}
              options={machineOptions}
              icon={ServerCog}
              formatOption={(option) =>
                option === "ALL" ? option : formatDisplayMachineName(option)
              }
            />
            <FilterSelect
              label="sourceType"
              value={sourceFilter}
              onChange={setSourceFilter}
              options={sourceOptions}
              icon={Layers3}
            />
            <FilterSelect
              label="Status"
              value={statusFilter}
              onChange={setStatusFilter}
              options={statusOptions}
              icon={Activity}
            />
            <label className="flex flex-col gap-1 text-sm font-bold text-slate-600 dark:text-slate-300">
              <span className="inline-flex items-center gap-2">
                <Search size={16} />
                Lot / Part / INSP Search
              </span>
              <input
                value={lotSearch}
                onChange={(event) => setLotSearch(event.target.value)}
                placeholder="Search..."
                className="rounded-xl border border-slate-300 bg-white px-3 py-2 text-slate-950 outline-none focus:border-cyan-500 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-50"
              />
            </label>
          </div>

          <div className="mt-4 flex flex-wrap items-center gap-3 text-sm">
            <span className="inline-flex items-center gap-2 rounded-xl bg-slate-500/10 px-3 py-2 font-semibold text-slate-600 dark:text-slate-300">
              <Filter size={16} />
              Showing {filteredRows.length} / {rows.length} rows
            </span>
            {lastUpdated && (
              <span className="inline-flex items-center gap-2 rounded-xl bg-slate-500/10 px-3 py-2 font-semibold text-slate-600 dark:text-slate-300">
                <Clock3 size={16} />
                Last update: {lastUpdated.toLocaleString()}
              </span>
            )}
            <button
              type="button"
              onClick={clearFilters}
              className="inline-flex items-center gap-2 rounded-xl border border-slate-300 px-3 py-2 font-bold text-slate-700 hover:border-indigo-300 hover:bg-indigo-50 hover:text-indigo-700 dark:border-slate-700 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <RotateCcw size={16} />
              Clear filters
            </button>
            {error && (
              <span className="inline-flex items-center gap-2 rounded-xl bg-rose-500/10 px-3 py-2 font-semibold text-rose-700 dark:text-rose-300">
                <TriangleAlert size={16} />
                {error}
              </span>
            )}
            {message && (
              <span className="inline-flex items-center gap-2 rounded-xl bg-emerald-500/10 px-3 py-2 font-semibold text-emerald-700 dark:text-emerald-300">
                <Copy size={16} />
                {message}
              </span>
            )}
          </div>
        </section>

        <section className="overflow-hidden rounded-3xl border border-slate-200 bg-white/90 shadow-sm dark:border-slate-800 dark:bg-slate-900/90">
          <div className="flex flex-col gap-2 border-b border-slate-200 bg-slate-50/80 px-5 py-4 sm:flex-row sm:items-center sm:justify-between dark:border-slate-800 dark:bg-slate-950/50">
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-indigo-100 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300">
                <TableProperties size={20} />
              </span>
              <div>
                <h2 className="font-black text-slate-900 dark:text-white">
                  Machine Data Rows
                </h2>
                <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                  ตารางข้อมูลดิบตาม Filter ที่เลือก
                </p>
              </div>
            </div>
            <span className="rounded-full bg-indigo-100 px-3 py-1.5 text-xs font-black text-indigo-800 dark:bg-indigo-950/60 dark:text-indigo-300">
              {filteredRows.length} / {rows.length} rows
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-[1960px] w-full text-left text-[13px]">
              <thead className="sticky top-0 z-20 bg-slate-100 text-[11px] font-black uppercase tracking-[0.06em] text-slate-600 shadow-[0_1px_0_rgba(148,163,184,0.35)] dark:bg-slate-800 dark:text-slate-300">
                <tr>
                  {columns.map((column) => (
                    <th
                      key={column}
                      className={`whitespace-nowrap px-3 py-3.5 ${columnHeaderClass(column)}`}
                    >
                      {column}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {machineGroups.map((group, groupIndex) => (
                  <Fragment key={group.machine}>
                    <tr>
                      <td colSpan={columns.length} className="p-0">
                        <div
                          className={`flex flex-wrap items-center gap-2 border-y px-4 py-2.5 ${machineGroupClass(groupIndex)}`}
                        >
                          <span className="inline-flex items-center gap-2 text-sm font-black text-slate-950 dark:text-white">
                            <ServerCog size={16} />
                            {formatDisplayMachineName(group.machine)}
                          </span>
                          <span className="rounded-full bg-white/80 px-2.5 py-1 text-[11px] font-black text-slate-700 shadow-sm dark:bg-slate-950/70 dark:text-slate-200">
                            {group.rows.length} rows
                          </span>
                          {group.currentCount > 0 && (
                            <span className="rounded-full bg-cyan-100 px-2.5 py-1 text-[11px] font-black text-cyan-800 dark:bg-cyan-950/70 dark:text-cyan-200">
                              Current {group.currentCount}
                            </span>
                          )}
                          {group.activeCount > 0 && (
                            <span className="rounded-full bg-indigo-100 px-2.5 py-1 text-[11px] font-black text-indigo-800 dark:bg-indigo-950/70 dark:text-indigo-200">
                              ACTIVE {group.activeCount}
                            </span>
                          )}
                          {group.waitingCount > 0 && (
                            <span className="rounded-full bg-sky-100 px-2.5 py-1 text-[11px] font-black text-sky-800 dark:bg-sky-950/70 dark:text-sky-200">
                              WAITING {group.waitingCount}
                            </span>
                          )}
                          <span className="ml-auto flex items-center gap-2">
                            {group.runCount > 0 && (
                              <span className="rounded-full bg-emerald-100 px-2.5 py-1 text-[11px] font-black text-emerald-800 dark:bg-emerald-950/70 dark:text-emerald-200">
                                Run {group.runCount}
                              </span>
                            )}
                            {group.stopCount > 0 && (
                              <span className="rounded-full bg-rose-100 px-2.5 py-1 text-[11px] font-black text-rose-800 dark:bg-rose-950/70 dark:text-rose-200">
                                Stop {group.stopCount}
                              </span>
                            )}
                          </span>
                        </div>
                      </td>
                    </tr>

                    {group.rows.map((row, rowIndex) => (
                      <tr
                        key={`${row.machineName}-${row.queueNo}-${row.lotId}-${rowIndex}`}
                        className={`border-b border-slate-200 transition-colors hover:bg-cyan-50/70 dark:border-slate-800 dark:hover:bg-cyan-950/20 ${
                          rowIndex % 2 === 0
                            ? "bg-white dark:bg-slate-900"
                            : "bg-slate-50/70 dark:bg-slate-900/60"
                        }`}
                      >
                        {columns.map((column) => (
                          <td
                            key={column}
                            className={`whitespace-nowrap px-3 py-3 ${cellClass(column, row[column])} ${columnCellClass(column)}`}
                          >
                            {renderCell(column, row[column])}
                          </td>
                        ))}
                      </tr>
                    ))}
                  </Fragment>
                ))}

                {machineGroups.length === 0 && (
                  <tr>
                    <td
                      colSpan={columns.length}
                      className="px-6 py-12 text-center text-sm font-bold text-slate-500 dark:text-slate-400"
                    >
                      ไม่พบข้อมูลตาม Filter ที่เลือก
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </div>
  );
}

function SummaryCard({ label, value, tone = "default", icon: Icon }) {
  const style = {
    default: {
      value: "text-indigo-700 dark:text-indigo-300",
      icon: "bg-indigo-100 text-indigo-700 dark:bg-indigo-950/60 dark:text-indigo-300",
      card: "from-indigo-50 to-white dark:from-indigo-950/30 dark:to-slate-950",
    },
    run: {
      value: "text-emerald-700 dark:text-emerald-300",
      icon: "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300",
      card: "from-emerald-50 to-white dark:from-emerald-950/30 dark:to-slate-950",
    },
    stop: {
      value: "text-rose-700 dark:text-rose-300",
      icon: "bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300",
      card: "from-rose-50 to-white dark:from-rose-950/30 dark:to-slate-950",
    },
  }[tone];

  return (
    <div
      className={`flex items-center justify-between rounded-2xl border border-slate-200 bg-gradient-to-br p-4 shadow-sm dark:border-slate-800 ${style.card}`}
    >
      <div>
        <p className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-400">
          {label}
        </p>
        <p className={`mt-1 text-3xl font-black ${style.value}`}>{value}</p>
      </div>

      {Icon ? (
        <span
          className={`flex h-11 w-11 items-center justify-center rounded-2xl ${style.icon}`}
        >
          <Icon size={22} strokeWidth={2.2} />
        </span>
      ) : null}
    </div>
  );
}

function FilterSelect({
  label,
  value,
  onChange,
  options,
  icon: Icon,
  formatOption = (option) => option,
}) {
  return (
    <label className="flex flex-col gap-1 text-sm font-bold text-slate-600 dark:text-slate-300">
      <span className="inline-flex items-center gap-2">
        {Icon ? <Icon size={16} /> : null}
        {label}
      </span>
      <select
        value={value}
        onChange={(event) => onChange(event.target.value)}
        className="rounded-xl border border-slate-300 bg-white px-3 py-2 text-slate-950 outline-none transition focus:border-indigo-500 focus:ring-2 focus:ring-indigo-100 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-50 dark:focus:ring-indigo-950"
      >
        {options.map((option) => (
          <option key={option} value={option}>
            {formatOption(option)}
          </option>
        ))}
      </select>
    </label>
  );
}

function machineGroupClass(index) {
  return index % 2 === 0
    ? "border-cyan-200 bg-cyan-50/95 dark:border-cyan-900/70 dark:bg-cyan-950/30"
    : "border-indigo-200 bg-indigo-50/95 dark:border-indigo-900/70 dark:bg-indigo-950/30";
}

function columnHeaderClass(column) {
  if (column === "Machine") return "min-w-[120px]";
  if (column === "queueNo") return "min-w-[80px] text-center";
  if (column === "lotId") return "min-w-[145px]";
  if (column === "queueMachine" || column === "actualMachine") return "min-w-[120px]";
  if (column === "lineName") return "min-w-[105px]";
  if (column === "unitName") return "min-w-[245px]";
  if (column === "sourceType") return "min-w-[150px]";
  if (column === "processStatus") return "min-w-[135px]";
  return "";
}

function columnCellClass(column) {
  if (column === "queueNo") return "text-center font-black";
  if (column === "unitName" || column === "partName") return "max-w-[280px] overflow-hidden text-ellipsis";
  return "";
}

function renderCell(column, value) {
  const text = formatCell(column, value);

  if (column === "sourceType") {
    const current = normalize(value) === "CURRENT";
    return (
      <span
        className={`inline-flex rounded-full px-2.5 py-1 text-[11px] font-black ${
          current
            ? "bg-cyan-100 text-cyan-800 dark:bg-cyan-950/70 dark:text-cyan-200"
            : "bg-violet-100 text-violet-800 dark:bg-violet-950/70 dark:text-violet-200"
        }`}
      >
        {text}
      </span>
    );
  }

  if (column === "machineStatus") {
    const status = normalize(value);
    const className =
      status === "RUN"
        ? "bg-emerald-100 text-emerald-800 dark:bg-emerald-950/70 dark:text-emerald-200"
        : status === "STOP"
          ? "bg-rose-100 text-rose-800 dark:bg-rose-950/70 dark:text-rose-200"
          : "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300";

    return (
      <span className={`inline-flex rounded-full px-2.5 py-1 text-[11px] font-black ${className}`}>
        {text}
      </span>
    );
  }

  if (column === "processStatus") {
    const status = normalize(value);
    const className =
      status === "WAITING"
        ? "bg-sky-100 text-sky-800 dark:bg-sky-950/70 dark:text-sky-200"
        : status === "ACTIVE"
          ? "bg-indigo-100 text-indigo-800 dark:bg-indigo-950/70 dark:text-indigo-200"
          : "bg-slate-100 text-slate-600 dark:bg-slate-800 dark:text-slate-300";

    return (
      <span className={`inline-flex rounded-full px-2.5 py-1 text-[11px] font-black ${className}`}>
        {text}
      </span>
    );
  }

  if (column === "stopCode" && hasValue(value)) {
    return (
      <span className="inline-flex rounded-full bg-rose-100 px-2.5 py-1 text-[11px] font-black text-rose-700 dark:bg-rose-950/70 dark:text-rose-200">
        {text}
      </span>
    );
  }

  return text;
}

function formatCell(column, value) {
  if (value === null || value === undefined || value === "") return "-";

  if (["Machine", "queueMachine", "actualMachine", "lineName"].includes(column)) {
    return formatDisplayMachineName(value);
  }

  return String(value);
}

function cellClass(column, value) {
  if (column === "Machine")
    return "font-black text-slate-900 dark:text-slate-50";
  if (column === "lotId") return "font-bold text-cyan-700 dark:text-cyan-300";
  if (column === "stopCode" && hasValue(value))
    return "font-black text-rose-600 dark:text-rose-300";
  if (column === "machineStatus" && normalize(value) === "RUN")
    return "font-black text-emerald-600 dark:text-emerald-300";
  if (column === "machineStatus" && normalize(value) === "STOP")
    return "font-black text-rose-600 dark:text-rose-300";
  if (column === "sourceType")
    return "font-bold text-indigo-600 dark:text-indigo-300";
  return "text-slate-700 dark:text-slate-300";
}
