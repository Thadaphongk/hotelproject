import { useState, useEffect, useRef } from "react";
import {
  AlertTriangle,
  ArrowRightLeft,
  Info,
  Maximize2,
  Minimize2,
  MonitorCog,
  PlayCircle,
  RefreshCw,
  Server,
  Wrench,
} from "lucide-react";
import { getMachines } from "../services/api";
import {
  formatDisplayMachineName,
  formatMachineName,
} from "../utils/machineQueueUtils";

// Mapping Line -> Machine โหลดแบบ Real-time ผ่าน getMachines / Demo mapping service

// ลำดับการเรียงเครื่องจักรที่ต้องการอย่างชัดเจน
const machineSortOrder = [
  "DEMO-MC-A01",
  "DEMO-MC-A02",
  "DEMO-MC-B01",
  "DEMO-MC-B02",
  "DEMO-MC-C01",
  "DEMO-MC-C02",
];

// Helper functions สำหรับจัดการข้อมูลเครื่องจักรแบบใหม่
const hasValue = (value) =>
  value !== null &&
  value !== undefined &&
  String(value).trim() !== "" &&
  String(value).trim() !== "-";

const getMachineFirstLot = (machine) => machine.lots?.[0] || machine;

const hasMachineData = (machine) => {
  const lot = getMachineFirstLot(machine);
  return [
    lot.machineStatus,
    lot.lotId,
    lot.lotId,
    lot.stopCode,
    lot.startTime,
    lot.inputDate,
  ].some(hasValue);
};

const isCurrentMachineLot = (lot) =>
  String(lot?.sourceType || "")
    .trim()
    .toUpperCase() === "CURRENT";

const isRunningMachine = (machine) => {
  const lot = getMachineFirstLot(machine);

  // Running ต้องเป็น Current Lot ที่ Backend ยืนยันว่า
  // Process ล่าสุดยังอยู่ Demo/WIP Demo เท่านั้น
  if (!isCurrentMachineLot(lot)) return false;
  if (isStopLossMachine(machine)) return false;

  return true;
};

const isStopLossMachine = (machine) => {
  if (!hasMachineData(machine)) return false;

  const lot = getMachineFirstLot(machine);

  // Loss/STOP ของประวัติ Lot รอผลิตไม่ควรทำให้เครื่องเป็นสีแดง
  if (!isCurrentMachineLot(lot)) return false;

  const status = lot.machineStatus?.trim().toUpperCase();
  const hasLoss = hasValue(lot.stopCode);

  return hasLoss || (!!status && status !== "RUN");
};

const isNoDataMachine = (machine) => !hasMachineData(machine);

const formatDuration = (dateValue, now) => {
  if (!dateValue) return "-";
  let start = new Date(dateValue);
  if (Number.isNaN(start.getTime()))
    start = new Date(String(dateValue).replace(/-/g, "/"));
  if (Number.isNaN(start.getTime())) return "-";
  const diffMs = now.getTime() - start.getTime();
  if (diffMs < 0) return "-";
  const totalMinutes = Math.floor(diffMs / 60000);
  const days = Math.floor(totalMinutes / 1440);
  const hours = Math.floor((totalMinutes % 1440) / 60);
  const minutes = totalMinutes % 60;
  if (days > 0) return `${days}d ${hours}h`;
  if (hours > 0) return `${hours}h ${minutes}m`;
  return `${minutes}m`;
};

// Helpers เพิ่มเติมสำหรับจัดการ State และ Status Text ของ Theme ใหม่
const getMachineState = (machine) => {
  if (isRunningMachine(machine)) return "running";
  if (isStopLossMachine(machine)) return "stop";

  // มี Lot ใน Queue แต่ไม่มี CURRENT = รอผลิต
  if (hasMachineData(machine)) return "waiting";

  return "nodata";
};

const getMachineStatusText = (machine) => {
  const state = getMachineState(machine);
  const lot = getMachineFirstLot(machine);

  if (state === "running") return "";
  if (state === "stop") return lot?.machineStatus || "STOP";
  if (state === "input") return "INPUT QUEUE";
  if (state === "waiting") return "WAITING";
  return "NO DATA";
};

// ชุดสี Theme สำหรับการ์ดเครื่องจักร
const neutralMachineCard =
  "group relative flex min-w-0 overflow-hidden rounded-2xl border p-4 text-left transition-all duration-200 bg-[#EAF1F8] border-[#AFC2D8] text-slate-950 shadow-[0_10px_28px_rgba(15,23,42,0.16)] hover:-translate-y-0.5 hover:bg-[#DDEAF6] hover:border-[#8EA4C1] hover:shadow-[0_16px_40px_rgba(15,23,42,0.22)] focus:outline-none dark:bg-[#142033] dark:border-[#4B5F7A] dark:text-slate-50 dark:shadow-[0_16px_44px_rgba(0,0,0,0.55)] dark:hover:bg-[#1A2A42] dark:hover:border-[#64748B] dark:hover:shadow-[0_20px_52px_rgba(0,0,0,0.75)]";

const machineTheme = {
  running: {
    card: neutralMachineCard,
    title: "text-slate-900 dark:text-slate-100",
    badge:
      "bg-emerald-500/15 text-emerald-600 ring-1 ring-emerald-500/25 dark:text-emerald-300",
    progress: "bg-emerald-500",
  },
  stop: {
    card: neutralMachineCard,
    title: "text-slate-900 dark:text-slate-100",
    badge:
      "bg-rose-500/15 text-rose-600 ring-1 ring-rose-500/25 dark:text-rose-300",
    progress: "bg-rose-500",
  },
  input: {
    card: neutralMachineCard,
    title: "text-slate-900 dark:text-slate-100",
    badge:
      "bg-indigo-500/15 text-indigo-600 ring-1 ring-indigo-500/25 dark:text-indigo-300",
    progress: "bg-indigo-400",
  },
  waiting: {
    card: neutralMachineCard,
    title: "text-slate-900 dark:text-slate-100",
    badge:
      "bg-amber-500/15 text-amber-600 ring-1 ring-amber-500/25 dark:text-amber-300",
    progress: "bg-amber-400",
  },
  nodata: {
    card: neutralMachineCard,
    title: "text-slate-800 dark:text-slate-200",
    badge:
      "bg-slate-500/15 text-slate-600 ring-1 ring-slate-500/25 dark:text-slate-300",
    progress: "bg-slate-400 dark:bg-slate-500",
  },
};

// ชุดสี Theme สำหรับ Summary Cards ด้านบนสุด
const neutralSummaryCard =
  "border border-slate-300 bg-slate-50/80 shadow-[0_10px_28px_rgba(15,23,42,0.12)] backdrop-blur-md dark:border-slate-700 dark:bg-slate-950/75 dark:shadow-[0_16px_44px_rgba(0,0,0,0.55)]";

const summaryTheme = {
  total: {
    card: neutralSummaryCard,
    title: "text-slate-600 dark:text-slate-400",
    number: "text-blue-600 dark:text-blue-400",
  },
  running: {
    card: neutralSummaryCard,
    title: "text-slate-600 dark:text-slate-400",
    number: "text-emerald-600 dark:text-emerald-400",
  },
  stop: {
    card: neutralSummaryCard,
    title: "text-slate-600 dark:text-slate-400",
    number: "text-rose-600 dark:text-rose-400",
  },
};

// Component ย่อยสำหรับแสดงข้อมูลแต่ละช่องใน Modal
const detailToneMap = {
  default: {
    box: "border-slate-300 bg-slate-100 shadow-sm dark:border-slate-700 dark:bg-slate-900/80",
    label: "text-slate-500 dark:text-slate-400",
    value: "text-slate-900 dark:text-slate-100",
  },
  cyan: {
    box: "border-cyan-200 bg-cyan-50 shadow-sm dark:border-cyan-900/60 dark:bg-cyan-950/25",
    label: "text-cyan-700 dark:text-cyan-300",
    value: "text-cyan-900 dark:text-cyan-100",
  },
  emerald: {
    box: "border-emerald-200 bg-emerald-50 shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/25",
    label: "text-emerald-700 dark:text-emerald-300",
    value: "text-emerald-900 dark:text-emerald-100",
  },
  amber: {
    box: "border-amber-200 bg-amber-50 shadow-sm dark:border-amber-900/60 dark:bg-amber-950/25",
    label: "text-amber-700 dark:text-amber-300",
    value: "text-amber-900 dark:text-amber-100",
  },
  rose: {
    box: "border-rose-200 bg-rose-50 shadow-sm dark:border-rose-900/60 dark:bg-rose-950/25",
    label: "text-rose-700 dark:text-rose-300",
    value: "text-rose-900 dark:text-rose-100",
  },
};

const DetailItem = ({ label, value, valueColorClass, tone = "default" }) => {
  const theme = detailToneMap[tone] || detailToneMap.default;

  return (
    <div className={`rounded-xl border p-4 transition ${theme.box}`}>
      <p
        className={`text-sm font-bold uppercase tracking-wider ${theme.label}`}
      >
        {label}
      </p>
      <p
        className={`mt-2 text-lg font-semibold ${
          valueColorClass || theme.value
        }`}
      >
        {value}
      </p>
    </div>
  );
};

export default function Dashboard({ setActive }) {
  const [machines, setMachines] = useState([]);
  const [selectedMachine, setSelectedMachine] = useState(null);
  const [activeLot, setActiveLot] = useState(null);
  const [loading, setLoading] = useState(true);
  const [lastUpdated, setLastUpdated] = useState(null);

  // States ใหม่สำหรับการทำ Overview Dashboard
  const [error, setError] = useState(null);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [showLegendInfo, setShowLegendInfo] = useState(false);
  const [isMonitorMode, setIsMonitorMode] = useState(() => {
    return (
      new URLSearchParams(window.location.search).get("mode") === "monitor"
    );
  });

  const dashboardRef = useRef(null);
  const legendRef = useRef(null);

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 30000);
    return () => clearInterval(timer);
  }, []);

  useEffect(() => {
    const handleFullscreenChange = () =>
      setIsMonitorMode(!!document.fullscreenElement);
    document.addEventListener("fullscreenchange", handleFullscreenChange);
    return () =>
      document.removeEventListener("fullscreenchange", handleFullscreenChange);
  }, []);

  // ดักจับการคลิกด้านนอกกล่อง Legend เพื่อปิด
  useEffect(() => {
    const handleClickOutside = (event) => {
      if (legendRef.current && !legendRef.current.contains(event.target)) {
        setShowLegendInfo(false);
      }
    };

    if (showLegendInfo) {
      document.addEventListener("mousedown", handleClickOutside);
    }
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [showLegendInfo]);

  // ดึงฟังก์ชันโหลดข้อมูลออกมาเพื่อให้ปุ่ม Refresh เรียกใช้ได้ง่าย
  const fetchMachinesData = async (isInitialLoad = false, force = false) => {
    if (isInitialLoad) setLoading(true);
    setError(null);
    try {
      const data = await getMachines({
        includeMoveLot: true,
        preservePhysical: true,
        force,
      });

      // แปลงชื่อเป็นชื่อใหม่ และคัดเฉพาะเครื่องที่เปิดใช้งานบน Frontend
      const fullData = (data || [])
        .map((m) => ({ ...m, machineName: formatMachineName(m.machineName) }))
        .filter((m) => machineSortOrder.includes(m.machineName.toUpperCase()));

      const existingNames = fullData.map((m) =>
        formatMachineName((m.machineName || "").trim()),
      );

      // เติมเครื่องจักรที่ไม่มีข้อมูลจาก machineSortOrder ให้มี Card เปล่าๆ ปรากฏขึ้นมา
      machineSortOrder.forEach((name) => {
        if (!existingNames.includes(name)) {
          fullData.push({ machineName: name });
        }
      });

      // เรียงลำดับชื่อเครื่องจักร (อิงตามชื่อใหม่) ตามลำดับเครื่องที่เปิดใช้งาน
      const sortedData = fullData.sort((a, b) => {
        const nameA = formatMachineName((a.machineName || "").trim());
        const nameB = formatMachineName((b.machineName || "").trim());

        let indexA = machineSortOrder.indexOf(nameA);
        let indexB = machineSortOrder.indexOf(nameB);

        // ถ้าเครื่องไหนไม่อยู่ในลิสต์ที่เราบังคับเรียง ให้เอาไปต่อท้ายสุด
        if (indexA === -1) indexA = 999;
        if (indexB === -1) indexB = 999;

        if (indexA !== indexB) return indexA - indexB;
        return nameA.localeCompare(nameB); // ถ้าลำดับเท่ากัน ค่อยเรียงตามตัวอักษรปกติ
      });

      setMachines(sortedData);
      setLastUpdated(new Date());
    } catch (err) {
      console.error(err);
      setError("ไม่สามารถเชื่อมต่อข้อมูลเครื่องจักรได้");
    } finally {
      if (isInitialLoad) setLoading(false);
    }
  };

  useEffect(() => {
    fetchMachinesData(true);
    const intervalId = setInterval(() => {
      fetchMachinesData(false);
    }, 60000);
    return () => clearInterval(intervalId);
  }, []);

  const toggleMonitorMode = async () => {
    if (!document.fullscreenElement) {
      if (dashboardRef.current?.requestFullscreen) {
        try {
          await dashboardRef.current.requestFullscreen();
        } catch (err) {
          console.error("Fullscreen failed:", err);
          setIsMonitorMode(true);
        }
      } else setIsMonitorMode(true);
    } else {
      if (document.exitFullscreen) await document.exitFullscreen();
      else setIsMonitorMode(false);
    }
  };

  const total = machines.length;
  const runningList = machines.filter(isRunningMachine);
  const stopLossList = machines.filter(isStopLossMachine);
  const noDataList = machines.filter(isNoDataMachine);

  const runningCount = runningList.length;
  const stoppedCount = stopLossList.length;
  const noDataCount = noDataList.length;

  const isStale =
    lastUpdated &&
    currentTime.getTime() - lastUpdated.getTime() > 3 * 60 * 1000;

  const stopLossText = stopLossList
    .map((m) => {
      const lot = getMachineFirstLot(m);
      const code = hasValue(lot.stopCode)
        ? lot.stopCode
        : lot.machineStatus || "STOP";
      return `${formatDisplayMachineName(m.machineName)}: ${code}`;
    })
    .join(" • ");

  // สำหรับคำนวณ % งานผลิตปัจจุบัน ใน Modal
  const modalInputQty = parseFloat(activeLot?.inputQty) || 0;
  const modalOutputQty = parseFloat(activeLot?.outputQty) || 0;
  const modalPercentCurrent =
    modalInputQty > 0 ? Math.round((modalOutputQty / modalInputQty) * 100) : 0;

  // สำหรับเปิดหน้า Queue
  const openMachineQueue = () => {
    const machineName = formatMachineName(
      selectedMachine?.machineName || activeLot?.machineName || "",
    );

    if (!machineName || machineName === "N/A") return;

    const params = new URLSearchParams(window.location.search);
    params.set("machine", machineName);

    window.history.replaceState(null, "", `?${params.toString()}`);

    setSelectedMachine(null);
    setActiveLot(null);

    if (typeof setActive === "function") {
      setActive("queue");
    }
  };

  return (
    <div
      ref={dashboardRef}
      className={`flex flex-col gap-2 md:gap-3 xl:gap-4 ${
        isMonitorMode
          ? "fixed inset-0 z-[999] bg-slate-100 dark:bg-slate-950 p-3 sm:p-4 lg:p-6 overflow-hidden h-screen w-screen"
          : "flex-1 xl:h-[calc(100dvh-92px)] xl:min-h-0 xl:overflow-hidden"
      }`}
    >
      {/* CSS อนิเมชั่นสำหรับหลอด Progress Bar */}
      <style>{`
        @keyframes progress-stripes {
          0% { background-position: 1rem 0; }
          100% { background-position: 0 0; }
        }
        .progress-bar-stripes {
          background-image: repeating-linear-gradient(
            45deg,
            rgba(255, 255, 255, 0.2) 25%,
            transparent 25%,
            transparent 50%,
            rgba(255, 255, 255, 0.2) 50%,
            rgba(255, 255, 255, 0.2) 75%,
            transparent 75%,
            transparent
          );
          background-size: 1rem 1rem;
          animation: progress-stripes 1s linear infinite;
        }
      `}</style>

      {/* Stats Cards */}
      <div className="grid shrink-0 grid-cols-3 gap-2 xl:gap-3 2xl:gap-4">
        {[
          {
            title: "Total Machines",
            value: total,
            theme: summaryTheme.total,
            icon: Server,
          },
          {
            title: "Running",
            value: runningCount,
            theme: summaryTheme.running,
            icon: PlayCircle,
          },
          {
            title: "Stop",
            value: stoppedCount,
            theme: summaryTheme.stop,
            icon: Wrench,
          },
        ].map((stat) => {
          const StatIcon = stat.icon;

          return (
            <div
              key={stat.title}
              className={`flex flex-col md:flex-row md:items-center justify-center md:justify-between rounded-xl md:rounded-2xl border ${stat.theme.card} p-3 xl:p-4 2xl:p-6 gap-2 transition-all duration-300`}
            >
              <div className="flex items-center justify-center gap-2 md:justify-start">
                <span className="hidden h-10 w-10 items-center justify-center rounded-xl bg-white/60 shadow-sm ring-1 ring-black/5 sm:flex dark:bg-slate-950/30 dark:ring-white/10">
                  <StatIcon size={21} />
                </span>
                <p
                  className={`text-xs md:text-sm xl:text-lg 2xl:text-xl font-bold uppercase tracking-wider ${stat.theme.title} text-center md:text-left`}
                >
                  {stat.title}
                </p>
              </div>
              <p
                className={`text-3xl xl:text-5xl 2xl:text-6xl font-extrabold ${stat.theme.number}`}
              >
                {stat.value}
              </p>
            </div>
          );
        })}
      </div>

      {/* Alert Bars */}
      {error && (
        <div className="shrink-0 rounded-lg bg-rose-50 px-4 py-2 text-sm md:text-base font-bold text-rose-700 border border-rose-200 shadow-sm dark:bg-rose-900/30 dark:border-rose-800/50 dark:text-rose-300 flex items-center justify-center gap-2">
          <AlertTriangle size={18} />
          {error}
        </div>
      )}
      {!error && isStale && (
        <div className="shrink-0 rounded-lg bg-amber-50 px-4 py-2 text-sm md:text-base font-bold text-amber-700 border border-amber-200 shadow-sm dark:bg-amber-900/30 dark:border-amber-800/50 dark:text-amber-300 flex items-center justify-center gap-2">
          <AlertTriangle size={18} />
          ข้อมูลล่าสุดเกิน 3 นาที กรุณาตรวจสอบการเชื่อมต่อหรือกด Refresh
        </div>
      )}
      {/* {!error && !isStale && stopLossList.length > 0 && (
        <div className="shrink-0 flex items-center justify-center flex-wrap gap-2 rounded-lg bg-rose-50 px-4 py-2 text-sm md:text-base font-bold text-rose-700 border border-rose-200 shadow-sm dark:bg-rose-900/30 dark:border-rose-800/50 dark:text-rose-300">
          <span className="whitespace-nowrap shrink-0">⚠ Stop/Loss:</span>
          <span className="text-center">{stopLossText}</span>
        </div>
      )}
      {!error && !isStale && stopLossList.length === 0 && machines.length > 0 && (
        <div className="shrink-0 rounded-lg bg-emerald-50 px-4 py-2 text-sm md:text-base font-bold text-emerald-700 border border-emerald-200 shadow-sm dark:bg-emerald-900/30 dark:border-emerald-800/50 dark:text-emerald-300 flex items-center justify-center">
          ✅ No active stop/loss
        </div>
      )} */}

      {/* Machine Grid */}
      <section className="flex flex-1 flex-col rounded-3xl border border-slate-400 bg-slate-50/90 p-4 shadow-[0_14px_40px_rgba(15,23,42,0.12)] backdrop-blur-md dark:border-slate-700 dark:bg-slate-950/75 dark:shadow-[0_18px_55px_rgba(0,0,0,0.55)] md:p-5 xl:min-h-0 xl:overflow-hidden">
        <div className="shrink-0 flex flex-col lg:flex-row lg:items-center lg:justify-between gap-2 border-b border-slate-300 pb-2 md:pb-3 dark:border-slate-700/60">
          <div className="flex items-center gap-3">
            <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-600 text-white shadow-lg shadow-cyan-600/20 xl:h-12 xl:w-12">
              <MonitorCog size={24} />
            </span>
            <h2 className="text-xl lg:text-2xl xl:text-4xl 2xl:text-4xl font-black text-slate-900 dark:text-slate-100">
              Machine Status
            </h2>
            <div className="relative" ref={legendRef}>
              <button
                onClick={() => setShowLegendInfo(!showLegendInfo)}
                className="flex h-7 w-7 items-center justify-center rounded-full bg-slate-300 text-sm font-bold text-slate-600 hover:bg-slate-400 dark:bg-slate-800 dark:text-slate-400 dark:hover:bg-slate-700"
              >
                <Info size={16} />
              </button>
              {showLegendInfo && (
                <div className="absolute left-0 top-8 z-50 w-64 rounded-xl border border-slate-200 bg-white p-3 shadow-lg dark:border-slate-700 dark:bg-slate-800 text-left">
                  <h4 className="mb-2 text-sm font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                    สัญลักษณ์และสถานะ
                  </h4>
                  <ul className="space-y-1.5 text-xs text-slate-700 dark:text-slate-300">
                    <li className="flex items-center gap-2">
                      <span className="h-3 w-3 rounded-full bg-emerald-500 shrink-0"></span>{" "}
                      <b>Running:</b> กำลังเดินเครื่อง
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="h-3 w-3 rounded-full bg-rose-500 shrink-0"></span>{" "}
                      <b>Stop/Loss:</b> เครื่องหยุด/มี Stop Code
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="h-3 w-3 rounded-full bg-amber-500 shrink-0"></span>{" "}
                      <b>Waiting:</b> กำลังรอการผลิต
                    </li>
                    <li className="flex items-center gap-2">
                      <span className="h-3 w-3 rounded-full bg-slate-400 shrink-0"></span>{" "}
                      <b>No Data:</b> ไม่มีข้อมูลในฐานข้อมูล
                    </li>
                    {/* <li className="flex items-center gap-2">
                      <span className="font-bold text-cyan-600 dark:text-cyan-400 shrink-0">
                        Progress:
                      </span>{" "}
                      Output / Input Qty
                    </li> */}
                  </ul>
                </div>
              )}
            </div>
          </div>

          <div className="flex w-full lg:w-auto flex-row items-center justify-between lg:justify-end gap-2 md:gap-4">
            <span className="text-xs lg:text-sm xl:text-lg 2xl:text-lg font-medium text-slate-600 dark:text-slate-300">
              Last Updated:{" "}
              {lastUpdated ? lastUpdated.toLocaleTimeString("th-TH") : "..."}
            </span>
            <button
              onClick={toggleMonitorMode}
              className="inline-flex items-center gap-2 rounded-lg md:rounded-xl border-2 border-slate-300 bg-white px-3 py-1.5 xl:px-4 xl:py-2 2xl:px-5 2xl:py-2.5 text-xs xl:text-sm 2xl:text-base font-bold text-slate-700 shadow-sm transition hover:bg-slate-50 dark:border-slate-600 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
            >
              {isMonitorMode ? (
                <Minimize2 size={17} />
              ) : (
                <Maximize2 size={17} />
              )}
              {isMonitorMode ? "Exit Monitor" : "Monitor Mode"}
            </button>
            <button
              onClick={() => fetchMachinesData(true, true)}
              disabled={loading}
              className="inline-flex items-center gap-2 rounded-lg md:rounded-xl bg-cyan-600 px-4 py-2 xl:px-5 xl:py-2.5 2xl:px-7 2xl:py-3 text-sm xl:text-lg 2xl:text-xl font-bold text-white shadow-md transition hover:bg-cyan-700 active:scale-95 disabled:opacity-50"
            >
              <RefreshCw size={19} className={loading ? "animate-spin" : ""} />
              {loading ? "Loading..." : "Refresh"}
            </button>
          </div>
        </div>

        {loading ? (
          <div className="flex h-full items-center justify-center text-2xl font-bold text-slate-500">
            กำลังโหลดข้อมูลเครื่องจักร...
          </div>
        ) : machines.length === 0 ? (
          <div className="flex h-full items-center justify-center text-2xl font-bold text-slate-500">
            ไม่พบข้อมูลเครื่องจักรในระบบ
          </div>
        ) : (
          // UI LOCK: Dashboard machine cards use auto-fit grid so cards drop columns when sidebar is open. Do not replace with fixed xl:grid-cols-4.
          <div
            className="grid min-h-0 w-full gap-3 overflow-y-auto rounded-2xl p-2
                        grid-cols-1
                        min-[640px]:grid-cols-2
                        xl:grid-cols-3
                        2xl:grid-cols-4"
          >
            {machines.map((m) => {
              const lot = getMachineFirstLot(m);
              const stateKey = getMachineState(m);
              const theme = machineTheme[stateKey] || machineTheme.nodata;

              let markerStyle = "bg-slate-500";
              let statusTitle = "NO DATA";

              if (stateKey === "running") {
                markerStyle =
                  "bg-emerald-500 shadow-[0_0_14px_rgba(16,185,129,0.65)]";
                statusTitle = "RUNNING";
              } else if (stateKey === "stop") {
                markerStyle =
                  "bg-rose-500 shadow-[0_0_14px_rgba(244,63,94,0.65)]";
                statusTitle = hasValue(lot.stopCode)
                  ? `STOP / LOSS: ${lot.stopCode}`
                  : "STOP / LOSS";
              } else if (stateKey === "input" || stateKey === "waiting") {
                markerStyle =
                  "bg-amber-400 shadow-[0_0_14px_rgba(245,158,11,0.55)]";
                statusTitle = stateKey === "input" ? "PLANNED" : "WAITING";
              }

              return (
                <button
                  key={m.id || m.machineName}
                  title={`${formatDisplayMachineName(
                    m.machineName,
                  )} - ${statusTitle}`}
                  onClick={() => {
                    setSelectedMachine(m);
                    setActiveLot(lot);
                  }}
                  className={`${theme.card} min-h-[120px] items-center ${
                    selectedMachine?.machineName === m.machineName
                      ? "!border-cyan-500 ring-4 ring-cyan-500/25 dark:!border-cyan-400 scale-[1.02]"
                      : ""
                  }`}
                >
                  <span
                    className={`absolute left-0 top-0 h-full w-2 ${markerStyle}`}
                  />
                  <div className="flex min-w-0 items-center gap-4 pl-2">
                    <div className="flex h-14 w-14 sm:h-16 sm:w-16 shrink-0 items-center justify-center rounded-xl bg-white ring-1 ring-white dark:bg-white dark:ring-white">
                      <img
                        src="/icons/line_process01.gif"
                        alt=""
                        draggable="false"
                        className="h-10 w-10 sm:h-12 sm:w-12 object-contain opacity-85 dark:opacity-90"
                      />
                    </div>
                    <div className="min-w-0">
                      <h3
                        className={`whitespace-nowrap text-2xl sm:text-3xl font-black tracking-tight ${theme.title}`}
                      >
                        {formatDisplayMachineName(m.machineName)}
                      </h3>
                      <p
                        className="mt-2 max-w-full truncate text-sm sm:text-base font-bold text-slate-600 dark:text-slate-300"
                        title={lot?.lotId || lot?.lotId || "-"}
                      >
                        <span className="text-slate-400 dark:text-slate-500">
                          Lot:
                        </span>{" "}
                        {lot?.lotId || lot?.lotId || "-"}
                      </p>
                      {lot?.moveStatus === "ย้ายงาน" &&
                      hasValue(
                        lot?.targetMachine || lot?.targetMachine,
                      ) ? (
                        <span
                          className="mt-2 inline-flex max-w-full items-center gap-1.5 rounded-full bg-amber-100 px-3 py-1 text-xs font-black text-amber-700 dark:bg-amber-950/50 dark:text-amber-300"
                          title={`ย้ายคิวไป ${formatDisplayMachineName(
                            lot.targetMachine || lot.targetMachine,
                          )}`}
                        >
                          <ArrowRightLeft size={14} className="shrink-0" />

                          <span className="truncate">
                            ย้ายคิวไป{" "}
                            {formatDisplayMachineName(
                              lot.targetMachine || lot.targetMachine,
                            )}
                          </span>
                        </span>
                      ) : null}
                    </div>
                  </div>
                </button>
              );
            })}
          </div>
        )}
      </section>

      {/* Modal - แสดงรายละเอียด 38 คอลัมน์ */}
      {selectedMachine && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-sm sm:p-8">
          <div className="flex max-h-full w-full max-w-8xl flex-col overflow-hidden rounded-3xl border border-slate-200 bg-white shadow-2xl dark:border-slate-800 dark:bg-slate-950 dark:shadow-black/50">
            <div className="flex flex-col gap-4 border-b border-slate-100 p-5 dark:border-slate-800 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
                  Machine Detail:{" "}
                  {formatDisplayMachineName(selectedMachine.machineName)}
                </h2>
                <p className="text-sm text-slate-500 dark:text-slate-400">
                  สถานะ MC: {activeLot?.machineStatus || "-"}
                </p>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={openMachineQueue}
                  className="inline-flex items-center justify-center rounded-xl bg-cyan-600 px-4 py-3 text-sm font-bold text-white shadow-sm transition hover:bg-cyan-700 active:scale-95"
                >
                  View Machine Queue
                </button>

                <button
                  type="button"
                  onClick={() => {
                    setSelectedMachine(null);
                    setActiveLot(null);
                  }}
                  className="rounded-xl bg-slate-100 p-3 text-slate-500 transition hover:bg-rose-100 hover:text-rose-600 dark:bg-slate-800 dark:text-slate-400 dark:hover:bg-rose-900/50 dark:hover:text-rose-400"
                >
                  ✕
                </button>
              </div>
            </div>

            <div className="flex-1 overflow-y-auto p-5 sm:p-8">
              <div className="space-y-8">
                <section>
                  <h3 className="mb-4 text-sm font-bold text-cyan-600 dark:text-cyan-400">
                    📌 ข้อมูลทั่วไปของเครื่องจักร
                  </h3>
                  <div className="grid grid-cols-2 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                    <DetailItem
                      label="Machine Name"
                      value={formatDisplayMachineName(selectedMachine.machineName)}
                      tone="cyan"
                    />
                    <DetailItem
                      label="Lot No"
                      value={activeLot?.lotId || "-"}
                      tone="cyan"
                    />
                    <DetailItem
                      label="Product Code"
                      value={activeLot?.productCode || "-"}
                    />
                    <DetailItem
                      label="INSP NO"
                      value={activeLot?.trackingNo || "-"}
                    />
                    <DetailItem
                      label="Part Name"
                      value={activeLot?.partName || "-"}
                    />
                    <DetailItem
                      label="Unit Name"
                      value={
                        activeLot?.unitName || selectedMachine?.unitName || "-"
                      }
                    />
                    <DetailItem
                      label="Quantity"
                      value={
                        activeLot?.plannedQty != null &&
                        !isNaN(parseFloat(activeLot.plannedQty))
                          ? parseFloat(activeLot.plannedQty).toFixed(2)
                          : "-"
                      }
                    />
                    <DetailItem
                      label="Lot Status"
                      value={activeLot?.lotStatus || "-"}
                    />
                    <DetailItem
                      label="Input Date"
                      value={activeLot?.inputDate || "-"}
                    />
                    <DetailItem
                      label="Status Process"
                      value={activeLot?.processStatus || "-"}
                    />
                    <DetailItem
                      label="Comment"
                      value={activeLot?.comment || "-"}
                    />
                  </div>
                </section>

                {(!activeLot?.queueNo || activeLot?.queueNo === 1) && (
                  <section>
                    <h3 className="mb-4 text-sm font-bold text-slate-400">
                      ⚙️ ข้อมูลการผลิต
                    </h3>
                    <div className="grid grid-cols-2 gap-3 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
                      {/* ซ่อน DetailItem ของ Stop Code หากเครื่องมีสถานะ RUN */}
                      {activeLot?.machineStatus?.trim().toUpperCase() !== "RUN" && (
                        <DetailItem
                          label="Stop Code"
                          value={activeLot?.stopCode || "-"}
                          tone={
                            activeLot?.stopCode && activeLot.stopCode !== "-"
                              ? "rose"
                              : "default"
                          }
                          valueColorClass={
                            activeLot?.stopCode && activeLot.stopCode !== "-"
                              ? "text-rose-600 dark:text-rose-400"
                              : ""
                          }
                        />
                      )}

                      <DetailItem
                        label="Input QTY (Lot)"
                        value={activeLot?.inputQty || "-"}
                      />
                      <DetailItem
                        label="Output QTY (Lot)"
                        value={activeLot?.outputQty || "-"}
                      />
                      <DetailItem
                        label="Operator ID"
                        value={activeLot?.operatorId || "-"}
                      />
                      <DetailItem
                        label="Start Date"
                        value={activeLot?.startTime || "-"}
                      />
                    </div>

                    {/* Progress Bar สำหรับ Modal */}
                    <div className="mt-4 rounded-xl border border-slate-100 bg-slate-50/50 p-4 dark:border-slate-800 dark:bg-slate-800/50">
                      <div className="flex justify-between text-sm font-semibold text-slate-500 dark:text-slate-400">
                        <span>ความคืบหน้างานผลิตปัจจุบัน</span>
                        <span
                          className={
                            modalPercentCurrent >= 100
                              ? "text-emerald-500"
                              : "text-slate-700 dark:text-slate-300"
                          }
                        >
                          {modalPercentCurrent}%
                        </span>
                      </div>
                      <div className="mt-2 h-2.5 w-full overflow-hidden rounded-full bg-slate-200 dark:bg-slate-900">
                        <div
                          className={`relative h-full transition-all duration-500 ${
                            activeLot?.machineStatus?.trim().toUpperCase() === "RUN"
                              ? "bg-gradient-to-r from-emerald-600 to-green-400 shadow-[0_0_10px_theme('colors.emerald.500')]"
                              : "bg-rose-500"
                          }`}
                          style={{
                            width: `${Math.min(modalPercentCurrent, 100)}%`,
                          }}
                        >
                          {activeLot?.machineStatus?.trim().toUpperCase() ===
                            "RUN" && (
                            <div className="absolute inset-0 progress-bar-stripes"></div>
                          )}
                        </div>
                      </div>
                    </div>
                  </section>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
