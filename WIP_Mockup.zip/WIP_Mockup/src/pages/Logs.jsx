import React, { useEffect, useMemo, useState } from "react";
import {
  Activity,
  AlertTriangle,
  ClipboardCopy,
  Download,
  Eye,
  FileClock,
  ListFilter,
  RefreshCw,
  Search,
  Table2,
  X,
} from "lucide-react";
import { getActivityLogs } from "../services/logClient";

const pad2 = (value) => String(value).padStart(2, "0");

const getTodayInputDate = () => {
  const now = new Date();
  return `${now.getFullYear()}-${pad2(now.getMonth() + 1)}-${pad2(
    now.getDate(),
  )}`;
};

const formatDateTime = (value) => {
  if (!value) return "-";

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) return value;

  return date.toLocaleString("en-GB", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
};

const levelClassMap = {
  INFO: "bg-cyan-100 text-cyan-700 dark:bg-cyan-950/40 dark:text-cyan-300",
  WARN: "bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300",
  ERROR: "bg-rose-100 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300",
};

const typeClassMap = {
  LOT_SEARCH:
    "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300",
  MACHINE_QUEUE:
    "bg-indigo-100 text-indigo-700 dark:bg-indigo-950/40 dark:text-indigo-300",
  SETUP_DETAIL:
    "bg-orange-100 text-orange-700 dark:bg-orange-950/40 dark:text-orange-300",
  DAILY_CHECK:
    "bg-cyan-100 text-cyan-700 dark:bg-cyan-950/40 dark:text-cyan-300",
  API_ERROR: "bg-rose-100 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300",
  ACTIVITY: "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
};

const StatCard = ({ label, value, tone = "default", icon: Icon }) => {
  const toneMap = {
    default:
      "border-slate-300 bg-white text-slate-900 shadow-md dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:shadow-black/30",
    cyan: "border-cyan-300 bg-cyan-50 text-cyan-900 shadow-md dark:border-cyan-800 dark:bg-cyan-950 dark:text-cyan-100 dark:shadow-black/30",
    rose: "border-rose-300 bg-rose-50 text-rose-900 shadow-md dark:border-rose-800 dark:bg-rose-950 dark:text-rose-100 dark:shadow-black/30",
    amber:
      "border-amber-300 bg-amber-50 text-amber-900 shadow-md dark:border-amber-800 dark:bg-amber-950 dark:text-amber-100 dark:shadow-black/30",
    emerald:
      "border-emerald-300 bg-emerald-50 text-emerald-900 shadow-md dark:border-emerald-800 dark:bg-emerald-950 dark:text-emerald-100 dark:shadow-black/30",
    indigo:
      "border-indigo-300 bg-indigo-50 text-indigo-900 shadow-md dark:border-indigo-800 dark:bg-indigo-950 dark:text-indigo-100 dark:shadow-black/30",
  };

  return (
    <div
      className={[
        "rounded-3xl border-2 p-5 ring-1 ring-white/40 transition hover:-translate-y-0.5 hover:shadow-lg dark:ring-white/5",
        toneMap[tone] || toneMap.default,
      ].join(" ")}
    >
      <div className="flex items-center justify-between gap-3">
        <p className="text-sm font-black uppercase tracking-[0.22em] opacity-70">
          {label}
        </p>
        {Icon ? (
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-white/60 shadow-sm ring-1 ring-black/5 dark:bg-slate-950/30 dark:ring-white/10">
            <Icon size={21} />
          </span>
        ) : null}
      </div>

      <p className="mt-3 text-4xl font-black leading-none">{value}</p>
    </div>
  );
};

export default function Logs({ user }) {
  const [date, setDate] = useState(getTodayInputDate());
  const [type, setType] = useState("");
  const [level, setLevel] = useState("");
  const [search, setSearch] = useState("");
  const [logs, setLogs] = useState([]);
  const [selectedLog, setSelectedLog] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const loadLogs = async () => {
    setLoading(true);
    setError("");

    try {
      const data = await getActivityLogs({
        date,
        type,
        level,
        search,
      });

      setLogs(data.logs || []);
    } catch (err) {
      console.error("Load logs error:", err);
      setError("ไม่สามารถโหลด Logs ได้");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadLogs();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [date, type, level]);

  const summary = useMemo(() => {
    return {
      total: logs.length,
      error: logs.filter((log) => log.level === "ERROR").length,
      warn: logs.filter((log) => log.level === "WARN").length,
      lotSearch: logs.filter((log) => log.type === "LOT_SEARCH").length,
      machineQueue: logs.filter((log) => log.type === "MACHINE_QUEUE").length,
      setupDetail: logs.filter((log) => log.type === "SETUP_DETAIL").length,
      dailyCheck: logs.filter((log) => log.type === "DAILY_CHECK").length,
    };
  }, [logs]);

  const copyJson = async () => {
    try {
      await navigator.clipboard.writeText(JSON.stringify(logs, null, 2));
      alert("Copied logs JSON");
    } catch {
      alert("Copy failed");
    }
  };

  const exportCsv = () => {
    const headers = [
      "time",
      "type",
      "level",
      "userId",
      "userName",
      "page",
      "action",
      "machine",
      "lot",
      "result",
      "message",
    ];

    const escapeCsv = (value) => {
      const text = String(value ?? "");
      return `"${text.replaceAll('"', '""')}"`;
    };

    const rows = logs.map((log) =>
      headers.map((key) => escapeCsv(log[key])).join(","),
    );

    const csv = [headers.join(","), ...rows].join("\r\n");
    const blob = new Blob(["\uFEFF" + csv], {
      type: "text/csv;charset=utf-8;",
    });

    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");

    a.href = url;
    a.download = `nmpm-logs-${date}.csv`;
    a.click();

    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6 pt-6">
      <section className="relative overflow-hidden rounded-[2rem] border border-slate-300 bg-gradient-to-br from-indigo-50 via-white to-slate-100 p-6 shadow-lg dark:border-slate-700 dark:from-slate-900 dark:via-slate-950 dark:to-indigo-950/30">
        <div className="absolute right-[-80px] top-[-80px] h-56 w-56 rounded-full bg-indigo-400/20 blur-3xl" />
        <div className="relative flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
          <div className="flex items-start gap-4">
            <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-indigo-600 text-white shadow-lg shadow-indigo-600/20">
              <FileClock size={28} strokeWidth={2.2} />
            </div>
            <div>
              <p className="text-xs font-black uppercase tracking-[0.22em] text-indigo-700 dark:text-indigo-300">
                System Audit Trail
              </p>
              <h1 className="mt-1 text-2xl font-black tracking-tight text-slate-900 sm:text-3xl dark:text-white">
                Logs / Activity
              </h1>
              <p className="mt-2 max-w-3xl text-sm font-medium text-slate-600 dark:text-slate-300">
                ตรวจสอบ Search Lot, Machine Queue, Setup Compare, Daily Check และ API Error
              </p>
            </div>
          </div>

          <div className="inline-flex items-center gap-2 rounded-2xl bg-white/70 px-5 py-3 text-sm font-bold text-slate-600 ring-1 ring-slate-200 dark:bg-slate-900/70 dark:text-slate-300 dark:ring-slate-700">
            <Activity size={17} className="text-indigo-600 dark:text-indigo-300" />
            Login: {user?.name || user?.id || "Guest"}
          </div>
        </div>
      </section>

      <section className="grid gap-4 sm:grid-cols-2 lg:grid-cols-6 2xl:grid-cols-6">
        <StatCard label="Total" value={summary.total} tone="cyan" icon={Activity} />
        <StatCard label="Errors" value={summary.error} tone="rose" icon={AlertTriangle} />
        <StatCard label="Warnings" value={summary.warn} tone="amber" icon={ListFilter} />
        <StatCard label="Lot Search" value={summary.lotSearch} tone="emerald" icon={Search} />
        <StatCard label="Queue" value={summary.machineQueue} tone="indigo" icon={Table2} />
        <StatCard label="Setup Compare" value={summary.setupDetail} tone="amber" icon={FileClock} />
      </section>

      <section className="rounded-[2rem] border-2 border-slate-300 bg-white p-5 shadow-lg ring-1 ring-white/60 dark:border-slate-700 dark:bg-slate-950 dark:shadow-black/40 dark:ring-white/5">
        <div className="space-y-4">
          {/* Row 1: Date / Type / Level / Buttons */}
          <div className="flex flex-col gap-3 xl:flex-row xl:items-center xl:justify-between">
            <div className="grid min-w-0 grid-cols-1 gap-3 sm:grid-cols-3 xl:w-[720px] xl:shrink-0">
              <input
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
                className="h-14 min-w-0 rounded-2xl border border-slate-300 bg-slate-50 px-4 text-base font-black text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:focus:border-cyan-400 dark:focus:ring-cyan-400/20"
              />

              <select
                value={type}
                onChange={(e) => setType(e.target.value)}
                className="h-14 min-w-0 rounded-2xl border border-slate-300 bg-slate-50 px-4 text-base font-black text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:focus:border-cyan-400 dark:focus:ring-cyan-400/20"
              >
                <option value="">All Types</option>
                <option value="LOT_SEARCH">LOT_SEARCH</option>
                <option value="MACHINE_QUEUE">MACHINE_QUEUE</option>
                <option value="SETUP_DETAIL">SETUP_DETAIL</option>
                <option value="DAILY_CHECK">DAILY_CHECK</option>
                <option value="API_ERROR">API_ERROR</option>
                <option value="ACTIVITY">ACTIVITY</option>
              </select>

              <select
                value={level}
                onChange={(e) => setLevel(e.target.value)}
                className="h-14 min-w-0 rounded-2xl border border-slate-300 bg-slate-50 px-4 text-base font-black text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:focus:border-cyan-400 dark:focus:ring-cyan-400/20"
              >
                <option value="">All Levels</option>
                <option value="INFO">INFO</option>
                <option value="WARN">WARN</option>
                <option value="ERROR">ERROR</option>
              </select>
            </div>

            <div className="flex shrink-0 flex-wrap gap-3 xl:justify-end">
              <button
                type="button"
                onClick={loadLogs}
                disabled={loading}
                className="inline-flex h-14 min-w-[120px] items-center justify-center gap-2 rounded-2xl bg-cyan-600 px-5 text-base font-black text-white shadow-sm transition hover:bg-cyan-700 disabled:opacity-50"
              >
                <RefreshCw size={18} className={loading ? "animate-spin" : ""} />
                {loading ? "Loading..." : "Refresh"}
              </button>

              <button
                type="button"
                onClick={exportCsv}
                className="inline-flex h-14 min-w-[135px] items-center justify-center gap-2 rounded-2xl bg-emerald-600 px-5 text-base font-black text-white shadow-sm transition hover:bg-emerald-700"
              >
                <Download size={18} />
                Export CSV
              </button>

              <button
                type="button"
                onClick={copyJson}
                className="inline-flex h-14 min-w-[135px] items-center justify-center gap-2 rounded-2xl bg-slate-700 px-5 text-base font-black text-white shadow-sm transition hover:bg-slate-800 dark:bg-slate-600 dark:hover:bg-slate-500"
              >
                <ClipboardCopy size={18} />
                Copy JSON
              </button>
            </div>
          </div>

          {/* Row 2: Search full width */}
          <div>
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter") loadLogs();
              }}
              placeholder="Search user, lot, machine, message..."
              className="h-14 w-full rounded-2xl border border-slate-300 bg-slate-50 px-5 text-base font-black text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:placeholder:text-slate-500 dark:focus:border-cyan-400 dark:focus:ring-cyan-400/20"
            />
          </div>
        </div>

        {error ? (
          <div className="mt-4 flex items-start gap-3 rounded-2xl bg-rose-50 p-4 font-bold text-rose-600 ring-1 ring-rose-200 dark:bg-rose-950/40 dark:text-rose-300 dark:ring-rose-500/30">
            <AlertTriangle size={19} className="mt-0.5 shrink-0" />
            <span>{error}</span>
          </div>
        ) : null}
      </section>

      <section className="overflow-hidden rounded-3xl border border-slate-300 bg-white shadow-md dark:border-slate-700 dark:bg-slate-900 dark:shadow-black/30">
        <div className="flex items-center gap-3 border-b border-slate-200 bg-slate-50 px-5 py-4 dark:border-slate-800 dark:bg-slate-950">
          <Table2 size={21} className="text-indigo-600 dark:text-indigo-300" />
          <div>
            <h3 className="font-black text-slate-900 dark:text-slate-100">Activity Log Table</h3>
            <p className="text-xs font-bold text-slate-500 dark:text-slate-400">{logs.length} records</p>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full min-w-max text-left text-sm">
            <thead className="border-b border-slate-200 bg-slate-50 text-xs uppercase text-slate-500 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
              <tr>
                <th className="px-4 py-4">Time</th>
                <th className="px-4 py-4">Type</th>
                <th className="px-4 py-4">Level</th>
                <th className="px-4 py-4">User</th>
                <th className="px-4 py-4">Page</th>
                <th className="px-4 py-4">Action</th>
                <th className="px-4 py-4">Machine</th>
                <th className="px-4 py-4">Lot</th>
                <th className="px-4 py-4">Result</th>
                <th className="px-4 py-4">Message</th>
                <th className="px-4 py-4 text-center">Detail</th>
              </tr>
            </thead>

            <tbody>
              {logs.length === 0 ? (
                <tr>
                  <td
                    colSpan={11}
                    className="px-4 py-12 text-center text-slate-500 dark:text-slate-400"
                  >
                    ไม่พบ Logs ตามเงื่อนไขที่เลือก
                  </td>
                </tr>
              ) : (
                logs.map((log) => (
                  <tr
                    key={log.id}
                    className="border-b border-slate-100 transition hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800/50"
                  >
                    <td className="px-4 py-3 font-medium text-slate-600 dark:text-slate-300">
                      {formatDateTime(log.time)}
                    </td>

                    <td className="px-4 py-3">
                      <span
                        className={`rounded-full px-3 py-1 text-xs font-black ${
                          typeClassMap[log.type] ||
                          "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300"
                        }`}
                      >
                        {log.type}
                      </span>
                    </td>

                    <td className="px-4 py-3">
                      <span
                        className={`rounded-full px-3 py-1 text-xs font-black ${
                          levelClassMap[log.level] ||
                          "bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300"
                        }`}
                      >
                        {log.level}
                      </span>
                    </td>

                    <td className="px-4 py-3 text-slate-600 dark:text-slate-300">
                      <div className="font-bold">{log.userId || "-"}</div>
                      <div className="text-xs text-slate-400">
                        {log.userName || "-"}
                      </div>
                    </td>

                    <td className="px-4 py-3 text-slate-600 dark:text-slate-300">
                      {log.page || "-"}
                    </td>

                    <td className="px-4 py-3 font-bold text-slate-700 dark:text-slate-200">
                      {log.action || "-"}
                    </td>

                    <td className="px-4 py-3 font-bold text-cyan-600 dark:text-cyan-300">
                      {log.machine || "-"}
                    </td>

                    <td className="px-4 py-3 font-bold text-slate-700 dark:text-slate-200">
                      {log.lot || "-"}
                    </td>

                    <td className="px-4 py-3 text-slate-600 dark:text-slate-300">
                      {log.result || "-"}
                    </td>

                    <td
                      className="max-w-[360px] truncate px-4 py-3 text-slate-500 dark:text-slate-400"
                      title={log.message || "-"}
                    >
                      {log.message || "-"}
                    </td>

                    <td className="px-4 py-3 text-center">
                      <button
                        type="button"
                        onClick={() => setSelectedLog(log)}
                        className="inline-flex items-center gap-2 rounded-xl bg-slate-100 px-3 py-2 text-xs font-black text-slate-700 transition hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-200 dark:hover:bg-slate-700"
                      >
                        <Eye size={15} />
                        View
                      </button>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </section>

      {selectedLog && (
        <div className="fixed inset-0 z-[130] flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-sm">
          <div className="flex max-h-[90vh] w-full max-w-3xl flex-col overflow-hidden rounded-3xl bg-white shadow-2xl dark:bg-slate-950">
            <div className="flex items-center justify-between border-b border-slate-200 p-5 dark:border-slate-800">
              <div>
                <h3 className="text-2xl font-black text-slate-900 dark:text-slate-100">
                  Log Detail
                </h3>
                <p className="mt-1 text-sm font-bold text-slate-500 dark:text-slate-400">
                  {selectedLog.id}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setSelectedLog(null)}
                className="inline-flex items-center gap-2 rounded-xl bg-slate-100 px-4 py-2 font-black text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-200"
              >
                <X size={17} />
                Close
              </button>
            </div>

            <pre className="overflow-auto p-5 text-sm text-slate-700 dark:text-slate-200">
              {JSON.stringify(selectedLog, null, 2)}
            </pre>
          </div>
        </div>
      )}
    </div>
  );
}
