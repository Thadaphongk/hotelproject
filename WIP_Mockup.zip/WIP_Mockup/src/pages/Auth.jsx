import { useEffect, useState } from "react";
import {
  AlertTriangle,
  ArrowLeft,
  Clock3,
  Info,
  KeyRound,
  LogIn,
  Moon,
  Send,
  ShieldCheck,
  Sun,
  UsersRound,
} from "lucide-react";
import {
  fetchEmployee,
  getRequestStatus,
  submitAccessRequest,
  loginEmployee,
} from "../services/api";
import CenterAlert from "../components/CenterAlert";

const reasons = [
  { value: "wip_view", label: "ขอสิทธิ์ดูข้อมูล WIP" },
  {
    value: "lot_management",
    label: "ขอสิทธิ์การจัดการ LOT",
  },
  {
    value: "line_information",
    label: "ขอสิทธิ์ดู Line Information",
  },
  {
    value: "admin",
    label: "ขอสิทธิ์ Admin",
  },
  {
    value: "other",
    label: "อื่นๆ (ระบุรายละเอียด)",
  },
];

const formatEmployeeDisplayName = (employee) => {
  const englishName = String(employee?.empName || employee?.name || "").trim();

  const thaiName = String(
    employee?.empName_TH || employee?.thaiName || "",
  ).trim();

  if (
    englishName &&
    thaiName &&
    englishName.toUpperCase() !== thaiName.toUpperCase()
  ) {
    return `${englishName} (${thaiName})`;
  }

  return englishName || thaiName || "-";
};

export default function Auth({ onLogin, theme, onThemeToggle, onCancel }) {
  const [employeeId, setEmployeeId] = useState("");
  const [employee, setEmployee] = useState(null);
  const [status, setStatus] = useState(null);
  const [reason, setReason] = useState("");
  const [customReason, setCustomReason] = useState("");
  const [error, setError] = useState("");
  const [notification, setNotification] = useState("");
  const [popup, setPopup] = useState(null);

  const [pendingLoginUser, setPendingLoginUser] = useState(null);

  const isRequestMode = Boolean(employee && !employee.approved);

  useEffect(() => {
    if (!employee) {
      setStatus(null);
      setReason("");
      setCustomReason("");
    }
  }, [employee]);

  useEffect(() => {
    if (reason !== "other") {
      setCustomReason("");
    }
  }, [reason]);

  useEffect(() => {
    const previousBodyOverflow = document.body.style.overflow;
    const previousHtmlOverflow = document.documentElement.style.overflow;

    document.body.style.overflow = "hidden";
    document.documentElement.style.overflow = "hidden";

    return () => {
      document.body.style.overflow = previousBodyOverflow;
      document.documentElement.style.overflow = previousHtmlOverflow;
    };
  }, []);

  const handlePopupConfirm = () => {
    if (popup?.type === "LOGIN_SUCCESS" && pendingLoginUser) {
      const user = pendingLoginUser;

      setPopup(null);
      setPendingLoginUser(null);

      onLogin(user);
      return;
    }

    setPopup(null);
  };

  const handleLogin = async (event) => {
    event.preventDefault();

    setError("");
    setNotification("");
    setEmployee(null);
    setStatus(null);
    setReason("");
    setCustomReason("");

    const id = employeeId.trim().toUpperCase();

    if (!id) {
      setPopup({
        type: "WARNING",
        title: "กรุณากรอกรหัสพนักงาน",
        message: "กรุณาใส่รหัสพนักงานก่อนเข้าสู่ระบบ",
        variant: "warning",
      });
      return;
    }

    try {
      const loggedInUser = await loginEmployee(id);

      setPendingLoginUser(loggedInUser);

      setPopup({
        type: "LOGIN_SUCCESS",
        title: "เข้าสู่ระบบสำเร็จ",
        message: `ยินดีต้อนรับ คุณ ${formatEmployeeDisplayName(
          loggedInUser,
        )}\nระบบตรวจสอบสิทธิ์เรียบร้อยแล้ว`,
        variant: "success",
      });
    } catch (err) {
      console.error("Login error:", err);

      // ไม่พบรหัสใน NameList
      if (err.code === "EMPLOYEE_NOT_FOUND" || err.status === 404) {
        setEmployee(null);
        setStatus(null);

        setPopup({
          type: "EMPLOYEE_NOT_FOUND",
          title: "ไม่พบรหัสพนักงาน",
          message:
            `ไม่พบรหัสพนักงาน ${id} ในฐานข้อมูล\n` +
            "กรุณาตรวจสอบรหัสพนักงานแล้วลองอีกครั้ง",
          variant: "danger",
        });

        return;
      }

      const accessErrorCodes = [
        "REGISTER_REQUIRED",
        "PENDING_APPROVAL",
        "ACCESS_REJECTED",
        "ACCESS_DISABLED",
        "ACCESS_NOT_APPROVED",
      ];

      // Error ที่ไม่เกี่ยวกับสิทธิ์ เช่น Server หรือ Network
      if (!accessErrorCodes.includes(err.code)) {
        setPopup({
          type: "SYSTEM_ERROR",
          title: "เข้าสู่ระบบไม่สำเร็จ",
          message:
            err.message || "ไม่สามารถเชื่อมต่อระบบได้ กรุณาลองใหม่อีกครั้ง",
          variant: "danger",
        });

        return;
      }

      try {
        const employeeData = await fetchEmployee(id);

        if (!employeeData) {
          setPopup({
            type: "EMPLOYEE_NOT_FOUND",
            title: "ไม่พบรหัสพนักงาน",
            message:
              `ไม่พบรหัสพนักงาน ${id} ในฐานข้อมูล\n` +
              "กรุณาตรวจสอบรหัสพนักงานแล้วลองอีกครั้ง",
            variant: "danger",
          });

          return;
        }

        setEmployee(employeeData);

        const requestStatus = await getRequestStatus(id);

        setStatus(requestStatus);

        const currentStatus = String(requestStatus?.status || "").toLowerCase();

        // มีใน NameList แต่ยังไม่เคยขอสิทธิ์
        if (err.code === "REGISTER_REQUIRED" || !requestStatus) {
          setPopup({
            type: "REGISTER_REQUIRED",
            title: "ต้องขอสิทธิ์ใช้งานระบบ",
            message:
              `พบรหัสพนักงาน ${id} ในฐานข้อมูล\n` +
              "แต่ยังไม่เคยได้รับสิทธิ์เข้าใช้งานระบบ\n" +
              "กรุณาเลือกเหตุผลและส่งคำขอให้ Admin อนุมัติ",
            variant: "warning",
          });

          return;
        }

        // ส่งคำขอไปแล้ว
        if (err.code === "PENDING_APPROVAL" || currentStatus === "pending") {
          setPopup({
            type: "PENDING_APPROVAL",
            title: "กำลังรอ Admin อนุมัติ",
            message:
              "รหัสพนักงานนี้ส่งคำขอใช้งานแล้ว\nกรุณารอ Admin ตรวจสอบและอนุมัติสิทธิ์",
            variant: "info",
          });

          return;
        }

        if (err.code === "ACCESS_REJECTED" || currentStatus === "rejected") {
          setPopup({
            type: "ACCESS_REJECTED",
            title: "คำขอถูกปฏิเสธ",
            message:
              "คำขอใช้งานระบบถูกปฏิเสธ\nกรุณาติดต่อ Admin หรือเลือกเหตุผลใหม่แล้วส่งคำขออีกครั้ง",
            variant: "danger",
          });

          return;
        }

        if (err.code === "ACCESS_DISABLED" || currentStatus === "disabled") {
          setPopup({
            type: "ACCESS_DISABLED",
            title: "สิทธิ์ถูกปิดใช้งาน",
            message: "สิทธิ์เข้าใช้งานระบบของรหัสนี้ถูกปิด\nกรุณาติดต่อ Admin",
            variant: "danger",
          });

          return;
        }

        setPopup({
          type: "ACCESS_NOT_APPROVED",
          title: "ยังไม่ได้รับอนุมัติสิทธิ์",
          message:
            "รหัสพนักงานนี้ยังไม่ได้รับอนุมัติสิทธิ์เข้าใช้งานระบบ\nกรุณาส่งคำขอหรือติดต่อ Admin",
          variant: "warning",
        });
      } catch (lookupError) {
        console.error("Lookup employee after login failed:", lookupError);

        setEmployee(null);
        setStatus(null);

        setPopup({
          type: "LOOKUP_ERROR",
          title: "ตรวจสอบข้อมูลไม่สำเร็จ",
          message:
            lookupError.message ||
            "ไม่สามารถตรวจสอบข้อมูลพนักงานได้ กรุณาลองใหม่อีกครั้ง",
          variant: "danger",
        });
      }
    }
  };

  const handleRequestAccess = async (event) => {
    event?.preventDefault();
    event?.stopPropagation();

    setError("");
    setNotification("");

    if (!employee) {
      setError("กรุณาตรวจสอบรหัสพนักงานก่อน");
      return;
    }

    if (!reason) {
      setError("กรุณาเลือกประเภทสิทธิ์ที่ต้องการ");
      return;
    }

    if (reason === "other" && !customReason.trim()) {
      setError("กรุณาระบุสิทธิ์ที่ต้องการขอเพิ่มเติม");
      return;
    }

    const selectedReason = reasons.find((item) => item.value === reason);
    const requestReason =
      reason === "other"
        ? `อื่นๆ: ${customReason.trim()}`
        : selectedReason?.label || reason;

    try {
      await submitAccessRequest(employee.id || employee.empCode, requestReason);

      const newStatus = await getRequestStatus(employee.id || employee.empCode);
      setStatus(newStatus);

      setNotification("ส่งคำขอเรียบร้อยแล้ว! กรุณารอ Admin อนุมัติหรือปฏิเสธ");
    } catch (err) {
      console.error("Request access error:", err);

      if (err.data?.access) {
        setStatus({
          ...err.data.access,
          status: String(err.data.access.status || "").toLowerCase(),
          statusRaw: err.data.access.status,
        });
      }

      setError(err.message || "ส่งคำขอไม่สำเร็จ");
    }
  };

  return (
    <div className="flex h-screen h-dvh w-full items-center justify-center overflow-hidden bg-gradient-to-br from-cyan-50 via-slate-100 to-slate-200 p-3 text-slate-900 dark:from-slate-950 dark:via-slate-950 dark:to-cyan-950/30 dark:text-slate-100 sm:p-4">
      <div
        className={`relative flex min-h-[78dvh] w-full flex-col justify-center overflow-hidden rounded-[2rem] border border-slate-200 bg-white p-6 shadow-2xl shadow-slate-300/40 transition-all duration-300 dark:border-slate-700 dark:bg-slate-900 dark:shadow-slate-950/60 sm:p-8 ${
          isRequestMode ? "max-w-6xl" : "max-w-3xl"
        }`}
      >
        <div className="pointer-events-none absolute right-[-80px] top-[-80px] h-56 w-56 rounded-full bg-cyan-400/20 blur-3xl" />
        <div className="pointer-events-none absolute bottom-[-90px] left-[-70px] h-52 w-52 rounded-full bg-indigo-400/10 blur-3xl" />

        <div className="relative mb-2 flex shrink-0 items-center justify-end">
          <button
            type="button"
            onClick={onThemeToggle}
            className="inline-flex h-9 items-center gap-2 rounded-xl border border-slate-200 bg-slate-50 px-3 text-xs font-bold text-slate-700 transition hover:bg-slate-100 dark:border-slate-600 dark:bg-slate-800 dark:text-slate-100 dark:hover:bg-slate-700"
          >
            {theme === "dark" ? <Sun size={16} /> : <Moon size={16} />}
            {theme === "dark" ? "Light mode" : "Dark mode"}
          </button>
        </div>

        <div
          className={`relative min-h-0 flex-1 ${
            isRequestMode
              ? "grid items-stretch gap-4 md:grid-cols-[0.9fr_1.1fr]"
              : ""
          }`}
        >
          <section
            className={`min-w-0 ${
              isRequestMode
                ? "flex flex-col rounded-3xl border border-slate-200 bg-white/80 p-4 dark:border-slate-700 dark:bg-slate-900/70 sm:p-5"
                : ""
            }`}
          >
            <div className="relative mb-4 space-y-1.5 text-center">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-cyan-600 text-white shadow-lg shadow-cyan-600/20 sm:h-14 sm:w-14">
                <ShieldCheck size={27} strokeWidth={2.2} />
              </div>

              <p className="text-xl font-black uppercase tracking-[0.26em] text-cyan-600 dark:text-cyan-300">
                WIP Demo Access
              </p>

              <h1 className="text-xl font-black text-slate-900 dark:text-slate-100 sm:text-3xl">
                เข้าสู่ระบบด้วยรหัสพนักงาน
              </h1>

              <p className="text-xs font-medium text-slate-500 dark:text-slate-400 sm:text-sm">
                ใช้รหัสพนักงานเพื่อเข้าสู่ระบบและตรวจสอบสิทธิ์การใช้งาน
              </p>
            </div>

            <form onSubmit={handleLogin} className="space-y-3">
              <div>
                <label
                  className="inline-flex items-center gap-2 text-sm font-bold text-slate-600 dark:text-slate-300"
                  htmlFor="employeeId"
                >
                  <KeyRound
                    size={16}
                    className="text-cyan-600 dark:text-cyan-300"
                  />
                  รหัสพนักงาน
                </label>

                <input
                  id="employeeId"
                  value={employeeId}
                  onChange={(event) => setEmployeeId(event.target.value)}
                  placeholder="กรุณาใส่รหัสพนักงาน"
                  className="mt-1.5 h-11 w-full rounded-xl border border-slate-300 bg-slate-50 px-4 text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:focus:border-cyan-400"
                />
              </div>

              <button
                type="submit"
                className="inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-cyan-600 px-5 text-sm font-black text-white shadow-sm transition hover:bg-cyan-700"
              >
                <LogIn size={18} />
                ตรวจสอบและเข้าสู่ระบบ
              </button>

              {onCancel ? (
                <button
                  type="button"
                  onClick={onCancel}
                  className="inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl border border-slate-300 bg-white px-5 text-sm font-bold text-slate-700 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800"
                >
                  <ArrowLeft size={18} />
                  กลับสู่หน้าหลัก (ไม่เข้าสู่ระบบ)
                </button>
              ) : null}

              {error ? (
                <div className="flex items-start gap-3 rounded-xl bg-red-50 p-3 text-xs font-bold text-red-700 dark:bg-rose-900/40 dark:text-rose-200 sm:text-sm">
                  <AlertTriangle size={18} className="mt-0.5 shrink-0" />
                  <span>{error}</span>
                </div>
              ) : null}

              {notification ? (
                <div className="flex items-start gap-3 rounded-xl bg-amber-50 p-3 text-xs font-bold text-amber-800 dark:bg-amber-900/40 dark:text-amber-100 sm:text-sm">
                  <Clock3 size={18} className="mt-0.5 shrink-0" />
                  <span>{notification}</span>
                </div>
              ) : null}
            </form>

            <div className="mt-3 rounded-2xl border border-slate-200 bg-slate-100 p-3 text-xs text-slate-600 dark:border-slate-700 dark:bg-slate-950/60 dark:text-slate-300">
              <p className="inline-flex items-center gap-2 font-black text-slate-900 dark:text-slate-100">
                <Info size={16} className="text-cyan-600 dark:text-cyan-300" />
                หมายเหตุ
              </p>

              <ul className="mt-1.5 space-y-1 list-disc pl-5">
                <li>เข้าสู่ระบบด้วยรหัสพนักงานโดยไม่ต้องใช้รหัสผ่าน</li>
                <li>ผู้ใช้งานใหม่สามารถส่งคำขอสิทธิ์ให้ Admin อนุมัติได้</li>
              </ul>
            </div>
          </section>

          {isRequestMode ? (
            <section className="min-h-0 rounded-3xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-700 dark:bg-slate-950/50 sm:p-5">
              <h2 className="mb-3 inline-flex items-center gap-2 text-lg font-black text-slate-900 dark:text-slate-100 sm:text-xl">
                <UsersRound
                  size={22}
                  className="text-cyan-600 dark:text-cyan-300"
                />
                ข้อมูลพนักงานและคำขอสิทธิ์
              </h2>

              <div className="space-y-2">
                {/* ชื่อเต็มความกว้าง */}
                <div className="rounded-2xl bg-white p-3 shadow-sm dark:bg-slate-900 dark:shadow-slate-950/30">
                  <p className="text-[11px] font-black uppercase tracking-[0.18em] text-slate-400 dark:text-slate-500">
                    ชื่อ
                  </p>

                  <p className="mt-1 break-words font-semibold text-slate-900 dark:text-slate-100">
                    {formatEmployeeDisplayName(employee)}
                  </p>
                </div>

                {/* แผนกและตำแหน่งอยู่แถวเดียวกัน */}
                <div className="grid gap-2 sm:grid-cols-2">
                  <div className="rounded-2xl bg-white p-3 shadow-sm dark:bg-slate-900 dark:shadow-slate-950/30">
                    <p className="text-[11px] font-black uppercase tracking-[0.18em] text-slate-400 dark:text-slate-500">
                      แผนก
                    </p>

                    <p className="mt-1 break-words font-semibold text-slate-900 dark:text-slate-100">
                      {employee.department || employee.dept || "-"}
                    </p>
                  </div>

                  <div className="rounded-2xl bg-white p-3 shadow-sm dark:bg-slate-900 dark:shadow-slate-950/30">
                    <p className="text-[11px] font-black uppercase tracking-[0.18em] text-slate-400 dark:text-slate-500">
                      ตำแหน่ง
                    </p>

                    <p className="mt-1 break-words font-semibold text-slate-900 dark:text-slate-100">
                      {employee.position || "-"}
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-4 space-y-3">
                <div>
                  <label
                    className="text-sm font-bold text-slate-700 dark:text-slate-300"
                    htmlFor="accessReason"
                  >
                    เลือกประเภทสิทธิ์ที่ต้องการ
                  </label>

                  <select
                    id="accessReason"
                    value={reason}
                    onChange={(event) => setReason(event.target.value)}
                    className="mt-1.5 h-11 w-full rounded-xl border border-slate-300 bg-white px-4 text-sm text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:focus:border-cyan-400"
                  >
                    <option value="">-- เลือกประเภทสิทธิ์ --</option>
                    {reasons.map((item) => (
                      <option key={item.value} value={item.value}>
                        {item.label}
                      </option>
                    ))}
                  </select>

                  {reason === "other" ? (
                    <div className="mt-3">
                      <label
                        className="text-sm font-bold text-slate-700 dark:text-slate-300"
                        htmlFor="customAccessReason"
                      >
                        ระบุสิทธิ์ที่ต้องการ
                      </label>
                      <textarea
                        id="customAccessReason"
                        value={customReason}
                        onChange={(event) => setCustomReason(event.target.value)}
                        maxLength={300}
                        rows={3}
                        placeholder="เช่น ขอสิทธิ์ดู Logs, ขอสิทธิ์ใช้งาน Daily Check หรือระบุสิทธิ์อื่นที่ต้องการ..."
                        className="mt-1.5 w-full resize-none rounded-xl border border-slate-300 bg-white px-4 py-3 text-sm text-slate-900 outline-none transition placeholder:text-slate-400 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:placeholder:text-slate-500 dark:focus:border-cyan-400"
                      />
                      <div className="mt-1 flex items-center justify-between gap-3 text-[11px] font-medium text-slate-500 dark:text-slate-400">
                        <span>ระบุให้ชัดเจนเพื่อช่วยให้ Admin ตรวจสอบได้เร็วขึ้น</span>
                        <span>{customReason.length}/300</span>
                      </div>
                    </div>
                  ) : null}
                </div>

                <button
                  type="button"
                  onClick={(event) => handleRequestAccess(event)}
                  className="inline-flex h-11 w-full items-center justify-center gap-2 rounded-xl bg-slate-800 px-5 text-sm font-black text-white transition hover:bg-slate-700 dark:bg-cyan-700 dark:hover:bg-cyan-600"
                >
                  <Send size={18} />
                  ส่งคำขอไปยัง Admin
                </button>

                {status?.status === "pending" ? (
                  <div className="flex items-start gap-2 rounded-xl bg-sky-50 p-3 text-xs font-bold text-sky-700 dark:bg-sky-900/40 dark:text-sky-100 sm:text-sm">
                    <Clock3 size={18} className="mt-0.5 shrink-0" />
                    <span>สถานะคำขอ: รออนุมัติจาก Admin</span>
                  </div>
                ) : null}

                {status?.status === "rejected" ? (
                  <div className="flex items-start gap-2 rounded-xl bg-rose-50 p-3 text-xs font-bold text-rose-700 dark:bg-rose-900/40 dark:text-rose-100 sm:text-sm">
                    <AlertTriangle size={18} className="mt-0.5 shrink-0" />
                    <span>
                      สถานะคำขอ: ถูกปฏิเสธแล้ว กรุณาติดต่อ Admin
                      หรือเลือกเหตุผลใหม่แล้วส่งคำขออีกครั้ง
                    </span>
                  </div>
                ) : null}

                <div className="flex items-start gap-3 rounded-2xl border border-amber-200 bg-amber-50/90 p-4 text-sm text-amber-900 shadow-sm dark:border-amber-800/70 dark:bg-amber-950/35 dark:text-amber-100">
                  <Info
                    size={20}
                    className="mt-0.5 shrink-0 text-amber-600 dark:text-amber-300"
                  />
                  <div>
                    <p className="font-black">หลังส่งคำขอสิทธิ์</p>
                    <p className="mt-1 font-medium leading-relaxed">
                      <span className="font-black text-rose-600 dark:text-rose-500">กรุณาติดต่อทีมงาน IT </span>
                      เพื่อดำเนินการตรวจสอบและอนุมัติสิทธิ์เข้าใช้งานระบบ
                      หลังได้รับการอนุมัติแล้ว ให้กด  
                      <span className="font-black text-emerald-600 dark:text-emerald-500"> “ตรวจสอบและเข้าสู่ระบบ”</span> อีกครั้ง
                    </p>
                  </div>
                </div>
              </div>
            </section>
          ) : null}
        </div>
      </div>
      <CenterAlert
        open={Boolean(popup)}
        title={popup?.title || "แจ้งเตือน"}
        message={popup?.message || ""}
        variant={popup?.variant || "info"}
        confirmText="ตกลง"
        onClose={() => {
          setPopup(null);

          if (popup?.type === "LOGIN_SUCCESS") {
            setPendingLoginUser(null);
          }
        }}
        onConfirm={handlePopupConfirm}
      />
    </div>
  );
}
