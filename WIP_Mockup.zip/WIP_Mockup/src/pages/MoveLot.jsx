import DemoGuideButton from "../components/DemoGuideButton";
import DemoMachineQueuePanel from "../components/DemoMachineQueuePanel";
import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  ArrowRightLeft,
  CheckCircle2,
  ClipboardPenLine,
  Download,
  Eraser,
  Factory,
  History,
  Info,
  RefreshCw,
  Save,
  Search,
  X,
} from "lucide-react";
import {
  createMoveLot,
  getMoveLots,
  lookupMoveLot,
} from "../services/moveLotClient";
import { writeActivityLog } from "../services/logClient";
import { clearMachinesCache, getMachines } from "../services/api";
import CenterAlert from "../components/CenterAlert";
import HorizontalBarChart from "../components/HorizontalBarChart";
import DonutChart from "../components/DonutChart";
import ChartFilterPlaceholder from "../components/ChartFilterPlaceholder";
import DateModeFilter from "../components/DateModeFilter";
import {
  DATE_RANGE_ERROR_MESSAGE,
  getCurrentTimeText,
  getDateModeRangeText,
  getEffectiveDateRange,
  hasDateFilterForChart,
  isInvalidDateModeRange,
} from "../utils/dateRangeText";
import {
  formatDisplayMachineName,
  isFrontendVisibleMachine,
} from "../utils/machineQueueUtils";

const LINE_CODE = "DEMO";
const SHOW_CURRENT_LOTS = false;

const machineOptions = [
  "DEMO-MC-A01",
  "DEMO-MC-A02",
  "DEMO-MC-B01",
  "DEMO-MC-B02",
  "DEMO-MC-C01",
  "DEMO-MC-C02",
];

const normalizeMachineOption = (value) => {
  const text = String(value ?? "")
    .trim()
    .toUpperCase();

  if (!text || text === "-" || text === "NULL" || text === "UNDEFINED") {
    return "";
  }

  return text;
};

const getMachineSortIndex = (machine) => {
  const index = machineOptions.indexOf(machine);
  return index === -1 ? Number.MAX_SAFE_INTEGER : index;
};

const buildMoveToMachineOptions = (rows = []) => {
  const uniqueMap = new Map();

  for (const row of rows || []) {
    const machine = normalizeMachineOption(
      row?.toMachine ||
        row?.targetMachine ||
        row?.targetMachine ||
        row?.newMachine,
    );

    if (!machine || !isFrontendVisibleMachine(machine)) continue;

    uniqueMap.set(machine, machine);
  }

  return Array.from(uniqueMap.values()).sort((a, b) => {
    const sortDiff = getMachineSortIndex(a) - getMachineSortIndex(b);
    if (sortDiff !== 0) return sortDiff;

    return a.localeCompare(b, "en");
  });
};

const reasonOptions = [
  "Balance workload",
  "Urgent demo order",
  "Planned maintenance",
  "Quality review",
  "Setup compatibility",
  "Operator availability",
  "Return to original demo machine",
  "Demo scenario",
  "อื่นๆ",
];

const ReasonDropdown = ({
  value,
  onChange,
  options = [],
  placeholder = "กรุณาเลือกเหตุผล",
}) => {
  const [open, setOpen] = useState(false);
  const dropdownRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const selectedText = value || placeholder;

  return (
    <div ref={dropdownRef} className="relative">
      <button
        type="button"
        onClick={() => setOpen((current) => !current)}
        onKeyDown={(event) => {
          if (event.key === "Escape") setOpen(false);
        }}
        className="mt-2 flex h-14 w-full items-center justify-between rounded-2xl border border-slate-300 bg-slate-50 px-4 text-left text-lg font-bold text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:focus:border-cyan-400"
      >
        <span
          className={
            value
              ? "truncate text-slate-900 dark:text-slate-100"
              : "truncate text-slate-500 dark:text-slate-400"
          }
        >
          {selectedText}
        </span>

        <span className="ml-3 text-slate-500 dark:text-slate-400">
          {open ? "▲" : "▼"}
        </span>
      </button>

      {open ? (
        <div className="absolute left-0 right-0 z-[90] mt-2 max-h-64 overflow-y-auto rounded-2xl border border-slate-300 bg-white py-2 shadow-xl ring-1 ring-black/5 dark:border-slate-700 dark:bg-slate-900">
          <button
            type="button"
            onClick={() => {
              onChange("");
              setOpen(false);
            }}
            className={`block w-full px-4 py-3 text-left text-base font-bold transition hover:bg-cyan-50 hover:text-cyan-700 dark:hover:bg-slate-800 dark:hover:text-cyan-300 ${
              !value
                ? "bg-slate-100 text-slate-900 dark:bg-slate-800 dark:text-white"
                : "text-slate-600 dark:text-slate-300"
            }`}
          >
            {placeholder}
          </button>

          {options.map((item) => {
            const active = value === item;

            return (
              <button
                key={item}
                type="button"
                onClick={() => {
                  onChange(item);
                  setOpen(false);
                }}
                className={`block w-full px-4 py-3 text-left text-base font-bold transition hover:bg-cyan-50 hover:text-cyan-700 dark:hover:bg-slate-800 dark:hover:text-cyan-300 ${
                  active
                    ? "bg-cyan-50 text-cyan-700 dark:bg-cyan-950/40 dark:text-cyan-300"
                    : "text-slate-700 dark:text-slate-300"
                }`}
              >
                {item}
              </button>
            );
          })}
        </div>
      ) : null}
    </div>
  );
};

const getEmployeeId = (user) => {
  return String(user?.id || user?.empCode || user?.employeeId || "")
    .trim()
    .toUpperCase();
};

const getEmployeeName = (user) => {
  return String(user?.name || user?.empName || user?.empName_TH || "").trim();
};

const pad2 = (value) => String(value).padStart(2, "0");

const getTodayInputDate = () => {
  const now = new Date();
  return `${now.getFullYear()}-${pad2(now.getMonth() + 1)}-${pad2(
    now.getDate(),
  )}`;
};

const formatDateTime = (value) => {
  if (!value) return "-";

  const date = new Date(String(value).replace(" ", "T"));
  if (Number.isNaN(date.getTime())) return value;

  return date.toLocaleString("en-GB", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
};

const hasUsefulValue = (value) => {
  const text = String(value ?? "").trim();

  return (
    text !== "" &&
    text !== "-" &&
    text.toLowerCase() !== "null" &&
    text.toLowerCase() !== "undefined"
  );
};

const getLotNoFromRow = (lot) => {
  return String(lot?.lotId || lot?.lotId || "")
    .trim()
    .toUpperCase();
};

const buildRunningMoveLots = (machines = []) => {
  return (machines || [])
    .filter((machine) => machineOptions.includes(machine.machineName))
    .map((machine) => {
      const lots = Array.isArray(machine.lots) ? machine.lots : [];

      const currentLot =
        lots.find(
          (lot) =>
            String(lot?.sourceType || "")
              .trim()
              .toUpperCase() === "CURRENT",
        ) || lots[0];

      if (!currentLot) return null;

      const lotId = getLotNoFromRow(currentLot);
      if (!lotId || lotId === "-") return null;

      const lossText = String(currentLot?.stopCode ?? "").trim();
      const hasLossCode = lossText !== "" && lossText !== "-";

      const mcStatus = String(currentLot?.machineStatus || "")
        .trim()
        .toUpperCase();

      const process = String(currentLot?.processStatus || "")
        .trim()
        .toUpperCase();

      const hasActiveData = [
        currentLot?.startTime,
        currentLot?.inputQty,
        currentLot?.outputQty,
        currentLot?.operatorId,
      ].some(hasUsefulValue);

      let status = "WAIT";
      let statusBadgeClass =
        "bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300";
      let cardClass =
        "border-amber-200 bg-amber-50/70 dark:border-amber-900/60 dark:bg-amber-950/20";

      if (hasLossCode) {
        status = "STOP";
        statusBadgeClass =
          "bg-rose-100 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300";
        cardClass =
          "border-rose-200 bg-rose-50/80 dark:border-rose-900/60 dark:bg-rose-950/20";
      } else if (mcStatus === "RUN" || process === "ACTIVE" || hasActiveData) {
        status = "RUN";
        statusBadgeClass =
          "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300";
        cardClass =
          "border-emerald-200 bg-emerald-50/80 dark:border-emerald-900/60 dark:bg-emerald-950/20";
      }

      return {
        machine: machine.machineName,
        lotId,
        partName: currentLot?.partName || currentLot?.partName || "-",
        machineLine: currentLot?.lineName || currentLot?.queueMachine || "-",
        status,
        statusProcess: process || currentLot?.processStatus || "-",
        mcStatus: mcStatus || "-",
        lossCode: hasLossCode ? lossText : "-",
        inputDate: currentLot?.inputDate || currentLot?.inputDate || "-",
        statusBadgeClass,
        cardClass,
      };
    })
    .filter(Boolean);
};

const buildCountItems = (rows, getLabel) => {
  const countMap = new Map();

  for (const row of rows || []) {
    const rawLabel = getLabel(row);
    const label = String(rawLabel || "-").trim();

    if (!label || label === "-") continue;

    countMap.set(label, (countMap.get(label) || 0) + 1);
  }

  return Array.from(countMap.entries()).map(([label, value]) => ({
    label,
    value,
  }));
};

const moveMachineColorMap = {
  "DEMO-MC-A01": "#8b5cf6",
  "DEMO-MC-A02": "#ef4444",
  "DEMO-MC-B01": "#3b82f6",
  "DEMO-MC-B02": "#f59e0b",
  "DEMO-MC-C01": "#10b981",
  "DEMO-MC-C02": "#06b6d4",
};

const normalizeChartValue = (value) => {
  const text = String(value ?? "").trim();

  if (
    !text ||
    text === "-" ||
    text.toLowerCase() === "null" ||
    text.toLowerCase() === "undefined"
  ) {
    return "";
  }

  return text;
};

const getMoveSourceMachine = (row) => {
  return normalizeChartValue(row?.fromMachine || row?.machineName);
};

const getMoveTargetMachine = (row) => {
  return normalizeChartValue(
    row?.toMachine ||
      row?.targetMachine ||
      row?.targetMachine ||
      row?.newMachine,
  );
};

const getMoveReason = (row) => {
  return normalizeChartValue(row?.reason || row?.reason);
};

const getMoveMachineColor = (machine) => {
  return moveMachineColorMap[machine] || "#64748b";
};

const buildCountItemsWithColor = (rows, getLabel, getColor) => {
  const countMap = new Map();

  for (const row of rows || []) {
    const label = normalizeChartValue(getLabel(row));
    if (!label) continue;

    countMap.set(label, (countMap.get(label) || 0) + 1);
  }

  return Array.from(countMap.entries()).map(([label, value]) => ({
    label,
    value,
    color: getColor(label),
  }));
};

const getDominantMachineForReason = (rows, reason) => {
  const countMap = new Map();

  for (const row of rows || []) {
    if (getMoveReason(row) !== reason) continue;

    const machine = getMoveSourceMachine(row);
    if (!machine) continue;

    countMap.set(machine, (countMap.get(machine) || 0) + 1);
  }

  return (
    Array.from(countMap.entries()).sort((a, b) => b[1] - a[1])?.[0]?.[0] || ""
  );
};

const hasMachineReasonRelation = (rows, machine, reason) => {
  return (rows || []).some(
    (row) =>
      (!machine || getMoveSourceMachine(row) === machine) &&
      (!reason || getMoveReason(row) === reason),
  );
};

const hasMoveChartRelation = (
  rows,
  { sourceMachine = "", targetMachine = "", reason = "" } = {},
) => {
  return (rows || []).some((row) => {
    const rowSourceMachine = getMoveSourceMachine(row);
    const rowTargetMachine = getMoveTargetMachine(row);
    const rowReason = getMoveReason(row);

    if (sourceMachine && rowSourceMachine !== sourceMachine) return false;
    if (targetMachine && rowTargetMachine !== targetMachine) return false;
    if (reason && rowReason !== reason) return false;

    return true;
  });
};

export default function MoveLot({ user }) {
  const formSectionRef = useRef(null);
  const toMachineSelectRef = useRef(null);

  const employeeId = getEmployeeId(user);
  const employeeName = getEmployeeName(user);

  const [lotId, setLotno] = useState("");
  const [lotInfo, setLotInfo] = useState(null);

  const [toMachine, setToMachine] = useState("");
  const [reason, setReason] = useState("");
  const [otherReason, setOtherReason] = useState("");
  const [etc, setEtc] = useState("");

  const [search, setSearch] = useState("");
  const [filterMachine, setFilterMachine] = useState("");
  const [moveToMachineOptions, setMoveToMachineOptions] = useState([]);
  const [dateMode, setDateMode] = useState("single");
  const [filterDateFrom, setFilterDateFrom] = useState("");
  const [filterDateTo, setFilterDateTo] = useState("");

  const [hoveredChartItem, setHoveredChartItem] = useState(null);
  const [selectedSourceMachine, setSelectedSourceMachine] = useState("");
  const [selectedTargetMachine, setSelectedTargetMachine] = useState("");
  const [selectedMoveReason, setSelectedMoveReason] = useState("");

  const historyLine = LINE_CODE;

  const [rows, setRows] = useState([]);
  const [lookupLoading, setLookupLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [loadingRows, setLoadingRows] = useState(false);
  const [runningLots, setRunningLots] = useState([]);
  const [loadingRunningLots, setLoadingRunningLots] = useState(false);

  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [alertMessage, setAlertMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [dateAlertMessage, setDateAlertMessage] = useState("");
  const [confirmSaveData, setConfirmSaveData] = useState(null);
  const [showMoveGuide, setShowMoveGuide] = useState(false);
  const [showMoveCriteria, setShowMoveCriteria] = useState(false);

  const moveFromMachineChartItems = useMemo(() => {
    return buildCountItemsWithColor(
      rows,
      getMoveSourceMachine,
      getMoveMachineColor,
    ).map((item) => {
      const isSelected =
        selectedSourceMachine && item.label === selectedSourceMachine;

      const isHovered =
        hoveredChartItem?.type === "machine" &&
        hoveredChartItem.value === item.label;

      const isRelatedToSelectedReason =
        selectedMoveReason &&
        hasMachineReasonRelation(rows, item.label, selectedMoveReason);

      const isRelatedToHoveredReason =
        hoveredChartItem?.type === "reason" &&
        hasMachineReasonRelation(rows, item.label, hoveredChartItem.value);

      const shouldDim =
        (selectedSourceMachine && item.label !== selectedSourceMachine) ||
        (selectedMoveReason && !isRelatedToSelectedReason) ||
        (hoveredChartItem?.type === "machine" &&
          hoveredChartItem.value !== item.label) ||
        (hoveredChartItem?.type === "reason" && !isRelatedToHoveredReason);

      return {
        ...item,
        displayLabel: formatDisplayMachineName(item.label),
        active: Boolean(isSelected || isHovered),
        dimmed: Boolean(shouldDim),
      };
    });
  }, [rows, selectedSourceMachine, selectedMoveReason, hoveredChartItem]);

  const moveReasonChartItems = useMemo(() => {
    const reasonSourceRows = (rows || []).filter((row) => {
      const sourceMachine = getMoveSourceMachine(row);
      const targetMachine = getMoveTargetMachine(row);

      if (selectedSourceMachine && sourceMachine !== selectedSourceMachine) {
        return false;
      }

      if (selectedTargetMachine && targetMachine !== selectedTargetMachine) {
        return false;
      }

      return true;
    });

    return buildCountItemsWithColor(
      reasonSourceRows,
      getMoveReason,
      (reason) => {
        const activeMachine =
          selectedSourceMachine ||
          selectedTargetMachine ||
          (hoveredChartItem?.type === "machine"
            ? hoveredChartItem.value
            : "") ||
          (hoveredChartItem?.type === "targetMachine"
            ? hoveredChartItem.value
            : "") ||
          getDominantMachineForReason(rows, reason);

        return getMoveMachineColor(activeMachine);
      },
    ).map((item) => {
      const isSelected =
        selectedMoveReason && item.label === selectedMoveReason;

      const isHovered =
        hoveredChartItem?.type === "reason" &&
        hoveredChartItem.value === item.label;

      const isRelatedToSelectedSource =
        selectedSourceMachine &&
        hasMoveChartRelation(rows, {
          sourceMachine: selectedSourceMachine,
          reason: item.label,
        });

      const isRelatedToSelectedTarget =
        selectedTargetMachine &&
        hasMoveChartRelation(rows, {
          targetMachine: selectedTargetMachine,
          reason: item.label,
        });

      const isRelatedToHoveredSource =
        hoveredChartItem?.type === "machine" &&
        hasMoveChartRelation(rows, {
          sourceMachine: hoveredChartItem.value,
          reason: item.label,
        });

      const isRelatedToHoveredTarget =
        hoveredChartItem?.type === "targetMachine" &&
        hasMoveChartRelation(rows, {
          targetMachine: hoveredChartItem.value,
          reason: item.label,
        });

      const shouldDim =
        (selectedMoveReason && item.label !== selectedMoveReason) ||
        (selectedSourceMachine && !isRelatedToSelectedSource) ||
        (selectedTargetMachine && !isRelatedToSelectedTarget) ||
        (hoveredChartItem?.type === "reason" &&
          hoveredChartItem.value !== item.label) ||
        (hoveredChartItem?.type === "machine" && !isRelatedToHoveredSource) ||
        (hoveredChartItem?.type === "targetMachine" &&
          !isRelatedToHoveredTarget);

      return {
        ...item,
        active: Boolean(isSelected || isHovered),
        dimmed: Boolean(shouldDim),
      };
    });
  }, [
    rows,
    selectedSourceMachine,
    selectedTargetMachine,
    selectedMoveReason,
    hoveredChartItem,
  ]);

  const moveToMachineChartItems = useMemo(() => {
    return buildCountItemsWithColor(
      rows,
      getMoveTargetMachine,
      getMoveMachineColor,
    ).map((item) => {
      const isSelected =
        selectedTargetMachine && item.label === selectedTargetMachine;

      const isHovered =
        hoveredChartItem?.type === "targetMachine" &&
        hoveredChartItem.value === item.label;

      const isRelatedToSelectedSource =
        selectedSourceMachine &&
        hasMoveChartRelation(rows, {
          sourceMachine: selectedSourceMachine,
          targetMachine: item.label,
        });

      const isRelatedToSelectedReason =
        selectedMoveReason &&
        hasMoveChartRelation(rows, {
          targetMachine: item.label,
          reason: selectedMoveReason,
        });

      const isRelatedToHoveredSource =
        hoveredChartItem?.type === "machine" &&
        hasMoveChartRelation(rows, {
          sourceMachine: hoveredChartItem.value,
          targetMachine: item.label,
        });

      const isRelatedToHoveredReason =
        hoveredChartItem?.type === "reason" &&
        hasMoveChartRelation(rows, {
          targetMachine: item.label,
          reason: hoveredChartItem.value,
        });

      const shouldDim =
        (selectedTargetMachine && item.label !== selectedTargetMachine) ||
        (selectedSourceMachine && !isRelatedToSelectedSource) ||
        (selectedMoveReason && !isRelatedToSelectedReason) ||
        (hoveredChartItem?.type === "targetMachine" &&
          hoveredChartItem.value !== item.label) ||
        (hoveredChartItem?.type === "machine" && !isRelatedToHoveredSource) ||
        (hoveredChartItem?.type === "reason" && !isRelatedToHoveredReason);

      return {
        ...item,
        displayLabel: formatDisplayMachineName(item.label),
        active: Boolean(isSelected || isHovered),
        dimmed: Boolean(shouldDim),
      };
    });
  }, [
    rows,
    selectedSourceMachine,
    selectedTargetMachine,
    selectedMoveReason,
    hoveredChartItem,
  ]);

  const [currentDataTimeText, setCurrentDataTimeText] = useState(() =>
    getCurrentTimeText(),
  );

  const canShowCharts = hasDateFilterForChart({
    dateMode,
    dateFrom: filterDateFrom,
    dateTo: filterDateTo,
  });

  const dateRangeInvalid = isInvalidDateModeRange(
    dateMode,
    filterDateFrom,
    filterDateTo,
  );

  const dateRangeText = getDateModeRangeText({
    dateMode,
    dateFrom: filterDateFrom,
    dateTo: filterDateTo,
  });

  const finalReason = useMemo(() => {
    if (reason === "อื่นๆ") return otherReason.trim();
    return reason.trim();
  }, [reason, otherReason]);

  const resetForm = () => {
    setLotno("");
    setLotInfo(null);
    setToMachine("");
    setReason("");
    setOtherReason("");
    setEtc("");
    setMessage("");
    setError("");
    setAlertMessage("");
    setConfirmSaveData(null);
  };

  const handleFilterDateFromChange = (value) => {
    setFilterDateFrom(value);

    if (dateMode === "single") {
      setFilterDateTo("");
      return;
    }

    if (filterDateTo && value && value > filterDateTo) {
      setFilterDateTo("");
      setDateAlertMessage(
        "วันที่เริ่มต้นมากกว่าวันที่สิ้นสุด ระบบจึงล้างวันที่สิ้นสุดให้ กรุณาเลือกใหม่อีกครั้ง",
      );
    }
  };

  const handleFilterDateToChange = (value) => {
    if (
      dateMode === "range" &&
      filterDateFrom &&
      value &&
      value < filterDateFrom
    ) {
      setDateAlertMessage(DATE_RANGE_ERROR_MESSAGE);
      return;
    }

    setFilterDateTo(value);
  };

  const handleDateModeChange = (nextMode) => {
    setDateMode(nextMode);
    setError("");
    setDateAlertMessage("");

    if (nextMode === "single") {
      setFilterDateTo("");
    }
  };

  const handleHoverMachineChart = (item) => {
    setHoveredChartItem({ type: "machine", value: item.label });
  };

  const handleHoverReasonChart = (item) => {
    setHoveredChartItem({ type: "reason", value: item.label });
  };

  const handleHoverTargetMachineChart = (item) => {
    setHoveredChartItem({ type: "targetMachine", value: item.label });
  };

  const handleLeaveChart = () => {
    setHoveredChartItem(null);
  };

  const handleClickMachineChart = (item) => {
    const nextMachine = item?.label || "";

    setSelectedSourceMachine((currentMachine) => {
      const isSameMachine = currentMachine === nextMachine;

      if (isSameMachine) {
        setSelectedMoveReason("");
        return "";
      }

      setSelectedMoveReason("");
      return nextMachine;
    });
  };

  const handleClickReasonChart = (item) => {
    const nextReason = item?.label || "";

    setSelectedMoveReason((currentReason) => {
      const isSameReason = currentReason === nextReason;

      if (isSameReason) {
        return "";
      }

      return nextReason;
    });
  };

  const handleClickTargetMachineChart = (item) => {
    const nextMachine = item?.label || "";

    setSelectedTargetMachine((currentMachine) => {
      const isSameMachine = currentMachine === nextMachine;

      if (isSameMachine) {
        setSelectedMoveReason("");
        return "";
      }

      setSelectedMoveReason("");
      return nextMachine;
    });
  };

  const loadRows = async (override = {}) => {
    const nextSearch = override.search ?? search;
    const nextMachine = override.machine ?? filterMachine;
    const nextDateMode = override.dateMode ?? dateMode;
    const nextDateFrom = override.dateFrom ?? filterDateFrom;
    const nextDateTo = override.dateTo ?? filterDateTo;
    const nextLine = override.line ?? historyLine;

    const effectiveDateRange = getEffectiveDateRange(
      nextDateMode,
      nextDateFrom,
      nextDateTo,
    );

    setLoadingRows(true);
    setError("");

    if (isInvalidDateModeRange(nextDateMode, nextDateFrom, nextDateTo)) {
      setRows([]);
      setError(DATE_RANGE_ERROR_MESSAGE);
      setDateAlertMessage(DATE_RANGE_ERROR_MESSAGE);
      setLoadingRows(false);
      return;
    }

    try {
      const rowsRequest = getMoveLots({
        line: nextLine,
        search: nextSearch,
        machine: nextMachine,
        dateFrom: effectiveDateRange.dateFrom,
        dateTo: effectiveDateRange.dateTo,
      });

      const optionRowsRequest = nextMachine
        ? getMoveLots({
            line: nextLine,
            search: nextSearch,
            machine: "",
            dateFrom: effectiveDateRange.dateFrom,
            dateTo: effectiveDateRange.dateTo,
          })
        : rowsRequest;

      const [data, optionData] = await Promise.all([
        rowsRequest,
        optionRowsRequest,
      ]);

      const visibleRows = (data.rows || []).filter((row) => {
        return (
          isFrontendVisibleMachine(getMoveSourceMachine(row)) &&
          isFrontendVisibleMachine(getMoveTargetMachine(row))
        );
      });

      const visibleOptionRows = (optionData.rows || []).filter((row) => {
        return (
          isFrontendVisibleMachine(getMoveSourceMachine(row)) &&
          isFrontendVisibleMachine(getMoveTargetMachine(row))
        );
      });

      setRows(visibleRows);
      setMoveToMachineOptions(buildMoveToMachineOptions(visibleOptionRows));
    } catch (err) {
      console.error("Load move lots error:", err);
      setError(err.message || "โหลดประวัติ Move Lot ไม่สำเร็จ");
    } finally {
      setLoadingRows(false);
    }
  };

  const handleClearFilters = async () => {
    setSearch("");
    setFilterMachine("");
    setDateMode("single");
    setFilterDateFrom("");
    setFilterDateTo("");
    setHoveredChartItem(null);
    setSelectedSourceMachine("");
    setSelectedMoveReason("");
    setSelectedTargetMachine("");

    await loadRows({
      search: "",
      machine: "",
      dateMode: "single",
      dateFrom: "",
      dateTo: "",
    });
  };

  const loadRunningLots = async ({ force = false } = {}) => {
    setLoadingRunningLots(true);

    try {
      const data = await getMachines({
        force,
      });

      const runningData = buildRunningMoveLots(data || []);

      setRunningLots(runningData);
    } catch (err) {
      console.error("Load running lots error:", err);

      setRunningLots([]);
    } finally {
      setLoadingRunningLots(false);
    }
  };

  useEffect(() => {
    const timer = window.setInterval(() => {
      setCurrentDataTimeText(getCurrentTimeText());
    }, 1000);

    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    if (!showMoveGuide) return undefined;

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    const handleEscape = (event) => {
      if (event.key === "Escape") {
        setShowMoveGuide(false);
      }
    };

    window.addEventListener("keydown", handleEscape);

    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", handleEscape);
    };
  }, [showMoveGuide]);

  useEffect(() => {
    if (SHOW_CURRENT_LOTS) {
      loadRunningLots();
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    loadRows();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dateMode, filterDateFrom, filterDateTo, filterMachine]);

  const handleUseRunningLot = async (item) => {
    const cleanLot = String(item?.lotId || "")
      .trim()
      .toUpperCase();

    if (!cleanLot) {
      showMoveLotAlert(
        "ไม่พบ Lot No จากเครื่องที่เลือก กรุณากด Refresh Machines แล้วลองใหม่อีกครั้ง",
      );
      return;
    }

    setLotno(cleanLot);
    setLotInfo(null);
    setToMachine("");
    setReason("");
    setOtherReason("");
    setEtc("");
    setMessage("");
    setError("");
    setAlertMessage("");
    setLookupLoading(true);

    try {
      /*
       * สำคัญ:
       * ต้อง Lookup จาก Backend อีกครั้ง
       * เพื่อดึง latestMove, originalMachine และ isMoved
       */
      const data = await lookupMoveLot(cleanLot);
      const nextLot = data?.lot || null;

      if (!nextLot) {
        showLotNotFoundAlert(
          "ไม่พบ Lot นี้ในฐานข้อมูล กรุณาตรวจสอบเลข Lot แล้วลองใหม่อีกครั้ง",
        );
        return;
      }

      const sourceMachine =
        nextLot.fromMachine ||
        nextLot.currentMachine ||
        nextLot.originalMachine ||
        nextLot.machineLine ||
        nextLot.wipMachine ||
        "";

      if (sourceMachine && !isFrontendVisibleMachine(sourceMachine)) {
        showMoveLotAlert(
          "Lot นี้อยู่ในเครื่องที่ไม่ได้เปิดใช้งานบนหน้าเว็บปัจจุบัน",
        );
        return;
      }

      setLotInfo(nextLot);

      setMessage(
        `เลือก Lot ${cleanLot} จาก ${formatDisplayMachineName(
          nextLot.currentMachine || nextLot.fromMachine || item.machine || "-",
        )} แล้ว`,
      );

      window.requestAnimationFrame(() => {
        formSectionRef.current?.scrollIntoView({
          behavior: "smooth",
          block: "start",
        });

        window.setTimeout(() => {
          toMachineSelectRef.current?.focus();
        }, 450);
      });
    } catch (err) {
      console.error("Lookup running lot error:", err);

      const errorMessage =
        err?.message || "ไม่สามารถตรวจสอบข้อมูล Lot ได้ กรุณาลองใหม่อีกครั้ง";

      if (
        err?.code === "LOT_NOT_FOUND" ||
        err?.status === 404 ||
        errorMessage.includes("ไม่พบ Lot")
      ) {
        showLotNotFoundAlert(errorMessage);
        return;
      }

      showMoveLotAlert(errorMessage);
    } finally {
      setLookupLoading(false);
    }
  };

  const handleLookup = async () => {
    const cleanLot = lotId.trim().toUpperCase();

    setMessage("");
    setError("");
    setAlertMessage("");
    setLotInfo(null);

    if (!cleanLot) {
      showMoveLotAlert("กรุณากรอก LOT NO ก่อนกด Search");
      return;
    }

    setLookupLoading(true);

    try {
      const data = await lookupMoveLot(cleanLot);
      const nextLot = data.lot || null;
      const sourceMachine =
        nextLot?.fromMachine ||
        nextLot?.currentMachine ||
        nextLot?.machineLine ||
        nextLot?.wipMachine ||
        "";

      if (nextLot && !isFrontendVisibleMachine(sourceMachine)) {
        showMoveLotAlert(
          "Lot นี้อยู่ในเครื่องที่ไม่ได้เปิดใช้งานบนหน้าเว็บปัจจุบัน",
        );
        return;
      }

      setLotInfo(nextLot);

      if (!nextLot) {
        showLotNotFoundAlert(
          "ไม่พบ Lot นี้ในฐานข้อมูล กรุณาตรวจสอบเลข Lot แล้วลองใหม่อีกครั้ง",
        );
        return;
      }

      writeActivityLog({
        user,
        type: "ACTIVITY",
        level: "INFO",
        page: "Move Lot",
        action: "LOOKUP_LOT",
        lot: cleanLot,
        result: "FOUND",
        message: `Lookup lot ${cleanLot} for move lot`,
        meta: {
          line: LINE_CODE,
          resultCount: data.total || 0,
          lot: data.lot || null,
        },
      });
    } catch (err) {
      console.error("Lookup lot error:", err);

      const message =
        err?.message ||
        "ไม่พบ Lot นี้ในฐานข้อมูล กรุณาตรวจสอบเลข Lot แล้วลองใหม่อีกครั้ง";

      showLotNotFoundAlert(message);

      writeActivityLog({
        user,
        type: "ACTIVITY",
        level: "WARN",
        page: "Move Lot",
        action: "LOOKUP_LOT",
        lot: cleanLot,
        result: "NOT_FOUND",
        message: message || `Lookup lot ${cleanLot} not found`,
        meta: {
          line: LINE_CODE,
        },
      });
    } finally {
      setLookupLoading(false);
    }
  };

  const showLotNotFoundAlert = (
    message = "ไม่พบ Lot นี้ในฐานข้อมูล กรุณาตรวจสอบเลข Lot แล้วลองใหม่อีกครั้ง",
  ) => {
    setAlertMessage(message);
  };

  const showMoveLotAlert = (message) => {
    setAlertMessage(message);
  };

  const displayedRows = useMemo(() => {
    return (rows || []).filter((row) => {
      const sourceMachine = getMoveSourceMachine(row);
      const targetMachine = getMoveTargetMachine(row);
      const reason = getMoveReason(row);

      if (selectedSourceMachine && sourceMachine !== selectedSourceMachine) {
        return false;
      }

      if (selectedTargetMachine && targetMachine !== selectedTargetMachine) {
        return false;
      }

      if (selectedMoveReason && reason !== selectedMoveReason) {
        return false;
      }

      return true;
    });
  }, [rows, selectedSourceMachine, selectedTargetMachine, selectedMoveReason]);

  const submitMoveLotRecord = async (data) => {
    if (!data) return;

    setSaving(true);
    setMessage("");
    setError("");
    setAlertMessage("");

    try {
      await createMoveLot({
        lotId: data.lotId,
        partName: data.partName,
        fromMachine: data.fromMachine,
        toMachine: data.toMachine,
        reason: data.reason,
        etc: data.etc,
        emp: employeeId,
        name: employeeName,
        line: LINE_CODE,
      });

      writeActivityLog({
        user,
        type: "ACTIVITY",
        level: "INFO",
        page: "Move Lot",
        action: "CREATE_MOVE_LOT",
        lot: data.lotId,
        machine: data.fromMachine,
        result: "SUCCESS",
        message: `Move lot ${data.lotId} from ${data.fromMachine} to ${data.toMachine}`,
        meta: {
          line: LINE_CODE,
          partName: data.partName,
          fromMachine: data.fromMachine,
          toMachine: data.toMachine,
          reason: data.reason,
          etc: data.etc,
        },
      });

      const successText = `บันทึกข้อมูล Move Lot สำเร็จ\nLot No: ${data.lotId}\nจากเครื่อง: ${formatDisplayMachineName(data.fromMachine)}\nไปเครื่อง: ${formatDisplayMachineName(data.toMachine)}`;
      setMessage("บันทึกข้อมูลการย้าย Lot เรียบร้อยแล้ว");
      setSuccessMessage(successText);
      resetForm();

      clearMachinesCache();
      window.dispatchEvent(new Event("wip-demo-queue-updated"));

      try {
        if (SHOW_CURRENT_LOTS) {
          await Promise.all([
            loadRows(),
            loadRunningLots({
              force: true,
            }),
          ]);
        } else {
          await loadRows();
        }
      } catch (refreshError) {
        console.error("Refresh move lot data after save error:", refreshError);
      }
    } catch (err) {
      console.error("Create move lot error:", err);

      const message = err?.message || "บันทึกข้อมูลการย้าย Lot ไม่สำเร็จ";

      if (
        err?.code === "LOT_NOT_FOUND" ||
        err?.status === 404 ||
        message.includes("ไม่พบ Lot")
      ) {
        showLotNotFoundAlert(message);
        return;
      }

      showMoveLotAlert(message);
    } finally {
      setSaving(false);
    }
  };

  const handleConfirmSaveMoveLot = async () => {
    const data = confirmSaveData;
    if (!data) return;

    setConfirmSaveData(null);
    await submitMoveLotRecord(data);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    const cleanLot = lotId.trim().toUpperCase();
    const searchedLot = String(lotInfo?.lotId || "")
      .trim()
      .toUpperCase();

    setMessage("");
    setError("");
    setAlertMessage("");

    if (!employeeId || !employeeName) {
      showMoveLotAlert("ไม่พบข้อมูล Demo User กรุณา Login ใหม่");
      return;
    }

    if (!cleanLot) {
      showMoveLotAlert("กรุณากรอก LOT NO");
      return;
    }

    if (!lotInfo || searchedLot !== cleanLot) {
      showMoveLotAlert("กรุณากด Search เพื่อตรวจสอบ Lot No ก่อนบันทึกข้อมูล");
      return;
    }

    if (!lotInfo.fromMachine) {
      showMoveLotAlert(
        "ไม่พบเครื่องต้นทางของ Lot นี้ กรุณาตรวจสอบข้อมูลอีกครั้ง",
      );
      return;
    }

    if (!toMachine) {
      showMoveLotAlert("กรุณาเลือกเครื่องปลายทาง");
      return;
    }

    if (lotInfo.fromMachine === toMachine) {
      showMoveLotAlert("เครื่องต้นทางและเครื่องปลายทางต้องไม่เหมือนกัน");
      return;
    }

    if (!reason) {
      showMoveLotAlert("กรุณาเลือกเหตุผลการย้าย");
      return;
    }

    if (reason === "อื่นๆ" && !otherReason.trim()) {
      showMoveLotAlert("กรุณากรอกเหตุผลอื่นๆ");
      return;
    }

    if (!finalReason) {
      showMoveLotAlert("กรุณาเลือกหรือกรอกเหตุผลการย้าย");
      return;
    }

    setConfirmSaveData({
      lotId: cleanLot,
      partName: lotInfo.partName,
      fromMachine: lotInfo.fromMachine,
      toMachine,
      reason: finalReason,
      etc,
    });
  };

  const exportCsv = () => {
    const headers = [
      "No",
      "lotId",
      "PartName",
      "FromMachine",
      "ToMachine",
      "Reason",
      "Etc",
      "Emp",
      "Name",
      "DateTime",
      "Line",
    ];

    const escapeCsv = (value) => {
      const text = String(value ?? "");
      return `"${text.replaceAll('"', '""')}"`;
    };

    const csvRows = displayedRows.map((row, index) =>
      [
        index + 1,
        row.lotId,
        row.partName,
        row.fromMachine,
        row.toMachine,
        row.reason,
        row.etc,
        row.emp,
        row.name,
        row.dateTime,
        row.line,
      ]
        .map(escapeCsv)
        .join(","),
    );

    const csv = [headers.join(","), ...csvRows].join("\n");

    const blob = new Blob(["\uFEFF" + csv], {
      type: "text/csv;charset=utf-8;",
    });

    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");

    a.href = url;
    a.download = `move-lot-${LINE_CODE}-${getTodayInputDate()}.csv`;
    a.click();

    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6 pt-6">
      <section className="rounded-[2rem] border border-slate-300 bg-white p-6 shadow-md dark:border-slate-700 dark:bg-slate-900 dark:shadow-black/30">
        <div className="relative overflow-hidden rounded-[1.75rem] bg-gradient-to-br from-cyan-50 via-white to-slate-100 p-5 dark:from-slate-900 dark:via-slate-950 dark:to-cyan-950/30">
          <div className="absolute right-[-70px] top-[-70px] h-48 w-48 rounded-full bg-cyan-400/20 blur-3xl" />
          <div className="relative flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
            <div className="flex items-start gap-4">
              <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-cyan-600 text-white shadow-lg shadow-cyan-600/20">
                <ArrowRightLeft size={28} strokeWidth={2.2} />
              </div>
              <div>
                <p className="text-xs font-black uppercase tracking-[0.22em] text-cyan-700 dark:text-cyan-300">
                  Move Lot
                </p>
                <h1 className="mt-1 text-2xl font-black tracking-tight text-slate-950 sm:text-3xl dark:text-white">
                  ย้าย Lot งาน
                </h1>
                <p className="mt-2 text-base font-medium text-slate-600 dark:text-slate-300">
                  บันทึกคำสั่งย้าย Lot จากเครื่องเดิมไปเครื่องปลายทาง สำหรับ
                  Line {LINE_CODE}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              <button type="button" onClick={() => setShowMoveCriteria(true)} className="inline-flex h-11 items-center justify-center rounded-xl border border-amber-200 bg-amber-50 px-4 text-sm font-black text-amber-800 hover:bg-amber-100">ขั้นตอนการโยกย้ายงาน</button>
              <DemoGuideButton kind="moveLot" />
            </div>
          </div>
        </div>

        {SHOW_CURRENT_LOTS ? (
          <div className="mt-6 rounded-[1.75rem] border border-cyan-200 bg-cyan-50/80 p-5 shadow-sm dark:border-cyan-900/60 dark:bg-cyan-950/20">
            <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
              <div>
                <h3 className="inline-flex items-center gap-2 text-2xl font-black text-slate-950 dark:text-white">
                  <Factory
                    size={23}
                    className="text-cyan-600 dark:text-cyan-300"
                  />
                  Current Machine Lots
                </h3>
                <p className="mt-1 text-sm font-bold text-cyan-700 dark:text-cyan-300">
                  แสดงเครื่องปัจจุบันทั้งหมด สามารถกดเลือก Lot
                  เพื่อนำไปย้ายเครื่องได้
                </p>
              </div>

              <button
                type="button"
                onClick={() =>
                  loadRunningLots({
                    force: true,
                  })
                }
                disabled={loadingRunningLots}
                className="inline-flex h-12 items-center justify-center gap-2 rounded-2xl bg-cyan-600 px-5 font-black text-white shadow-sm transition hover:bg-cyan-700 disabled:opacity-50"
              >
                <RefreshCw
                  size={18}
                  className={loadingRunningLots ? "animate-spin" : ""}
                />
                {loadingRunningLots ? "Loading..." : "Refresh Machines"}
              </button>
            </div>

            <div className="mt-5 grid gap-4 md:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-3">
              {runningLots.length === 0 ? (
                <div className="rounded-2xl border border-slate-200 bg-white p-5 text-center font-bold text-slate-500 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-400 md:col-span-2 xl:col-span-3 2xl:col-span-4">
                  {loadingRunningLots
                    ? "กำลังโหลดข้อมูล..."
                    : "ไม่พบข้อมูลเครื่องปัจจุบัน"}
                </div>
              ) : (
                runningLots.map((item) => {
                  const statusStripClass =
                    item.status === "RUN"
                      ? "bg-emerald-500"
                      : item.status === "STOP"
                        ? "bg-rose-500"
                        : "bg-amber-500";

                  const statusBadgeClass =
                    item.status === "RUN"
                      ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300"
                      : item.status === "STOP"
                        ? "bg-rose-100 text-rose-700 dark:bg-rose-950/40 dark:text-rose-300"
                        : "bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300";

                  return (
                    <button
                      key={`${item.machine}-${item.lotId}`}
                      type="button"
                      onClick={() => handleUseRunningLot(item)}
                      disabled={lookupLoading}
                      className="group relative min-h-[96px] overflow-hidden rounded-3xl border border-slate-300 bg-white p-5 pl-7 text-left shadow-sm transition hover:-translate-y-0.5 hover:border-cyan-300 hover:shadow-lg dark:border-slate-700 dark:bg-slate-900 dark:hover:border-cyan-700"
                    >
                      <span
                        className={`absolute left-0 top-0 h-full w-2 ${statusStripClass}`}
                      />

                      <div className="flex items-start justify-between gap-3">
                        <div className="min-w-0">
                          <p className="text-xs font-black uppercase tracking-[0.22em] text-slate-500 dark:text-slate-400">
                            {formatDisplayMachineName(item.machine)}
                          </p>

                          <p className="mt-2 truncate text-2xl font-black text-slate-950 dark:text-white">
                            {item.lotId}
                          </p>
                        </div>

                        <span
                          className={`shrink-0 rounded-full px-3 py-1 text-xs font-black ${statusBadgeClass}`}
                        >
                          {item.status}
                        </span>
                      </div>
                    </button>
                  );
                })
              )}
            </div>
          </div>
        ) : null}
      </section>

      <DemoMachineQueuePanel />

      <section
        ref={formSectionRef}
        className="scroll-mt-24 rounded-[2rem] border border-slate-300 bg-white p-6 shadow-md dark:border-slate-700 dark:bg-slate-900 dark:shadow-black/30"
      >
        <div className="mb-5 flex flex-col gap-3 border-b border-slate-200 pb-4 sm:flex-row sm:items-center sm:justify-between dark:border-slate-800">
          <div className="flex items-center gap-3">
            <span className="flex h-11 w-11 items-center justify-center rounded-xl bg-cyan-100 text-cyan-700 dark:bg-cyan-950/50 dark:text-cyan-300">
              <ClipboardPenLine size={22} />
            </span>
            <div>
              <h2 className="text-xl font-black text-slate-950 dark:text-white">
                Move Lot Form
              </h2>
              <p className="text-sm font-semibold text-slate-500 dark:text-slate-400">
                ตรวจสอบ Lot และเลือกเครื่องปลายทางก่อนบันทึก
              </p>
            </div>
          </div>

          <button
            type="button"
            hidden
            style={{ display: "none" }}
            onClick={() => setShowMoveGuide(true)}
            className="inline-flex h-11 items-center justify-center gap-2 self-start rounded-xl border border-cyan-200 bg-cyan-50 px-4 text-sm font-black text-cyan-700 transition hover:border-cyan-300 hover:bg-cyan-100 sm:self-auto dark:border-cyan-900/70 dark:bg-cyan-950/30 dark:text-cyan-300 dark:hover:bg-cyan-950/50"
            title="ดูขั้นตอนการโยกย้ายงาน"
            aria-label="ดูขั้นตอนการโยกย้ายงาน"
          >
            <Info size={19} />
            วิธีการย้ายงาน
          </button>
        </div>

        <form onSubmit={handleSubmit} className="grid gap-5 xl:grid-cols-2">
          <div>
            <label className="text-base font-black text-slate-800 dark:text-slate-100">
              Demo User ID
            </label>
            <input
              value={employeeId || "-"}
              readOnly
              className="mt-2 h-14 w-full rounded-2xl border border-slate-300 bg-slate-100 px-4 text-lg font-bold text-slate-700 outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
            />
          </div>

          <div>
            <label className="text-base font-black text-slate-800 dark:text-slate-100">
              ชื่อ-นามสกุล
            </label>
            <input
              value={employeeName || "-"}
              readOnly
              className="mt-2 h-14 w-full rounded-2xl border border-slate-300 bg-slate-100 px-4 text-lg font-bold text-slate-700 outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
            />
          </div>

          <div className="xl:col-span-2">
            <label className="text-base font-black text-slate-800 dark:text-slate-100">
              LOT NO
            </label>

            <div className="mt-2 flex flex-col gap-3 md:flex-row">
              <input
                value={lotId}
                onChange={(event) => {
                  setLotno(event.target.value.toUpperCase());
                  setLotInfo(null);
                  setMessage("");
                  setError("");
                }}
                onKeyDown={(event) => {
                  if (event.key === "Enter") {
                    event.preventDefault();
                    handleLookup();
                  }
                }}
                placeholder="กรอก Lot No แล้วกด Search..."
                className="h-14 flex-1 rounded-2xl border border-slate-300 bg-slate-50 px-4 text-lg font-black uppercase text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:focus:border-cyan-400"
              />

              <button
                type="button"
                onClick={handleLookup}
                disabled={lookupLoading}
                className="inline-flex h-14 items-center justify-center gap-2 rounded-2xl bg-cyan-600 px-8 text-lg font-black text-white shadow-sm transition hover:bg-cyan-700 disabled:opacity-50"
              >
                <Search size={19} />
                {lookupLoading ? "Searching..." : "Search"}
              </button>
            </div>
          </div>

          {lotInfo ? (
            <div className="xl:col-span-2 rounded-3xl border border-cyan-200 bg-cyan-50/70 p-5 dark:border-cyan-900/60 dark:bg-cyan-950/20">
              <h3 className="text-lg font-black text-cyan-800 dark:text-cyan-200">
                Lot Information
              </h3>

              <div className="mt-4 grid gap-4 md:grid-cols-5">
                <div>
                  <p className="text-xs font-black uppercase tracking-[0.18em] text-cyan-700 dark:text-cyan-300">
                    Lot No
                  </p>
                  <p className="mt-1 text-xl font-black text-slate-900 dark:text-white">
                    {lotInfo.lotId || "-"}
                  </p>
                </div>

                <div>
                  <p className="text-xs font-black uppercase tracking-[0.18em] text-cyan-700 dark:text-cyan-300">
                    Queue Machine ปัจจุบัน
                  </p>

                  <p className="mt-1 text-xl font-black text-slate-900 dark:text-white">
                    {formatDisplayMachineName(
                      lotInfo.currentMachine || lotInfo.fromMachine || "-",
                    )}
                  </p>

                  {lotInfo.isMoved ? (
                    <div className="mt-3 rounded-2xl border border-amber-200 bg-amber-50 p-3 dark:border-amber-900/60 dark:bg-amber-950/30">
                      <p className="text-xs font-black uppercase tracking-[0.18em] text-amber-700 dark:text-amber-300">
                        Original Machine
                      </p>

                      <p className="mt-1 text-lg font-black text-amber-700 dark:text-amber-300">
                        {formatDisplayMachineName(
                          lotInfo.originalMachine || "-",
                        )}
                      </p>

                      <p className="mt-1 text-xs font-bold text-amber-600 dark:text-amber-400">
                        LOT นี้อยู่ในสถานะย้ายงาน
                      </p>
                    </div>
                  ) : null}
                </div>

                <div>
                  <p className="text-xs font-black uppercase tracking-[0.18em] text-cyan-700 dark:text-cyan-300">
                    Machine Line
                  </p>
                  <p className="mt-1 text-xl font-black text-slate-900 dark:text-white">
                    {formatDisplayMachineName(
                      lotInfo.machineLine || lotInfo.wipMachine || "-",
                    )}
                  </p>
                </div>

                <div>
                  <p className="text-xs font-black uppercase tracking-[0.18em] text-cyan-700 dark:text-cyan-300">
                    Status
                  </p>
                  <p className="mt-1 text-xl font-black text-slate-900 dark:text-white">
                    {lotInfo.statusProcess || lotInfo.mcStatus || "-"}
                  </p>
                </div>

                <div>
                  <p className="text-xs font-black uppercase tracking-[0.18em] text-cyan-700 dark:text-cyan-300">
                    Stop Code
                  </p>
                  <p
                    className={`mt-1 text-xl font-black ${
                      lotInfo.lossCode && lotInfo.lossCode !== "-"
                        ? "text-rose-600 dark:text-rose-300"
                        : "text-slate-900 dark:text-white"
                    }`}
                  >
                    {lotInfo.lossCode || "-"}
                  </p>
                </div>

                <div className="md:col-span-5">
                  <p className="text-xs font-black uppercase tracking-[0.18em] text-cyan-700 dark:text-cyan-300">
                    Part Name
                  </p>
                  <p className="mt-1 text-lg font-bold text-slate-700 dark:text-slate-200">
                    {lotInfo.partName || "-"}
                  </p>
                </div>
              </div>
            </div>
          ) : null}

          <div className="xl:col-span-2 grid gap-5 lg:grid-cols-2">
            <div>
              <label className="text-base font-black text-slate-800 dark:text-slate-100">
                เครื่องปลายทาง
              </label>

              <select
                ref={toMachineSelectRef}
                value={toMachine}
                onChange={(event) => setToMachine(event.target.value)}
                className="mt-2 h-14 w-full rounded-2xl border border-slate-300 bg-slate-50 px-4 text-lg font-bold text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:focus:border-cyan-400"
              >
                <option value="">เลือกเครื่องปลายทาง</option>

                {machineOptions.map((machine) => {
                  const isEffectiveMachine = lotInfo?.fromMachine === machine;

                  const isOriginalMachine =
                    lotInfo?.isMoved && lotInfo?.originalMachine === machine;

                  return (
                    <option
                      key={machine}
                      value={machine}
                      disabled={isEffectiveMachine}
                    >
                      {formatDisplayMachineName(machine)}

                      {isEffectiveMachine ? " (ตำแหน่งปัจจุบัน)" : ""}

                      {isOriginalMachine ? " (กลับเครื่องเดิม)" : ""}
                    </option>
                  );
                })}
              </select>
              {lotInfo?.isMoved && lotInfo?.originalMachine ? (
                <button
                  type="button"
                  onClick={() => {
                    setToMachine(lotInfo.originalMachine);

                    setReason("ย้ายกลับเครื่องเดิม");
                  }}
                  className="mt-3 inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-amber-300 bg-amber-50 px-4 text-sm font-black text-amber-700 transition hover:bg-amber-100 dark:border-amber-800 dark:bg-amber-950/30 dark:text-amber-300"
                >
                  <ArrowRightLeft size={17} />
                  กลับไป {formatDisplayMachineName(lotInfo.originalMachine)}
                </button>
              ) : null}
            </div>

            <div>
              <label className="text-base font-black text-slate-800 dark:text-slate-100">
                เหตุผลการย้าย
              </label>

              <ReasonDropdown
                value={reason}
                options={reasonOptions}
                placeholder="กรุณาเลือกเหตุผล"
                onChange={(nextReason) => {
                  setReason(nextReason);

                  if (nextReason !== "อื่นๆ") {
                    setOtherReason("");
                  }
                }}
              />
            </div>
          </div>

          {reason === "อื่นๆ" ? (
            <div className="xl:col-span-2">
              <label className="text-base font-black text-slate-800 dark:text-slate-100">
                กรอกเหตุผลอื่นๆ
              </label>
              <textarea
                value={otherReason}
                onChange={(event) => setOtherReason(event.target.value)}
                rows={3}
                placeholder="ระบุเหตุผลเพิ่มเติม..."
                className="mt-2 w-full rounded-2xl border border-slate-300 bg-slate-50 px-4 py-3 text-lg font-bold text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:focus:border-cyan-400"
              />
            </div>
          ) : null}

          <div className="xl:col-span-2">
            <label className="text-base font-black text-slate-800 dark:text-slate-100">
              หมายเหตุเพิ่มเติม
            </label>
            <textarea
              value={etc}
              onChange={(event) => setEtc(event.target.value)}
              rows={3}
              placeholder="ระบุรายละเอียดเพิ่มเติม..."
              className="mt-2 w-full rounded-2xl border border-slate-300 bg-slate-50 px-4 py-3 text-lg font-bold text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:focus:border-cyan-400"
            />
          </div>

          <div className="xl:col-span-2 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-center">
            <button
              type="submit"
              disabled={saving}
              className="inline-flex h-14 items-center justify-center gap-2 rounded-2xl bg-emerald-600 px-8 text-lg font-black text-white shadow-sm transition hover:bg-emerald-700 disabled:opacity-50"
            >
              <Save size={20} />
              {saving ? "Saving..." : "Save"}
            </button>

            <button
              type="button"
              onClick={resetForm}
              disabled={saving}
              className="inline-flex h-14 items-center justify-center gap-2 rounded-2xl bg-slate-600 px-8 text-lg font-black text-white shadow-sm transition hover:bg-slate-700 disabled:opacity-50"
            >
              <Eraser size={20} />
              Clear
            </button>
          </div>
        </form>

        {message ? (
          <div className="mt-5 flex items-start gap-3 rounded-2xl bg-emerald-50 p-4 font-bold text-emerald-700 ring-1 ring-emerald-200 dark:bg-emerald-950/30 dark:text-emerald-300 dark:ring-emerald-900/60">
            <CheckCircle2 size={19} className="mt-0.5 shrink-0" />
            <span>{message}</span>
          </div>
        ) : null}

        {error ? (
          <div className="mt-5 flex items-start gap-3 rounded-2xl bg-rose-50 p-4 font-bold text-rose-700 ring-1 ring-rose-200 dark:bg-rose-950/30 dark:text-rose-300 dark:ring-rose-900/60">
            <AlertTriangle size={19} className="mt-0.5 shrink-0" />
            <span>{error}</span>
          </div>
        ) : null}
      </section>

      <section className="overflow-hidden rounded-[2rem] border border-slate-300 bg-white shadow-md dark:border-slate-700 dark:bg-slate-900 dark:shadow-black/30">
        <div className="bg-gradient-to-r from-cyan-950 via-slate-950 to-indigo-950 px-6 py-5 text-white">
          <div className="flex items-center justify-center gap-3 text-center">
            <History size={26} className="text-cyan-300" />
            <div>
              <h3 className="text-2xl font-black">ประวัติการย้าย Lot</h3>
              <p className="mt-1 text-sm font-bold text-cyan-100 dark:text-slate-300">
                จำนวนทั้งหมด {rows.length} รายการ / แหล่งข้อมูล: {historyLine}
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-4 border-b border-slate-200 p-6 dark:border-slate-800">
          <DateModeFilter
            dateMode={dateMode}
            onDateModeChange={handleDateModeChange}
            dateFrom={filterDateFrom}
            onDateFromChange={handleFilterDateFromChange}
            dateTo={filterDateTo}
            onDateToChange={handleFilterDateToChange}
            helperText={dateRangeText}
            rightContent={
              <div>
                <label className="mb-1 block text-xs font-black uppercase tracking-[0.10em] text-slate-500 dark:text-slate-400">
                  เลือกเครื่องปลายทางที่ต้องการดู
                </label>

                <select
                  value={filterMachine}
                  onChange={(event) => setFilterMachine(event.target.value)}
                  className="h-12 w-full rounded-2xl border border-slate-300 bg-white px-4 font-bold text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
                >
                  <option value="">All Machines</option>
                  {machineOptions.map((machine) => (
                    <option key={machine} value={machine}>
                      {formatDisplayMachineName(machine)}
                    </option>
                  ))}
                </select>
              </div>
            }
            actions={
              <>
                <button
                  type="button"
                  onClick={() => loadRows()}
                  disabled={loadingRows}
                  className="inline-flex h-12 min-w-[140px] items-center justify-center gap-2 rounded-2xl bg-cyan-600 px-6 font-black text-white transition hover:bg-cyan-700 disabled:opacity-50"
                >
                  <Search size={17} />
                  {loadingRows ? "Loading..." : "Search"}
                </button>

                <button
                  type="button"
                  onClick={() => loadRows()}
                  disabled={loadingRows}
                  className="inline-flex h-12 min-w-[140px] items-center justify-center gap-2 rounded-2xl bg-sky-600 px-6 font-black text-white transition hover:bg-sky-700 disabled:opacity-50"
                >
                  <RefreshCw
                    size={17}
                    className={loadingRows ? "animate-spin" : ""}
                  />
                  Refresh
                </button>

                <button
                  type="button"
                  onClick={handleClearFilters}
                  className="inline-flex h-12 min-w-[150px] items-center justify-center gap-2 rounded-2xl bg-slate-600 px-6 text-sm font-black text-white transition hover:bg-slate-700"
                >
                  <Eraser size={17} />
                  Clear Filter
                </button>
              </>
            }
          />
        </div>

        <div className="grid gap-5 border-b border-slate-200 p-6 dark:border-slate-800 xl:grid-cols-2">
          {dateRangeInvalid ? (
            <div className="xl:col-span-2">
              <ChartFilterPlaceholder
                title="กรุณากรอกช่วงวันที่ให้ถูกต้อง"
                description="วันที่เริ่มต้นต้องไม่มากกว่าวันที่สิ้นสุด กรุณาเลือกช่วงวันที่ใหม่อีกครั้ง"
              />
            </div>
          ) : canShowCharts ? (
            <>
              <DonutChart
                title="สรุปเครื่องต้นทางของ Lot ที่ถูกย้าย"
                subtitle="นับจำนวนครั้งที่ Lot ถูกย้ายออกจากแต่ละเครื่อง"
                items={moveFromMachineChartItems}
                emptyText="ยังไม่มีข้อมูลเครื่องต้นทางสำหรับแสดงกราฟ"
                maxItems={8}
                headerRightText={currentDataTimeText}
                onItemMouseEnter={handleHoverMachineChart}
                onItemMouseLeave={handleLeaveChart}
                onItemClick={handleClickMachineChart}
              />

              <DonutChart
                title="สรุปเครื่องปลายทางที่รับ Lot ย้ายเข้า"
                subtitle="นับจำนวนครั้งที่ Lot ถูกย้ายเข้าแต่ละเครื่อง"
                items={moveToMachineChartItems}
                emptyText="ยังไม่มีข้อมูลเครื่องปลายทางสำหรับแสดงกราฟ"
                maxItems={8}
                headerRightText={currentDataTimeText}
                onItemMouseEnter={handleHoverTargetMachineChart}
                onItemMouseLeave={handleLeaveChart}
                onItemClick={handleClickTargetMachineChart}
              />

              <div className="xl:col-span-2">
                <HorizontalBarChart
                  title="สรุปเหตุผลการย้าย Lot"
                  subtitle="นับจำนวนครั้งของแต่ละเหตุผล ตาม filter ปัจจุบัน"
                  items={moveReasonChartItems}
                  emptyText="ยังไม่มีข้อมูลเหตุผลสำหรับแสดงกราฟ"
                  maxItems={8}
                  labelWidth="minmax(280px, 420px)"
                  wrapLabels={true}
                  showValues={true}
                  headerRightText={currentDataTimeText}
                  onItemMouseEnter={handleHoverReasonChart}
                  onItemMouseLeave={handleLeaveChart}
                  onItemClick={handleClickReasonChart}
                />
              </div>
            </>
          ) : (
            <div className="xl:col-span-2">
              <ChartFilterPlaceholder />
            </div>
          )}
        </div>

        <div className="flex flex-col gap-3 border-b border-slate-200 p-6 dark:border-slate-800 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h4 className="text-xl font-black text-slate-950 dark:text-white">
              รายการประวัติการย้าย Lot
            </h4>
            <p className="mt-1 text-sm font-bold text-slate-500 dark:text-slate-400">
              กรอกคําค้นหาแล้วกดปุ่ม Search หรือกด Enter เพื่อค้นหา
            </p>
          </div>

          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter") loadRows();
              }}
              placeholder="ค้นหา Lot / เหตุผล / รหัส / ชื่อ..."
              className="h-12 w-full rounded-2xl border border-slate-300 bg-slate-50 px-4 font-bold text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 sm:w-[360px]"
            />

            <button
              type="button"
              onClick={loadRows}
              disabled={loadingRows}
              className="inline-flex h-12 items-center justify-center gap-2 rounded-2xl bg-cyan-600 px-6 font-black text-white transition hover:bg-cyan-700 disabled:opacity-50"
            >
              <Search size={17} />
              {loadingRows ? "Loading..." : "Search"}
            </button>

            <button
              type="button"
              onClick={exportCsv}
              disabled={rows.length === 0}
              className="inline-flex h-12 items-center justify-center gap-2 rounded-2xl bg-emerald-600 px-6 font-black text-white transition hover:bg-emerald-700 disabled:opacity-50"
            >
              <Download size={17} />
              Export CSV
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-max text-left text-sm">
            <thead className="border-b border-slate-200 bg-slate-50 text-xs uppercase text-slate-500 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
              <tr>
                <th className="px-4 py-4 text-center">ลำดับ</th>
                <th className="px-4 py-4">lotId</th>
                <th className="px-4 py-4">Part Name</th>
                <th className="px-4 py-4">เครื่องเดิม</th>
                <th className="px-4 py-4">เครื่องใหม่</th>
                <th className="px-4 py-4">เหตุผล</th>
                <th className="px-4 py-4">หมายเหตุ</th>
                <th className="px-4 py-4">ชื่อ-นามสกุล</th>
                <th className="px-4 py-4">Demo User ID</th>
                <th className="px-4 py-4">วันที่เวลา</th>
              </tr>
            </thead>

            <tbody>
              {rows.length === 0 ? (
                <tr>
                  <td
                    colSpan={10}
                    className="px-4 py-12 text-center text-slate-500 dark:text-slate-400"
                  >
                    ไม่พบข้อมูล
                  </td>
                </tr>
              ) : (
                rows.map((row, index) => (
                  <tr
                    key={`${row.id || row.lotId}-${index}`}
                    className="border-b border-slate-100 transition last:border-b-0 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800/50"
                  >
                    <td className="px-4 py-3 text-center font-bold text-slate-600 dark:text-slate-300">
                      {index + 1}
                    </td>

                    <td className="px-4 py-3 font-black text-cyan-700 dark:text-cyan-300">
                      {row.lotId || "-"}
                    </td>

                    <td className="px-4 py-3 text-slate-600 dark:text-slate-300">
                      {row.partName || "-"}
                    </td>

                    <td className="px-4 py-3 font-bold text-slate-700 dark:text-slate-200">
                      {formatDisplayMachineName(row.fromMachine || "-")}
                    </td>

                    <td className="px-4 py-3 font-black text-emerald-700 dark:text-emerald-300">
                      {formatDisplayMachineName(row.toMachine || "-")}
                    </td>

                    <td className="px-4 py-3 text-slate-600 dark:text-slate-300">
                      {row.reason || "-"}
                    </td>

                    <td className="px-4 py-3 text-slate-500 dark:text-slate-400">
                      {row.etc || "-"}
                    </td>

                    <td className="px-4 py-3 text-slate-600 dark:text-slate-300">
                      {row.name || "-"}
                    </td>

                    <td className="px-4 py-3 font-bold text-slate-700 dark:text-slate-200">
                      {row.emp || "-"}
                    </td>

                    <td className="px-4 py-3 text-slate-500 dark:text-slate-400">
                      {formatDateTime(row.dateTime)}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </section>
      <CenterAlert
        open={Boolean(alertMessage)}
        title="กรุณาตรวจสอบข้อมูล"
        message={alertMessage}
        variant="danger"
        onClose={() => setAlertMessage("")}
      />

      <CenterAlert
        open={Boolean(successMessage)}
        title="บันทึกข้อมูลสำเร็จ"
        message={successMessage}
        variant="success"
        confirmText="ตกลง"
        onClose={() => setSuccessMessage("")}
      />

      <CenterAlert
        open={Boolean(confirmSaveData)}
        title="ยืนยันการบันทึก Move Lot"
        message={
          confirmSaveData
            ? `กรุณาทวนข้อมูลก่อนบันทึก\n\nLot No: ${confirmSaveData.lotId}\nจากเครื่อง: ${formatDisplayMachineName(
                confirmSaveData.fromMachine,
              )}\nไปเครื่อง: ${formatDisplayMachineName(
                confirmSaveData.toMachine,
              )}\nเหตุผล: ${confirmSaveData.reason}`
            : ""
        }
        variant="info"
        confirmText="ยืนยัน"
        cancelText="ยกเลิก"
        requireEmployeeCode
        expectedEmployeeCode={employeeId}
        onClose={() => setConfirmSaveData(null)}
        onConfirm={handleConfirmSaveMoveLot}
      />

      <CenterAlert
        open={Boolean(dateAlertMessage)}
        title="กรุณาตรวจสอบช่วงวันที่"
        message={dateAlertMessage}
        variant="warning"
        onClose={() => setDateAlertMessage("")}
      />
      {showMoveCriteria ? <div role="presentation" className="fixed inset-0 z-[230] flex items-center justify-center bg-black/90 p-4" onMouseDown={e => { if (e.target === e.currentTarget) setShowMoveCriteria(false); }}>
        <div role="dialog" aria-label="เกณฑ์การโยกย้ายงาน (ข้อมูลจำลอง)" aria-modal="true" className="relative flex h-[90dvh] w-[92dvw] items-center justify-center rounded-2xl border border-slate-500 bg-slate-950 p-3 shadow-2xl">
          <img src="/user-guides/demo/move-criteria.gif" alt="เกณฑ์การย้ายงานจำลอง 4 ขั้นตอน" className="max-h-full max-w-full rounded-lg object-contain" />
          <button type="button" onClick={() => setShowMoveCriteria(false)} className="absolute right-2 top-2 rounded-xl bg-slate-900/90 px-4 py-2 text-2xl font-black text-white" aria-label="ปิด">×</button>
        </div>
      </div> : null}
      {showMoveGuide ? (
        <div
          className="fixed inset-0 z-[140] flex items-center justify-center bg-slate-950/75 p-2 backdrop-blur-sm sm:p-4"
          role="presentation"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) {
              setShowMoveGuide(false);
            }
          }}
        >
          <div
            role="dialog"
            aria-modal="true"
            aria-label="วิธีการย้ายงาน"
            className="relative max-h-[96vh] w-full max-w-[1600px] overflow-hidden rounded-[1.5rem] bg-slate-950 shadow-2xl"
          >
            <button
              type="button"
              onClick={() => setShowMoveGuide(false)}
              className="absolute right-3 top-3 z-10 flex h-12 w-12 items-center justify-center rounded-2xl border border-white/60 bg-white/90 text-slate-700 shadow-lg backdrop-blur transition hover:bg-white hover:text-slate-950 sm:right-4 sm:top-4"
              aria-label="ปิดวิธีการย้ายงาน"
              title="ปิด"
            >
              <X size={24} />
            </button>

            <img
              src="/move-lot-guide.svg"
              alt="วิธีการย้ายงาน"
              className="block max-h-[96vh] w-full object-contain"
            />
          </div>
        </div>
      ) : null}
    </div>
  );
}
