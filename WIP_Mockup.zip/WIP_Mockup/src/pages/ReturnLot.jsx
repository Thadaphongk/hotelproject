import DemoGuideButton from "../components/DemoGuideButton";
import React, { useEffect, useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  Download,
  Eraser,
  FileWarning,
  History,
  LogIn,
  RefreshCw,
  Save,
  Search,
} from "lucide-react";
import { createReturnLot, getReturnLots } from "../services/returnLotClient";
import { writeActivityLog } from "../services/logClient";
import CenterAlert from "../components/CenterAlert";
import HorizontalBarChart from "../components/HorizontalBarChart";
import ChartFilterPlaceholder from "../components/ChartFilterPlaceholder";
import DateModeFilter from "../components/DateModeFilter";
import {
  DATE_RANGE_ERROR_MESSAGE,
  getCurrentTimeText,
  getDateModeRangeText,
  getEffectiveDateRange,
  hasDateFilterForChart,
  isInvalidDateModeRange,
} from "../utils/dateRangeText";

const LINE_CODE = "DEMO";

const reasonOptions = [
  "Urgent demo order",
  "Quality review",
  "Material unavailable",
  "Planned process check",
  "Demo routing change",
  "Waiting for verification",
  "Training scenario",
  "อื่นๆ",
];

const ReasonDropdown = ({
  value,
  onChange,
  options = [],
  placeholder = "กรุณาเลือกเหตุผล",
}) => {
  const [open, setOpen] = useState(false);
  const dropdownRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  const selectedText = value || placeholder;

  return (
    <div ref={dropdownRef} className="relative">
      <button
        type="button"
        onClick={() => setOpen((current) => !current)}
        onKeyDown={(event) => {
          if (event.key === "Escape") setOpen(false);
        }}
        className="mt-2 flex h-14 w-full items-center justify-between rounded-2xl border border-slate-300 bg-slate-50 px-4 text-left text-lg font-bold text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:focus:border-cyan-400"
      >
        <span
          className={
            value
              ? "truncate text-slate-900 dark:text-slate-100"
              : "truncate text-slate-500 dark:text-slate-400"
          }
        >
          {selectedText}
        </span>

        <span className="ml-3 text-slate-500 dark:text-slate-400">
          {open ? "▲" : "▼"}
        </span>
      </button>

      {open ? (
        <div className="absolute left-0 right-0 z-[80] mt-2 max-h-64 overflow-y-auto rounded-2xl border border-slate-300 bg-white py-2 shadow-xl ring-1 ring-black/5 dark:border-slate-700 dark:bg-slate-900">
          <button
            type="button"
            onClick={() => {
              onChange("");
              setOpen(false);
            }}
            className={`block w-full px-4 py-3 text-left text-base font-bold transition hover:bg-cyan-50 hover:text-cyan-700 dark:hover:bg-slate-800 dark:hover:text-cyan-300 ${
              !value
                ? "bg-slate-100 text-slate-900 dark:bg-slate-800 dark:text-white"
                : "text-slate-600 dark:text-slate-300"
            }`}
          >
            {placeholder}
          </button>

          {options.map((item) => {
            const active = value === item;

            return (
              <button
                key={item}
                type="button"
                onClick={() => {
                  onChange(item);
                  setOpen(false);
                }}
                className={`block w-full px-4 py-3 text-left text-base font-bold transition hover:bg-cyan-50 hover:text-cyan-700 dark:hover:bg-slate-800 dark:hover:text-cyan-300 ${
                  active
                    ? "bg-cyan-50 text-cyan-700 dark:bg-cyan-950/40 dark:text-cyan-300"
                    : "text-slate-700 dark:text-slate-300"
                }`}
              >
                {item}
              </button>
            );
          })}
        </div>
      ) : null}
    </div>
  );
};

const getEmployeeId = (user) => {
  return String(user?.id || user?.empCode || user?.employeeId || "")
    .trim()
    .toUpperCase();
};

const getEmployeeName = (user) => {
  return String(user?.name || user?.empName || user?.empName_TH || "").trim();
};

const formatDateTime = (value) => {
  if (!value) return "-";

  const date = new Date(value.replace(" ", "T"));
  if (Number.isNaN(date.getTime())) return value;

  return date.toLocaleString("en-GB", {
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
  });
};

const buildCountItems = (rows, getLabel) => {
  const countMap = new Map();

  for (const row of rows || []) {
    const rawLabel = getLabel(row);
    const label = String(rawLabel || "-").trim();

    if (!label || label === "-") continue;

    countMap.set(label, (countMap.get(label) || 0) + 1);
  }

  return Array.from(countMap.entries()).map(([label, value]) => ({
    label,
    value,
  }));
};

export default function issueReason({ user, onRequestLogin }) {
  const isLoggedIn = Boolean(user);
  const employeeId = getEmployeeId(user);
  const employeeName = getEmployeeName(user);

  const [lotId, setLotno] = useState("");
  const [reason, setReason] = useState("");
  const [otherReason, setOtherReason] = useState("");
  const [search, setSearch] = useState("");
  const [dateMode, setDateMode] = useState("single");
  const [filterDateFrom, setFilterDateFrom] = useState("");
  const [filterDateTo, setFilterDateTo] = useState("");
  const [rows, setRows] = useState([]);
  const [loadingRows, setLoadingRows] = useState(false);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");
  const [error, setError] = useState("");
  const [alertMessage, setAlertMessage] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [dateAlertMessage, setDateAlertMessage] = useState("");
  const [confirmSaveData, setConfirmSaveData] = useState(null);
  const returnReasonChartItems = useMemo(() => {
    return buildCountItems(rows, (row) => row.issueReason);
  }, [rows]);

  const [currentDataTimeText, setCurrentDataTimeText] = useState(() =>
    getCurrentTimeText(),
  );

  const canShowCharts = hasDateFilterForChart({
    dateMode,
    dateFrom: filterDateFrom,
    dateTo: filterDateTo,
  });

  const dateRangeInvalid = isInvalidDateModeRange(
    dateMode,
    filterDateFrom,
    filterDateTo,
  );

  const dateRangeText = getDateModeRangeText({
    dateMode,
    dateFrom: filterDateFrom,
    dateTo: filterDateTo,
  });

  const finalReason = useMemo(() => {
    if (reason === "อื่นๆ") return otherReason.trim();
    return reason.trim();
  }, [reason, otherReason]);

  const handleFilterDateFromChange = (value) => {
    setFilterDateFrom(value);

    if (dateMode === "single") {
      setFilterDateTo("");
      return;
    }

    if (filterDateTo && value && value > filterDateTo) {
      setFilterDateTo("");
      setDateAlertMessage(
        "วันที่เริ่มต้นมากกว่าวันที่สิ้นสุด ระบบจึงล้างวันที่สิ้นสุดให้ กรุณาเลือกใหม่อีกครั้ง",
      );
    }
  };

  const handleFilterDateToChange = (value) => {
    if (
      dateMode === "range" &&
      filterDateFrom &&
      value &&
      value < filterDateFrom
    ) {
      setDateAlertMessage(DATE_RANGE_ERROR_MESSAGE);
      return;
    }

    setFilterDateTo(value);
  };

  const handleDateModeChange = (nextMode) => {
    setDateMode(nextMode);
    setError("");
    setDateAlertMessage("");

    if (nextMode === "single") {
      setFilterDateTo("");
    }
  };

  const loadRows = async (override = {}) => {
    const nextSearch = override.search ?? search;
    const nextDateMode = override.dateMode ?? dateMode;
    const nextDateFrom = override.dateFrom ?? filterDateFrom;
    const nextDateTo = override.dateTo ?? filterDateTo;

    const effectiveDateRange = getEffectiveDateRange(
      nextDateMode,
      nextDateFrom,
      nextDateTo,
    );

    setLoadingRows(true);
    setError("");

    if (isInvalidDateModeRange(nextDateMode, nextDateFrom, nextDateTo)) {
      setRows([]);
      setError(DATE_RANGE_ERROR_MESSAGE);
      setDateAlertMessage(DATE_RANGE_ERROR_MESSAGE);
      setLoadingRows(false);
      return;
    }

    try {
      const data = await getReturnLots({
        line: LINE_CODE,
        search: nextSearch,
        dateFrom: effectiveDateRange.dateFrom,
        dateTo: effectiveDateRange.dateTo,
      });

      setRows(data.rows || []);
    } catch (err) {
      console.error("Load return lots error:", err);
      setError(err.message || "โหลดประวัติ Return Lot ไม่สำเร็จ");
    } finally {
      setLoadingRows(false);
    }
  };

  const handleClearFilters = async () => {
    setSearch("");
    setDateMode("single");
    setFilterDateFrom("");
    setFilterDateTo("");

    await loadRows({
      search: "",
      dateMode: "single",
      dateFrom: "",
      dateTo: "",
    });
  };

  useEffect(() => {
    const timer = window.setInterval(() => {
      setCurrentDataTimeText(getCurrentTimeText());
    }, 1000);

    return () => window.clearInterval(timer);
  }, []);

  useEffect(() => {
    loadRows();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [dateMode, filterDateFrom, filterDateTo]);

  const resetForm = () => {
    setLotno("");
    setReason("");
    setOtherReason("");
  };

  const showLotNotFoundAlert = (
    message = "ไม่พบ Lot นี้ในฐานข้อมูล กรุณาตรวจสอบเลข Lot แล้วลองใหม่อีกครั้ง",
  ) => {
    setAlertMessage(message);
  };

  const submitReturnLotRecord = async ({
    lotId: cleanLot,
    reason: reasonText,
  }) => {
    setSaving(true);

    try {
      await createReturnLot({
        lotId: cleanLot,
        idemp: employeeId,
        empName: employeeName,
        reason: reasonText,
        line: LINE_CODE,
      });

      writeActivityLog({
        user,
        type: "ACTIVITY",
        level: "INFO",
        page: "Return Lot",
        action: "CREATE_RETURN_LOT",
        lot: cleanLot,
        result: "SUCCESS",
        message: `Created return lot issue for ${cleanLot}`,
        meta: {
          line: LINE_CODE,
          reason: reasonText,
        },
      });

      const successText = `บันทึกข้อมูล Return Lot สำเร็จ\nLot No: ${cleanLot}`;
      setMessage("บันทึกข้อมูลเรียบร้อยแล้ว");
      setSuccessMessage(successText);
      resetForm();

      try {
        await loadRows();
      } catch (refreshError) {
        console.error("Refresh return lot rows after save error:", refreshError);
      }
    } catch (err) {
      console.error("Create return lot error:", err);

      const message = err?.message || "บันทึกข้อมูลไม่สำเร็จ";

      if (
        err?.code === "LOT_NOT_FOUND" ||
        err?.status === 404 ||
        message.includes("ไม่พบ Lot")
      ) {
        showLotNotFoundAlert(message);
        return;
      }

      setAlertMessage(message);
    } finally {
      setSaving(false);
    }
  };

  const handleConfirmSaveReturnLot = async () => {
    const data = confirmSaveData;
    if (!data) return;

    setConfirmSaveData(null);
    await submitReturnLotRecord(data);
  };

  const handleSubmit = async (event) => {
    event.preventDefault();

    const cleanLot = lotId.trim().toUpperCase();

    setMessage("");
    setError("");
    setAlertMessage("");

    if (!isLoggedIn) {
      onRequestLogin?.();
      return;
    }
    if (!employeeId || !employeeName) {
      setAlertMessage("ไม่พบข้อมูล Demo User กรุณา Login ใหม่");
      return;
    }

    if (!cleanLot) {
      setAlertMessage("กรุณากรอก LOT NO");
      return;
    }

    if (!finalReason) {
      setAlertMessage("กรุณาเลือกหรือกรอกเหตุผล");
      return;
    }

    setConfirmSaveData({
      lotId: cleanLot,
      reason: finalReason,
    });
  };

  const exportCsv = () => {
    const headers = [
      "No",
      "lotId",
      "issueReason",
      "reportedByName",
      "reportedBy",
      "createdAt",
      "Line",
    ];

    const escapeCsv = (value) => {
      const text = String(value ?? "");
      return `"${text.replaceAll('"', '""')}"`;
    };

    const csvRows = rows.map((row, index) =>
      [
        index + 1,
        row.lotId,
        row.issueReason,
        row.reportedByName,
        row.reportedBy,
        row.createdAt,
        row.lineName,
      ]
        .map(escapeCsv)
        .join(","),
    );

    const csv = [headers.join(","), ...csvRows].join("\n");

    const blob = new Blob(["\uFEFF" + csv], {
      type: "text/csv;charset=utf-8;",
    });

    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");

    a.href = url;
    a.download = `return-lot-${LINE_CODE}.csv`;
    a.click();

    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-6 pt-6">
      <div className="flex justify-end"><DemoGuideButton kind="returnLot" /></div>
      <section className="relative overflow-hidden rounded-[2rem] border border-slate-300 bg-gradient-to-br from-cyan-50 via-white to-slate-100 p-6 shadow-lg dark:border-slate-700 dark:from-slate-900 dark:via-slate-950 dark:to-cyan-950/30">
        <div className="absolute right-[-80px] top-[-80px] h-56 w-56 rounded-full bg-cyan-400/20 blur-3xl" />
        <div className="relative flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
          <div className="flex items-start gap-4">
            <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-cyan-600 text-white shadow-lg shadow-cyan-600/20">
              <FileWarning size={28} strokeWidth={2.2} />
            </div>
            <div>
              <p className="text-xs font-black uppercase tracking-[0.22em] text-cyan-700 dark:text-cyan-300">
                Return Lot / Issue Report
              </p>
              <h1 className="mt-1 text-2xl font-black tracking-tight text-slate-950 sm:text-3xl dark:text-white">
                แจ้งปัญหาและการเดินงานข้าม Lot
              </h1>
              <p className="mt-2 text-base font-medium text-slate-600 dark:text-slate-300">
                บันทึก Lot ที่มีปัญหาหรือมีการเดินงานข้าม Lot
              </p>
            </div>
          </div>

          <div className="rounded-2xl bg-cyan-100 px-5 py-3 text-sm font-black text-cyan-800 dark:bg-cyan-950/60 dark:text-cyan-300">
            lineName: {LINE_CODE}
          </div>
        </div>
      </section>

      <section className="rounded-[2rem] border border-slate-300 bg-white p-6 shadow-md dark:border-slate-700 dark:bg-slate-900 dark:shadow-black/30">
        {!isLoggedIn ? (
          <div className="mb-5 flex items-start gap-3 rounded-2xl border border-amber-300 bg-amber-50 p-4 font-bold text-amber-800 dark:border-amber-900/60 dark:bg-amber-950/30 dark:text-amber-300">
            <LogIn size={19} className="mt-0.5 shrink-0" />
            <span>
              คุณกำลังใช้งานแบบ Guest สามารถดูประวัติได้
              แต่ถ้าต้องการบันทึกข้อมูล กรุณา Login ก่อน
            </span>
          </div>
        ) : null}
        <form onSubmit={handleSubmit} className="grid gap-5 xl:grid-cols-2">
          <div>
            <label className="text-base font-black text-slate-800 dark:text-slate-100">
              Demo User ID
            </label>
            <input
              value={employeeId || "กรุณา Login ก่อนบันทึกข้อมูล"}
              readOnly
              className="mt-2 h-14 w-full rounded-2xl border border-slate-300 bg-slate-100 px-4 text-lg font-bold text-slate-700 outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
            />
          </div>

          <div>
            <label className="text-base font-black text-slate-800 dark:text-slate-100">
              ชื่อ-นามสกุล
            </label>
            <input
              value={employeeName || "กรุณา Login ก่อนบันทึกข้อมูล"}
              readOnly
              className="mt-2 h-14 w-full rounded-2xl border border-slate-300 bg-slate-100 px-4 text-lg font-bold text-slate-700 outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
            />
          </div>

          <div>
            <label className="text-base font-black text-slate-800 dark:text-slate-100">
              LOT NO
            </label>
            <input
              value={lotId}
              onChange={(event) => setLotno(event.target.value.toUpperCase())}
              placeholder="กรอก Lot No..."
              className="mt-2 h-14 w-full rounded-2xl border border-slate-300 bg-slate-50 px-4 text-lg font-black uppercase text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:focus:border-cyan-400"
            />
          </div>

          <div>
            <label className="text-base font-black text-slate-800 dark:text-slate-100">
              เหตุผลการหยุด Lot / เดินงานข้าม Lot
            </label>
            <ReasonDropdown
              value={reason}
              options={reasonOptions}
              placeholder="กรุณาเลือกเหตุผล"
              onChange={(nextReason) => {
                setReason(nextReason);

                if (nextReason !== "อื่นๆ") {
                  setOtherReason("");
                }
              }}
            />
          </div>

          {reason === "อื่นๆ" ? (
            <div className="xl:col-span-2">
              <label className="text-base font-black text-slate-800 dark:text-slate-100">
                กรอกเหตุผลอื่นๆ
              </label>
              <textarea
                value={otherReason}
                onChange={(event) => setOtherReason(event.target.value)}
                rows={4}
                placeholder="ระบุรายละเอียดเพิ่มเติม..."
                className="mt-2 w-full rounded-2xl border border-slate-300 bg-slate-50 px-4 py-3 text-lg font-bold text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:focus:border-cyan-400"
              />
            </div>
          ) : null}

          <div className="xl:col-span-2 flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-center">
            <button
              type="submit"
              disabled={saving}
              className="inline-flex h-14 items-center justify-center gap-2 rounded-2xl bg-emerald-600 px-8 text-lg font-black text-white shadow-sm transition hover:bg-emerald-700 disabled:cursor-not-allowed disabled:opacity-50"
            >
              <Save size={20} />
              {!isLoggedIn ? "Login เพื่อบันทึก" : saving ? "Saving..." : "Save"}
            </button>

            <button
              type="button"
              onClick={resetForm}
              disabled={saving}
              className="inline-flex h-14 items-center justify-center gap-2 rounded-2xl bg-slate-600 px-8 text-lg font-black text-white shadow-sm transition hover:bg-slate-700 disabled:opacity-50"
            >
              <Eraser size={20} />
              Clear
            </button>
          </div>
        </form>

        {message ? (
          <div className="mt-5 flex items-start gap-3 rounded-2xl bg-emerald-50 p-4 font-bold text-emerald-700 ring-1 ring-emerald-200 dark:bg-emerald-950/30 dark:text-emerald-300 dark:ring-emerald-900/60">
            <CheckCircle2 size={19} className="mt-0.5 shrink-0" />
            <span>{message}</span>
          </div>
        ) : null}

        {error ? (
          <div className="mt-5 flex items-start gap-3 rounded-2xl bg-rose-50 p-4 font-bold text-rose-700 ring-1 ring-rose-200 dark:bg-rose-950/30 dark:text-rose-300 dark:ring-rose-900/60">
            <AlertTriangle size={19} className="mt-0.5 shrink-0" />
            <span>{error}</span>
          </div>
        ) : null}
      </section>

      <section className="overflow-hidden rounded-[2rem] border border-slate-300 bg-white shadow-md dark:border-slate-700 dark:bg-slate-900 dark:shadow-black/30">
        <div className="bg-gradient-to-r from-cyan-950 via-slate-950 to-indigo-950 px-6 py-5 text-white">
          <div className="flex items-center justify-center gap-3 text-center">
            <History size={26} className="text-cyan-300" />
            <div>
              <h3 className="text-2xl font-black">
                ประวัติการแจ้งปัญหา / เดินงานข้าม Lot
              </h3>
              <p className="mt-1 text-sm font-bold text-cyan-100 dark:text-slate-300">
                จำนวนทั้งหมด {rows.length} รายการ
              </p>
            </div>
          </div>
        </div>

        <div className="space-y-4 border-b border-slate-200 p-6 dark:border-slate-800">
          <DateModeFilter
            dateMode={dateMode}
            onDateModeChange={handleDateModeChange}
            dateFrom={filterDateFrom}
            onDateFromChange={handleFilterDateFromChange}
            dateTo={filterDateTo}
            onDateToChange={handleFilterDateToChange}
            helperText={dateRangeText}
            actions={
              <>
                <button
                  type="button"
                  onClick={() => loadRows()}
                  disabled={loadingRows}
                  className="inline-flex h-12 min-w-[140px] items-center justify-center gap-2 rounded-2xl bg-cyan-600 px-6 font-black text-white transition hover:bg-cyan-700 disabled:opacity-50"
                >
                  <Search size={17} />
                  {loadingRows ? "Loading..." : "Search"}
                </button>

                <button
                  type="button"
                  onClick={() => loadRows()}
                  disabled={loadingRows}
                  className="inline-flex h-12 min-w-[140px] items-center justify-center gap-2 rounded-2xl bg-sky-600 px-6 font-black text-white transition hover:bg-sky-700 disabled:opacity-50"
                >
                  <RefreshCw
                    size={17}
                    className={loadingRows ? "animate-spin" : ""}
                  />
                  Refresh
                </button>

                <button
                  type="button"
                  onClick={handleClearFilters}
                  className="inline-flex h-12 min-w-[150px] items-center justify-center gap-2 rounded-2xl bg-slate-600 px-6 text-sm font-black text-white transition hover:bg-slate-700"
                >
                  <Eraser size={17} />
                  Clear Filter
                </button>
              </>
            }
          />
        </div>

        <div className="border-b border-slate-200 p-6 dark:border-slate-800">
          {dateRangeInvalid ? (
            <ChartFilterPlaceholder
              title="กรุณากรอกช่วงวันที่ให้ถูกต้อง"
              description="วันที่เริ่มต้นต้องไม่มากกว่าวันที่สิ้นสุด กรุณาเลือกช่วงวันที่ใหม่อีกครั้ง"
            />
          ) : canShowCharts ? (
            <HorizontalBarChart
              title="สรุปเหตุผลการแจ้งปัญหา / เดินงานข้าม Lot"
              subtitle="นับจากข้อมูลประวัติที่กำลังแสดงอยู่ตาม filter ปัจจุบัน"
              items={returnReasonChartItems}
              emptyText="ยังไม่มีข้อมูลเหตุผลสำหรับแสดงกราฟ"
              maxItems={8}
              labelWidth="minmax(260px, 360px)"
              wrapLabels={true}
              showValues={true}
              headerRightText={currentDataTimeText}
            />
          ) : (
            <ChartFilterPlaceholder />
          )}
        </div>
        <div className="flex flex-col gap-3 border-b border-slate-200 p-6 dark:border-slate-800 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h4 className="text-xl font-black text-slate-950 dark:text-white">
              รายการประวัติแจ้งปัญหา / เดินงานข้าม Lot
            </h4>
            <p className="mt-1 text-sm font-bold text-slate-500 dark:text-slate-400">
              กรอกคําค้นหาแล้วกดปุ่ม Search หรือกด Enter เพื่อค้นหา
            </p>
          </div>

          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <input
              value={search}
              onChange={(event) => setSearch(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter") loadRows();
              }}
              placeholder="ค้นหา Lot / เหตุผล / รหัส / ชื่อ..."
              className="h-12 w-full rounded-2xl border border-slate-300 bg-slate-50 px-4 font-bold text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 sm:w-[360px]"
            />

            <button
              type="button"
              onClick={loadRows}
              disabled={loadingRows}
              className="inline-flex h-12 items-center justify-center gap-2 rounded-2xl bg-cyan-600 px-6 font-black text-white transition hover:bg-cyan-700 disabled:opacity-50"
            >
              <Search size={17} />
              {loadingRows ? "Loading..." : "Search"}
            </button>

            <button
              type="button"
              onClick={exportCsv}
              disabled={rows.length === 0}
              className="inline-flex h-12 items-center justify-center gap-2 rounded-2xl bg-emerald-600 px-6 font-black text-white transition hover:bg-emerald-700 disabled:opacity-50"
            >
              <Download size={17} />
              Export CSV
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full min-w-max text-left text-sm">
            <thead className="border-b border-slate-200 bg-slate-50 text-xs uppercase text-slate-500 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
              <tr>
                <th className="px-4 py-4 text-center">ลำดับ</th>
                <th className="px-4 py-4">lotId</th>
                <th className="px-4 py-4">เหตุผล</th>
                <th className="px-4 py-4">ชื่อ-นามสกุล</th>
                <th className="px-4 py-4">Demo User ID</th>
                <th className="px-4 py-4">วันที่เวลา</th>
                <th className="px-4 py-4">Line</th>
              </tr>
            </thead>

            <tbody>
              {rows.length === 0 ? (
                <tr>
                  <td
                    colSpan={7}
                    className="px-4 py-12 text-center text-slate-500 dark:text-slate-400"
                  >
                    ไม่พบข้อมูล
                  </td>
                </tr>
              ) : (
                rows.map((row, index) => (
                  <tr
                    key={`${row.lotId}-${row.createdAt}-${index}`}
                    className="border-b border-slate-100 transition last:border-b-0 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800/50"
                  >
                    <td className="px-4 py-3 text-center font-bold text-slate-600 dark:text-slate-300">
                      {index + 1}
                    </td>

                    <td className="px-4 py-3 font-black text-cyan-700 dark:text-cyan-300">
                      {row.lotId || "-"}
                    </td>

                    <td className="px-4 py-3 text-slate-600 dark:text-slate-300">
                      {row.issueReason || "-"}
                    </td>

                    <td className="px-4 py-3 text-slate-600 dark:text-slate-300">
                      {row.reportedByName || "-"}
                    </td>

                    <td className="px-4 py-3 font-bold text-slate-700 dark:text-slate-200">
                      {row.reportedBy || "-"}
                    </td>

                    <td className="px-4 py-3 text-slate-500 dark:text-slate-400">
                      {formatDateTime(row.createdAt)}
                    </td>

                    <td className="px-4 py-3 font-bold text-slate-600 dark:text-slate-300">
                      {row.lineName || "-"}
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </section>
      <CenterAlert
        open={Boolean(alertMessage)}
        title="ไม่สามารถบันทึกข้อมูลได้"
        message={alertMessage}
        onClose={() => setAlertMessage("")}
      />
      <CenterAlert
        open={Boolean(successMessage)}
        title="บันทึกข้อมูลสำเร็จ"
        message={successMessage}
        variant="success"
        confirmText="ตกลง"
        onClose={() => setSuccessMessage("")}
      />
      <CenterAlert
        open={Boolean(confirmSaveData)}
        title="ยืนยันการบันทึกข้อมูล"
        message={
          confirmSaveData
            ? `ต้องการบันทึกข้อมูล Lot: ${confirmSaveData.lotId} ใช่หรือไม่?\nเหตุผล: ${confirmSaveData.reason}`
            : ""
        }
        variant="info"
        confirmText="ยืนยัน"
        cancelText="ยกเลิก"
        requireEmployeeCode
        expectedEmployeeCode={employeeId}
        onClose={() => setConfirmSaveData(null)}
        onConfirm={handleConfirmSaveReturnLot}
      />
      <CenterAlert
        open={Boolean(dateAlertMessage)}
        title="กรุณาตรวจสอบช่วงวันที่"
        message={dateAlertMessage}
        onClose={() => setDateAlertMessage("")}
      />
    </div>
  );
}
