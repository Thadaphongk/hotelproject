import { useEffect, useMemo, useRef, useState } from "react";
import {
  AlertTriangle,
  ChevronDown,
  ChevronRight,
  Columns3,
  Factory,
  ListOrdered,
  RefreshCw,
  RotateCcw,
  Search,
  Table2,
  Wrench,
} from "lucide-react";
import { getMachines } from "../services/api";
import {
  formatDisplayMachineName,
  formatMachineName,
  getSetupInfo,
  getStatusInfo,
  isQueueTargetMachine,
  normalizeSetupValue,
  sortLotsByQueue,
} from "../utils/machineQueueUtils";
import { formatDateOnly } from "../utils/displayFormat";

const displayValue = (value) => {
  const text = String(value ?? "").trim();

  if (
    !text ||
    text === "-" ||
    text.toLowerCase() === "null" ||
    text.toLowerCase() === "undefined"
  ) {
    return "-";
  }

  return text;
};

const normalizeText = (value) =>
  String(value ?? "")
    .trim()
    .replace(/\s+/g, " ");

const normalizeLotStatus = (value) => normalizeText(value).toUpperCase();

const getLotNo = (lot) =>
  displayValue(lot?.lotId || lot?.lotId || lot?.lotId);

const getPartName = (lot) => displayValue(lot?.partName || lot?.partName);

const getLineName = (lot) => {
  const lineName = normalizeText(lot?.lineName).toUpperCase();
  return /^LINE-[A-Z0-9]+$/.test(lineName) ? lineName : "-";
};

const formatQuantity = (value) => {
  if (value === null || value === undefined || String(value).trim() === "") {
    return "-";
  }

  const number = Number(value);
  if (!Number.isFinite(number)) return displayValue(value);

  return number.toLocaleString("en-US", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  });
};

const getUnitDiameter = (value) => {
  if (value === null || value === undefined || String(value).trim() === "") {
    return "-";
  }

  const number = Number(value);
  return Number.isFinite(number) ? number.toFixed(1) : displayValue(value);
};

const displayMachineValue = (value) => {
  const text = displayValue(value);
  return text === "-" ? "-" : formatDisplayMachineName(text);
};

const hasMoveLot = (lot) =>
  displayValue(lot?.targetMachine || lot?.targetMachine) !== "-";

const getMoveStatusText = (lot) => {
  if (hasMoveLot(lot)) return "ย้ายงาน";
  return displayValue(lot?.moveStatus) === "-" ? "ปกติ" : lot.moveStatus;
};

const getMoveFromMachine = (lot) =>
  displayMachineValue(
    lot?.originalMachine ||
      lot?.originalMachine ||
      lot?.actualMachine ||
      lot?.queueMachine ||
      lot?.lineName ||
      lot?.machineName ||
      lot?.queueMachine,
  );

const getMoveToMachine = (lot) =>
  displayMachineValue(
    lot?.targetMachine ||
      lot?.targetMachine ||
      lot?.displayMachine,
  );

const getStatusMeta = ({ lot, isCurrent, isFirstWaiting }) => {
  const process = normalizeText(lot?.processStatus).toUpperCase();

  if (isCurrent) {
    return {
      label: "กำลังผลิต",
      badge:
        "bg-emerald-600 text-white ring-1 ring-emerald-600 dark:bg-emerald-600",
      order: 0,
    };
  }

  // รักษาพฤติกรรมเดียวกับ WIP Monitor หากในอนาคตมี INPUT กลับมาใน Dataset
  if (process === "PLANNED") {
    const baseStatusInfo = getStatusInfo(lot);
    return {
      label: baseStatusInfo.label,
      badge: baseStatusInfo.colors,
      order: 3,
    };
  }

  if (isFirstWaiting) {
    return {
      label: "รอผลิต",
      badge:
        "bg-amber-500 text-white ring-1 ring-amber-600 dark:bg-amber-600",
      order: 1,
    };
  }

  return {
    label: "รอหน้าเครื่อง",
    badge: "bg-red-600 text-white ring-1 ring-red-600 dark:bg-red-600",
    order: 2,
  };
};

const getLotStatusRowClass = (lotStatus) => {
  const status = normalizeLotStatus(lotStatus);

  if (status === "REVIEWED") {
    return "border-emerald-200 bg-emerald-50/90 hover:bg-emerald-100/90 dark:border-emerald-900/50 dark:bg-emerald-950/25 dark:hover:bg-emerald-950/40";
  }

  if (status === "BLOCKED" || status === "HOLD") {
    return "border-yellow-200 bg-yellow-50/90 hover:bg-yellow-100/90 dark:border-yellow-900/50 dark:bg-yellow-950/25 dark:hover:bg-yellow-950/40";
  }

  return "border-slate-100 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800/50";
};

const getLotStatusBadgeClass = (lotStatus) => {
  const status = normalizeLotStatus(lotStatus);

  if (status === "REVIEWED") {
    return "bg-emerald-100 text-emerald-700 ring-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:ring-emerald-900/60";
  }

  if (status === "BLOCKED" || status === "HOLD") {
    return "bg-yellow-100 text-yellow-800 ring-yellow-200 dark:bg-yellow-950/40 dark:text-yellow-300 dark:ring-yellow-900/60";
  }

  return "bg-slate-100 text-slate-700 ring-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:ring-slate-700";
};

const COMPARE_FIELD_KEYS = [
  "productCode",
  "specA",
  "specB",
  "specC",
  "specD",
  "specE",
  "specF",
  "specG",
  "specH",
  "specI",
  "specJ",
  "specK",
  "specL",
  "specM",
  "specN",
  "specO",
  "specP",
  "specQ",
  "specR",
  "specS",
  "specT",
  "specU",
];

const getVariationKeys = (lots) => {
  const variationKeys = new Set();

  for (const key of COMPARE_FIELD_KEYS) {
    const values = new Set(
      (lots || [])
        .map((lot) => normalizeSetupValue(lot?.[key]))
        .filter(Boolean),
    );

    if (values.size > 1) {
      variationKeys.add(key);
    }
  }

  return variationKeys;
};

const buildRows = (machines) => {
  const rows = [];

  for (const machine of machines || []) {
    const queueMachine = formatMachineName(machine?.machineName);
    if (!isQueueTargetMachine(queueMachine)) continue;

    const sortedLots = sortLotsByQueue(machine?.lots || []);
    const firstWaiting = sortedLots.find((lot) => {
      const source = normalizeText(lot?.sourceType).toUpperCase();
      const process = normalizeText(lot?.processStatus).toUpperCase();
      return source !== "CURRENT" && process !== "PLANNED";
    });
    const firstWaitingLotKey = firstWaiting ? getLotNo(firstWaiting) : null;

    sortedLots.forEach((lot, index) => {
      const source = normalizeText(lot?.sourceType).toUpperCase();
      const isCurrent = source === "CURRENT";
      const isFirstWaiting =
        !isCurrent && firstWaitingLotKey && getLotNo(lot) === firstWaitingLotKey;
      const previousLot =
        index > 0 ? sortedLots[index - 1] : lot?.previousLot || null;
      const statusMeta = getStatusMeta({ lot, isCurrent, isFirstWaiting });

      rows.push({
        ...lot,
        __lotNo: getLotNo(lot),
        __partName: getPartName(lot),
        __line: getLineName(lot),
        __machine: queueMachine,
        __queueId: lot?.queueNo ?? index + 1,
        __status: statusMeta,
        __isCurrent: isCurrent,
        __previousLot: previousLot,
        __setupInfo: getSetupInfo(previousLot, lot),
      });
    });
  }

  // ป้องกัน Lot เดียวกันถูกแสดงซ้ำกรณีข้อมูลต้นทางมีทั้ง Current และ queue data
  // โดยให้ Current Machine มี Priority สูงสุด
  const deduped = new Map();

  rows.forEach((row, index) => {
    const lotKey = normalizeText(row.__lotNo).toUpperCase();
    const fallbackKey = `${row.__machine}-${row.__queueId}-${index}`;
    const key = lotKey && lotKey !== "-" ? lotKey : fallbackKey;
    const existing = deduped.get(key);

    if (!existing || (row.__isCurrent && !existing.__isCurrent)) {
      deduped.set(key, row);
    }
  });

  return [...deduped.values()];
};

function SetupDetailModal({ detail, onClose }) {
  if (!detail) return null;

  return (
    <div className="fixed inset-0 z-[120] flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-sm">
      <div className="flex max-h-[90vh] w-full max-w-lg flex-col overflow-hidden rounded-2xl bg-white shadow-2xl dark:bg-slate-950">
        <div className="flex items-center justify-between bg-amber-500 px-5 py-4 text-slate-900">
          <div>
            <h3 className="text-base font-black">เครื่องมือที่ต้องเปลี่ยน</h3>
            <p className="mt-1 text-xs font-semibold text-slate-800">
              {formatDisplayMachineName(detail.machineName)} / Queue {detail.queueNo} / {getLotNo(detail.lot)}
            </p>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="flex h-9 w-9 items-center justify-center rounded-xl bg-white/35 text-xl font-black text-slate-800 transition hover:bg-white/60"
            aria-label="ปิดรายละเอียด Technical setup"
          >
            ×
          </button>
        </div>

        <div className="border-b border-amber-200 bg-amber-50 px-5 py-3 text-center dark:border-amber-900/60 dark:bg-amber-950/30">
          <p className="text-sm font-black text-amber-900 dark:text-amber-200">
            {detail.setupInfo.code === "CHANGE"
              ? "มีรายการที่ต้อง Setup / เปลี่ยนค่า"
              : detail.setupInfo.hasPreviousLot
                ? "Spec เหมือนคิวก่อนหน้า ไม่ต้อง Setup เพิ่ม"
                : "ยังไม่พบ Lot ก่อนหน้าที่บันทึกไว้ จึงยังไม่สรุป Setup Compare"}
          </p>
        </div>

        <div className="flex-1 overflow-y-auto">
          <section className="bg-yellow-50 px-7 py-5 dark:bg-yellow-950/20">
            <h4 className="mb-4 text-center font-black text-yellow-900 dark:text-yellow-200">
              เปลี่ยนสำหรับช่าง
            </h4>
            <div className="grid grid-cols-1 gap-2 text-sm sm:grid-cols-2">
              {detail.setupInfo.details
                .filter((item) => item.group === "technician")
                .map((item) => (
                  <div
                    key={item.key}
                    className={`rounded-xl border px-3 py-2 ${
                      item.isDifferent
                        ? "border-red-200 bg-red-50 font-bold text-red-600 dark:border-red-900/60 dark:bg-red-950/20 dark:text-red-400"
                        : "border-slate-200 bg-white text-slate-700 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200"
                    }`}
                    title={
                      item.isDifferent
                        ? `ก่อนหน้า: ${item.previousDisplay} | ปัจจุบัน: ${item.currentDisplay}`
                        : item.currentDisplay
                    }
                  >
                    <span className="block text-[11px] font-bold text-slate-400">{item.label}</span>
                    <span>{item.currentDisplay}</span>
                  </div>
                ))}
            </div>
          </section>

          <section className="border-t border-slate-200 bg-orange-50/50 px-7 py-5 dark:border-slate-800 dark:bg-orange-950/10">
            <h4 className="mb-4 text-center font-black text-orange-900 dark:text-orange-200">
              เปลี่ยนสำหรับพนักงาน
            </h4>
            <div className="grid grid-cols-1 gap-2 text-sm sm:grid-cols-2">
              {detail.setupInfo.details
                .filter((item) => item.group === "operator")
                .map((item) => (
                  <div
                    key={item.key}
                    className={`rounded-xl border px-3 py-2 ${
                      item.isDifferent
                        ? "border-red-200 bg-red-50 font-bold text-red-600 dark:border-red-900/60 dark:bg-red-950/20 dark:text-red-400"
                        : "border-slate-200 bg-white text-slate-700 dark:border-slate-800 dark:bg-slate-900 dark:text-slate-200"
                    }`}
                    title={
                      item.isDifferent
                        ? `ก่อนหน้า: ${item.previousDisplay} | ปัจจุบัน: ${item.currentDisplay}`
                        : item.currentDisplay
                    }
                  >
                    <span className="block text-[11px] font-bold text-slate-400">{item.label}</span>
                    <span>{item.currentDisplay}</span>
                  </div>
                ))}
            </div>
          </section>
        </div>

        <div className="flex justify-end border-t border-slate-200 bg-white px-5 py-4 dark:border-slate-800 dark:bg-slate-950">
          <button
            type="button"
            onClick={onClose}
            className="rounded-xl bg-slate-900 px-5 py-2 text-sm font-black text-white transition hover:bg-slate-700 dark:bg-slate-100 dark:text-slate-900 dark:hover:bg-white"
          >
            ปิด
          </button>
        </div>
      </div>
    </div>
  );
}

function PartGroupTable({ group, viewMode, onOpenSetup }) {
  const showCoreColumns = viewMode !== "TECH";
  const showTechnicalColumns = viewMode !== "CORE";
  const variationKeys = group.variationKeys || new Set();

  const variationCellClass = (key) =>
    variationKeys.has(key)
      ? "bg-amber-50/80 font-black text-amber-800 dark:bg-amber-950/25 dark:text-amber-300"
      : "text-slate-600 dark:text-slate-400";

  return (
    <div className="part-group-scrollbar overflow-x-auto">
      <table className="w-full min-w-max whitespace-nowrap text-left text-sm text-slate-600 dark:text-slate-400">
        <thead className="border-b border-slate-200 bg-slate-50/95 text-[11px] uppercase tracking-wide text-slate-500 dark:border-slate-800 dark:bg-slate-900/95 dark:text-slate-400">
          <tr className="border-b border-slate-200/80 text-[10px] tracking-[0.14em] dark:border-slate-800">
            <th colSpan={5} className="bg-cyan-50/80 px-4 py-2 font-black text-cyan-700 dark:bg-cyan-950/25 dark:text-cyan-300">
              Queue / Lot
            </th>
            {showCoreColumns && (
              <th colSpan={18} className="bg-blue-50/80 px-4 py-2 font-black text-blue-700 dark:bg-blue-950/25 dark:text-blue-300">
                WIP Information
              </th>
            )}
            {showTechnicalColumns && (
              <th colSpan={23} className="bg-violet-50/80 px-4 py-2 font-black text-violet-700 dark:bg-violet-950/25 dark:text-violet-300">
                Product Specification / Setup
              </th>
            )}
          </tr>

          <tr>
            <th className="px-4 py-3 text-center">Queue</th>
            <th className="px-4 py-3 text-center">Status</th>
            <th className="px-4 py-3">Lot No</th>
            <th className="px-4 py-3">Line</th>
            <th className="px-4 py-3">Machine</th>

            {showCoreColumns && (
              <>
                <th className="px-4 py-3">สถานะการย้าย</th>
                <th className="px-4 py-3">Product Code</th>
                <th className="px-4 py-3 text-center">Setup Compare</th>
                <th className="px-4 py-3">Stop Code</th>
                <th className="px-4 py-3 text-center">ลำดับงานเข้าเครื่อง</th>
                <th className="px-4 py-3">Part Name</th>
                <th className="px-4 py-3">Unit Name</th>
                <th className="px-4 py-3">Input Date</th>
                <th className="px-4 py-3">Status Process</th>
                <th className="px-4 py-3">Machine เดิม</th>
                <th className="px-4 py-3">Machine ใหม่</th>
                <th className="px-4 py-3">Tracking No</th>
                <th className="px-4 py-3 text-right">Qty</th>
                <th className="px-4 py-3 text-right">Input Qty</th>
                <th className="px-4 py-3 text-right">Output Qty</th>
                <th className="px-4 py-3">%งานผลิตปัจจุบัน</th>
                <th className="px-4 py-3">Lot Status</th>
                <th className="px-4 py-3">Comment</th>
              </>
            )}

            {showTechnicalColumns && (
              <>
                <th className="px-4 py-3">specA</th>
                <th className="px-4 py-3">Spec B</th>
                <th className="px-4 py-3">specC</th>
                <th className="px-4 py-3">specD</th>
                <th className="px-4 py-3">specE</th>
                <th className="px-4 py-3">Spec F</th>
                <th className="px-4 py-3">Spec G</th>
                <th className="px-4 py-3">specH</th>
                <th className="px-4 py-3">Spec I</th>
                <th className="px-4 py-3">specJ</th>
                <th className="px-4 py-3">specK</th>
                <th className="px-4 py-3">Spec L</th>
                <th className="px-4 py-3">specM</th>
                <th className="px-4 py-3">Spec N</th>
                <th className="px-4 py-3">Spec O</th>
                <th className="px-4 py-3">Spec P</th>
                <th className="px-4 py-3">Spec Q</th>
                <th className="px-4 py-3">Spec R</th>
                <th className="px-4 py-3">Spec S</th>
                <th className="px-4 py-3">Spec T</th>
                <th className="px-4 py-3">specU</th>
                <th className="px-4 py-3">Operator ID</th>
                <th className="px-4 py-3">Start Date</th>
              </>
            )}
          </tr>
        </thead>

        <tbody>
          {group.lots.map((lot, index) => {
            const setupInfo = lot.__setupInfo || getSetupInfo(lot.__previousLot, lot);
            const inputQty = Number.parseFloat(lot.inputQty) || 0;
            const outputQty = Number.parseFloat(lot.outputQty) || 0;
            const rawProgressPercent =
              inputQty > 0 ? Math.round((outputQty / inputQty) * 100) : 0;
            const progressBarPercent = Math.max(
              0,
              Math.min(rawProgressPercent, 100),
            );
            const progressText = inputQty > 0 ? `${rawProgressPercent}%` : "-";

            return (
              <tr
                key={`${lot.__lotNo}-${lot.__machine}-${lot.__queueId}-${index}`}
                className={`border-b transition ${getLotStatusRowClass(lot.lotStatus)}`}
              >
                <td className="px-4 py-3 text-center font-black text-slate-700 dark:text-slate-300">
                  {displayValue(lot.__queueId)}
                </td>
                <td className="px-4 py-3 text-center">
                  <span className={`inline-flex rounded-lg px-2.5 py-1 text-[11px] font-black ${lot.__status.badge}`}>
                    {lot.__status.label}
                  </span>
                </td>
                <td className="px-4 py-3 font-black text-slate-950 dark:text-white">
                  {lot.__lotNo}
                </td>
                <td className="px-4 py-3 font-black text-violet-700 dark:text-violet-300">
                  {lot.__line}
                </td>
                <td className="px-4 py-3 font-black text-blue-700 dark:text-blue-300">
                  {lot.__machine}
                </td>

                {showCoreColumns && (
                  <>
                    <td className="px-4 py-3">
                      <span
                        className={`inline-flex rounded-full px-3 py-1 text-xs font-black ${
                          hasMoveLot(lot)
                            ? "bg-amber-100 text-amber-700 ring-1 ring-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:ring-amber-900/60"
                            : "bg-slate-100 text-slate-600 ring-1 ring-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:ring-slate-700"
                        }`}
                      >
                        {getMoveStatusText(lot)}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-center">
                      {displayValue(lot.productCode)}
                    </td>
                    <td className="px-4 py-3 text-center">
                      <button
                        type="button"
                        onClick={() =>
                          onOpenSetup({
                            lot,
                            previousLot: lot.__previousLot,
                            setupInfo,
                            queueNo: lot.__queueId,
                            machineName: lot.__machine,
                          })
                        }
                        className={
                          setupInfo.code === "CHANGE"
                            ? "inline-flex items-center gap-1.5 font-black text-red-600 underline decoration-red-400 underline-offset-4 hover:text-red-700"
                            : setupInfo.hasPreviousLot
                              ? "inline-flex items-center gap-1.5 font-bold text-emerald-700 underline decoration-emerald-400 underline-offset-4 hover:text-emerald-800 dark:text-emerald-300"
                              : "inline-flex items-center gap-1.5 font-bold text-slate-400 underline decoration-slate-300 underline-offset-4 hover:text-slate-500 dark:text-slate-500"
                        }
                        title={
                          setupInfo.hasPreviousLot
                            ? "กดเพื่อดูรายละเอียด Technical setup"
                            : "ยังไม่พบ Lot ก่อนหน้าที่บันทึกไว้ จึงยังไม่สรุป Setup Compare"
                        }
                      >
                        <Wrench size={14} />
                        {setupInfo.code}
                      </button>
                    </td>
                    <td
                      className={`px-4 py-3 font-medium ${
                        displayValue(lot.stopCode) !== "-"
                          ? "text-rose-600 dark:text-rose-400"
                          : "text-slate-500"
                      }`}
                    >
                      {displayValue(lot.stopCode)}
                    </td>
                    <td className="px-4 py-3 text-center">
                      {lot.manualSequence ? (
                        <span className="inline-flex min-w-9 items-center justify-center rounded-lg bg-cyan-100 px-2.5 py-1 text-xs font-black text-cyan-700 ring-1 ring-cyan-200 dark:bg-cyan-950/40 dark:text-cyan-300 dark:ring-cyan-900/60">
                          {lot.manualSequence}
                        </span>
                      ) : (
                        <span className="text-slate-400 dark:text-slate-500">-</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.partName || lot.partName)}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.unitName)}
                    </td>
                    <td className="px-4 py-3 text-slate-500 dark:text-slate-400">
                      {formatDateOnly(lot.inputDate || lot.inputDate)}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.processStatus)}
                    </td>
                    <td className="px-4 py-3 font-bold text-slate-700 dark:text-slate-200">
                      {getMoveFromMachine(lot)}
                    </td>
                    <td className="px-4 py-3">
                      {hasMoveLot(lot) ? (
                        <span className="inline-flex rounded-full bg-emerald-100 px-3 py-1 text-xs font-black text-emerald-700 ring-1 ring-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:ring-emerald-900/60">
                          {getMoveToMachine(lot)}
                        </span>
                      ) : (
                        <span className="text-slate-400 dark:text-slate-500">-</span>
                      )}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.trackingNo || lot.trackingNo || lot.trackingNo || lot.trackingNo)}
                    </td>
                    <td className="px-4 py-3 text-right font-semibold text-cyan-700 dark:text-cyan-300">
                      {formatQuantity(lot.plannedQty)}
                    </td>
                    <td className="px-4 py-3 text-right text-slate-600 dark:text-slate-400">
                      {formatQuantity(lot.inputQty)}
                    </td>
                    <td className="px-4 py-3 text-right text-slate-600 dark:text-slate-400">
                      {formatQuantity(lot.outputQty)}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      <div className="flex min-w-[130px] items-center gap-2">
                        <div className="h-2 w-20 overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800">
                          <div
                            className={`h-full rounded-full transition-all duration-500 ${
                              rawProgressPercent >= 100 ? "bg-cyan-500" : "bg-emerald-500"
                            }`}
                            style={{ width: `${progressBarPercent}%` }}
                          />
                        </div>
                        <span className="w-10 text-right font-bold text-slate-700 dark:text-slate-300">
                          {progressText}
                        </span>
                      </div>
                    </td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex rounded-full px-2.5 py-1 text-[11px] font-black ring-1 ${getLotStatusBadgeClass(lot.lotStatus)}`}>
                        {displayValue(lot.lotStatus)}
                      </span>
                    </td>
                    <td
                      className="max-w-[280px] truncate px-4 py-3 text-slate-500 dark:text-slate-400"
                      title={displayValue(lot.comment)}
                    >
                      {displayValue(lot.comment)}
                    </td>
                  </>
                )}

                {showTechnicalColumns && (
                  <>
                    <td className={`px-4 py-3 ${variationCellClass("specA")}`}>{displayValue(lot.specA)}</td>
                    <td className={`px-4 py-3 ${variationCellClass("specB")}`}>{displayValue(lot.specB)}</td>
                    <td className={`px-4 py-3 ${variationCellClass("specC")}`}>{displayValue(lot.specC)}</td>
                    <td className={`px-4 py-3 ${variationCellClass("specD")}`}>{displayValue(lot.specD)}</td>
                    <td className={`px-4 py-3 ${variationCellClass("specE")}`}>{displayValue(lot.specE)}</td>
                    <td className={`px-4 py-3 ${variationCellClass("specF")}`}>{getUnitDiameter(lot.specF)}</td>
                    <td className={`px-4 py-3 ${variationCellClass("specG")}`}>{displayValue(lot.specG)}</td>
                    <td className={`px-4 py-3 ${variationCellClass("specH")}`}>{displayValue(lot.specH)}</td>
                    <td className={`px-4 py-3 ${variationCellClass("specI")}`}>{displayValue(lot.specI)}</td>
                    <td className={`px-4 py-3 ${variationCellClass("specJ")}`}>{displayValue(lot.specJ)}</td>
                    <td className={`px-4 py-3 ${variationCellClass("specK")}`}>{displayValue(lot.specK)}</td>
                    <td className={`px-4 py-3 ${variationCellClass("specL")}`}>{displayValue(lot.specL)}</td>
                    <td className={`px-4 py-3 ${variationCellClass("specM")}`}>{displayValue(lot.specM)}</td>
                    <td className={`px-4 py-3 ${variationCellClass("specN")}`}>{displayValue(lot.specN)}</td>
                    <td className={`px-4 py-3 ${variationCellClass("specO")}`}>{displayValue(lot.specO)}</td>
                    <td className={`px-4 py-3 ${variationCellClass("specP")}`}>{displayValue(lot.specP)}</td>
                    <td className={`px-4 py-3 ${variationCellClass("specQ")}`}>{displayValue(lot.specQ)}</td>
                    <td className={`px-4 py-3 ${variationCellClass("specR")}`}>{displayValue(lot.specR)}</td>
                    <td className={`px-4 py-3 ${variationCellClass("specS")}`}>{displayValue(lot.specS)}</td>
                    <td className={`px-4 py-3 ${variationCellClass("specT")}`}>{displayValue(lot.specT)}</td>
                    <td className={`px-4 py-3 ${variationCellClass("specU")}`}>{displayValue(lot.specU)}</td>
                    <td className="px-4 py-3 text-slate-500 dark:text-slate-400">{displayValue(lot.operatorId)}</td>
                    <td className="px-4 py-3 text-slate-500 dark:text-slate-400">{displayValue(lot.startTime)}</td>
                  </>
                )}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
}

export default function PartGroupWip() {
  const [machines, setMachines] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [lastUpdated, setLastUpdated] = useState(null);
  const [searchText, setSearchText] = useState("");
  const [lineFilter, setLineFilter] = useState("ALL");
  const [machineFilter, setMachineFilter] = useState("ALL");
  const [viewMode, setViewMode] = useState("ALL");
  const [collapsedGroups, setCollapsedGroups] = useState(() => new Set());
  const [selectedSetupDetail, setSelectedSetupDetail] = useState(null);
  const requestSeqRef = useRef(0);
  const inFlightRef = useRef(false);

  const loadData = async ({ reason = "AUTO" } = {}) => {
    if (reason === "AUTO" && inFlightRef.current) return;

    const requestSeq = ++requestSeqRef.current;
    inFlightRef.current = true;
    setLoading(true);
    setError("");

    try {
      const data = await getMachines({
        includeTechnical: true,
        includeMoveLot: true,
        force: true,
      });

      if (requestSeq !== requestSeqRef.current) return;

      setMachines(Array.isArray(data) ? data : []);
      setLastUpdated(new Date());
    } catch (loadError) {
      if (requestSeq !== requestSeqRef.current) return;
      console.error("Load WIP by Part Name failed:", loadError);
      setError(loadError?.message || "โหลดข้อมูล WIP ไม่สำเร็จ");
    } finally {
      if (requestSeq === requestSeqRef.current) {
        setLoading(false);
        inFlightRef.current = false;
      }
    }
  };

  useEffect(() => {
    loadData({ reason: "INITIAL" });

    const timer = window.setInterval(() => {
      loadData({ reason: "AUTO" });
    }, 60_000);

    return () => window.clearInterval(timer);
  }, []);

  const allRows = useMemo(() => buildRows(machines), [machines]);

  const lineOptions = useMemo(() => {
    return [
      ...new Set(
        allRows.map((row) => row.__line).filter((line) => line !== "-"),
      ),
    ].sort((a, b) => a.localeCompare(b));
  }, [allRows]);

  const machineOptions = useMemo(() => {
    return [
      ...new Set(allRows.map((row) => row.__machine).filter(Boolean)),
    ].sort((a, b) => a.localeCompare(b));
  }, [allRows]);

  const summary = useMemo(() => {
    const partNames = new Set(
      allRows
        .map((row) => normalizeText(row.__partName).toUpperCase())
        .filter((value) => value && value !== "-"),
    );
    const lines = new Set(
      allRows.map((row) => row.__line).filter((value) => value !== "-"),
    );
    const machineNames = new Set(
      allRows.map((row) => row.__machine).filter(Boolean),
    );
    const currentCount = allRows.filter((row) => row.__isCurrent).length;

    return {
      partNameCount: partNames.size,
      lotCount: allRows.length,
      lineCount: lines.size,
      machineCount: machineNames.size,
      currentCount,
    };
  }, [allRows]);

  const filteredRows = useMemo(() => {
    const keyword = normalizeText(searchText).toUpperCase();

    return allRows.filter((row) => {
      if (lineFilter !== "ALL" && row.__line !== lineFilter) return false;
      if (machineFilter !== "ALL" && row.__machine !== machineFilter) return false;

      if (!keyword) return true;

      const haystack = [
        row.__partName,
        row.__lotNo,
        row.__line,
        row.__machine,
        row.unitName,
        row.productCode,
        row.trackingNo,
        row.trackingNo,
        row.trackingNo,
        row.lotStatus,
        row.processStatus,
        row.stopCode,
        row.comment,
        row.specA,
        row.specC,
        row.specD,
      ]
        .map((value) => normalizeText(value).toUpperCase())
        .join(" ");

      return haystack.includes(keyword);
    });
  }, [allRows, lineFilter, machineFilter, searchText]);

  const groups = useMemo(() => {
    const grouped = new Map();

    for (const row of filteredRows) {
      const displayPartName =
        row.__partName === "-" ? "ไม่พบ Part Name" : row.__partName;
      const key = normalizeText(displayPartName).toUpperCase();

      if (!grouped.has(key)) {
        grouped.set(key, {
          key,
          partName: displayPartName,
          lots: [],
        });
      }

      grouped.get(key).lots.push(row);
    }

    return [...grouped.values()]
      .map((group) => {
        const lots = [...group.lots].sort((a, b) => {
          if (a.__status.order !== b.__status.order) {
            return a.__status.order - b.__status.order;
          }

          const lineCompare = a.__line.localeCompare(b.__line);
          if (lineCompare !== 0) return lineCompare;

          const machineCompare = a.__machine.localeCompare(b.__machine);
          if (machineCompare !== 0) return machineCompare;

          return Number(a.__queueId || 999) - Number(b.__queueId || 999);
        });

        const variationKeys = getVariationKeys(lots);

        return {
          ...group,
          lots,
          lines: [
            ...new Set(
              lots.map((lot) => lot.__line).filter((value) => value !== "-"),
            ),
          ],
          machines: [
            ...new Set(lots.map((lot) => lot.__machine).filter(Boolean)),
          ],
          currentCount: lots.filter((lot) => lot.__isCurrent).length,
          variationKeys,
          variationCount: variationKeys.size,
        };
      })
      .sort((a, b) => a.partName.localeCompare(b.partName));
  }, [filteredRows]);

  const hasActiveFilters =
    Boolean(searchText.trim()) || lineFilter !== "ALL" || machineFilter !== "ALL";

  const allVisibleGroupsCollapsed =
    groups.length > 0 && groups.every((group) => collapsedGroups.has(group.key));

  const resetFilters = () => {
    setSearchText("");
    setLineFilter("ALL");
    setMachineFilter("ALL");
  };

  const toggleGroup = (groupKey) => {
    setCollapsedGroups((previous) => {
      const next = new Set(previous);
      if (next.has(groupKey)) {
        next.delete(groupKey);
      } else {
        next.add(groupKey);
      }
      return next;
    });
  };

  const toggleAllGroups = () => {
    if (allVisibleGroupsCollapsed) {
      setCollapsedGroups(new Set());
      return;
    }

    setCollapsedGroups(new Set(groups.map((group) => group.key)));
  };

  return (
    <div className="flex h-full flex-col space-y-5 pt-6">
      <section className="relative overflow-hidden rounded-[2rem] border border-slate-300 bg-gradient-to-br from-cyan-50 via-white to-slate-100 p-5 shadow-lg dark:border-slate-700 dark:from-slate-900 dark:via-slate-950 dark:to-cyan-950/30 sm:p-6">
        <div className="absolute right-[-70px] top-[-70px] h-48 w-48 rounded-full bg-cyan-400/20 blur-3xl" />

        <div className="relative flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex min-w-0 items-start gap-4">
            <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-cyan-600 text-white shadow-lg shadow-cyan-600/20">
              <Table2 size={28} strokeWidth={2.2} />
            </div>

            <div>
              <p className="text-xs font-black uppercase tracking-[0.22em] text-cyan-700 dark:text-cyan-300">
                Part Name Group
              </p>
              <h1 className="mt-1 text-2xl font-black tracking-tight text-slate-900 sm:text-3xl dark:text-white">
                WIP ตาม Part Name
              </h1>
              <p className="mt-1 max-w-4xl text-xs font-semibold leading-6 text-slate-600 sm:text-sm dark:text-slate-300">
                รวม Lot ที่มี Part Name เดียวกันจากทุก Line และทุกเครื่อง พร้อมข้อมูล WIP และ Product Specification
                เพื่อช่วยเปรียบเทียบและตัดสินใจเลือกงานเข้าเครื่องจักร
              </p>
            </div>
          </div>

          <div className="flex shrink-0 flex-col items-stretch gap-2 sm:flex-row sm:items-center">
            <div className="text-right text-xs font-semibold text-slate-500 dark:text-slate-400">
              <div>
                อัปเดตล่าสุด: {lastUpdated ? lastUpdated.toLocaleTimeString("th-TH") : "-"}
              </div>
              <div className="text-[11px] text-slate-400 dark:text-slate-500">
                อัปเดตอัตโนมัติทุก 1 นาที
              </div>
            </div>

            <button
              type="button"
              onClick={() => loadData({ reason: "MANUAL" })}
              disabled={loading}
              className="inline-flex h-12 items-center justify-center gap-2 rounded-2xl bg-cyan-600 px-5 text-sm font-black text-white transition hover:bg-cyan-700 disabled:cursor-not-allowed disabled:opacity-50"
            >
              <RefreshCw size={18} className={loading ? "animate-spin" : ""} />
              {loading ? "กำลังโหลด..." : "Refresh"}
            </button>
          </div>
        </div>
      </section>

      <section className="grid grid-cols-2 gap-3 xl:grid-cols-4">
        <div className="rounded-3xl border border-cyan-200 bg-cyan-50/90 p-4 shadow-sm dark:border-cyan-900/60 dark:bg-cyan-950/30 sm:p-5">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.12em] text-cyan-700 dark:text-cyan-300">Part Name</p>
              <p className="mt-1 text-2xl font-black text-slate-950 dark:text-white sm:text-3xl">{summary.partNameCount}</p>
              <p className="mt-1 text-xs font-semibold text-slate-500 dark:text-slate-400">กลุ่ม Part Name ทั้งหมด</p>
            </div>
            <Table2 className="text-cyan-600 dark:text-cyan-300" size={28} />
          </div>
        </div>

        <div className="rounded-3xl border border-blue-200 bg-blue-50/90 p-4 shadow-sm dark:border-blue-900/60 dark:bg-blue-950/30 sm:p-5">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.12em] text-blue-700 dark:text-blue-300">LOT</p>
              <p className="mt-1 text-2xl font-black text-slate-950 dark:text-white sm:text-3xl">{summary.lotCount}</p>
              <p className="mt-1 text-xs font-semibold text-slate-500 dark:text-slate-400">จำนวน Lot การผลิตทั้งหมด</p>
            </div>
            <ListOrdered className="text-blue-600 dark:text-blue-300" size={28} />
          </div>
        </div>

        <div className="rounded-3xl border border-violet-200 bg-violet-50/90 p-4 shadow-sm dark:border-violet-900/60 dark:bg-violet-950/30 sm:p-5">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.12em] text-violet-700 dark:text-violet-300">Production Line</p>
              <p className="mt-1 text-2xl font-black text-slate-950 dark:text-white sm:text-3xl">{summary.lineCount}</p>
              <p className="mt-1 text-xs font-semibold text-slate-500 dark:text-slate-400">จำนวน Line การผลิตทั้งหมด</p>
            </div>
            <Factory className="text-violet-600 dark:text-violet-300" size={28} />
          </div>
        </div>

        <div className="rounded-3xl border border-emerald-200 bg-emerald-50/90 p-4 shadow-sm dark:border-emerald-900/60 dark:bg-emerald-950/30 sm:p-5">
          <div className="flex items-center justify-between gap-3">
            <div>
              <p className="text-[11px] font-black uppercase tracking-[0.12em] text-emerald-700 dark:text-emerald-300">Machine</p>
              <p className="mt-1 text-2xl font-black text-slate-950 dark:text-white sm:text-3xl">{summary.machineCount}</p>
              <p className="mt-1 text-xs font-semibold text-slate-500 dark:text-slate-400">จำนวนเครื่องทั้งหมด</p>
            </div>
            <Factory className="text-emerald-600 dark:text-emerald-300" size={28} />
          </div>
        </div>
      </section>

      <section className="rounded-3xl border border-slate-300 bg-white/90 p-4 shadow-sm backdrop-blur dark:border-slate-700 dark:bg-slate-950/70 sm:p-5">
        <div className="grid grid-cols-1 gap-3 xl:grid-cols-[minmax(320px,1fr)_160px_210px_auto] xl:items-end">
          <label className="block">
            <span className="mb-1.5 block text-xs font-black uppercase tracking-wide text-slate-500 dark:text-slate-400">
              ค้นหา
            </span>
            <div className="relative">
              <Search className="pointer-events-none absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input
                value={searchText}
                onChange={(event) => setSearchText(event.target.value)}
                placeholder="Part Name / Lot No / Product Code / Machine / TL"
                className="h-11 w-full rounded-xl border border-slate-300 bg-white pl-10 pr-3 text-sm font-semibold text-slate-800 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100 dark:focus:ring-cyan-950"
              />
            </div>
          </label>

          <label className="block">
            <span className="mb-1.5 block text-xs font-black uppercase tracking-wide text-slate-500 dark:text-slate-400">Line</span>
            <select
              value={lineFilter}
              onChange={(event) => setLineFilter(event.target.value)}
              className="h-11 w-full rounded-xl border border-slate-300 bg-white px-3 text-sm font-bold text-slate-700 outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:focus:ring-cyan-950"
            >
              <option value="ALL">ทุก Line</option>
              {lineOptions.map((line) => (
                <option key={line} value={line}>{line}</option>
              ))}
            </select>
          </label>

          <label className="block">
            <span className="mb-1.5 block text-xs font-black uppercase tracking-wide text-slate-500 dark:text-slate-400">Machine</span>
            <select
              value={machineFilter}
              onChange={(event) => setMachineFilter(event.target.value)}
              className="h-11 w-full rounded-xl border border-slate-300 bg-white px-3 text-sm font-bold text-slate-700 outline-none focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:focus:ring-cyan-950"
            >
              <option value="ALL">ทุกเครื่อง</option>
              {machineOptions.map((machine) => (
                <option key={machine} value={machine}>{machine}</option>
              ))}
            </select>
          </label>

          <div className="flex h-11 items-center justify-center rounded-xl bg-slate-100 px-4 text-sm font-black text-slate-600 dark:bg-slate-800 dark:text-slate-300">
            {groups.length} กลุ่ม / {filteredRows.length} Lot
          </div>
        </div>

        <div className="mt-4 flex flex-col gap-3 border-t border-slate-200 pt-4 dark:border-slate-800 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-1.5 text-xs font-black uppercase tracking-wide text-slate-500 dark:text-slate-400">
              <Columns3 size={15} /> Table View
            </span>
            {[
              { key: "CORE", label: "ข้อมูล WIP" },
              { key: "TECH", label: "Technical" },
              { key: "ALL", label: "ทั้งหมด" },
            ].map((option) => (
              <button
                key={option.key}
                type="button"
                onClick={() => setViewMode(option.key)}
                className={`rounded-xl px-3 py-2 text-xs font-black transition ${
                  viewMode === option.key
                    ? "bg-cyan-600 text-white shadow-sm"
                    : "bg-slate-100 text-slate-600 hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700"
                }`}
              >
                {option.label}
              </button>
            ))}
            {/* <span className="ml-1 text-[11px] font-semibold text-slate-400 dark:text-slate-500">
              สีเหลือง = ค่าที่แตกต่างกันภายใน Part Name เดียวกัน
            </span> */}
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {hasActiveFilters && (
              <button
                type="button"
                onClick={resetFilters}
                className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-black text-slate-600 transition hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800"
              >
                <RotateCcw size={14} /> ล้าง Filter
              </button>
            )}
            <button
              type="button"
              onClick={toggleAllGroups}
              disabled={groups.length === 0}
              className="inline-flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-3 py-2 text-xs font-black text-slate-600 transition hover:bg-slate-50 disabled:opacity-40 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800"
            >
              {allVisibleGroupsCollapsed ? <ChevronDown size={14} /> : <ChevronRight size={14} />}
              {allVisibleGroupsCollapsed ? "ขยายทั้งหมด" : "ย่อทั้งหมด"}
            </button>
          </div>
        </div>
      </section>

      {error ? (
        <div className="flex items-center justify-center gap-2 rounded-3xl border border-rose-200 bg-rose-50 p-10 font-bold text-rose-600 dark:border-rose-900/60 dark:bg-rose-950/30 dark:text-rose-300">
          <AlertTriangle size={20} />
          {error}
        </div>
      ) : loading && allRows.length === 0 ? (
        <div className="rounded-3xl border border-slate-200 bg-white/90 p-12 text-center font-bold text-slate-500 dark:border-slate-700 dark:bg-slate-950/70 dark:text-slate-400">
          กำลังโหลดข้อมูล WIP ตาม Part Name...
        </div>
      ) : groups.length === 0 ? (
        <div className="rounded-3xl border border-slate-200 bg-white/90 p-12 text-center font-bold text-slate-500 dark:border-slate-700 dark:bg-slate-950/70 dark:text-slate-400">
          ไม่พบข้อมูลตาม Filter ที่เลือก
        </div>
      ) : (
        <div className="space-y-4 pb-8">
          {groups.map((group) => {
            const isCollapsed = collapsedGroups.has(group.key);
            const waitingCount = group.lots.length - group.currentCount;

            return (
              <section
                key={group.key}
                className="overflow-hidden rounded-3xl border border-slate-300 bg-white/95 shadow-[0_10px_28px_rgba(15,23,42,0.08)] dark:border-slate-700 dark:bg-slate-950/80"
              >
                <div className="flex flex-col gap-3 border-b border-slate-200 bg-gradient-to-r from-cyan-50 via-white to-slate-50 px-5 py-4 dark:border-slate-800 dark:from-cyan-950/30 dark:via-slate-950 dark:to-slate-900 lg:flex-row lg:items-center lg:justify-between">
                  <button
                    type="button"
                    onClick={() => toggleGroup(group.key)}
                    className="flex min-w-0 items-start gap-3 text-left"
                    aria-expanded={!isCollapsed}
                  >
                    <span className="mt-1 flex h-8 w-8 shrink-0 items-center justify-center rounded-xl bg-cyan-100 text-cyan-700 dark:bg-cyan-950/50 dark:text-cyan-300">
                      {isCollapsed ? <ChevronRight size={18} /> : <ChevronDown size={18} />}
                    </span>
                    <span className="min-w-0">
                      <span className="block text-[11px] font-black uppercase tracking-[0.15em] text-cyan-600 dark:text-cyan-300">Part Name</span>
                      <span className="mt-0.5 block break-all text-lg font-black text-slate-950 sm:text-xl dark:text-white">
                        {group.partName}
                      </span>
                    </span>
                  </button>

                  <div className="flex flex-wrap items-center gap-2 text-xs font-black">
                    <span className="rounded-full bg-cyan-100 px-3 py-1.5 text-cyan-700 ring-1 ring-cyan-200 dark:bg-cyan-950/50 dark:text-cyan-300 dark:ring-cyan-900/60">
                      {group.lots.length} LOT
                    </span>
                    <span className="rounded-full bg-violet-100 px-3 py-1.5 text-violet-700 ring-1 ring-violet-200 dark:bg-violet-950/50 dark:text-violet-300 dark:ring-violet-900/60">
                      lineName: {group.lines.length ? group.lines.join(", ") : "-"}
                    </span>
                    <span
                      className="max-w-[360px] truncate rounded-full bg-blue-100 px-3 py-1.5 text-blue-700 ring-1 ring-blue-200 dark:bg-blue-950/50 dark:text-blue-300 dark:ring-blue-900/60"
                      title={group.machines.join(", ")}
                    >
                      machineName: {group.machines.length <= 3 ? group.machines.join(", ") : `${group.machines.length} เครื่อง`}
                    </span>
                    {/* {group.currentCount > 0 && (
                      <span className="rounded-full bg-emerald-100 px-3 py-1.5 text-emerald-700 ring-1 ring-emerald-200 dark:bg-emerald-950/50 dark:text-emerald-300 dark:ring-emerald-900/60">
                        กำลังผลิต {group.currentCount}
                      </span>
                    )}
                    {waitingCount > 0 && (
                      <span className="rounded-full bg-red-100 px-3 py-1.5 text-red-700 ring-1 ring-red-200 dark:bg-red-950/40 dark:text-red-300 dark:ring-red-900/60">
                        รอ {waitingCount}
                      </span>
                    )} */}
                    {/* {group.variationCount > 0 ? (
                      <span className="rounded-full bg-amber-100 px-3 py-1.5 text-amber-800 ring-1 ring-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:ring-amber-900/60">
                        ค่าต่างกัน {group.variationCount} จุด
                      </span>
                    ) : (
                      <span className="rounded-full bg-slate-100 px-3 py-1.5 text-slate-600 ring-1 ring-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:ring-slate-700">
                        Spec ตรงกัน
                      </span>
                    )} */}
                  </div>
                </div>

                {!isCollapsed && (
                  <>
                    <div className="flex items-center justify-between gap-3 border-b border-slate-100 bg-white/80 px-5 py-2 text-[11px] font-semibold text-slate-400 dark:border-slate-800 dark:bg-slate-950/50 dark:text-slate-500">
                      <span>
                        {viewMode === "ALL"
                          ? "แสดงข้อมูลครบเทียบเท่าตาราง WIP Monitor + Line/Machine"
                          : viewMode === "CORE"
                            ? "โหมดข้อมูล WIP: ซ่อน Spec Data เพื่ออ่านคิวง่ายขึ้น"
                            : "โหมด Technical: เน้นเปรียบเทียบ Product Specification"}
                      </span>
                      <span className="hidden shrink-0 sm:inline">เลื่อนซ้าย/ขวาเพื่อดูข้อมูลทั้งหมด →</span>
                    </div>

                    <PartGroupTable
                      group={group}
                      viewMode={viewMode}
                      onOpenSetup={setSelectedSetupDetail}
                    />
                  </>
                )}
              </section>
            );
          })}
        </div>
      )}

      <SetupDetailModal
        detail={selectedSetupDetail}
        onClose={() => setSelectedSetupDetail(null)}
      />

      <style>{`
        .part-group-scrollbar::-webkit-scrollbar {
          height: 9px;
        }
        .part-group-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .part-group-scrollbar::-webkit-scrollbar-thumb {
          background: #cbd5e1;
          border-radius: 999px;
        }
        .part-group-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #94a3b8;
        }
        .dark .part-group-scrollbar::-webkit-scrollbar-thumb {
          background: #475569;
        }
        .dark .part-group-scrollbar::-webkit-scrollbar-thumb:hover {
          background: #64748b;
        }
      `}</style>
    </div>
  );
}
