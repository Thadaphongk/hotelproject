import React, { useEffect, useState } from "react";
import {
  AlertTriangle,
  Clock3,
  Eraser,
  PackageSearch,
  RefreshCw,
  Search,
  Table2,
  Wrench,
  X,
} from "lucide-react";
import { getMachines } from "../services/api";
import { writeActivityLog } from "../services/logClient";
import {
  formatDisplayMachineName,
  formatMachineName,
  getRecentLotSearches,
  getSetupInfo,
  getStatusInfo,
  isSearchTargetMachine,
  sortLotsByQueue,
  updateRecentLotSearches,
} from "../utils/machineQueueUtils";
import CenterAlert from "../components/CenterAlert";

// Map สำหรับแปลงชื่อเครื่องจักร

// ใช้เทียบ Setup Compare และใช้แสดงใน popup
// หมายเหตุ: specH และ F ไม่อยู่ในชุดนี้ เพราะไม่ต้องใช้เทียบและไม่ต้องแสดงใน popup
// แต่ specH และ F ยังอยู่ในตารางด้านล่างตามเดิม

const displayMoveValue = (value) => {
  const text = String(value ?? "").trim();

  if (
    text === "" ||
    text === "-" ||
    text.toLowerCase() === "null" ||
    text.toLowerCase() === "undefined"
  ) {
    return "-";
  }

  return text;
};

const displayMachineValue = (value) => {
  const text = displayMoveValue(value);
  return text === "-" ? "-" : formatDisplayMachineName(text);
};

const hasMoveLot = (lot) => {
  return (
    displayMoveValue(lot?.targetMachine || lot?.targetMachine) !== "-"
  );
};

const getMoveStatusText = (lot) => {
  if (hasMoveLot(lot)) return "ย้ายงาน";
  return lot?.moveStatus || "ปกติ";
};

const getMoveFromMachine = (lot) => {
  return displayMachineValue(
    lot?.originalMachine ||
      lot?.originalMachine ||
      lot?.actualMachine ||
      lot?.queueMachine ||
      lot?.lineName ||
      lot?.machineName ||
      lot?.queueMachine,
  );
};

const getMoveToMachine = (lot) => {
  return displayMachineValue(
    lot?.targetMachine ||
      lot?.targetMachine ||
      lot?.displayMachine,
  );
};

export default function Machines({ user }) {
  const [searchTerm, setSearchTerm] = useState(() => {
    return new URLSearchParams(window.location.search).get("lot") || "";
  });
  const [allLots, setAllLots] = useState([]);
  const [searchResults, setSearchResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [searched, setSearched] = useState(false);
  const [dataReady, setDataReady] = useState(false);
  const [recentSearches, setRecentSearches] = useState([]);
  const [selectedSetupDetail, setSelectedSetupDetail] = useState(null);
  const [alertMessage, setAlertMessage] = useState("");

  const loadLotData = async ({ force = false } = {}) => {
    setLoading(true);

    try {
      const data = await getMachines({
        includeTechnical: true,
        includeMoveLot: true,
        force,
      });

      const filteredData = (data || [])
        .map((machine) => ({
          ...machine,
          machineName: formatMachineName(machine.machineName),
        }))
        .filter((machine) => isSearchTargetMachine(machine.machineName));

      const lots = [];

      filteredData.forEach((machine) => {
        const sortedLots = sortLotsByQueue(machine.lots || []);

        sortedLots.forEach((lot, index) => {
          const previousLot =
            index > 0
              ? sortedLots[index - 1]
              : lot?.previousLot || null;
          const nextLot =
            index < sortedLots.length - 1 ? sortedLots[index + 1] : null;
          const setupInfo = getSetupInfo(previousLot, lot);

          lots.push({
            ...lot,
            machineName: machine.machineName,
            queueMachine: lot.queueMachine || machine.machineName,
            machineName: lot.machineName || machine.machineName,
            previousLot,
            nextLot,
            totalQueue: sortedLots.length,
            setupInfo,
          });
        });
      });

      setAllLots(lots);
      setDataReady(true);

      return lots;
    } catch (error) {
      console.error("Load LOT Search data error:", error);
      setDataReady(false);
      throw error;
    } finally {
      setLoading(false);
    }
  };

  const handleClearSearch = () => {
    setSearchTerm("");
    setSearchResults([]);
    setSearched(false);
    setAlertMessage("");
    setSelectedSetupDetail(null);

    const params = new URLSearchParams(window.location.search);
    params.delete("lot");

    const queryString = params.toString();

    window.history.replaceState(
      null,
      "",
      `${window.location.pathname}${queryString ? `?${queryString}` : ""}`,
    );
  };

  const handleSearch = async (e, queryOverride = null) => {
    if (e) e.preventDefault();

    const query = String(queryOverride || searchTerm || "")
      .trim()
      .toUpperCase();

    if (!query) {
      setAlertMessage("กรุณากรอก Lot No ที่ต้องการค้นหา");
      return;
    }

    setSearchTerm(query);

    const params = new URLSearchParams(window.location.search);
    params.set("lot", query);

    window.history.replaceState(
      null,
      "",
      `${window.location.pathname}?${params.toString()}`,
    );

    try {
      let sourceLots = allLots;

      if (!dataReady || sourceLots.length === 0) {
        sourceLots = await loadLotData();
      }

      // ต้องเก็บ Logic ค้นหา Lot เดิมไว้
      const results = sourceLots.filter((lot) => {
        const wipLot = String(lot.lotId || "")
          .trim()
          .toUpperCase();

        const mlLot = String(lot.lotId || "")
          .trim()
          .toUpperCase();

        return wipLot.includes(query) || mlLot.includes(query);
      });

      results.sort((a, b) => {
        const machineA = String(a.machineName || "");
        const machineB = String(b.machineName || "");

        if (machineA !== machineB) {
          return machineA.localeCompare(machineB);
        }

        return Number(a.queueNo || 999) - Number(b.queueNo || 999);
      });

      setSearchResults(results);
      setSearched(true);

      const updatedRecents = updateRecentLotSearches(query);
      setRecentSearches(updatedRecents);

      if (results.length === 0) {
        setAlertMessage(`ไม่พบข้อมูล Lot No: "${query}" ในระบบ`);
      } else {
        setAlertMessage("");
      }

      writeActivityLog({
        user,
        type: "LOT_SEARCH",
        level: results.length > 0 ? "INFO" : "WARN",
        page: "LOT Search",
        action: "SEARCH",
        lot: query,
        result: results.length > 0 ? "FOUND" : "NOT_FOUND",
        message: `Search lot ${query}: found ${results.length} result(s)`,
        meta: {
          query,
          resultCount: results.length,
          machines: [
            ...new Set(results.map((item) => item.machineName).filter(Boolean)),
          ],
          lots: results
            .map((item) => item.lotId || item.lotId)
            .filter(Boolean),
        },
      });
    } catch (error) {
      console.error("LOT Search error:", error);

      setSearchResults([]);
      setSearched(false);

      setAlertMessage(
        "ไม่สามารถโหลดข้อมูลการผลิตได้ กรุณาตรวจสอบการเชื่อมต่อแล้วลองใหม่อีกครั้ง",
      );

      writeActivityLog({
        user,
        type: "API_ERROR",
        level: "ERROR",
        page: "LOT Search",
        action: "SEARCH_ERROR",
        lot: query,
        result: "ERROR",
        message: error?.message || "Unable to load LOT Search data",
      });
    }
  };

  useEffect(() => {
    const init = async () => {
      setRecentSearches(getRecentLotSearches());

      try {
        const lots = await loadLotData();

        const lotFromUrl = new URLSearchParams(window.location.search).get(
          "lot",
        );

        if (lotFromUrl) {
          const query = lotFromUrl.trim().toUpperCase();

          setSearchTerm(query);

          const results = lots.filter((lot) => {
            const wipLot = String(lot.lotId || "")
              .trim()
              .toUpperCase();

            const mlLot = String(lot.lotId || "")
              .trim()
              .toUpperCase();

            return wipLot.includes(query) || mlLot.includes(query);
          });

          results.sort((a, b) => {
            const machineA = String(a.machineName || "");
            const machineB = String(b.machineName || "");

            if (machineA !== machineB) {
              return machineA.localeCompare(machineB);
            }

            return Number(a.queueNo || 999) - Number(b.queueNo || 999);
          });

          setSearchResults(results);
          setSearched(true);

          if (results.length === 0) {
            setAlertMessage(`ไม่พบข้อมูล Lot No: "${query}" ในระบบ`);
          }
        }
      } catch (error) {
        console.error("Initial LOT Search load error:", error);

        setSearchResults([]);
        setSearched(false);

        setAlertMessage(
          "ไม่สามารถโหลดข้อมูลการผลิตได้ กรุณาตรวจสอบการเชื่อมต่อแล้วลองใหม่อีกครั้ง",
        );
      }
    };

    init();

    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  return (
    <div className="space-y-6 pt-6">
      <style>{`
        .custom-scrollbar::-webkit-scrollbar {
          height: 6px;
        }
        .custom-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb {
          background-color: #e2e8f0;
          border-radius: 10px;
        }
        .custom-scrollbar::-webkit-scrollbar-thumb:hover {
          background-color: #cbd5e1;
        }
        .dark .custom-scrollbar::-webkit-scrollbar-thumb {
          background-color: #475569;
        }
      `}</style>

      {/* Search Header */}
      <section className="relative overflow-hidden rounded-[2rem] border border-slate-300 bg-gradient-to-br from-cyan-50 via-white to-slate-100 p-6 shadow-lg dark:border-slate-700 dark:from-slate-900 dark:via-slate-950 dark:to-cyan-950/30">
        <div className="absolute right-[-80px] top-[-80px] h-56 w-56 rounded-full bg-cyan-400/20 blur-3xl" />
        <div className="relative flex items-start gap-4">
          <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-cyan-600 text-white shadow-lg shadow-cyan-600/20">
            <PackageSearch size={28} strokeWidth={2.2} />
          </div>
          <div>
            <p className="text-xs font-black uppercase tracking-[0.22em] text-cyan-700 dark:text-cyan-300">
              LOT Tracking
            </p>
            <h1 className="mt-1 text-2xl font-black tracking-tight text-slate-900 sm:text-3xl dark:text-white">
              Quick LOT Search
            </h1>
            <p className="mt-2 text-base font-medium text-slate-600 dark:text-slate-300">
              กรอกหมายเลข Lot No เพื่อตรวจสอบคิว สถานะเครื่อง และข้อมูล
              Technical
            </p>
          </div>
        </div>

        <form
          onSubmit={handleSearch}
          className="mt-6 grid grid-cols-1 gap-3 lg:grid-cols-[minmax(0,1fr)_auto_auto_auto] lg:items-center"
        >
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="ระบุ Lot No..."
            className="h-14 w-full min-w-0 rounded-2xl border border-slate-300 bg-slate-50 px-5 text-lg font-bold text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:focus:border-cyan-400"
          />

          <button
            type="submit"
            disabled={loading}
            className="inline-flex h-12 w-full items-center justify-center gap-2 whitespace-nowrap rounded-xl bg-cyan-600 px-5 text-sm font-black text-white shadow-sm transition hover:bg-cyan-700 disabled:opacity-50 lg:h-14 lg:w-auto"
          >
            <Search size={18} />
            {loading ? "Loading..." : "Search"}
          </button>

          <button
            type="button"
            onClick={handleClearSearch}
            disabled={loading || (!searchTerm && !searched)}
            className="inline-flex h-12 w-full items-center justify-center gap-2 whitespace-nowrap rounded-xl bg-slate-500 px-4 text-sm font-black text-white shadow-sm transition hover:bg-slate-600 disabled:cursor-not-allowed disabled:opacity-50 lg:h-14 lg:w-auto"
          >
            <Eraser size={18} />
            Clear
          </button>

          <button
            type="button"
            onClick={async () => {
              const query = searchTerm.trim().toUpperCase();

              if (!query) {
                setAlertMessage("กรุณากรอก Lot No ก่อนกด Refresh Data");
                return;
              }

              try {
                const lots = await loadLotData({
                  force: true,
                });

                const results = lots.filter((lot) => {
                  const wipLot = String(lot.lotId || "")
                    .trim()
                    .toUpperCase();

                  const mlLot = String(lot.lotId || "")
                    .trim()
                    .toUpperCase();

                  return wipLot.includes(query) || mlLot.includes(query);
                });

                results.sort((a, b) => {
                  const machineA = String(a.machineName || "");
                  const machineB = String(b.machineName || "");

                  if (machineA !== machineB) {
                    return machineA.localeCompare(machineB);
                  }

                  return Number(a.queueNo || 999) - Number(b.queueNo || 999);
                });

                setSearchResults(results);
                setSearched(true);

                if (results.length === 0) {
                  setAlertMessage(`ไม่พบข้อมูล Lot No: "${query}" ในระบบ`);
                } else {
                  setAlertMessage("");
                }
              } catch (error) {
                console.error("Refresh LOT Search data error:", error);

                setSearchResults([]);
                setSearched(false);

                setAlertMessage(
                  "ไม่สามารถรีเฟรชข้อมูลการผลิตได้ กรุณาตรวจสอบการเชื่อมต่อแล้วลองใหม่อีกครั้ง",
                );
              }
            }}
            disabled={loading}
            className="inline-flex h-12 w-full items-center justify-center gap-2 whitespace-nowrap rounded-xl bg-slate-600 px-5 text-sm font-black text-white shadow-sm transition hover:bg-slate-700 disabled:opacity-50 lg:h-14 lg:w-auto"
          >
            <RefreshCw size={18} className={loading ? "animate-spin" : ""} />
            Refresh Data
          </button>
        </form>

        {recentSearches.length > 0 && (
          <div className="mt-5 flex flex-wrap items-center gap-2">
            <span className="inline-flex items-center gap-2 text-sm font-black text-slate-500 dark:text-slate-400">
              <Clock3 size={16} />
              ประวัติการค้นหา:
            </span>

            {recentSearches.map((historyLot) => (
              <button
                key={historyLot}
                type="button"
                onClick={() => handleSearch(null, historyLot)}
                className="rounded-xl bg-slate-100 px-4 py-2 text-sm font-bold text-slate-600 transition hover:bg-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700"
              >
                {historyLot}
              </button>
            ))}
          </div>
        )}
      </section>

      {/* Search Result */}
      {searched && (
        <section className="space-y-4">
          <div className="rounded-3xl border border-slate-300 bg-white p-6 shadow-md dark:border-slate-700 dark:bg-slate-900 dark:shadow-black/30">
            <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h3 className="inline-flex items-center gap-2 text-2xl font-black text-slate-900 dark:text-slate-100">
                  <Search
                    size={23}
                    className="text-cyan-600 dark:text-cyan-300"
                  />
                  ผลการค้นหา
                </h3>

                <p className="mt-2 text-base font-bold text-cyan-600 dark:text-cyan-400">
                  Lot: {searchTerm} / พบทั้งหมด {searchResults.length} รายการ
                </p>
              </div>

              {/* <div className="inline-flex w-fit items-center rounded-2xl bg-cyan-50 px-5 py-3 text-cyan-700 shadow-sm dark:bg-cyan-950/30 dark:text-cyan-300">
                <span className="text-sm font-black">
                  {searchResults.length} รายการ
                </span>
              </div> */}
            </div>
          </div>

          {searchResults.length === 0 ? (
            <div className="rounded-3xl border border-dashed border-slate-300 bg-slate-50 p-10 text-center dark:border-slate-700 dark:bg-slate-950">
              <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-2xl bg-amber-100 text-amber-700 dark:bg-amber-950/40 dark:text-amber-300">
                <AlertTriangle size={24} />
              </div>
              <p className="mt-3 text-lg font-bold text-slate-600 dark:text-slate-300">
                ไม่พบข้อมูล Lot No: "{searchTerm}" ในระบบ
              </p>
            </div>
          ) : (
            <div className="rounded-3xl border border-slate-300 bg-white shadow-md overflow-hidden flex flex-col dark:border-slate-700 dark:bg-slate-900 dark:shadow-black/30">
              <div className="border-b border-slate-100 p-6 dark:border-slate-800">
                <h3 className="inline-flex items-center gap-2 text-xl font-bold text-slate-900 dark:text-slate-100">
                  <Table2
                    size={21}
                    className="text-cyan-600 dark:text-cyan-300"
                  />
                  LOT Search Results
                </h3>
                <p className="mt-1 text-sm font-medium text-cyan-600 dark:text-cyan-400">
                  แสดงผลแบบตารางเดียวกับ Machine Queue
                </p>
              </div>

              <div className="relative overflow-x-auto custom-scrollbar">
                <table className="w-full min-w-max text-left text-sm text-slate-600 dark:text-slate-400 whitespace-nowrap">
                  <thead className="bg-slate-50/80 text-xs uppercase text-slate-500 dark:bg-slate-950 dark:text-slate-400 border-b border-slate-200 dark:border-slate-800">
                    <tr>
                      <th className="px-4 py-4 text-center">Queue</th>
                      <th className="px-4 py-4">Machine</th>
                      <th className="px-4 py-4 text-center">Status</th>
                      <th className="px-4 py-4">Lot No</th>
                      <th className="px-4 py-3 whitespace-nowrap">
                        สถานะการย้าย
                      </th>
                      <th className="px-4 py-4">Product Code</th>
                      <th className="px-4 py-4">Setup Compare</th>
                      <th className="px-4 py-4">Stop Code</th>
                      <th className="px-4 py-4">Part Name</th>
                      <th className="px-4 py-4">Unit Name</th>
                      <th className="px-4 py-4">Input Date</th>
                      <th className="px-4 py-4">Status Process</th>
                      <th className="px-4 py-3 whitespace-nowrap">
                        Machine เดิม
                      </th>
                      <th className="px-4 py-3 whitespace-nowrap">
                        Machine ใหม่
                      </th>
                      <th className="px-4 py-4">Tracking No</th>
                      <th className="px-4 py-4">Qty</th>
                      <th className="px-4 py-4">Input Qty</th>
                      <th className="px-4 py-4">Output Qty</th>
                      <th className="px-4 py-4">%งานผลิตปัจจุบัน</th>
                      <th className="px-4 py-4">Lot Status</th>
                      <th className="px-4 py-4">Comment</th>

                      <th className="px-4 py-4">specA</th>
                      <th className="px-4 py-4">Spec B</th>
                      <th className="px-4 py-4">specC</th>
                      <th className="px-4 py-4">specD</th>
                      <th className="px-4 py-4">specE</th>
                      <th className="px-4 py-4">Spec F</th>
                      <th className="px-4 py-4">Spec G</th>
                      <th className="px-4 py-4">specH</th>
                      <th className="px-4 py-4">Spec I</th>
                      <th className="px-4 py-4">specJ</th>
                      <th className="px-4 py-4">specK</th>
                      <th className="px-4 py-4">Spec L</th>
                      <th className="px-4 py-4">specM</th>
                      <th className="px-4 py-4">Spec N</th>
                      <th className="px-4 py-4">Spec O</th>
                      <th className="px-4 py-4">Spec P</th>
                      <th className="px-4 py-4">Spec Q</th>
                      <th className="px-4 py-4">Spec R</th>
                      <th className="px-4 py-4">Spec S</th>
                      <th className="px-4 py-4">Spec T</th>
                      <th className="px-4 py-4">specU</th>

                      <th className="px-4 py-4">Operator ID</th>
                      <th className="px-4 py-4">Start Date</th>
                    </tr>
                  </thead>

                  <tbody>
                    {searchResults.map((lot, idx) => {
                      const baseStatusInfo = getStatusInfo(lot);

                      const isCurrentMachineLot =
                        String(lot.sourceType || "")
                          .trim()
                          .toUpperCase() === "CURRENT";

                      const statusInfo = isCurrentMachineLot
                        ? {
                            label: "กำลังผลิต",
                            colors:
                              "bg-emerald-600 text-white ring-1 ring-emerald-600 dark:bg-emerald-600 dark:text-white",
                          }
                        : baseStatusInfo;
                      const setupInfo =
                        lot.setupInfo || getSetupInfo(lot.previousLot, lot);

                      const inputQty = parseFloat(lot.inputQty) || 0;
                      const outputQty = parseFloat(lot.outputQty) || 0;

                      const rawProgressPercent =
                        inputQty > 0
                          ? Math.round((outputQty / inputQty) * 100)
                          : 0;

                      const progressBarPercent = Math.max(
                        0,
                        Math.min(rawProgressPercent, 100),
                      );

                      const progressText =
                        inputQty > 0 ? `${rawProgressPercent}%` : "-";

                      return (
                        <tr
                          key={`${lot.machineName || "M"}-${lot.queueNo || idx}-${lot.lotId || lot.lotId || idx}`}
                          className="border-b border-slate-100 transition hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800/50"
                        >
                          <td className="px-4 py-3 text-center font-bold text-slate-700 dark:text-slate-300">
                            {lot.queueNo || "-"}
                          </td>

                          <td className="px-4 py-3 font-black text-cyan-700 dark:text-cyan-300">
                            {formatDisplayMachineName(
                              lot.machineName || lot.machineName || "-",
                            )}
                          </td>

                          <td className="px-4 py-3 text-center">
                            <span
                              className={`px-2.5 py-1 rounded-lg text-[11px] font-bold uppercase tracking-wider ${statusInfo.colors}`}
                            >
                              {statusInfo.label}
                            </span>
                          </td>

                          <td className="px-4 py-3 font-semibold text-slate-900 dark:text-slate-100">
                            {lot.lotId || lot.lotId || "-"}
                          </td>

                          <td className="px-4 py-3 whitespace-nowrap">
                            <span
                              className={`inline-flex rounded-full px-3 py-1 text-xs font-black ${
                                hasMoveLot(lot)
                                  ? "bg-amber-100 text-amber-700 ring-1 ring-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:ring-amber-900/60"
                                  : "bg-slate-100 text-slate-600 ring-1 ring-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:ring-slate-700"
                              }`}
                            >
                              {getMoveStatusText(lot)}
                            </span>
                          </td>

                          <td className="px-4 py-3 text-center text-slate-600 dark:text-slate-400">
                            {lot.productCode || "-"}
                          </td>

                          <td className="px-4 py-3 text-center">
                            <button
                              type="button"
                              onClick={() => {
                                writeActivityLog({
                                  user,
                                  type: "SETUP_DETAIL",
                                  level: "INFO",
                                  page: "LOT Search",
                                  action: "OPEN_SU_SS",
                                  machine: lot.machineName || lot.machineName || "",
                                  lot: lot.lotId || lot.lotId || "",
                                  result: setupInfo.code,
                                  message: `Open ${setupInfo.code} detail from LOT Search`,
                                  meta: {
                                    queueNo: lot.queueNo,
                                    hasDiff: setupInfo.hasDiff,
                                    diffItems: setupInfo.details
                                      .filter((item) => item.isDifferent)
                                      .map((item) => item.key),
                                  },
                                });

                                setSelectedSetupDetail({
                                  lot,
                                  previousLot: lot.previousLot,
                                  setupInfo,
                                  queueNo: lot.queueNo,
                                  machineName: lot.machineName || lot.machineName,
                                });
                              }}
                              className={
                                setupInfo.code === "CHANGE"
                                  ? "font-black text-red-600 underline decoration-red-400 underline-offset-4 hover:text-red-700"
                                  : setupInfo.hasPreviousLot
                                    ? "font-bold text-emerald-700 underline decoration-emerald-400 underline-offset-4 hover:text-emerald-800 dark:text-emerald-300"
                                    : "font-bold text-slate-400 underline decoration-slate-300 underline-offset-4 hover:text-slate-500 dark:text-slate-500"
                              }
                              title={
                                setupInfo.hasPreviousLot
                                  ? "กดเพื่อดูรายละเอียด Technical setup"
                                  : "ยังไม่พบ Lot ก่อนหน้าที่บันทึกไว้ จึงยังไม่สรุป Setup Compare"
                              }
                            >
                              <span className="inline-flex items-center gap-1.5">
                                <Wrench size={14} />
                                {setupInfo.code}
                              </span>
                            </button>
                          </td>

                          <td
                            className={`px-4 py-3 font-medium ${
                              lot.stopCode && lot.stopCode !== "-"
                                ? "text-rose-600 dark:text-rose-400"
                                : "text-slate-500"
                            }`}
                          >
                            {lot.stopCode || "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                            {lot.partName || lot.partName || "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                            {lot.unitName || "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-500 dark:text-slate-400">
                            {lot.inputDate || lot.inputDate || "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                            {lot.processStatus || "-"}
                          </td>

                          <td className="px-4 py-3 whitespace-nowrap font-bold text-slate-700 dark:text-slate-200">
                            {getMoveFromMachine(lot)}
                          </td>

                          <td className="px-4 py-3 whitespace-nowrap">
                            {hasMoveLot(lot) ? (
                              <span className="inline-flex rounded-full bg-emerald-100 px-3 py-1 text-xs font-black text-emerald-700 ring-1 ring-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:ring-emerald-900/60">
                                {getMoveToMachine(lot)}
                              </span>
                            ) : (
                              <span className="text-slate-400 dark:text-slate-500">
                                -
                              </span>
                            )}
                          </td>

                          <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                            {lot.trackingNo || lot.trackingNo || "-"}
                          </td>

                          <td className="px-4 py-3 text-right font-semibold text-cyan-600 dark:text-cyan-400">
                            {lot.plannedQty != null &&
                            !Number.isNaN(parseFloat(lot.plannedQty))
                              ? parseFloat(lot.plannedQty).toFixed(2)
                              : "-"}
                          </td>

                          <td className="px-4 py-3 text-right text-slate-600 dark:text-slate-400">
                            {lot.inputQty || "-"}
                          </td>

                          <td className="px-4 py-3 text-right text-slate-600 dark:text-slate-400">
                            {lot.outputQty || "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                            <div className="flex min-w-[130px] items-center gap-2">
                              <div className="h-2 w-20 overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800">
                                <div
                                  className={`h-full rounded-full transition-all duration-500 ${
                                    rawProgressPercent >= 100
                                      ? "bg-cyan-500"
                                      : "bg-emerald-500"
                                  }`}
                                  style={{
                                    width: `${progressBarPercent}%`,
                                  }}
                                />
                              </div>

                              <span className="w-10 text-right font-bold text-slate-700 dark:text-slate-300">
                                {progressText}
                              </span>
                            </div>
                          </td>

                          <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                            {lot.lotStatus || "-"}
                          </td>

                          <td
                            className="max-w-[250px] truncate px-4 py-3 text-slate-500 dark:text-slate-400"
                            title={lot.comment || "-"}
                          >
                            {lot.comment || "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                            {lot.specA || "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                            {lot.specB || "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                            {lot.specC || "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                            {lot.specD || "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                            {lot.specE || "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                            {lot.specF != null && lot.specF !== ""
                              ? Number(lot.specF).toFixed(1)
                              : "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                            {lot.specG || "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                            {lot.specH || "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                            {lot.specI || "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                            {lot.specJ || "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                            {lot.specK || "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                            {lot.specL || "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                            {lot.specM || "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                            {lot.specN || "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                            {lot.specO || "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                            {lot.specP || "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                            {lot.specQ || "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                            {lot.specR || "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                            {lot.specS || "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                            {lot.specT || "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                            {lot.specU || "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-500 dark:text-slate-400">
                            {lot.operatorId || "-"}
                          </td>

                          <td className="px-4 py-3 text-slate-500 dark:text-slate-400">
                            {lot.startTime || "-"}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </section>
      )}

      {/* Setup Compare Detail Modal */}
      {selectedSetupDetail && (
        <div className="fixed inset-0 z-[120] flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-sm">
          <div className="flex max-h-[90vh] w-full max-w-lg flex-col overflow-hidden rounded-lg bg-white shadow-2xl dark:bg-slate-950">
            <div className="flex items-center justify-between bg-amber-500 px-5 py-4 text-slate-900">
              <div>
                <h3 className="text-base font-bold">
                  เครื่องมือที่ต้องเปลี่ยน
                </h3>
                <p className="mt-1 text-xs font-semibold text-slate-800">
                  {formatDisplayMachineName(
                    selectedSetupDetail.machineName || "-",
                  )}{" "}
                  / Queue {selectedSetupDetail.queueNo || "-"} /{" "}
                  {selectedSetupDetail.lot?.lotId ||
                    selectedSetupDetail.lot?.lotId ||
                    "-"}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setSelectedSetupDetail(null)}
                className="text-xl font-black text-slate-700 hover:text-slate-950"
              >
                ×
              </button>
            </div>

            <div className="border-b border-amber-200 bg-amber-50 px-5 py-3 text-center dark:border-amber-900/60 dark:bg-amber-950/30">
              <p className="text-sm font-black text-amber-900 dark:text-amber-200">
                {selectedSetupDetail.setupInfo.code === "CHANGE"
                  ? "มีรายการที่ต้อง Setup / เปลี่ยนค่า"
                  : selectedSetupDetail.setupInfo.hasPreviousLot
                    ? "Spec เหมือนคิวก่อนหน้า ไม่ต้อง Setup เพิ่ม"
                    : "ยังไม่พบ Lot ก่อนหน้าที่บันทึกไว้ จึงยังไม่สรุป Setup Compare"}
              </p>
            </div>

            <div className="flex-1 overflow-y-auto">
              <section className="bg-yellow-50 px-7 py-5 dark:bg-yellow-950/20">
                <h4 className="mb-4 text-center font-black text-yellow-900 dark:text-yellow-200">
                  เปลี่ยนสำหรับช่าง
                </h4>

                <div className="space-y-3 text-sm">
                  {selectedSetupDetail.setupInfo.details
                    .filter((item) => item.group === "technician")
                    .map((item) => (
                      <p
                        key={item.key}
                        className={
                          item.isDifferent
                            ? "font-bold text-red-600 dark:text-red-400"
                            : "text-slate-700 dark:text-slate-200"
                        }
                        title={
                          item.isDifferent
                            ? `ก่อนหน้า: ${item.previousDisplay} | ปัจจุบัน: ${item.currentDisplay}`
                            : item.currentDisplay
                        }
                      >
                        {item.label}: {item.currentDisplay}
                      </p>
                    ))}
                </div>
              </section>

              <section className="border-t border-slate-200 bg-orange-50/50 px-7 py-5 dark:border-slate-800 dark:bg-orange-950/10">
                <h4 className="mb-4 text-center font-black text-orange-900 dark:text-orange-200">
                  เปลี่ยนสำหรับพนักงาน
                </h4>

                <div className="space-y-3 text-sm">
                  {selectedSetupDetail.setupInfo.details
                    .filter((item) => item.group === "operator")
                    .map((item) => (
                      <p
                        key={item.key}
                        className={
                          item.isDifferent
                            ? "font-bold text-red-600 dark:text-red-400"
                            : "text-slate-700 dark:text-slate-200"
                        }
                        title={
                          item.isDifferent
                            ? `ก่อนหน้า: ${item.previousDisplay} | ปัจจุบัน: ${item.currentDisplay}`
                            : item.currentDisplay
                        }
                      >
                        {item.label}: {item.currentDisplay}
                      </p>
                    ))}
                </div>
              </section>
            </div>

            <div className="flex justify-end border-t border-slate-200 bg-white px-5 py-4 dark:border-slate-800 dark:bg-slate-950">
              <button
                type="button"
                onClick={() => setSelectedSetupDetail(null)}
                className="inline-flex items-center gap-2 rounded-lg bg-slate-600 px-5 py-2.5 font-bold text-white transition hover:bg-slate-700"
              >
                <X size={17} />
                Close
              </button>
            </div>
          </div>
        </div>
      )}
      <CenterAlert
        open={Boolean(alertMessage)}
        title="แจ้งเตือน LOT Search"
        message={alertMessage}
        variant="warning"
        onClose={() => setAlertMessage("")}
      />
    </div>
  );
}
