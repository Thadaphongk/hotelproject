import DemoGuideButton from "../components/DemoGuideButton";
import { useEffect, useRef, useState } from "react";
import {
  ArrowDown,
  ArrowUp,
  ChevronDown,
  CircleHelp,
  Database,
  Eraser,
  ListChecks,
  ListPlus,
  LockKeyhole,
  RefreshCw,
  RotateCcw,
  Save,
  SearchCheck,
  Trash2,
  X,
} from "lucide-react";
import CenterAlert from "../components/CenterAlert";
import MachineQueueTable from "../components/MachineQueueTable";
import { getMachines } from "../services/api";
import {
  clearSortLots,
  getSortLots,
  saveSortLots,
} from "../services/sortLotClient";
import { writeActivityLog } from "../services/logClient";
import {
  SEQUENCE_DISPLAY_MACHINES,
  toDisplayMachineCode,
  toQueueMachineCode,
} from "../config/sequenceMachines";
import { formatDateOnly } from "../utils/displayFormat";

const getEmployeeId = (user) =>
  String(user?.id || user?.empCode || user?.employeeId || "")
    .trim()
    .toUpperCase();

const getEmployeeName = (user) =>
  String(
    user?.name || user?.empName || user?.displayName || user?.empName_TH || "",
  ).trim();

const getLotNo = (row) =>
  String(row?.lotId || row?.lotId || row?.lotId || "")
    .trim()
    .toUpperCase();

const getPartName = (row) =>
  String(row?.partName || row?.partName || row?.partName || "-").trim() ||
  "-";

const getInputDate = (row) =>
  formatDateOnly(
    row?.queueInputDate ||
      row?.inputDate ||
      row?.inputDate ||
      row?.inputDate,
  );

const getStatusText = (row) => {
  const source = String(row?.sourceType || "")
    .trim()
    .toUpperCase();

  if (source === "CURRENT") return "กำลังผลิต";

  return (
    String(
      row?.statusDescription ||
        row?.processStatus ||
        row?.statusProcess ||
        "-",
    ).trim() || "-"
  );
};

const isCurrentMachineLot = (row) =>
  String(row?.sourceType || "")
    .trim()
    .toUpperCase() === "CURRENT";

const isNextDayInputLot = (row) => {
  const statusProcess = String(
    row?.processStatus || row?.statusProcess || row?.processStatus || "",
  )
    .trim()
    .toUpperCase();

  const sortGroup = Number(row?.sortGroup);

  return statusProcess === "PLANNED" || sortGroup === 3;
};

const isValidLotFormat = (lotId) => /^LOT-DEMO-\d{3}$/.test(lotId);

const parseLotInput = (value) => {
  const text = String(value || "")
    .trim()
    .toUpperCase();
  if (!text) return [];

  const tokens = text
    .split(/[\s,;|]+/)
    .map((item) => item.trim())
    .filter(Boolean);

  const results = [];

  for (const token of tokens) {
    results.push(token);
  }

  return results;
};

function MachineDropdown({ value, onChange, disabled = false }) {
  const [open, setOpen] = useState(false);
  const dropdownRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setOpen(false);
      }
    };

    document.addEventListener("mousedown", handleClickOutside);

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <div ref={dropdownRef} className="relative">
      <button
        type="button"
        disabled={disabled}
        onClick={() => setOpen((current) => !current)}
        onKeyDown={(event) => {
          if (event.key === "Escape") setOpen(false);
        }}
        className="mt-2 flex h-14 w-full items-center justify-between rounded-2xl border border-slate-300 bg-slate-50 px-4 text-left text-lg font-bold text-slate-900 outline-none transition hover:border-cyan-400 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 disabled:cursor-not-allowed disabled:opacity-60 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:focus:border-cyan-400"
      >
        <span
          className={
            value
              ? "truncate text-slate-900 dark:text-slate-100"
              : "truncate text-slate-500 dark:text-slate-400"
          }
        >
          {value || "กรุณาเลือกเครื่องจักร"}
        </span>

        <ChevronDown
          size={20}
          className={`shrink-0 text-slate-500 transition-transform dark:text-slate-400 ${
            open ? "rotate-180" : ""
          }`}
        />
      </button>

      {open ? (
        <div className="absolute left-0 right-0 z-[90] mt-2 max-h-72 overflow-y-auto rounded-2xl border border-slate-300 bg-white py-2 shadow-xl ring-1 ring-black/5 dark:border-slate-700 dark:bg-slate-900">
          <button
            type="button"
            onClick={() => {
              onChange("");
              setOpen(false);
            }}
            className={`block w-full px-4 py-3 text-left text-base font-bold transition hover:bg-cyan-50 hover:text-cyan-700 dark:hover:bg-slate-800 dark:hover:text-cyan-300 ${
              !value
                ? "bg-slate-100 text-slate-900 dark:bg-slate-800 dark:text-white"
                : "text-slate-600 dark:text-slate-300"
            }`}
          >
            กรุณาเลือกเครื่องจักร
          </button>

          {SEQUENCE_DISPLAY_MACHINES.map((machine) => (
            <button
              key={machine}
              type="button"
              onClick={() => {
                onChange(machine);
                setOpen(false);
              }}
              className={`block w-full px-4 py-3 text-left text-base font-bold transition hover:bg-cyan-50 hover:text-cyan-700 dark:hover:bg-slate-800 dark:hover:text-cyan-300 ${
                value === machine
                  ? "bg-cyan-50 text-cyan-700 dark:bg-cyan-950/40 dark:text-cyan-300"
                  : "text-slate-700 dark:text-slate-200"
              }`}
            >
              {machine}
            </button>
          ))}
        </div>
      ) : null}
    </div>
  );
}

const findMachineData = (machines, selectedMachine) => {
  const selectedQueueMachine = toQueueMachineCode(selectedMachine);

  return (machines || []).find(
    (item) => toQueueMachineCode(item?.machineName) === selectedQueueMachine,
  );
};

const buildLockedCurrentDraftRow = (queueRows = []) => {
  const currentRow = queueRows.find(isCurrentMachineLot);

  const lotId = getLotNo(currentRow);

  if (!currentRow || !lotId) {
    return null;
  }

  return {
    lotId,
    row: currentRow,
    locked: true,
  };
};

export default function SequenceLot({ user }) {
  const employeeId = getEmployeeId(user);
  const employeeName = getEmployeeName(user);

  const [machine, setMachine] = useState("");
  const [allMachines, setAllMachines] = useState([]);
  const [queueRows, setQueueRows] = useState([]);
  const [savedRows, setSavedRows] = useState([]);
  const [draftRows, setDraftRows] = useState([]);
  const [lotInput, setLotInput] = useState("");

  const [loading, setLoading] = useState(false);
  const [checking, setChecking] = useState(false);
  const [saving, setSaving] = useState(false);

  const [alert, setAlert] = useState(null);
  const [confirmAction, setConfirmAction] = useState(null);
  const [moveFeedback, setMoveFeedback] = useState(null);
  const [pullQueuePrompt, setPullQueuePrompt] = useState(null);
  const [showUsageGuide, setShowUsageGuide] = useState(false);

  useEffect(() => {
    if (!showUsageGuide) return undefined;

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    const handleKeyDown = (event) => {
      if (event.key === "Escape") {
        setShowUsageGuide(false);
      }
    };

    document.addEventListener("keydown", handleKeyDown);

    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.body.style.overflow = previousOverflow;
    };
  }, [showUsageGuide]);

  const queueMachine = toQueueMachineCode(machine);

  const buildDraftFromSavedRows = (nextSavedRows, nextQueueRows) => {
    const nextQueueMap = new Map(
      nextQueueRows.map((row) => [getLotNo(row), row]),
    );

    /*
     * Current Lot จะอยู่ลำดับแรกเสมอ
     * แม้ยังไม่เคยบันทึก Manual Sequence
     */
    const currentDraftRow = buildLockedCurrentDraftRow(nextQueueRows);

    const currentLotno = currentDraftRow?.lotId || "";

    const savedDraftRows = nextSavedRows
      .map((saved) => {
        const lotId = getLotNo(saved);
        const queueRow = nextQueueMap.get(lotId);

        /*
         * Current Lot ถูกเพิ่มแยกด้านบนแล้ว
         * จึงต้องกันไม่ให้เกิดรายการซ้ำ
         */
        if (
          !queueRow ||
          lotId === currentLotno ||
          isCurrentMachineLot(queueRow) ||
          isNextDayInputLot(queueRow)
        ) {
          return null;
        }

        return {
          lotId,
          row: queueRow,
          locked: false,
        };
      })
      .filter(Boolean);

    return currentDraftRow
      ? [currentDraftRow, ...savedDraftRows]
      : savedDraftRows;
  };

  useEffect(() => {
    let cancelled = false;

    const preloadMachines = async () => {
      try {
        const data = await getMachines({
          includeTechnical: true,
          includeMoveLot: true,
          force: false,
        });

        if (!cancelled) {
          setAllMachines(Array.isArray(data) ? data : []);
        }
      } catch (error) {
        // ไม่ต้อง Popup ตอน Preload
        // เมื่อ User เลือกเครื่อง ระบบจะลองโหลดอีกครั้ง
        console.warn("Preload sequence machines failed:", error);
      }
    };

    void preloadMachines();

    return () => {
      cancelled = true;
    };
  }, []);

  const loadMachineData = async (
    selectedMachine,
    { force = false, restoreDraft = true } = {},
  ) => {
    if (!selectedMachine) {
      setQueueRows([]);
      setSavedRows([]);
      setDraftRows([]);
      return;
    }

    const cachedMachineData = findMachineData(allMachines, selectedMachine);

    const cachedQueueRows = Array.isArray(cachedMachineData?.lots)
      ? cachedMachineData.lots
      : [];

    // แสดงข้อมูลจาก Memory ทันที ไม่ต้องรอ API
    if (!force && cachedMachineData) {
      setQueueRows(cachedQueueRows);
    }

    // แสดง Loading เต็มตารางเฉพาะตอนยังไม่มี Cache
    setLoading(force || !cachedMachineData);

    try {
      const [machines, savedResult] = await Promise.all([
        getMachines({
          includeTechnical: true,
          includeMoveLot: true,
          force,

          // ปกติไม่ต้องล้าง Technical Cache
          refreshTechnical: false,
        }),

        getSortLots(selectedMachine),
      ]);

      const nextMachines = Array.isArray(machines) ? machines : [];

      setAllMachines(nextMachines);

      const machineData = findMachineData(nextMachines, selectedMachine);

      const nextQueueRows = Array.isArray(machineData?.lots)
        ? machineData.lots
        : [];

      const nextSavedRows = Array.isArray(savedResult?.rows)
        ? savedResult.rows
        : [];

      setQueueRows(nextQueueRows);
      setSavedRows(nextSavedRows);

      if (restoreDraft) {
        setDraftRows(buildDraftFromSavedRows(nextSavedRows, nextQueueRows));
      }
    } catch (error) {
      console.error("Load sequence machine data error:", error);

      // หากมี Cache เดิม ให้เก็บตารางเดิมไว้
      if (!cachedMachineData) {
        setQueueRows([]);
        setSavedRows([]);
        setDraftRows([]);
      }

      setAlert({
        title: "โหลดข้อมูลไม่สำเร็จ",
        message:
          error?.message ||
          "ไม่สามารถโหลดคิวงานและลำดับที่บันทึกไว้ได้ กรุณาลองใหม่อีกครั้ง",
        variant: "danger",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleMachineChange = (nextMachine) => {
    setMachine(nextMachine);
    setLotInput("");
    setSavedRows([]);
    setDraftRows([]);

    if (!nextMachine) {
      setQueueRows([]);
      return;
    }

    const cachedMachineData = findMachineData(allMachines, nextMachine);

    // เปลี่ยนเครื่องแล้วแสดงตารางจาก Memory ทันที
    setQueueRows(
      Array.isArray(cachedMachineData?.lots) ? cachedMachineData.lots : [],
    );

    void loadMachineData(nextMachine, {
      force: false,
      restoreDraft: true,
    });
  };

  const getPullableQueueLots = () => {
    const existingDraftLots = new Set(draftRows.map((item) => item.lotId));

    const seenLots = new Set();
    const lots = [];

    let lockedCurrent = 0;
    let skippedInput = 0;
    let skippedDraft = 0;
    let skippedDuplicate = 0;
    let skippedInvalid = 0;

    for (const row of queueRows) {
      const lotId = getLotNo(row);

      // ข้าม LOT ที่กำลังผลิต
      if (isCurrentMachineLot(row)) {
        /*
         * Current Lot ไม่ต้องนำลงช่องกรอก
         * เพราะถูกเพิ่มใน Draft และล็อกเป็น No.1 แล้ว
         */
        lockedCurrent += 1;
        continue;
      }

      // ข้ามงาน INPUT หรืองานจ่ายวันถัดไป
      if (isNextDayInputLot(row)) {
        skippedInput += 1;
        continue;
      }

      // ข้าม LOT ว่างหรือรูปแบบไม่ถูกต้อง
      if (!lotId || !isValidLotFormat(lotId)) {
        skippedInvalid += 1;
        continue;
      }

      // ข้าม LOT ที่อยู่ใน Draft แล้ว
      if (existingDraftLots.has(lotId)) {
        skippedDraft += 1;
        continue;
      }

      // ข้าม LOT ซ้ำใน Queue
      if (seenLots.has(lotId)) {
        skippedDuplicate += 1;
        continue;
      }

      seenLots.add(lotId);
      lots.push(lotId);
    }

    return {
      lots,
      lockedCurrent,
      skippedInput,
      skippedDraft,
      skippedDuplicate,
      skippedInvalid,
    };
  };

  const buildPullSummaryMessage = (result, addedCount) => {
    const messages = [`เพิ่ม LOT ลงช่องกรอก ${addedCount} รายการ`];

    if (result.lockedCurrent > 0) {
      messages.push(
        `ล็อก LOT ที่กำลังผลิตไว้ลำดับ 1 จำนวน ${result.lockedCurrent} รายการ`,
      );
    }

    if (result.skippedInput > 0) {
      messages.push(
        `ข้ามงานจ่ายวันถัดไป / INPUT ${result.skippedInput} รายการ`,
      );
    }

    if (result.skippedDraft > 0) {
      messages.push(
        `ข้าม LOT ที่อยู่ในรายการแล้ว ${result.skippedDraft} รายการ`,
      );
    }

    if (result.skippedDuplicate > 0) {
      messages.push(`ข้าม LOT ซ้ำ ${result.skippedDuplicate} รายการ`);
    }

    if (result.skippedInvalid > 0) {
      messages.push(
        `ข้าม LOT ที่ข้อมูลไม่สมบูรณ์ ${result.skippedInvalid} รายการ`,
      );
    }

    return messages.join("\n");
  };

  const applyPulledQueueLots = (mode, result = pullQueuePrompt) => {
    if (!result) return;

    const currentInputLots = [...new Set(parseLotInput(lotInput))];

    let nextLots = [];
    let addedCount = 0;

    if (mode === "replace") {
      nextLots = result.lots;
      addedCount = result.lots.length;
    } else {
      const currentLotSet = new Set(currentInputLots);

      const newLots = result.lots.filter((lotId) => !currentLotSet.has(lotId));

      nextLots = [...currentInputLots, ...newLots];
      addedCount = newLots.length;
    }

    setLotInput(nextLots.join("\n"));
    setPullQueuePrompt(null);

    setAlert({
      title:
        addedCount > 0 ? "ดึง LOT จากคิวแล้ว" : "ไม่มี LOT ใหม่ที่ต้องเพิ่ม",
      message: buildPullSummaryMessage(result, addedCount),
      variant: addedCount > 0 ? "success" : "info",
    });
  };

  const handlePullLotsFromQueue = () => {
    if (!machine) {
      setAlert({
        title: "กรุณาเลือกเครื่องจักร",
        message: "ต้องเลือกเครื่องจักรก่อนดึง LOT จากคิว",
        variant: "warning",
      });
      return;
    }

    if (loading) {
      setAlert({
        title: "กำลังโหลดข้อมูล",
        message: "กรุณารอให้ข้อมูลคิวโหลดเสร็จก่อน",
        variant: "info",
      });
      return;
    }

    if (queueRows.length === 0) {
      setAlert({
        title: "ไม่พบข้อมูลคิว",
        message: `ไม่พบ LOT ในคิวของ ${machine}`,
        variant: "info",
      });
      return;
    }

    const result = getPullableQueueLots();

    if (result.lots.length === 0) {
      setAlert({
        title: "ไม่มี LOT ที่สามารถดึงได้",
        message: buildPullSummaryMessage(result, 0),
        variant: "info",
      });
      return;
    }

    // หากในช่องกรอกมีข้อมูลอยู่แล้ว ให้ถามก่อน
    if (lotInput.trim()) {
      setPullQueuePrompt(result);
      return;
    }

    // ช่องว่างอยู่ ให้ใส่รายการได้ทันที
    applyPulledQueueLots("replace", result);
  };

  const handleClearLotInput = () => {
    setLotInput("");
    setPullQueuePrompt(null);
  };

  const handleAddLots = async () => {
    if (!machine) {
      setAlert({
        title: "กรุณาเลือกเครื่องจักร",
        message: "ต้องเลือกเครื่องจักรก่อนตรวจสอบ Lot No",
        variant: "warning",
      });
      return;
    }

    if (!employeeId || !employeeName) {
      setAlert({
        title: "ไม่พบข้อมูล Demo User",
        message: "กรุณา Login ใหม่ก่อนทำรายการจัดลำดับงาน",
        variant: "danger",
      });
      return;
    }

    const parsedLots = parseLotInput(lotInput);

    if (parsedLots.length === 0) {
      setAlert({
        title: "กรุณากรอก Lot No",
        message: "สามารถกรอกหลาย Lot โดยแยกด้วย Enter, Space หรือ Comma",
        variant: "warning",
      });
      return;
    }

    const invalidLots = parsedLots.filter((lotId) => !isValidLotFormat(lotId));

    if (invalidLots.length > 0) {
      setAlert({
        title: "รูปแบบ Lot No ไม่ถูกต้อง",
        message: `รูปแบบ Demo Lot ต้องเป็น LOT-DEMO-001 ถึง LOT-DEMO-999\n${invalidLots.join(
          ", ",
        )}`,
        variant: "danger",
      });
      return;
    }

    const duplicateInputLots = parsedLots.filter(
      (lotId, index) => parsedLots.indexOf(lotId) !== index,
    );

    if (duplicateInputLots.length > 0) {
      setAlert({
        title: "พบ Lot ซ้ำ",
        message: `Lot ห้ามซ้ำกัน\n${[...new Set(duplicateInputLots)].join(
          ", ",
        )}`,
        variant: "danger",
      });
      return;
    }

    setChecking(true);

    try {
      let activeMachines = allMachines;
      let activeQueueRows = queueRows;

      if (activeMachines.length === 0 || activeQueueRows.length === 0) {
        const machines = await getMachines({
          includeTechnical: true,
          includeMoveLot: true,
          force: true,
        });

        activeMachines = Array.isArray(machines) ? machines : [];
        setAllMachines(activeMachines);

        const machineData = activeMachines.find(
          (item) => toQueueMachineCode(item?.machineName) === queueMachine,
        );

        activeQueueRows = Array.isArray(machineData?.lots)
          ? machineData.lots
          : [];

        setQueueRows(activeQueueRows);
      }

      const activeQueueMap = new Map(
        activeQueueRows.map((row) => [getLotNo(row), row]),
      );

      const globalLotMap = new Map();

      for (const machineItem of activeMachines) {
        const displayMachine =
          toDisplayMachineCode(machineItem?.machineName) ||
          machineItem?.machineName ||
          "-";

        for (const row of machineItem?.lots || []) {
          const lotId = getLotNo(row);
          if (!lotId || globalLotMap.has(lotId)) continue;

          globalLotMap.set(lotId, {
            machine: displayMachine,
            row,
          });
        }
      }

      const existingDraftLots = new Set(draftRows.map((item) => item.lotId));

      const alreadyAddedLots = parsedLots.filter((lotId) =>
        existingDraftLots.has(lotId),
      );

      if (alreadyAddedLots.length > 0) {
        setAlert({
          title: "Lot อยู่ในรายการแล้ว",
          message: `กรุณาตรวจสอบ Lot ต่อไปนี้\n${alreadyAddedLots.join(", ")}`,
          variant: "warning",
        });
        return;
      }

      const missingFromSelectedMachine = parsedLots.filter(
        (lotId) => !activeQueueMap.has(lotId),
      );

      const mismatchedLots = missingFromSelectedMachine
        .map((lotId) => ({
          lotId,
          actualMachine: globalLotMap.get(lotId)?.machine || "",
        }))
        .filter((item) => item.actualMachine);

      const notFoundLots = missingFromSelectedMachine.filter(
        (lotId) => !globalLotMap.has(lotId),
      );

      if (mismatchedLots.length > 0) {
        setAlert({
          title: "Lot ไม่ตรงกับเครื่องที่เลือก",
          message: `เครื่องที่เลือก: ${machine}\n\n${mismatchedLots
            .map((item) => `${item.lotId} อยู่ในคิวของ ${item.actualMachine}`)
            .join("\n")}`,
          variant: "danger",
        });
        return;
      }

      if (notFoundLots.length > 0) {
        setAlert({
          title: "ไม่พบ Lot ในคิวการผลิต",
          message: `${notFoundLots.join(
            ", ",
          )}\n\nกรุณาตรวจสอบ Lot No หรือ Refresh ข้อมูลอีกครั้ง`,
          variant: "danger",
        });
        return;
      }

      const nextDayInputLots = parsedLots.filter((lotId) =>
        isNextDayInputLot(activeQueueMap.get(lotId)),
      );

      if (nextDayInputLots.length > 0) {
        setAlert({
          title: "ไม่สามารถจัดลำดับงาน PLANNED",
          message: `${nextDayInputLots.join(
            ", ",
          )}\nเป็นงานสถานะ PLANNED จึงยังไม่สามารถนำมาจัดลำดับได้`,
          variant: "warning",
        });
        return;
      }

      /*
       * Current Lot ถูกจัดแยกไว้เป็นลำดับ 1
       * รายการที่ผู้ใช้กรอกจะเป็น Waiting Lot
       */
      const nextRows = parsedLots
        .filter((lotId) => !isCurrentMachineLot(activeQueueMap.get(lotId)))
        .map((lotId) => ({
          lotId,
          row: activeQueueMap.get(lotId),
          locked: false,
        }));

      setDraftRows((current) => {
        const currentDraftRow =
          current.find(
            (item) => item.locked || isCurrentMachineLot(item.row),
          ) || buildLockedCurrentDraftRow(activeQueueRows);

        const waitingRows = current.filter(
          (item) => !item.locked && !isCurrentMachineLot(item.row),
        );

        return currentDraftRow
          ? [currentDraftRow, ...waitingRows, ...nextRows]
          : [...waitingRows, ...nextRows];
      });

      setLotInput("");
    } catch (error) {
      console.error("Validate sequence lots error:", error);

      setAlert({
        title: "ตรวจสอบ Lot ไม่สำเร็จ",
        message:
          error?.message ||
          "ไม่สามารถตรวจสอบ Lot กับข้อมูลคิวงานได้ กรุณาลองใหม่อีกครั้ง",
        variant: "danger",
      });
    } finally {
      setChecking(false);
    }
  };

  const moveDraftRow = (index, direction) => {
    const selectedRow = draftRows[index];

    /*
     * Current Lot ห้ามเลื่อน
     */
    if (selectedRow?.locked || isCurrentMachineLot(selectedRow?.row)) {
      return;
    }

    const targetIndex = index + direction;

    if (targetIndex < 0 || targetIndex >= draftRows.length) {
      return;
    }

    const targetRow = draftRows[targetIndex];

    /*
     * Waiting Lot ห้ามเลื่อนแซง Current Lot
     */
    if (targetRow?.locked || isCurrentMachineLot(targetRow?.row)) {
      return;
    }

    /*
     * สลับตำแหน่ง
     */
    const next = [...draftRows];

    [next[index], next[targetIndex]] = [next[targetIndex], next[index]];

    setDraftRows(next);

    /*
     * แสดง Feedback ว่า Lot ไหนถูกขยับ
     */
    setMoveFeedback({
      lotId: selectedRow.lotId,
      direction: direction < 0 ? "up" : "down",
      moveCount: 1,
      newPosition: targetIndex + 1,
    });
  };

  const removeDraftRow = (index) => {
    setDraftRows((current) => {
      const selectedRow = current[index];

      /*
       * Current Lot ห้ามลบออกจากลำดับ
       */
      if (selectedRow?.locked || isCurrentMachineLot(selectedRow?.row)) {
        return current;
      }

      return current.filter((_, currentIndex) => currentIndex !== index);
    });
  };

  const restoreSavedDraft = () => {
    setDraftRows(buildDraftFromSavedRows(savedRows, queueRows));
    setLotInput("");
    setMoveFeedback(null);
  };

  const openSaveConfirmation = () => {
    if (!machine) {
      setAlert({
        title: "กรุณาเลือกเครื่องจักร",
        message: "ต้องเลือกเครื่องจักรก่อนบันทึกลำดับงาน",
        variant: "warning",
      });
      return;
    }

    // อนุญาตให้บันทึกได้แม้มีเพียง Current Lot ที่กำลังผลิตอยู่
    // โดย Current Lot จะถูกล็อกเป็นลำดับที่ 1 ตาม Validation เดิม
    if (draftRows.length === 0) {
      setAlert({
        title: "ยังไม่มี Lot ในรายการ",
        message: "ไม่พบ Lot สำหรับบันทึกลำดับงาน",
        variant: "warning",
      });
      return;
    }

    const previousDraftRows = buildDraftFromSavedRows(savedRows, queueRows);

    const previousPositionMap = new Map(
      previousDraftRows.map((item, index) => [item.lotId, index + 1]),
    );

    const previewRows = draftRows.map((item, index) => {
      const newPosition = index + 1;
      const oldPosition = previousPositionMap.get(item.lotId);

      let direction = "same";

      if (oldPosition === undefined) {
        direction = "new";
      } else if (newPosition < oldPosition) {
        direction = "up";
      } else if (newPosition > oldPosition) {
        direction = "down";
      }

      return {
        lotId: item.lotId,
        oldPosition,
        newPosition,
        direction,

        moveCount:
          oldPosition !== undefined ? Math.abs(oldPosition - newPosition) : 0,
      };
    });

    setConfirmAction({
      type: "SAVE",
      title: "ยืนยันการบันทึกลำดับงาน",

      message: (
        <div className="space-y-4">
          <div>
            <div>เครื่อง: {machine}</div>
            <div>จำนวน: {draftRows.length} Lot</div>
          </div>

          <div className="mx-auto max-w-xs space-y-2 text-left">
            {previewRows.map((item) => (
              <div
                key={item.lotId}
                className="flex items-center justify-between gap-4"
              >
                <span className="font-black">
                  {item.newPosition}. {item.lotId}
                </span>

                {item.direction === "up" ? (
                  <span className="font-black text-emerald-600">
                    ▲ {item.moveCount} → {item.newPosition}
                  </span>
                ) : item.direction === "down" ? (
                  <span className="font-black text-rose-600">
                    ▼ {item.moveCount} → {item.newPosition}
                  </span>
                ) : item.direction === "new" ? (
                  <span className="font-black text-cyan-600">ใหม่</span>
                ) : (
                  <span className="font-black text-slate-400">—</span>
                )}
              </div>
            ))}
          </div>

          <div className="pt-2">ลำดับเดิมของเครื่องนี้จะถูกแทนที่</div>
        </div>
      ),
    });
  };

  const openClearConfirmation = () => {
    if (!machine || savedRows.length === 0) {
      setAlert({
        title: "ไม่มีลำดับงานที่บันทึกไว้",
        message: "เครื่องนี้ยังไม่มี Manual Sequence ที่ต้องล้าง",
        variant: "info",
      });
      return;
    }

    setConfirmAction({
      type: "CLEAR",
      title: "ยืนยันการล้างลำดับงาน",
      message: `ต้องการล้าง Manual Sequence ของ ${machine} ใช่หรือไม่\n\nหลังล้าง ระบบจะกลับไปเรียงตาม FIFO เดิม`,
    });
  };

  const executeSave = async () => {
    setConfirmAction(null);
    setSaving(true);

    const lots = draftRows.map((item) => item.lotId);

    try {
      const result = await saveSortLots({
        machine,
        lots,
        empCode: employeeId,
        empName: employeeName,
      });

      await loadMachineData(machine, {
        force: true,
        restoreDraft: true,
      });

      setMoveFeedback(null);

      setLotInput("");

      setAlert({
        title: "บันทึกสำเร็จ",
        message:
          result?.message ||
          `บันทึกลำดับงานของ ${machine} จำนวน ${lots.length} Lot เรียบร้อยแล้ว`,
        variant: "success",
      });

      writeActivityLog({
        user,
        type: "SORT_LOT",
        level: "INFO",
        page: "จัดลำดับงาน",
        action: "SAVE_SEQUENCE",
        machine,
        result: "SUCCESS",
        message: `Saved ${lots.length} sort lot record(s) for ${machine}`,
        meta: {
          queueMachine,
          lots,
        },
      });
    } catch (error) {
      console.error("Save sort lots error:", error);

      setAlert({
        title: "บันทึกไม่สำเร็จ",
        message: error?.message || "ไม่สามารถบันทึกลำดับงานได้",
        variant: "danger",
      });

      writeActivityLog({
        user,
        type: "SORT_LOT",
        level: "ERROR",
        page: "จัดลำดับงาน",
        action: "SAVE_SEQUENCE",
        machine,
        result: "ERROR",
        message: error?.message || "Save sort lots failed",
        meta: {
          queueMachine,
          lots,
          code: error?.code || "",
        },
      });
    } finally {
      setSaving(false);
    }
  };

  const executeClear = async () => {
    setConfirmAction(null);
    setSaving(true);

    try {
      const result = await clearSortLots({
        machine,
        empCode: employeeId,
      });

      await loadMachineData(machine, {
        force: true,
        restoreDraft: true,
      });

      setLotInput("");

      setAlert({
        title: "ล้างลำดับสำเร็จ",
        message:
          result?.message ||
          `ล้าง Manual Sequence ของ ${machine} เรียบร้อยแล้ว`,
        variant: "success",
      });

      writeActivityLog({
        user,
        type: "SORT_LOT",
        level: "WARN",
        page: "จัดลำดับงาน",
        action: "CLEAR_SEQUENCE",
        machine,
        result: "SUCCESS",
        message: `Cleared sort lot records for ${machine}`,
      });
    } catch (error) {
      console.error("Clear sort lots error:", error);

      setAlert({
        title: "ล้างลำดับไม่สำเร็จ",
        message: error?.message || "ไม่สามารถล้างลำดับงานได้",
        variant: "danger",
      });
    } finally {
      setSaving(false);
    }
  };

  const currentLotCount = queueRows.filter(isCurrentMachineLot).length;

  const waitingLotCount = Math.max(queueRows.length - currentLotCount, 0);

  return (
    <div className="space-y-6 pt-6">
      <section className="relative overflow-hidden rounded-[2rem] border border-slate-300 bg-gradient-to-br from-cyan-50 via-white to-slate-100 p-6 shadow-lg dark:border-slate-700 dark:from-slate-900 dark:via-slate-950 dark:to-cyan-950/30">
        <div className="absolute right-[-80px] top-[-80px] h-56 w-56 rounded-full bg-cyan-400/20 blur-3xl" />

        <div className="relative flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex items-start gap-4">
            <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-cyan-600 text-white shadow-lg shadow-cyan-600/20">
              <ListChecks size={28} strokeWidth={2.2} />
            </div>

            <div>
              <h1 className="text-2xl font-black tracking-tight text-slate-900 sm:text-3xl dark:text-white">
                จัดลำดับงานเข้าเครื่อง
              </h1>
              <p className="mt-1 text-sm font-semibold text-slate-600 sm:text-base dark:text-slate-300">
                กำหนด Manual Sequence สำหรับ Lot ที่รอเข้าเครื่องใน Demo Process
              </p>
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <DemoGuideButton kind="sequence" />
            <button
              type="button"
              hidden
              style={{ display: "none" }}
              onClick={() => setShowUsageGuide(true)}
              className="inline-flex items-center gap-2 rounded-full border border-cyan-200 bg-white px-4 py-2 text-sm font-black text-cyan-700 shadow-sm transition hover:border-cyan-400 hover:bg-cyan-50 hover:text-cyan-800 dark:border-cyan-800 dark:bg-slate-900 dark:text-cyan-300 dark:hover:bg-cyan-950/40"
            >
              <CircleHelp size={18} />
              วิธีใช้งาน
            </button>

            <span className="rounded-full bg-cyan-100 px-4 py-2 text-sm font-black text-cyan-800 dark:bg-cyan-950/60 dark:text-cyan-300">
              lineName: DEMO
            </span>
          </div>
        </div>
      </section>

      <section className="rounded-[2rem] border border-slate-300 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-900">
        <div className="grid gap-4 lg:grid-cols-3">
          <label className="block">
            <span className="text-sm font-black text-slate-700 dark:text-slate-200">
              Demo User ID
            </span>
            <input
              type="text"
              value={employeeId || "-"}
              readOnly
              className="mt-2 h-14 w-full rounded-2xl border border-slate-300 bg-slate-100 px-4 text-lg font-bold text-slate-700 outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
            />
          </label>

          <label className="block">
            <span className="text-sm font-black text-slate-700 dark:text-slate-200">
              ชื่อ Demo User
            </span>
            <input
              type="text"
              value={employeeName || "-"}
              readOnly
              className="mt-2 h-14 w-full rounded-2xl border border-slate-300 bg-slate-100 px-4 text-lg font-bold text-slate-700 outline-none dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200"
            />
          </label>

          <div>
            <span className="text-sm font-black text-slate-700 dark:text-slate-200">
              เครื่องจักร
            </span>
            <MachineDropdown
              value={machine}
              onChange={handleMachineChange}
              disabled={saving}
            />
          </div>
        </div>
      </section>

      <section className="overflow-hidden rounded-[2rem] border border-slate-300 bg-white shadow-sm dark:border-slate-700 dark:bg-slate-900">
        <div className="flex flex-col gap-3 border-b border-slate-200 px-5 py-4 sm:flex-row sm:items-center sm:justify-between dark:border-slate-700">
          <div>
            <h2 className="text-xl font-black text-slate-900 dark:text-white">
              คิวงานปัจจุบัน {machine ? `— ${machine}` : ""}
            </h2>
            <p className="mt-1 text-sm font-semibold text-slate-500 dark:text-slate-400">
              งานกำลังผลิตจะถูกล็อกไว้ลำดับที่ 1
            </p>
          </div>

          <button
            type="button"
            disabled={!machine || loading || saving}
            onClick={() =>
              loadMachineData(machine, { force: true, restoreDraft: true })
            }
            className="inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-slate-300 bg-white px-4 text-sm font-black text-slate-700 transition hover:border-cyan-300 hover:bg-cyan-50 hover:text-cyan-700 disabled:cursor-not-allowed disabled:opacity-50 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200 dark:hover:bg-slate-800"
          >
            <RefreshCw size={17} className={loading ? "animate-spin" : ""} />
            Refresh
          </button>
        </div>

        <div className="grid grid-cols-3 border-b border-slate-200 bg-slate-50 dark:border-slate-700 dark:bg-slate-950/50">
          <div className="px-4 py-3 text-center">
            <div className="text-2xl font-black text-slate-900 dark:text-white">
              {queueRows.length}
            </div>
            <div className="text-xs font-bold text-slate-500">ทั้งหมด</div>
          </div>
          <div className="border-x border-slate-200 px-4 py-3 text-center dark:border-slate-700">
            <div className="text-2xl font-black text-emerald-600">
              {currentLotCount}
            </div>
            <div className="text-xs font-bold text-slate-500">กำลังผลิต</div>
          </div>
          <div className="px-4 py-3 text-center">
            <div className="text-2xl font-black text-cyan-600">
              {waitingLotCount}
            </div>
            <div className="text-xs font-bold text-slate-500">
              รอเข้าเครื่อง
            </div>
          </div>
        </div>

        <MachineQueueTable
          lots={queueRows}
          machineName={machine}
          loading={loading}
          emptyMessage={
            machine ? `ไม่พบข้อมูลคิวของ ${machine}` : "กรุณาเลือกเครื่องจักร"
          }
        />
      </section>

      <section className="rounded-[2rem] border border-slate-300 bg-white p-5 shadow-sm dark:border-slate-700 dark:bg-slate-900">
        <div className="flex items-start gap-3">
          <div className="flex h-11 w-11 shrink-0 items-center justify-center rounded-xl bg-violet-100 text-violet-700 dark:bg-violet-950 dark:text-violet-300">
            <SearchCheck size={22} />
          </div>
          <div>
            <h2 className="text-xl font-black text-slate-900 dark:text-white">
              กรอก Lot เพื่อจัดลำดับ
            </h2>
            <p className="mt-1 text-sm font-semibold text-slate-500 dark:text-slate-400">
              สามารถวาง Lot ได้หลาย Lot
            </p>
          </div>
        </div>

        <textarea
          value={lotInput}
          disabled={!machine || saving}
          onChange={(event) => setLotInput(event.target.value.toUpperCase())}
          onKeyDown={(event) => {
            if ((event.ctrlKey || event.metaKey) && event.key === "Enter") {
              event.preventDefault();
              handleAddLots();
            }
          }}
          rows={4}
          placeholder={
            machine
              ? "ตัวอย่าง:\nLOT-DEMO-002\nLOT-DEMO-003"
              : "กรุณาเลือกเครื่องจักรก่อน"
          }
          className="mt-5 w-full resize-y rounded-2xl border border-slate-300 bg-slate-50 px-4 py-4 font-mono text-base font-bold uppercase text-slate-900 outline-none transition focus:border-violet-500 focus:ring-2 focus:ring-violet-100 disabled:cursor-not-allowed disabled:opacity-60 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-100 dark:focus:border-violet-400"
        />

        <div className="mt-4 grid gap-3 sm:grid-cols-3">
          <button
            type="button"
            disabled={!machine || !lotInput.trim() || checking || saving}
            onClick={handleAddLots}
            className="inline-flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-violet-600 px-5 text-sm font-black text-white transition hover:bg-violet-700 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <SearchCheck size={22} />
            {checking ? "กำลังตรวจสอบ..." : "ตรวจสอบเลข Lot ที่กรอก"}
          </button>

          <button
            type="button"
            disabled={!machine || loading || checking || saving}
            onClick={handlePullLotsFromQueue}
            className="inline-flex h-12 w-full items-center justify-center gap-2 rounded-xl bg-cyan-600 px-5 text-sm font-black text-white transition hover:bg-cyan-700 disabled:cursor-not-allowed disabled:opacity-50"
          >
            <ListPlus size={22} />
            ดึงเลข Lot จากเครื่องที่เลือก
          </button>

          <button
            type="button"
            disabled={!lotInput.trim() || checking || saving}
            onClick={handleClearLotInput}
            className="inline-flex h-12 w-full items-center justify-center gap-2 rounded-xl border border-slate-300 bg-white px-5 text-sm font-black text-slate-700 transition hover:bg-slate-100 disabled:cursor-not-allowed disabled:opacity-50 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200 dark:hover:bg-slate-800"
          >
            <Eraser size={22} />
            Clear
          </button>
        </div>
      </section>

      <section className="overflow-hidden rounded-[2rem] border border-slate-300 bg-white shadow-sm dark:border-slate-700 dark:bg-slate-900">
        <div className="flex flex-col gap-3 border-b border-slate-200 px-5 py-4 sm:flex-row sm:items-center sm:justify-between dark:border-slate-700">
          <div>
            <h2 className="text-xl font-black text-slate-900 dark:text-white">
              ลำดับที่เตรียมบันทึก
            </h2>
            <p className="mt-1 text-sm font-semibold text-slate-500 dark:text-slate-400">
              ลำดับในตารางนี้จะต่อจาก Lot ที่กำลังผลิตอยู่
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              disabled={!machine || savedRows.length === 0 || loading || saving}
              onClick={restoreSavedDraft}
              className="inline-flex h-10 items-center justify-center gap-2 rounded-xl border border-slate-300 bg-white px-4 text-sm font-black text-slate-700 transition hover:border-violet-300 hover:bg-violet-50 hover:text-violet-700 disabled:cursor-not-allowed disabled:opacity-50 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200 dark:hover:bg-slate-800"
            >
              <RotateCcw size={17} />
              คืนค่าที่บันทึก
            </button>

            <span className="rounded-full bg-violet-100 px-4 py-2 text-sm font-black text-violet-700 dark:bg-violet-950 dark:text-violet-300">
              {draftRows.length} Lot
            </span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="min-w-[900px] w-full text-sm">
            <thead className="bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-200">
              <tr>
                {[
                  "Manual No.",
                  "Lot No",
                  "Part Name",
                  "Input Date",
                  "Status",
                  "จัดการ",
                ].map((header) => (
                  <th
                    key={header}
                    className="whitespace-nowrap px-4 py-3 text-left font-black"
                  >
                    {header}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {draftRows.length === 0 ? (
                <tr>
                  <td
                    colSpan={6}
                    className="px-4 py-12 text-center font-bold text-slate-500"
                  >
                    ยังไม่มี Lot ในรายการจัดลำดับ
                  </td>
                </tr>
              ) : (
                draftRows.map((item, index) => {
                  const isLockedCurrent =
                    item.locked || isCurrentMachineLot(item.row);

                  const previousRowIsLocked =
                    index > 0 &&
                    (draftRows[index - 1]?.locked ||
                      isCurrentMachineLot(draftRows[index - 1]?.row));

                  return (
                    <tr
                      key={item.lotId}
                      className={`border-t transition-all duration-300 dark:border-slate-800 ${
                        moveFeedback?.lotId === item.lotId
                          ? moveFeedback.direction === "up"
                            ? "bg-emerald-50 ring-2 ring-inset ring-emerald-300 dark:bg-emerald-950/30"
                            : "bg-rose-50 ring-2 ring-inset ring-rose-300 dark:bg-rose-950/30"
                          : "bg-white dark:bg-slate-900"
                      }`}
                    >
                      <td className="px-4 py-3">
                        <span
                          className={`inline-flex h-9 min-w-9 items-center justify-center gap-1 rounded-xl px-3 font-black text-white ${
                            isLockedCurrent ? "bg-emerald-600" : "bg-violet-600"
                          }`}
                        >
                          {isLockedCurrent ? <LockKeyhole size={14} /> : null}

                          {index + 1}
                        </span>
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <span className="font-black text-slate-900 dark:text-white">
                            {item.lotId}
                          </span>

                          {moveFeedback?.lotId === item.lotId ? (
                            <span
                              className={`whitespace-nowrap rounded-full px-2.5 py-1 text-xs font-black ${
                                moveFeedback.direction === "up"
                                  ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-950 dark:text-emerald-300"
                                  : "bg-rose-100 text-rose-700 dark:bg-rose-950 dark:text-rose-300"
                              }`}
                            >
                              {moveFeedback.direction === "up"
                                ? "▲ เลื่อนขึ้น"
                                : "▼ เลื่อนลง"}{" "}
                              {" • "} อยุ่ลำดับ {moveFeedback.newPosition}
                            </span>
                          ) : null}
                        </div>
                      </td>
                      <td className="max-w-[300px] truncate px-4 py-3 font-semibold text-slate-600 dark:text-slate-300">
                        {getPartName(item.row)}
                      </td>
                      <td className="whitespace-nowrap px-4 py-3 font-semibold text-slate-600 dark:text-slate-300">
                        {getInputDate(item.row)}
                      </td>
                      <td className="px-4 py-3 font-semibold text-slate-600 dark:text-slate-300">
                        {getStatusText(item.row)}
                      </td>
                      <td className="px-4 py-3">
                        <div className="flex items-center gap-2">
                          <button
                            type="button"
                            title="เลื่อนขึ้น"
                            disabled={
                              isLockedCurrent ||
                              previousRowIsLocked ||
                              index === 0 ||
                              saving
                            }
                            onClick={() => moveDraftRow(index, -1)}
                            className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-slate-300 text-slate-600 transition hover:border-violet-300 hover:bg-violet-50 hover:text-violet-700 disabled:cursor-not-allowed disabled:opacity-30 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                          >
                            <ArrowUp size={17} />
                          </button>

                          <button
                            type="button"
                            title="เลื่อนลง"
                            disabled={
                              isLockedCurrent ||
                              index === draftRows.length - 1 ||
                              saving
                            }
                            onClick={() => moveDraftRow(index, 1)}
                            className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-slate-300 text-slate-600 transition hover:border-violet-300 hover:bg-violet-50 hover:text-violet-700 disabled:cursor-not-allowed disabled:opacity-30 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
                          >
                            <ArrowDown size={17} />
                          </button>

                          <button
                            type="button"
                            title="ลบออกจากรายการ"
                            disabled={isLockedCurrent || saving}
                            onClick={() => removeDraftRow(index)}
                            className="inline-flex h-9 w-9 items-center justify-center rounded-lg border border-rose-200 text-rose-600 transition hover:bg-rose-50 disabled:cursor-not-allowed disabled:opacity-30 dark:border-rose-900 dark:text-rose-400 dark:hover:bg-rose-950/30"
                          >
                            <Trash2 size={17} />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>

        <div className="flex flex-col gap-3 border-t border-slate-200 bg-slate-50 px-5 py-4 sm:flex-row sm:items-center sm:justify-between dark:border-slate-700 dark:bg-slate-950/40">
          <div className="flex items-center gap-2 text-sm font-bold text-slate-500 dark:text-slate-400">
            <Database size={17} />
          </div>

          <div className="flex flex-wrap gap-3">
            <button
              type="button"
              disabled={!machine || savedRows.length === 0 || saving}
              onClick={openClearConfirmation}
              className="inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-rose-200 bg-white px-5 text-sm font-black text-rose-600 transition hover:bg-rose-50 disabled:cursor-not-allowed disabled:opacity-50 dark:border-rose-900 dark:bg-slate-950 dark:text-rose-400 dark:hover:bg-rose-950/30"
            >
              <Trash2 size={18} />
              ล้างลำดับที่บันทึก
            </button>

            <button
              type="button"
              disabled={!machine || draftRows.length === 0 || saving}
              onClick={openSaveConfirmation}
              className="inline-flex h-11 items-center justify-center gap-2 rounded-xl bg-emerald-600 px-6 text-sm font-black text-white transition hover:bg-emerald-700 disabled:cursor-not-allowed disabled:opacity-50"
            >
              <Save size={18} />
              {saving ? "กำลังบันทึก..." : "บันทึกลำดับงาน"}
            </button>
          </div>
        </div>
      </section>

      {showUsageGuide ? (
        <div
          className="fixed inset-0 z-[220] flex items-center justify-center bg-slate-950/65 p-4 backdrop-blur-sm"
          onMouseDown={(event) => {
            if (event.target === event.currentTarget) {
              setShowUsageGuide(false);
            }
          }}
        >
          <div className="flex max-h-[90vh] w-full max-w-4xl flex-col overflow-hidden rounded-[2rem] bg-white shadow-2xl ring-1 ring-slate-200 dark:bg-slate-950 dark:ring-slate-800">
            <div className="flex items-start justify-between gap-4 border-b border-slate-200 bg-gradient-to-r from-cyan-50 via-white to-violet-50 px-6 py-5 dark:border-slate-800 dark:from-cyan-950/30 dark:via-slate-950 dark:to-violet-950/30">
              <div className="flex items-start gap-3">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-cyan-600 text-white shadow-lg shadow-cyan-600/20">
                  <CircleHelp size={25} />
                </div>
                <div>
                  <h2 className="text-2xl font-black text-slate-900 dark:text-white">
                    วิธีจัดลำดับงานเข้าเครื่อง
                  </h2>
                  <p className="mt-1 text-sm font-semibold text-slate-500 dark:text-slate-400">
                    ทำตาม 5 ขั้นตอนนี้เพื่อจัด Manual Sequence และบันทึกลำดับงาน
                  </p>
                </div>
              </div>

              <button
                type="button"
                aria-label="ปิดวิธีใช้งาน"
                onClick={() => setShowUsageGuide(false)}
                className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-500 transition hover:bg-slate-100 hover:text-slate-900 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-white"
              >
                <X size={22} />
              </button>
            </div>

            <div className="overflow-y-auto px-6 py-6">
              <div className="mb-5 rounded-2xl border border-cyan-200 bg-cyan-50 px-4 py-3 dark:border-cyan-900 dark:bg-cyan-950/30">
                <div className="text-xs font-black uppercase tracking-[0.16em] text-cyan-700 dark:text-cyan-300">
                  Quick Flow
                </div>
                <div className="mt-2 flex flex-wrap items-center gap-2 text-sm font-black text-slate-800 dark:text-slate-100">
                  <span className="rounded-lg bg-white px-3 py-1.5 shadow-sm dark:bg-slate-900">1. เลือกเครื่อง</span>
                  <span className="text-cyan-500">→</span>
                  <span className="rounded-lg bg-white px-3 py-1.5 shadow-sm dark:bg-slate-900">2. ดึง LOT จากคิว</span>
                  <span className="text-cyan-500">→</span>
                  <span className="rounded-lg bg-white px-3 py-1.5 shadow-sm dark:bg-slate-900">3. ตรวจสอบทั้งหมด</span>
                  <span className="text-cyan-500">→</span>
                  <span className="rounded-lg bg-white px-3 py-1.5 shadow-sm dark:bg-slate-900">4. จัดลำดับ ▲ ▼</span>
                  <span className="text-cyan-500">→</span>
                  <span className="rounded-lg bg-white px-3 py-1.5 shadow-sm dark:bg-slate-900">5. บันทึก</span>
                </div>
              </div>

              <div className="grid gap-3">
                <div className="flex gap-4 rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-cyan-600 text-lg font-black text-white">1</div>
                  <div>
                    <h3 className="font-black text-slate-900 dark:text-white">เลือกเครื่องจักร</h3>
                    <p className="mt-1 text-sm font-semibold leading-6 text-slate-600 dark:text-slate-300">
                      กดช่อง <span className="font-black text-cyan-700 dark:text-cyan-300">“เครื่องจักร”</span> ด้านบน แล้วเลือกเครื่องที่ต้องการจัดคิว ระบบจะแสดงคิวปัจจุบันของเครื่องนั้นทันที
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-cyan-600 text-lg font-black text-white">2</div>
                  <div>
                    <h3 className="font-black text-slate-900 dark:text-white">นำ LOT ที่ต้องการจัดลำดับเข้ามา</h3>
                    <p className="mt-1 text-sm font-semibold leading-6 text-slate-600 dark:text-slate-300">
                      วิธีเร็วที่สุดคือกด <span className="rounded-lg bg-cyan-600 px-2 py-1 font-black text-white">ดึง LOT จากคิว</span> ระบบจะนำคิว<span className="font-black text-amber-600 dark:text-amber-400">รอผลิต</span>
                      และ<span className="font-black text-rose-600 dark:text-rose-500">รอหน้าเครื่อง</span>มาใส่ในช่องกรอก หรือจะพิมพ์/วาง Lot No. เองก็ได้
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-violet-600 text-lg font-black text-white">3</div>
                  <div>
                    <h3 className="font-black text-slate-900 dark:text-white">ตรวจสอบ LOT</h3>
                    <p className="mt-1 text-sm font-semibold leading-6 text-slate-600 dark:text-slate-300">
                      เมื่อ LOT อยู่ในช่องกรอกแล้ว ให้กด <span className="rounded-lg bg-violet-600 px-2 py-1 font-black text-white">ตรวจสอบทั้งหมด</span> ระบบจะตรวจสอบ Lot และนำรายการที่ผ่านไปยังตาราง <span className="font-black">“ลำดับที่เตรียมบันทึก”</span>
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 rounded-2xl border border-slate-200 bg-white p-4 dark:border-slate-800 dark:bg-slate-900">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-violet-600 text-lg font-black text-white">4</div>
                  <div>
                    <h3 className="font-black text-slate-900 dark:text-white">จัดลำดับด้วยปุ่ม ▲ / ▼</h3>
                    <p className="mt-1 text-sm font-semibold leading-6 text-slate-600 dark:text-slate-300">
                      ใช้ปุ่ม <span className="font-black text-violet-700 dark:text-violet-300">▲ เลื่อนขึ้น</span> และ <span className="font-black text-violet-700 dark:text-violet-300">▼ เลื่อนลง</span> ในคอลัมน์ “จัดการ” เพื่อเรียงคิวตามต้องการ โดย Lot ที่
                      <span className="font-black text-emerald-600 dark:text-emerald-400">กำลังผลิต</span>จะถูกล็อกไว้ลำดับที่ 1 และเลื่อนไม่ได้
                    </p>
                  </div>
                </div>

                <div className="flex gap-4 rounded-2xl border border-emerald-200 bg-emerald-50/60 p-4 dark:border-emerald-900 dark:bg-emerald-950/20">
                  <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-emerald-600 text-lg font-black text-white">5</div>
                  <div>
                    <h3 className="font-black text-slate-900 dark:text-white">บันทึกลำดับงาน</h3>
                    <p className="mt-1 text-sm font-semibold leading-6 text-slate-600 dark:text-slate-300">
                      ตรวจสอบลำดับให้ถูกต้อง แล้วกด <span className="rounded-lg bg-emerald-600 px-2 py-1 font-black text-white">บันทึกลำดับงาน</span> จากนั้นยืนยันด้วยDemo User IDของคุณ เพื่อบันทึกลำดับคิวงาน
                    </p>
                  </div>
                </div>
              </div>

              <div className="mt-5 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm font-semibold leading-6 text-amber-900 dark:border-amber-900 dark:bg-amber-950/30 dark:text-amber-200">
                <span className="font-black">หมายเหตุ:</span> ปุ่ม <span className="font-black text-rose-600 dark:text-rose-500">“ล้างลำดับที่บันทึก”</span>
                ใช้เมื่อต้องการยกเลิกการจัดลำดับที่เคยบันทึกไว้ และต้องยืนยันDemo User IDเช่นเดียวกัน
              </div>
            </div>

            <div className="border-t border-slate-200 bg-slate-50 px-6 py-4 text-right dark:border-slate-800 dark:bg-slate-900/70">
              <button
                type="button"
                onClick={() => setShowUsageGuide(false)}
                className="h-11 rounded-xl bg-cyan-600 px-6 text-sm font-black text-white transition hover:bg-cyan-700"
              >
                เข้าใจแล้ว
              </button>
            </div>
          </div>
        </div>
      ) : null}

      {pullQueuePrompt ? (
        <div className="fixed inset-0 z-[210] flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-sm">
          <div className="w-full max-w-lg overflow-hidden rounded-3xl bg-white shadow-2xl ring-1 ring-slate-200 dark:bg-slate-950 dark:ring-slate-800">
            <div className="bg-violet-600 px-6 py-4 text-white">
              <h3 className="text-lg font-black">พบ LOT อยู่ในช่องกรอกแล้ว</h3>
            </div>

            <div className="px-6 py-6">
              <p className="text-center text-base font-bold text-slate-800 dark:text-slate-100">
                กรุณาเลือกวิธีนำ LOT จากคิวมาใส่ในช่องกรอก
              </p>

              <p className="mt-2 text-center text-sm font-semibold text-slate-500 dark:text-slate-400">
                พบ LOT ที่สามารถดึงได้ {pullQueuePrompt.lots.length} รายการ
              </p>
            </div>

            <div className="grid gap-3 border-t border-slate-200 px-6 py-5 dark:border-slate-800">
              <button
                type="button"
                onClick={() => applyPulledQueueLots("append")}
                className="h-11 rounded-xl bg-cyan-600 px-5 text-sm font-black text-white transition hover:bg-cyan-700"
              >
                เพิ่มเฉพาะ LOT ที่ยังไม่มี
              </button>

              <button
                type="button"
                onClick={() => applyPulledQueueLots("replace")}
                className="h-11 rounded-xl bg-violet-600 px-5 text-sm font-black text-white transition hover:bg-violet-700"
              >
                แทนที่ข้อความในช่องกรอกทั้งหมด
              </button>

              <button
                type="button"
                onClick={() => setPullQueuePrompt(null)}
                className="h-11 rounded-xl bg-slate-600 px-5 text-sm font-black text-white transition hover:bg-slate-700"
              >
                ยกเลิก
              </button>
            </div>
          </div>
        </div>
      ) : null}

      <CenterAlert
        open={Boolean(alert)}
        title={alert?.title}
        message={alert?.message}
        variant={alert?.variant || "danger"}
        onClose={() => setAlert(null)}
      />

      <CenterAlert
        open={Boolean(confirmAction)}
        title={confirmAction?.title}
        message={confirmAction?.message}
        variant={confirmAction?.type === "CLEAR" ? "danger" : "warning"}
        confirmText={
          confirmAction?.type === "CLEAR" ? "ยืนยันล้าง" : "ยืนยันบันทึก"
        }
        cancelText="ยกเลิก"
        requireEmployeeCode={
          confirmAction?.type === "SAVE" || confirmAction?.type === "CLEAR"
        }
        expectedEmployeeCode={employeeId}
        onClose={() => setConfirmAction(null)}
        onConfirm={confirmAction?.type === "CLEAR" ? executeClear : executeSave}
      />
    </div>
  );
}
