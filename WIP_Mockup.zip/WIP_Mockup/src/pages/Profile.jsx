import { useEffect, useState } from "react";
import {
  AlertTriangle,
  BadgeCheck,
  CheckCircle2,
  Clock3,
  LockKeyhole,
  Send,
  ShieldCheck,
  UserRound,
  X,
} from "lucide-react";
import { getRequestStatus, submitPermissionRequest } from "../services/api";
import { isFullAdmin } from "../utils/accessControl";

const formatDate = (dateString) => {
  if (!dateString || dateString === "-") {
    return "-";
  }

  const text = String(dateString).trim();

  // รองรับรูปแบบ YYYYMMDD เช่น 20260505
  if (/^\d{8}$/.test(text)) {
    const year = text.substring(0, 4);
    const month = text.substring(4, 6);
    const day = text.substring(6, 8);

    return `${day}/${month}/${year}`;
  }

  // รองรับรูปแบบ YYYY-MM-DD หรือ YYYY/MM/DD
  const dateMatch = text.match(/^(\d{4})[-/](\d{2})[-/](\d{2})/);

  if (dateMatch) {
    const [, year, month, day] = dateMatch;

    return `${day}/${month}/${year}`;
  }

  try {
    const date = new Date(dateString);

    if (Number.isNaN(date.getTime())) {
      return dateString;
    }

    const day = String(date.getDate()).padStart(2, "0");

    const month = String(date.getMonth() + 1).padStart(2, "0");

    const year = date.getFullYear();

    return `${day}/${month}/${year}`;
  } catch {
    return dateString;
  }
};

const getUserInitials = (user, fallbackId = "") => {
  const candidates = [user?.name, user?.empName, user?.displayName];

  for (const candidate of candidates) {
    const cleanName = String(candidate || "")
      // ตัดชื่อไทยในวงเล็บออก เช่น DEMO USER (ผู้ใช้สาธิต)
      .replace(/\([^)]*\)/g, " ")
      // เอาเฉพาะตัวอักษรอังกฤษกับช่องว่าง
      .replace(/[^A-Za-z\s]/g, " ")
      .trim();

    if (!cleanName) continue;

    const words = cleanName.split(/\s+/).filter(Boolean);

    if (words.length >= 2) {
      return `${words[0][0]}${words[words.length - 1][0]}`.toUpperCase();
    }

    if (words.length === 1) {
      return words[0].slice(0, 2).toUpperCase();
    }
  }

  const thaiName = String(user?.empName_TH || "")
    .replace(/\s+/g, "")
    .trim();

  if (thaiName) {
    return Array.from(thaiName).slice(0, 2).join("");
  }

  return fallbackId ? fallbackId.slice(-2) : "U";
};

const InfoCard = ({ label, value, helper, tone = "default" }) => {
  const toneClass = {
    default:
      "border-slate-200 bg-white dark:border-slate-700 dark:bg-slate-900",
    cyan: "border-cyan-200 bg-cyan-50/70 dark:border-cyan-900/70 dark:bg-cyan-950/25",
    emerald:
      "border-emerald-200 bg-emerald-50/70 dark:border-emerald-900/70 dark:bg-emerald-950/25",
    amber:
      "border-amber-200 bg-amber-50/70 dark:border-amber-900/70 dark:bg-amber-950/25",
  };

  return (
    <div
      className={`rounded-3xl border p-5 shadow-sm transition hover:-translate-y-0.5 hover:shadow-md ${
        toneClass[tone] || toneClass.default
      }`}
    >
      <p className="text-sm font-black uppercase tracking-[0.18em] text-slate-500 dark:text-slate-400">
        {label}
      </p>

      <div className="mt-3 text-2xl font-black leading-tight text-slate-950 dark:text-slate-50">
        {value || "-"}
      </div>

      {helper ? (
        <p className="mt-2 text-sm font-medium text-slate-500 dark:text-slate-400">
          {helper}
        </p>
      ) : null}
    </div>
  );
};

const AccessCard = ({ title, description, allowed }) => {
  return (
    <div
      className={[
        "rounded-2xl border p-4 shadow-sm transition",
        allowed
          ? "border-emerald-200 bg-emerald-50/80 dark:border-emerald-900/60 dark:bg-emerald-950/25"
          : "border-slate-200 bg-slate-50 dark:border-slate-700 dark:bg-slate-900/70",
      ].join(" ")}
    >
      <div className="flex items-start justify-between gap-3">
        <div>
          <h4 className="text-lg font-black text-slate-900 dark:text-slate-100">
            {title}
          </h4>
          <p className="mt-1 text-sm font-medium text-slate-500 dark:text-slate-400">
            {description}
          </p>
        </div>

        <span
          className={[
            "inline-flex shrink-0 items-center gap-1.5 rounded-full px-3 py-1 text-xs font-black",
            allowed
              ? "bg-emerald-600 text-white"
              : "bg-slate-300 text-slate-700 dark:bg-slate-700 dark:text-slate-200",
          ].join(" ")}
        >
          {allowed ? <BadgeCheck size={14} /> : <LockKeyhole size={14} />}
          {allowed ? "เข้าได้" : "จำกัดสิทธิ์"}
        </span>
      </div>
    </div>
  );
};

const permissionDefinitions = [
  {
    key: "dashboard",
    title: "Dashboard",
    description: "ดูภาพรวมสถานะเครื่องจักร",
  },
  {
    key: "queue",
    title: "Machine Queue",
    description: "ดูคิวงานและสถานะ Lot ของแต่ละเครื่อง",
  },
  {
    key: "lotSearch",
    title: "LOT Search",
    description: "ค้นหา Lot และดูตำแหน่งในคิว",
  },
  {
    key: "lineInfo",
    title: "Line Information",
    description: "ดู Mapping Line / Machine ประจำเดือน",
  },
  {
    key: "returnLot",
    title: "Return Lot",
    description: "แจ้งปัญหา / เดินงานข้าม Lot",
  },
  {
    key: "moveLot",
    title: "Move Lot",
    description: "บันทึกการย้าย Lot งาน",
  },
  {
    key: "sequence",
    title: "จัดลำดับงาน",
    description: "กำหนดลำดับ Lot ที่รอเข้าเครื่อง",
  },
  {
    key: "hold",
    title: "พักงาน / Hold Lot",
    description: "พัก Lot งานชั่วคราวและ Clear รายการพักงาน",
  },
  {
    key: "logs",
    title: "Logs",
    description: "ดูประวัติการใช้งานและกิจกรรมในระบบ",
  },
  {
    key: "dailyCheck",
    title: "Daily Check",
    description: "ตรวจสอบข้อมูลประจำวันของเครื่องจักร",
  },
  {
    key: "machineDebug",
    title: "Machine Debug",
    description: "ดูข้อมูลดิบสำหรับตรวจสอบปัญหาเครื่อง/คิว",
  },
  {
    key: "admin",
    title: "Admin Console",
    description: "จัดการสิทธิ์และข้อมูลผู้ดูแลระบบ",
  },
];

const normalizeStatus = (value) => String(value || "").trim().toUpperCase();

export default function Profile({ user }) {
  const [accessSnapshot, setAccessSnapshot] = useState(null);
  const [requestOpen, setRequestOpen] = useState(false);
  const [requestedPermissions, setRequestedPermissions] = useState({});
  const [requestReason, setRequestReason] = useState("");
  const [requestLoading, setRequestLoading] = useState(false);
  const [requestNotice, setRequestNotice] = useState("");
  const [requestError, setRequestError] = useState("");

  const employeeId = String(user?.id || user?.empCode || user?.employeeId || "")
    .trim()
    .toUpperCase();

  useEffect(() => {
    if (!employeeId) {
      setAccessSnapshot(null);
      return undefined;
    }

    let cancelled = false;

    const loadAccessStatus = async () => {
      try {
        const access = await getRequestStatus(employeeId);
        if (!cancelled && access) {
          setAccessSnapshot(access);
        }
      } catch (error) {
        // Profile ยังใช้สิทธิ์จาก session ที่ Login ได้ แม้โหลดสถานะล่าสุดไม่สำเร็จ
        console.error("Load profile access status error:", error);
      }
    };

    loadAccessStatus();
    const intervalId = window.setInterval(loadAccessStatus, 30000);

    return () => {
      cancelled = true;
      window.clearInterval(intervalId);
    };
  }, [employeeId]);

  if (!user) return null;

  const employeeInitials = getUserInitials(user, employeeId);

  const permissions = accessSnapshot?.permissions || user?.permissions || {};

  const roleCode = String(accessSnapshot?.role || user?.role || "")
    .trim()
    .toUpperCase();

  // Permission "admin" หมายถึงสิทธิ์เข้า Admin Console เท่านั้น
  // ไม่ถือว่าเป็น Full Admin และไม่ควรทำให้สิทธิ์หน้าอื่นกลายเป็นเข้าได้ทั้งหมด
  const isAdmin = isFullAdmin({ ...user, role: roleCode });

  const canAccess = (key) => {
    if (isAdmin) return true;
    return Boolean(permissions?.[key]);
  };

  const canAccessDebugPages = canAccess("machineDebug");

  const roleLabelMap = {
    ADMIN: "Administrator",
    TL: "TL / Supervisor",
    OPERATOR: "Operator",
    VIEWER: "Viewer",
    USER: "Employee",
  };

  const roleLabel =
    roleLabelMap[roleCode] || (isAdmin ? "Administrator" : "Employee");

  const accessItems = permissionDefinitions.map((item) => ({
    ...item,
    allowed: canAccess(item.key),
  }));

  const missingPermissionItems = accessItems.filter((item) => !item.allowed);
  const permissionRequest = accessSnapshot?.permissionRequest || null;
  const permissionRequestStatus = normalizeStatus(permissionRequest?.status);
  const hasPendingPermissionRequest = permissionRequestStatus === "PENDING";

  const requestedPermissionLabels = permissionRequest?.permissions
    ? permissionDefinitions
        .filter((item) => Boolean(permissionRequest.permissions?.[item.key]))
        .map((item) => item.title)
    : [];

  const selectedRequestCount = Object.values(requestedPermissions).filter(
    Boolean,
  ).length;

  const handleOpenPermissionRequest = () => {
    const initialSelection = missingPermissionItems.reduce((result, item) => {
      result[item.key] = false;
      return result;
    }, {});

    setRequestedPermissions(initialSelection);
    setRequestReason("");
    setRequestError("");
    setRequestNotice("");
    setRequestOpen(true);
  };

  const handleToggleRequestedPermission = (key) => {
    setRequestedPermissions((current) => ({
      ...current,
      [key]: !current[key],
    }));
  };

  const handleSubmitPermissionRequest = async () => {
    if (requestLoading || selectedRequestCount === 0) return;

    setRequestLoading(true);
    setRequestError("");
    setRequestNotice("");

    try {
      const updatedAccess = await submitPermissionRequest(employeeId, {
        permissions: requestedPermissions,
        requestReason,
      });

      if (updatedAccess) {
        setAccessSnapshot({
          ...updatedAccess,
          status: String(updatedAccess.status || "").toLowerCase(),
          statusRaw: updatedAccess.status,
        });
      }

      setRequestOpen(false);
      setRequestNotice(
        "ส่งคำขอสิทธิ์เพิ่มเติมไปยัง Admin แล้ว ระบบจะแจ้งใน Admin Console",
      );
    } catch (error) {
      setRequestError(error.message || "ส่งคำขอสิทธิ์เพิ่มเติมไม่สำเร็จ");
    } finally {
      setRequestLoading(false);
    }
  };

  return (
    <div className="space-y-6 pt-6">
      {/* Header Card */}
      <section className="relative overflow-hidden rounded-[2rem] border border-slate-300 bg-gradient-to-br from-cyan-50 via-white to-slate-100 p-6 shadow-lg dark:border-slate-700 dark:from-slate-900 dark:via-slate-950 dark:to-cyan-950/30">
        <div className="absolute right-[-80px] top-[-80px] h-56 w-56 rounded-full bg-cyan-400/20 blur-3xl" />
        <div className="absolute bottom-[-90px] left-[-90px] h-56 w-56 rounded-full bg-emerald-400/10 blur-3xl" />

        <div className="relative flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex items-center gap-5">
            <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-3xl bg-cyan-600 text-3xl font-black text-white shadow-lg shadow-cyan-900/20">
              {employeeInitials}
            </div>

            <div>
              <p className="text-sm font-black uppercase tracking-[0.25em] text-cyan-700 dark:text-cyan-300">
                My Profile
              </p>

              <h2 className="mt-2 text-3xl font-black leading-tight text-slate-950 dark:text-white sm:text-4xl">
                {user.name || "Unknown User"}
              </h2>

              {user.empName_TH ? (
                <p className="mt-1 text-xl font-bold text-slate-600 dark:text-slate-300">
                  {user.empName_TH}
                </p>
              ) : null}
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-3">
            <span className="rounded-2xl bg-slate-900 px-5 py-3 text-base font-black text-white shadow-sm dark:bg-white dark:text-slate-950">
              ID: {employeeId || "-"}
            </span>

            <span
              className={[
                "rounded-2xl px-5 py-3 text-base font-black shadow-sm",
                isAdmin
                  ? "bg-cyan-600 text-white"
                  : canAccessDebugPages
                    ? "bg-amber-500 text-slate-950"
                    : "bg-emerald-600 text-white",
              ].join(" ")}
            >
              {roleLabel}
            </span>
          </div>
        </div>
      </section>

      {/* Employee Information */}
      <section className="rounded-[2rem] border border-slate-300 bg-slate-50 p-5 shadow-md dark:border-slate-700 dark:bg-slate-950">
        <div className="mb-5">
          <h3 className="inline-flex items-center gap-2 text-2xl font-black text-slate-950 dark:text-white">
            <UserRound size={24} className="text-cyan-600 dark:text-cyan-300" />
            ข้อมูลพนักงาน
          </h3>
          <p className="mt-1 text-base font-medium text-slate-500 dark:text-slate-400">
            ข้อมูลผู้ใช้งานที่เข้าสู่ระบบปัจจุบัน
          </p>
        </div>

        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          <InfoCard
            label="รหัสพนักงาน"
            value={employeeId}
            helper="Employee ID"
            tone="cyan"
          />

          <InfoCard
            label="ชื่อ-นามสกุล"
            value={
              <span>
                {user.name || "-"}
                {user.empName_TH ? (
                  <span className="block pt-1 text-xl font-bold text-slate-600 dark:text-slate-300">
                    {user.empName_TH}
                  </span>
                ) : null}
              </span>
            }
          />

          <InfoCard label="แผนก" value={user.dept || "-"} helper="Department" />

          <InfoCard
            label="ตำแหน่ง"
            value={
              <span>
                {user.posCode || "-"}
                {user.positionShow ? (
                  <span className="block pt-1 text-xl font-bold text-slate-600 dark:text-slate-300">
                    {user.positionShow}
                  </span>
                ) : null}
              </span>
            }
          />

          <InfoCard
            label="วันที่เข้าทำงาน"
            value={formatDate(user.joinDate)}
            helper="Join Date"
            tone="amber"
          />

          <InfoCard
            label="ระดับสิทธิ์"
            value={roleLabel}
            helper={isAdmin ? "Full access" : "Permission based access"}
            tone={isAdmin ? "cyan" : "emerald"}
          />
        </div>
      </section>

      {/* Access Permission */}
      <section className="rounded-[2rem] border border-slate-300 bg-white p-5 shadow-md dark:border-slate-700 dark:bg-slate-900">
        <div className="mb-5 flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div>
            <h3 className="inline-flex items-center gap-2 text-2xl font-black text-slate-950 dark:text-white">
              <ShieldCheck
                size={24}
                className="text-cyan-600 dark:text-cyan-300"
              />
              สิทธิ์การเข้าใช้งาน
            </h3>
            <p className="mt-1 text-base font-medium text-slate-500 dark:text-slate-400">
              ตรวจสอบว่า user นี้สามารถเข้าใช้งานหน้าใดได้บ้าง
            </p>
          </div>

          {!isAdmin && missingPermissionItems.length > 0 ? (
            hasPendingPermissionRequest ? (
              <span className="inline-flex w-fit items-center gap-2 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm font-black text-amber-700 dark:border-amber-900/60 dark:bg-amber-950/30 dark:text-amber-300">
                <Clock3 size={18} />
                รอ Admin ตรวจสอบคำขอ
              </span>
            ) : (
              <button
                type="button"
                onClick={handleOpenPermissionRequest}
                className="inline-flex w-fit items-center gap-2 rounded-2xl bg-cyan-600 px-5 py-3 text-sm font-black text-white shadow-sm transition hover:bg-cyan-700"
              >
                <Send size={18} />
                ขอสิทธิ์เพิ่มเติม
              </button>
            )
          ) : !isAdmin ? (
            <span className="inline-flex w-fit items-center gap-2 rounded-2xl bg-emerald-100 px-4 py-3 text-sm font-black text-emerald-700 dark:bg-emerald-950/40 dark:text-emerald-300">
              <CheckCircle2 size={18} />
              มีสิทธิ์ครบทุกหน้าแล้ว
            </span>
          ) : null}
        </div>

        {requestNotice ? (
          <div className="mb-4 flex items-start gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-sm font-bold text-emerald-700 dark:border-emerald-900/60 dark:bg-emerald-950/30 dark:text-emerald-300">
            <CheckCircle2 size={19} className="mt-0.5 shrink-0" />
            <span>{requestNotice}</span>
          </div>
        ) : null}

        {requestError ? (
          <div className="mb-4 flex items-start gap-3 rounded-2xl border border-rose-200 bg-rose-50 p-4 text-sm font-bold text-rose-700 dark:border-rose-900/60 dark:bg-rose-950/30 dark:text-rose-300">
            <AlertTriangle size={19} className="mt-0.5 shrink-0" />
            <span>{requestError}</span>
          </div>
        ) : null}

        {permissionRequestStatus === "PENDING" ? (
          <div className="mb-5 rounded-2xl border border-amber-200 bg-amber-50/80 p-4 dark:border-amber-900/60 dark:bg-amber-950/25">
            <div className="flex items-start gap-3">
              <Clock3 size={20} className="mt-0.5 shrink-0 text-amber-600" />
              <div>
                <p className="font-black text-amber-800 dark:text-amber-200">
                  คำขอสิทธิ์เพิ่มเติมกำลังรอ Admin ตรวจสอบ
                </p>
                <p className="mt-1 text-sm font-semibold text-amber-700/80 dark:text-amber-300/80">
                  ขอ: {requestedPermissionLabels.join(", ") || "-"}
                  {permissionRequest?.requestedAt
                    ? ` • ส่งเมื่อ ${permissionRequest.requestedAt}`
                    : ""}
                </p>
              </div>
            </div>
          </div>
        ) : permissionRequestStatus === "RESOLVED" ? (
          <div className="mb-5 rounded-2xl border border-emerald-200 bg-emerald-50/80 p-4 dark:border-emerald-900/60 dark:bg-emerald-950/25">
            <div className="flex items-start gap-3">
              <CheckCircle2 size={20} className="mt-0.5 shrink-0 text-emerald-600" />
              <div>
                <p className="font-black text-emerald-800 dark:text-emerald-200">
                  Admin ตรวจสอบคำขอสิทธิ์ล่าสุดแล้ว
                </p>
                <p className="mt-1 text-sm font-semibold text-emerald-700/80 dark:text-emerald-300/80">
                  ระบบจะอัปเดตสิทธิ์และเมนูให้อัตโนมัติภายในประมาณ 30 วินาที หากยังไม่เปลี่ยนให้ Logout แล้ว Login ใหม่
                </p>
              </div>
            </div>
          </div>
        ) : null}

        <div className="grid gap-3 md:grid-cols-2 xl:grid-cols-3">
          {accessItems.map((item) => (
            <AccessCard
              key={item.key}
              title={item.title}
              description={item.description}
              allowed={item.allowed}
            />
          ))}
        </div>
      </section>

      {requestOpen ? (
        <div className="fixed inset-0 z-[210] flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-sm">
          <div className="max-h-[88vh] w-full max-w-3xl overflow-y-auto rounded-[2rem] bg-white shadow-2xl ring-1 ring-slate-200 dark:bg-slate-950 dark:ring-slate-800">
            <div className="sticky top-0 z-10 flex items-start justify-between gap-4 border-b border-slate-200 bg-white px-6 py-5 dark:border-slate-800 dark:bg-slate-950">
              <div>
                <p className="text-xs font-black uppercase tracking-[0.2em] text-cyan-600">
                  Permission Request
                </p>
                <h3 className="mt-1 text-2xl font-black text-slate-950 dark:text-white">
                  ขอสิทธิ์เพิ่มเติม
                </h3>
                <p className="mt-1 text-sm font-semibold text-slate-500 dark:text-slate-400">
                  เลือกเฉพาะหน้าที่ต้องการใช้งาน คำขอจะถูกส่งไปให้ Admin ตรวจสอบ
                </p>
              </div>

              <button
                type="button"
                onClick={() => setRequestOpen(false)}
                disabled={requestLoading}
                className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-slate-100 text-slate-500 transition hover:bg-slate-200 disabled:opacity-50 dark:bg-slate-800 dark:text-slate-300"
              >
                <X size={20} />
              </button>
            </div>

            <div className="p-6">
              <div className="grid gap-3 md:grid-cols-2">
                {missingPermissionItems.map((item) => {
                  const checked = Boolean(requestedPermissions[item.key]);

                  return (
                    <label
                      key={item.key}
                      className={[
                        "flex cursor-pointer items-start gap-3 rounded-2xl border p-4 transition",
                        checked
                          ? "border-cyan-300 bg-cyan-50 dark:border-cyan-800 dark:bg-cyan-950/30"
                          : "border-slate-200 bg-white hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:hover:bg-slate-800/70",
                      ].join(" ")}
                    >
                      <input
                        type="checkbox"
                        checked={checked}
                        onChange={() => handleToggleRequestedPermission(item.key)}
                        className="mt-1 h-4 w-4 rounded border-slate-300 text-cyan-600 focus:ring-cyan-500"
                      />
                      <span>
                        <span className="block font-black text-slate-900 dark:text-slate-100">
                          {item.title}
                        </span>
                        <span className="mt-1 block text-sm font-semibold text-slate-500 dark:text-slate-400">
                          {item.description}
                        </span>
                      </span>
                    </label>
                  );
                })}
              </div>

              <div className="mt-5">
                <label className="text-sm font-black text-slate-700 dark:text-slate-200">
                  เหตุผล / รายละเอียดเพิ่มเติม
                </label>
                <textarea
                  value={requestReason}
                  onChange={(event) => setRequestReason(event.target.value)}
                  rows={3}
                  maxLength={300}
                  placeholder="เช่น ต้องใช้ Line Information เพื่อตรวจสอบ Mapping ประจำเดือน"
                  className="mt-2 w-full resize-none rounded-2xl border border-slate-300 bg-white px-4 py-3 text-sm font-semibold text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
                />
                <p className="mt-1 text-right text-xs font-bold text-slate-400">
                  {requestReason.length} / 300
                </p>
              </div>

              {requestError ? (
                <div className="mt-4 flex items-start gap-3 rounded-2xl border border-rose-200 bg-rose-50 p-4 text-sm font-bold text-rose-700 dark:border-rose-900/60 dark:bg-rose-950/30 dark:text-rose-300">
                  <AlertTriangle size={19} className="mt-0.5 shrink-0" />
                  <span>{requestError}</span>
                </div>
              ) : null}
            </div>

            <div className="flex flex-col-reverse gap-3 border-t border-slate-200 px-6 py-5 sm:flex-row sm:justify-end dark:border-slate-800">
              <button
                type="button"
                onClick={() => setRequestOpen(false)}
                disabled={requestLoading}
                className="rounded-2xl border border-slate-300 bg-white px-5 py-3 text-sm font-black text-slate-700 transition hover:bg-slate-50 disabled:opacity-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200"
              >
                ยกเลิก
              </button>
              <button
                type="button"
                onClick={handleSubmitPermissionRequest}
                disabled={requestLoading || selectedRequestCount === 0}
                className="inline-flex items-center justify-center gap-2 rounded-2xl bg-cyan-600 px-5 py-3 text-sm font-black text-white transition hover:bg-cyan-700 disabled:cursor-not-allowed disabled:opacity-50"
              >
                <Send size={17} />
                {requestLoading
                  ? "กำลังส่งคำขอ..."
                  : `ส่งคำขอ ${selectedRequestCount || ""} สิทธิ์`}
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
