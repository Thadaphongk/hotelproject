import { useEffect, useMemo, useState } from "react";
import {
  CalendarDays,
  CheckCircle2,
  ClipboardCheck,
  ClipboardList,
  Clock3,
  Database,
  Download,
  Eraser,
  RefreshCw,
  RotateCcw,
  Save,
  TriangleAlert,
  XCircle,
} from "lucide-react";
import { writeLog, writeLogs } from "../services/logClient";
import { formatDisplayMachineName } from "../utils/machineQueueUtils";

const API_BASE_URL = "";

const machineSortOrder = [
  "DEMO-MC-A01",
  "DEMO-MC-A02",
  "DEMO-MC-B01",
  "DEMO-MC-B02",
  "DEMO-MC-C01",
  "DEMO-MC-C02",
];

const statusOptions = ["", "RUN", "STOP", "NO DATA"];

const todayText = () => {
  const now = new Date();
  const yyyy = now.getFullYear();
  const mm = String(now.getMonth() + 1).padStart(2, "0");
  const dd = String(now.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
};

const apiUrl = (path) => `${API_BASE_URL}${path}`;

const hasValue = (value) => {
  const text = String(value ?? "").trim();
  return (
    text !== "" &&
    text !== "-" &&
    text.toLowerCase() !== "null" &&
    text.toLowerCase() !== "undefined"
  );
};

const normalize = (value) =>
  String(value ?? "")
    .trim()
    .toUpperCase();

const normalizeLot = (value) => {
  const text = normalize(value);
  if (text === "-" || text === "NULL" || text === "UNDEFINED") return "";
  return text;
};

const normalizeLoss = (value) => {
  const text = normalize(value);
  if (text === "-" || text === "NULL" || text === "UNDEFINED") return "";
  return text;
};

const normalizeStatus = (value) => {
  const text = normalize(value);
  if (text === "RUNNING") return "RUN";
  if (text === "LOSS" || text === "STOPPING") return "STOP";
  if (text === "NO_DATA" || text === "NODATA") return "NO DATA";
  return text;
};

const getFirstLot = (machine) => machine?.lots?.[0] || machine || {};

const getOurStatus = (lot) => {
  if (!lot || lot.sourceType === "NO_DATA") return "NO DATA";
  if (hasValue(lot.stopCode)) return "STOP";

  const status = normalizeStatus(lot.machineStatus);
  if (status === "RUN") return "RUN";
  if (status && status !== "-") return status;

  if (hasValue(lot.lotId) || hasValue(lot.lotId)) return "RUN";
  return "NO DATA";
};

const buildEmptyRow = (date, machine) => ({
  date,
  machine,
  ourLot: "-",
  ourStatus: "NO DATA",
  ourLossCode: "",
  realLot: "",
  realStatus: "",
  realLossCode: "",
  result: "PENDING",
  remark: "",
  checkedBy: "",
});

const calculateResult = (row) => {
  const hasAnyReal =
    hasValue(row.realLot) ||
    hasValue(row.realStatus) ||
    hasValue(row.realLossCode);

  if (!hasAnyReal) return "PENDING";

  const lotOk = normalizeLot(row.ourLot) === normalizeLot(row.realLot);
  const statusOk =
    normalizeStatus(row.ourStatus) === normalizeStatus(row.realStatus);
  const lossOk =
    normalizeLoss(row.ourLossCode) === normalizeLoss(row.realLossCode);

  return lotOk && statusOk && lossOk ? "OK" : "NG";
};

const resultBadgeClass = (result) => {
  if (result === "OK") {
    return "bg-emerald-500/15 text-emerald-700 ring-1 ring-emerald-500/30 dark:text-emerald-300";
  }
  if (result === "NG") {
    return "bg-rose-500/15 text-rose-700 ring-1 ring-rose-500/30 dark:text-rose-300";
  }
  return "bg-slate-500/15 text-slate-700 ring-1 ring-slate-500/30 dark:text-slate-300";
};

const csvEscape = (value) => {
  const text = String(value ?? "");
  if (/[",\n]/.test(text)) return `"${text.replace(/"/g, '""')}"`;
  return text;
};

export default function DailyCheck({ user }) {
  const [date, setDate] = useState(todayText());
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  const [message, setMessage] = useState(null);
  const [lastUpdated, setLastUpdated] = useState(null);

  const currentUserId = String(
    user?.id || user?.empCode || user?.employeeId || "",
  ).trim();
  const currentUserName = String(
    user?.name || user?.empName || user?.empName_TH || "",
  ).trim();

  const summary = useMemo(() => {
    return rows.reduce(
      (acc, row) => {
        acc.total += 1;
        acc[row.result] = (acc[row.result] || 0) + 1;
        return acc;
      },
      { total: 0, OK: 0, NG: 0, PENDING: 0 },
    );
  }, [rows]);

  const buildRowsFromMachines = (machines, savedRows, draftRows = []) => {
    const savedMap = new Map(
      savedRows.map((row) => [normalize(row.machine), row]),
    );

    // draftRows = ข้อความที่ user กำลังกรอกอยู่บนหน้าจอ
    // ใช้เพื่อให้กด Refresh แล้วช่อง Real Lot / Real Status / Real Loss / Remark ไม่หาย
    const draftMap = new Map(
      draftRows.map((row) => [normalize(row.machine), row]),
    );

    const machineMap = new Map(
      machines.map((machine) => [normalize(machine.machineName), machine]),
    );

    return machineSortOrder.map((machineName) => {
      const machine = machineMap.get(machineName);
      const lot = getFirstLot(machine);
      const saved = savedMap.get(machineName) || {};
      const draft = draftMap.get(machineName);
      const manual = draft || saved;

      const ourLot = hasValue(lot?.lotId || lot?.lotId)
        ? String(lot.lotId || lot.lotId).trim()
        : "-";

      const baseRow = {
        ...buildEmptyRow(date, machineName),
        ourLot,
        ourStatus: getOurStatus(lot),
        ourLossCode: hasValue(lot?.stopCode) ? String(lot.stopCode).trim() : "",
        checkedBy: manual.checkedBy ?? "",
        realLot: manual.realLot ?? "",
        realStatus: manual.realStatus ?? "",
        realLossCode: manual.realLossCode ?? "",
        remark: manual.remark ?? "",
      };

      return {
        ...baseRow,
        result: calculateResult(baseRow),
      };
    });
  };

  const fetchData = async ({ preserveInputs = true } = {}) => {
    setLoading(true);
    setError(null);
    setMessage(null);

    try {
      const [machineRes, savedRes] = await Promise.all([
        fetch(apiUrl("/api/machines")),
        fetch(
          apiUrl(`/api/machine-verifications?date=${encodeURIComponent(date)}`),
        ),
      ]);

      if (!machineRes.ok) throw new Error("Failed to fetch /api/machines");
      if (!savedRes.ok)
        throw new Error("Failed to fetch /api/machine-verifications");

      const machines = await machineRes.json();
      const savedPayload = await savedRes.json();
      const savedRows = Array.isArray(savedPayload?.rows)
        ? savedPayload.rows
        : [];
      const draftRows = preserveInputs ? rows : [];

      setRows(
        buildRowsFromMachines(
          Array.isArray(machines) ? machines : [],
          savedRows,
          draftRows,
        ),
      );
      setLastUpdated(new Date());
    } catch (err) {
      console.error(err);
      setError(err.message || "Failed to load Daily Check data");
      setRows(machineSortOrder.map((machine) => buildEmptyRow(date, machine)));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    // เวลาเปลี่ยนวันที่ ให้โหลดข้อมูลที่บันทึกไว้ของวันนั้นจาก Demo API ใหม่
    // ไม่เอาข้อความ draft จากวันที่ก่อนหน้ามาปน
    fetchData({ preserveInputs: false });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [date]);

  const updateRow = (machine, field, value) => {
    setRows((prevRows) =>
      prevRows.map((row) => {
        if (row.machine !== machine) return row;
        const nextRow = { ...row, [field]: value };
        return { ...nextRow, result: calculateResult(nextRow) };
      }),
    );
  };

  const clearInputs = async () => {
    const ok = window.confirm(
      "ต้องการล้างช่อง Real Lot, Real Status, Real Loss, Remark และ Checked By บนหน้าจอใช่ไหม?",
    );

    if (!ok) return;

    setRows((prevRows) =>
      prevRows.map((row) => {
        const nextRow = {
          ...row,
          realLot: "",
          realStatus: "",
          realLossCode: "",
          remark: "",
          checkedBy: "",
        };

        return {
          ...nextRow,
          result: calculateResult(nextRow),
        };
      }),
    );

    setError(null);
    setMessage(
      "Cleared input fields on screen. Click Save if you want to overwrite saved data.",
    );

    await writeLog({
      date,
      type: "ACTIVITY",
      level: "INFO",
      userId: currentUserId,
      userName: currentUserName,
      page: "DailyCheck",
      action: "CLEAR_INPUTS",
      message: "Cleared Daily Check input fields on screen",
      meta: { rows: rows.length },
    });
  };

  const saveRows = async () => {
    setSaving(true);
    setError(null);
    setMessage(null);

    try {
      const payloadRows = rows.map((row) => ({
        ...row,
        date,
        result: calculateResult(row),
      }));

      const res = await fetch(apiUrl("/api/machine-verifications/bulk"), {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ date, rows: payloadRows }),
      });

      const payload = await res.json().catch(() => ({}));
      if (!res.ok || payload.ok === false) {
        throw new Error(payload.message || "Failed to save Daily Check data");
      }

      setMessage(
        `Saved ${payload.saved ?? payloadRows.length} rows successfully`,
      );
      setLastUpdated(new Date());

      await writeLogs(
        payloadRows.map((row) => ({
          date,
          type: "DAILY_CHECK",
          level: row.result === "NG" ? "WARN" : "INFO",
          userId: row.checkedBy || currentUserId,
          userName: currentUserName,
          page: "DailyCheck",
          action: "SAVE",
          machine: row.machine,
          lot: row.realLot || row.ourLot,
          result: row.result,
          message: `Saved verification ${row.machine}: ${row.result}`,
          meta: {
            ourLot: row.ourLot,
            ourStatus: row.ourStatus,
            ourLossCode: row.ourLossCode,
            realLot: row.realLot,
            realStatus: row.realStatus,
            realLossCode: row.realLossCode,
            remark: row.remark,
          },
        })),
      );
    } catch (err) {
      console.error(err);
      setError(err.message || "Failed to save Daily Check data");

      await writeLog({
        date,
        type: "DAILY_CHECK",
        level: "ERROR",
        userId: currentUserId,
        userName: currentUserName,
        page: "DailyCheck",
        action: "SAVE_ERROR",
        message: err.message || "Failed to save Daily Check data",
      });
    } finally {
      setSaving(false);
    }
  };

  const exportCsv = () => {
    const headers = [
      "Date",
      "Machine",
      "Our Lot",
      "Our Status",
      "Our LossCode",
      "Real Lot",
      "Real Status",
      "Real LossCode",
      "Result",
      "Remark",
      "Checked By",
    ];

    const lines = [
      headers.join(","),
      ...rows.map((row) =>
        [
          date,
          row.machine,
          row.ourLot,
          row.ourStatus,
          row.ourLossCode,
          row.realLot,
          row.realStatus,
          row.realLossCode,
          row.result,
          row.remark,
          row.checkedBy,
        ]
          .map(csvEscape)
          .join(","),
      ),
    ];

    const blob = new Blob(["\uFEFF" + lines.join("\r\n")], {
      type: "text/csv;charset=utf-8;",
    });
    const link = document.createElement("a");
    link.href = URL.createObjectURL(blob);
    link.download = `machine-daily-check-${date}.csv`;
    link.click();
    URL.revokeObjectURL(link.href);

    writeLog({
      date,
      type: "ACTIVITY",
      level: "INFO",
      userId: currentUserId,
      userName: currentUserName,
      page: "DailyCheck",
      action: "EXPORT_CSV",
      message: `Exported Daily Check CSV for ${date}`,
      meta: { rows: rows.length },
    });
  };

  return (
    <div className="min-h-full p-4 text-slate-950 dark:text-slate-50 sm:p-6">
      <div className="mx-auto flex max-w-8xl flex-col gap-4">
        <section className="relative overflow-hidden rounded-[2rem] border border-slate-300 bg-gradient-to-br from-cyan-50 via-white to-slate-100 p-5 shadow-lg dark:border-slate-700 dark:from-slate-900 dark:via-slate-950 dark:to-cyan-950/30">
          <div className="absolute right-[-70px] top-[-80px] h-52 w-52 rounded-full bg-cyan-400/20 blur-3xl" />

          <div className="relative flex flex-col gap-5 lg:flex-row lg:items-end lg:justify-between">
            <div className="flex items-start gap-4">
              <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-cyan-600 text-white shadow-lg shadow-cyan-600/20">
                <ClipboardCheck size={28} strokeWidth={2.2} />
              </div>

              <div>
                <p className="text-xs font-black uppercase tracking-[0.22em] text-cyan-700 dark:text-cyan-300">
                  Daily Data Check
                </p>
                <h1 className="mt-1 text-2xl font-black tracking-tight text-slate-900 sm:text-3xl dark:text-white">
                  Machine Verification
                </h1>
                <p className="mt-2 max-w-3xl text-sm font-medium text-slate-600 dark:text-slate-300">
                  บันทึกผลเทียบข้อมูลระหว่างเว็บของเราและเว็บจริงรายวัน
                  โดยเก็บลงไฟล์ JSON ใน Backend
                </p>

                <div className="mt-3 flex flex-wrap gap-2">
                  <span className="inline-flex items-center gap-2 rounded-full bg-cyan-100 px-3 py-1.5 text-xs font-black text-cyan-800 dark:bg-cyan-950/60 dark:text-cyan-300">
                    <Database size={14} />
                    JSON Storage
                  </span>
                  <span className="inline-flex items-center gap-2 rounded-full bg-slate-200/80 px-3 py-1.5 text-xs font-black text-slate-700 dark:bg-slate-800 dark:text-slate-300">
                    <ClipboardList size={14} />
                    {machineSortOrder.length} Machines
                  </span>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap items-end gap-3">
              <label className="flex flex-col gap-1 text-sm font-bold text-slate-600 dark:text-slate-300">
                <span className="inline-flex items-center gap-2">
                  <CalendarDays size={16} />
                  Date
                </span>
                <input
                  type="date"
                  value={date}
                  onChange={(event) => setDate(event.target.value)}
                  className="h-11 rounded-xl border border-slate-300 bg-white px-3 text-slate-950 shadow-sm outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-50 dark:focus:ring-cyan-950"
                />
              </label>

              <button
                type="button"
                onClick={() => fetchData({ preserveInputs: true })}
                disabled={loading}
                title="Refresh ข้อมูลเครื่อง โดยเก็บข้อความที่กำลังกรอกไว้"
                className="inline-flex h-11 items-center gap-2 rounded-xl bg-slate-900 px-4 font-bold text-white shadow-sm transition hover:bg-slate-700 disabled:cursor-not-allowed disabled:opacity-60 dark:bg-slate-100 dark:text-slate-950 dark:hover:bg-white"
              >
                <RefreshCw size={17} className={loading ? "animate-spin" : ""} />
                {loading ? "Loading..." : "Refresh"}
              </button>

              <button
                type="button"
                onClick={() => fetchData({ preserveInputs: false })}
                disabled={loading}
                title="โหลดข้อความที่ Save ไว้จาก JSON ใหม่ และทับข้อความที่ยังไม่ได้ Save"
                className="inline-flex h-11 items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 font-bold text-slate-700 shadow-sm transition hover:border-cyan-300 hover:bg-cyan-50 hover:text-cyan-700 disabled:cursor-not-allowed disabled:opacity-60 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200 dark:hover:bg-slate-900"
              >
                <RotateCcw size={17} />
                Reload Saved
              </button>

              <button
                type="button"
                onClick={clearInputs}
                disabled={loading || saving}
                title="ล้างช่องที่กรอกเองบนหน้าจอ ไม่ลบ JSON จนกว่าจะกด Save"
                className="inline-flex h-11 items-center gap-2 rounded-xl border border-rose-300 bg-white px-4 font-bold text-rose-700 shadow-sm transition hover:bg-rose-50 disabled:cursor-not-allowed disabled:opacity-60 dark:border-rose-800 dark:bg-slate-950 dark:text-rose-300 dark:hover:bg-rose-950/30"
              >
                <Eraser size={17} />
                Clear
              </button>

              <button
                type="button"
                onClick={saveRows}
                disabled={saving || loading}
                className="inline-flex h-11 items-center gap-2 rounded-xl bg-cyan-600 px-4 font-bold text-white shadow-sm shadow-cyan-600/20 transition hover:bg-cyan-500 disabled:cursor-not-allowed disabled:opacity-60"
              >
                <Save size={17} />
                {saving ? "Saving..." : "Save"}
              </button>

              <button
                type="button"
                onClick={exportCsv}
                className="inline-flex h-11 items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 font-bold text-slate-700 shadow-sm transition hover:border-cyan-300 hover:bg-cyan-50 hover:text-cyan-700 dark:border-slate-700 dark:bg-slate-950 dark:text-slate-200 dark:hover:bg-slate-900"
              >
                <Download size={17} />
                Export CSV
              </button>
            </div>
          </div>

          <div className="relative mt-5 grid gap-3 sm:grid-cols-4">
            <SummaryCard
              label="Total"
              value={summary.total}
              icon={Database}
            />
            <SummaryCard
              label="OK"
              value={summary.OK}
              tone="ok"
              icon={CheckCircle2}
            />
            <SummaryCard
              label="NG"
              value={summary.NG}
              tone="ng"
              icon={XCircle}
            />
            <SummaryCard
              label="Pending"
              value={summary.PENDING}
              tone="pending"
              icon={Clock3}
            />
          </div>

          {(error || message || lastUpdated) && (
            <div className="mt-4 flex flex-wrap gap-3 text-sm">
              {error && (
                <span className="inline-flex items-center gap-2 rounded-xl bg-rose-500/10 px-3 py-2 font-semibold text-rose-700 dark:text-rose-300">
                  <TriangleAlert size={16} />
                  {error}
                </span>
              )}
              {message && (
                <span className="inline-flex items-center gap-2 rounded-xl bg-emerald-500/10 px-3 py-2 font-semibold text-emerald-700 dark:text-emerald-300">
                  <CheckCircle2 size={16} />
                  {message}
                </span>
              )}
              {lastUpdated && (
                <span className="inline-flex items-center gap-2 rounded-xl bg-slate-500/10 px-3 py-2 font-semibold text-slate-600 dark:text-slate-300">
                  <Clock3 size={16} />
                  Last update: {lastUpdated.toLocaleString()}
                </span>
              )}
            </div>
          )}
        </section>

        <section className="overflow-hidden rounded-3xl border border-slate-200 bg-white/90 shadow-sm dark:border-slate-800 dark:bg-slate-900/90">
          <div className="flex flex-col gap-2 border-b border-slate-200 bg-slate-50/80 px-5 py-4 sm:flex-row sm:items-center sm:justify-between dark:border-slate-800 dark:bg-slate-950/50">
            <div className="flex items-center gap-3">
              <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-cyan-100 text-cyan-700 dark:bg-cyan-950/60 dark:text-cyan-300">
                <ClipboardList size={20} />
              </span>
              <div>
                <h2 className="font-black text-slate-900 dark:text-white">
                  รายการตรวจสอบเครื่องจักร
                </h2>
                <p className="text-xs font-medium text-slate-500 dark:text-slate-400">
                  เปรียบเทียบข้อมูลระบบกับข้อมูลจริงประจำวัน
                </p>
              </div>
            </div>
            <span className="rounded-full bg-cyan-100 px-3 py-1.5 text-xs font-black text-cyan-800 dark:bg-cyan-950/60 dark:text-cyan-300">
              {rows.length} รายการ
            </span>
          </div>

          <div className="overflow-x-auto">
            <table className="min-w-[1250px] w-full text-left text-sm">
              <thead className="bg-slate-100 text-xs font-black uppercase tracking-wider text-slate-600 dark:bg-slate-800 dark:text-slate-300">
                <tr>
                  <th className="px-4 py-4">Machine</th>
                  <th className="px-4 py-4">Our Lot</th>
                  <th className="px-4 py-4">Our Status</th>
                  <th className="px-4 py-4">Our Loss</th>
                  <th className="px-4 py-4">Real Lot</th>
                  <th className="px-4 py-4">Real Status</th>
                  <th className="px-4 py-4">Real Loss</th>
                  <th className="px-4 py-4 text-center">Result</th>
                  <th className="px-4 py-4">Remark</th>
                  <th className="px-4 py-4">Checked By</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-200 dark:divide-slate-800">
                {rows.map((row) => (
                  <tr
                    key={row.machine}
                    className="hover:bg-slate-50 dark:hover:bg-slate-800/70"
                  >
                    <td className="px-4 py-3 font-black text-slate-900 dark:text-slate-50">
                      {formatDisplayMachineName(row.machine)}
                    </td>
                    <td className="px-4 py-3 font-semibold text-slate-700 dark:text-slate-200">
                      {row.ourLot || "-"}
                    </td>
                    <td className="px-4 py-3">
                      <StatusPill status={row.ourStatus} />
                    </td>
                    <td className="px-4 py-3 font-semibold text-rose-600 dark:text-rose-300">
                      {row.ourLossCode || "-"}
                    </td>
                    <td className="px-4 py-3">
                      <input
                        value={row.realLot}
                        onChange={(event) =>
                          updateRow(row.machine, "realLot", event.target.value)
                        }
                        placeholder="Real lot"
                        className="w-36 rounded-xl border border-slate-300 bg-white px-3 py-2 outline-none focus:border-cyan-500 dark:border-slate-700 dark:bg-slate-950"
                      />
                    </td>
                    <td className="px-4 py-3">
                      <select
                        value={row.realStatus}
                        onChange={(event) =>
                          updateRow(
                            row.machine,
                            "realStatus",
                            event.target.value,
                          )
                        }
                        className="w-32 rounded-xl border border-slate-300 bg-white px-3 py-2 outline-none focus:border-cyan-500 dark:border-slate-700 dark:bg-slate-950"
                      >
                        {statusOptions.map((option) => (
                          <option key={option || "blank"} value={option}>
                            {option || "Select"}
                          </option>
                        ))}
                      </select>
                    </td>
                    <td className="px-4 py-3">
                      <input
                        value={row.realLossCode}
                        onChange={(event) =>
                          updateRow(
                            row.machine,
                            "realLossCode",
                            event.target.value,
                          )
                        }
                        placeholder="Loss"
                        className="w-28 rounded-xl border border-slate-300 bg-white px-3 py-2 outline-none focus:border-cyan-500 dark:border-slate-700 dark:bg-slate-950"
                      />
                    </td>
                    <td className="px-4 py-3 text-center">
                      <span
                        className={`inline-flex min-w-20 justify-center rounded-full px-3 py-1 text-xs font-black ${resultBadgeClass(row.result)}`}
                      >
                        {row.result}
                      </span>
                    </td>
                    <td className="px-4 py-3">
                      <input
                        value={row.remark}
                        onChange={(event) =>
                          updateRow(row.machine, "remark", event.target.value)
                        }
                        placeholder="Remark"
                        className="w-52 rounded-xl border border-slate-300 bg-white px-3 py-2 outline-none focus:border-cyan-500 dark:border-slate-700 dark:bg-slate-950"
                      />
                    </td>
                    <td className="px-4 py-3">
                      <input
                        value={row.checkedBy}
                        onChange={(event) =>
                          updateRow(
                            row.machine,
                            "checkedBy",
                            event.target.value,
                          )
                        }
                        placeholder="Emp ID"
                        className="w-28 rounded-xl border border-slate-300 bg-white px-3 py-2 outline-none focus:border-cyan-500 dark:border-slate-700 dark:bg-slate-950"
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </section>
      </div>
    </div>
  );
}

function SummaryCard({ label, value, tone = "total", icon: Icon }) {
  const style = {
    total: {
      value: "text-cyan-700 dark:text-cyan-300",
      icon: "bg-cyan-100 text-cyan-700 dark:bg-cyan-950/60 dark:text-cyan-300",
      card: "from-cyan-50 to-white dark:from-cyan-950/30 dark:to-slate-950",
    },
    ok: {
      value: "text-emerald-700 dark:text-emerald-300",
      icon: "bg-emerald-100 text-emerald-700 dark:bg-emerald-950/60 dark:text-emerald-300",
      card: "from-emerald-50 to-white dark:from-emerald-950/30 dark:to-slate-950",
    },
    ng: {
      value: "text-rose-700 dark:text-rose-300",
      icon: "bg-rose-100 text-rose-700 dark:bg-rose-950/60 dark:text-rose-300",
      card: "from-rose-50 to-white dark:from-rose-950/30 dark:to-slate-950",
    },
    pending: {
      value: "text-slate-700 dark:text-slate-300",
      icon: "bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300",
      card: "from-slate-100 to-white dark:from-slate-900 dark:to-slate-950",
    },
  }[tone];

  return (
    <div
      className={`flex items-center justify-between rounded-2xl border border-slate-200 bg-gradient-to-br p-4 shadow-sm dark:border-slate-800 ${style.card}`}
    >
      <div>
        <p className="text-xs font-black uppercase tracking-wider text-slate-500 dark:text-slate-400">
          {label}
        </p>
        <p className={`mt-1 text-3xl font-black ${style.value}`}>{value}</p>
      </div>

      {Icon ? (
        <span
          className={`flex h-11 w-11 items-center justify-center rounded-2xl ${style.icon}`}
        >
          <Icon size={22} strokeWidth={2.2} />
        </span>
      ) : null}
    </div>
  );
}

function StatusPill({ status }) {
  const normalized = normalizeStatus(status);
  const className =
    normalized === "RUN"
      ? "bg-emerald-500/15 text-emerald-700 ring-1 ring-emerald-500/30 dark:text-emerald-300"
      : normalized === "STOP"
        ? "bg-rose-500/15 text-rose-700 ring-1 ring-rose-500/30 dark:text-rose-300"
        : "bg-slate-500/15 text-slate-700 ring-1 ring-slate-500/30 dark:text-slate-300";

  return (
    <span
      className={`inline-flex rounded-full px-3 py-1 text-xs font-black ${className}`}
    >
      {normalized || "-"}
    </span>
  );
}
