import { useCallback, useEffect, useMemo, useState } from "react";
import { AlertTriangle, Clock3, RefreshCw, Waypoints } from "lucide-react";
import { getLineInformation } from "../services/api";

const formatDateTime = (value) => {
  const text = String(value || "").trim();
  if (!text) return "-";
  const date = new Date(text.replace(" ", "T"));
  if (Number.isNaN(date.getTime())) return text;
  return date.toLocaleString("th-TH", { hour12: false });
};

export default function LineInformation({ user }) {
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [lastLoaded, setLastLoaded] = useState(null);

  const employeeId = String(user?.empCode || user?.id || user?.employeeId || "")
    .trim()
    .toUpperCase();

  const loadData = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const data = await getLineInformation({ empCode: employeeId });
      setRows(Array.isArray(data?.rows) ? data.rows : []);
      setLastLoaded(new Date());
    } catch (loadError) {
      console.error("Load demo line information error:", loadError);
      setError(loadError?.message || "ไม่สามารถโหลดข้อมูล Line Information ได้");
    } finally {
      setLoading(false);
    }
  }, [employeeId]);

  useEffect(() => {
    loadData();
  }, [loadData]);

  const latestUpdate = useMemo(() => {
    const values = rows.map((row) => String(row?.updatedAt || "")).filter(Boolean);
    return values.sort((a, b) => b.localeCompare(a))[0] || "";
  }, [rows]);

  return (
    <div className="flex h-full flex-col space-y-5 pt-6">
      <section className="relative overflow-hidden rounded-[2rem] border border-slate-300 bg-gradient-to-br from-cyan-50 via-white to-slate-100 p-5 shadow-lg dark:border-slate-700 dark:from-slate-900 dark:via-slate-950 dark:to-cyan-950/30 sm:p-6">
        <div className="relative flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex min-w-0 items-start gap-4">
            <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl bg-cyan-600 text-white shadow-lg shadow-cyan-600/20">
              <Waypoints size={28} />
            </div>
            <div>
              <p className="text-xs font-black uppercase tracking-[0.22em] text-cyan-700 dark:text-cyan-300">Demo Line Mapping</p>
              <h1 className="mt-1 text-2xl font-black text-slate-900 sm:text-3xl dark:text-white">Line Information</h1>
              <p className="mt-1 text-sm font-semibold text-slate-600 dark:text-slate-300">
                ตาราง Mapping จำลองสำหรับใช้สาธิตการอ้างอิง Line และ Machine
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-xs font-semibold text-slate-500 dark:text-slate-400">
              <Clock3 size={17} />
              <div>
                <div>อัปเดตหน้าจอ: {lastLoaded ? lastLoaded.toLocaleTimeString("th-TH") : "-"}</div>
                <div className="text-[11px]">Demo Update: {formatDateTime(latestUpdate)}</div>
              </div>
            </div>
            <button type="button" onClick={loadData} disabled={loading} className="inline-flex h-11 items-center gap-2 rounded-2xl bg-cyan-600 px-5 text-sm font-black text-white hover:bg-cyan-700 disabled:opacity-50">
              <RefreshCw size={17} className={loading ? "animate-spin" : ""} />
              Refresh
            </button>
          </div>
        </div>
      </section>

      <section className="min-h-0 flex-1 overflow-hidden rounded-[1.75rem] border border-slate-300 bg-white shadow-lg dark:border-slate-700 dark:bg-slate-900">
        <div className="flex items-center justify-between border-b border-slate-200 px-5 py-4 dark:border-slate-700">
          <div>
            <p className="text-xs font-black uppercase tracking-[0.16em] text-cyan-700 dark:text-cyan-300">Synthetic Reference</p>
            <h2 className="mt-0.5 text-lg font-black text-slate-900 dark:text-white">Line / Machine Mapping</h2>
          </div>
          <span className="rounded-full bg-slate-100 px-3 py-1.5 text-xs font-black text-slate-600 ring-1 ring-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:ring-slate-700">{rows.length} Line</span>
        </div>

        {error ? (
          <div className="flex min-h-[260px] items-center justify-center gap-2 px-6 text-center font-semibold text-rose-600"><AlertTriangle size={20} />{error}</div>
        ) : loading && rows.length === 0 ? (
          <div className="flex min-h-[260px] items-center justify-center gap-3 text-sm font-semibold text-slate-500"><RefreshCw size={20} className="animate-spin" />กำลังโหลดข้อมูล Mapping...</div>
        ) : rows.length === 0 ? (
          <div className="flex min-h-[260px] items-center justify-center text-sm font-semibold text-slate-500">ไม่พบข้อมูล Mapping จำลอง</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full min-w-[760px] text-left">
              <thead><tr className="bg-slate-50 text-[11px] font-black uppercase tracking-[0.08em] text-slate-500 dark:bg-slate-800/80 dark:text-slate-400">
                <th className="border-b border-slate-200 px-6 py-4 dark:border-slate-700">Line</th>
                <th className="border-b border-slate-200 px-6 py-4 dark:border-slate-700">Primary Machine</th>
                <th className="border-b border-slate-200 px-6 py-4 dark:border-slate-700">Secondary Machine</th>
                <th className="border-b border-slate-200 px-6 py-4 dark:border-slate-700">Last Update</th>
              </tr></thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                {rows.map((row, index) => (
                  <tr key={`${row.lineName}-${index}`} className="transition hover:bg-cyan-50/60 dark:hover:bg-cyan-950/20">
                    <td className="px-6 py-4"><span className="inline-flex rounded-xl bg-cyan-100 px-3 py-1.5 text-sm font-black text-cyan-800 dark:bg-cyan-950/50 dark:text-cyan-300">{row.lineName || "-"}</span></td>
                    <td className="px-6 py-4 text-sm font-black text-blue-700 dark:text-blue-300">{row.primaryMachine || "-"}</td>
                    <td className="px-6 py-4 text-sm font-black text-emerald-700 dark:text-emerald-300">{row.secondaryMachine || "-"}</td>
                    <td className="px-6 py-4 text-sm font-semibold text-slate-600 dark:text-slate-300">{formatDateTime(row.updatedAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>
    </div>
  );
}
