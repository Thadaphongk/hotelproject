const pad = (value) => String(value).padStart(2, "0");

export const toLocalDate = (date = new Date()) =>
  `${date.getFullYear()}-${pad(date.getMonth() + 1)}-${pad(date.getDate())}`;

export const toLocalDateTime = (date = new Date()) =>
  `${toLocalDate(date)} ${pad(date.getHours())}:${pad(date.getMinutes())}:${pad(
    date.getSeconds(),
  )}`;

const relativeDate = (daysAgo = 0, hoursAgo = 0) => {
  const date = new Date();
  date.setDate(date.getDate() - daysAgo);
  date.setHours(date.getHours() - hoursAgo);
  return date;
};

export const DEMO_MACHINE_OPTIONS = [
  "DEMO-MC-A01",
  "DEMO-MC-A02",
  "DEMO-MC-B01",
  "DEMO-MC-B02",
  "DEMO-MC-C01",
  "DEMO-MC-C02",
];

export const DEMO_LINE_MAPPING = {
  "LINE-A": "DEMO-MC-A01",
  "LINE-B": "DEMO-MC-B01",
  "LINE-C": "DEMO-MC-C01",
};

export const demoLineInformation = [
  {
    lineName: "LINE-A",
    primaryMachine: "DEMO-MC-A01",
    secondaryMachine: "DEMO-MC-A02",
    updatedAt: toLocalDateTime(relativeDate(3)),
  },
  {
    lineName: "LINE-B",
    primaryMachine: "DEMO-MC-B01",
    secondaryMachine: "DEMO-MC-B02",
    updatedAt: toLocalDateTime(relativeDate(3)),
  },
  {
    lineName: "LINE-C",
    primaryMachine: "DEMO-MC-C01",
    secondaryMachine: "DEMO-MC-C02",
    updatedAt: toLocalDateTime(relativeDate(3)),
  },
];

export const fullPermissions = {
  dashboard: true,
  queue: true,
  lotSearch: true,
  lineInfo: true,
  returnLot: true,
  moveLot: true,
  dailyCheck: true,
  logs: true,
  machineDebug: true,
  admin: true,
  sequence: true,
  hold: true,
};

export const viewerPermissions = {
  dashboard: true,
  queue: true,
  lotSearch: true,
  lineInfo: false,
  returnLot: false,
  moveLot: false,
  dailyCheck: false,
  logs: false,
  machineDebug: false,
  admin: false,
  sequence: false,
  hold: false,
};

export const operatorPermissions = {
  ...viewerPermissions,
  returnLot: true,
  moveLot: true,
  sequence: true,
  hold: true,
};

export const staffPermissions = {
  ...operatorPermissions,
  lineInfo: true,
  dailyCheck: true,
  logs: true,
};

export const demoEmployees = [
  {
    empCode: "DEMO-ADMIN",
    empName: "Demo Administrator",
    empName_TH: "ผู้ดูแลระบบสาธิต",
    department: "Demo Operations",
    position: "Administrator",
    joinDate: "2026-01-05",
  },
  {
    empCode: "DEMO-OP01",
    empName: "Demo Operator One",
    empName_TH: "ผู้ใช้งานสาธิต หนึ่ง",
    department: "Demo Production",
    position: "Operator",
    joinDate: "2026-02-10",
  },
  {
    empCode: "DEMO-VIEW01",
    empName: "Demo Viewer One",
    empName_TH: "ผู้ชมระบบสาธิต หนึ่ง",
    department: "Demo Planning",
    position: "Viewer",
    joinDate: "2026-03-15",
  },
  {
    empCode: "DEMO-STAFF01",
    empName: "Demo Staff One",
    empName_TH: "เจ้าหน้าที่สาธิต หนึ่ง",
    department: "Demo Support",
    position: "Staff",
    joinDate: "2026-04-20",
  },
  {
    empCode: "DEMO-NEW01",
    empName: "Demo New User",
    empName_TH: "ผู้ใช้ใหม่สาธิต",
    department: "Demo Production",
    position: "Operator",
    joinDate: "2026-05-01",
  },
];

export const initialUserAccess = [
  {
    empCode: "DEMO-ADMIN",
    status: "APPROVED",
    role: "ADMIN",
    permissions: fullPermissions,
    approvedBy: "DEMO-SYSTEM",
    approvedAt: toLocalDateTime(relativeDate(30)),
  },
  {
    empCode: "DEMO-OP01",
    status: "APPROVED",
    role: "OPERATOR",
    permissions: operatorPermissions,
    approvedBy: "DEMO-ADMIN",
    approvedAt: toLocalDateTime(relativeDate(20)),
  },
  {
    empCode: "DEMO-VIEW01",
    status: "APPROVED",
    role: "VIEWER",
    permissions: viewerPermissions,
    approvedBy: "DEMO-ADMIN",
    approvedAt: toLocalDateTime(relativeDate(15)),
  },
  {
    empCode: "DEMO-STAFF01",
    status: "APPROVED",
    role: "STAFF",
    permissions: staffPermissions,
    approvedBy: "DEMO-ADMIN",
    approvedAt: toLocalDateTime(relativeDate(10)),
  },
];

const buildSpecs = (variant = "A") => {
  const offset = variant.charCodeAt(0) - 65;
  return {
    specA: `A-${10 + offset}`,
    specB: `${1.2 + offset * 0.1}`,
    specC: `C-${20 + offset}`,
    specD: `D-${30 + offset}`,
    specE: `E-${40 + offset}`,
    specF: `${8 + offset * 0.5}`,
    specG: `G-${50 + offset}`,
    specH: `H-${60 + offset}`,
    specI: `I-${70 + offset}`,
    specJ: `J-${80 + offset}`,
    specK: `K-${90 + offset}`,
    specL: `L-${100 + offset}`,
    specM: `M-${110 + offset}`,
    specN: `N-${120 + offset}`,
    specO: `O-${130 + offset}`,
    specP: `P-${140 + offset}`,
    specQ: `Q-${150 + offset}`,
    specR: `R-${160 + offset}`,
    specS: `S-${170 + offset}`,
    specT: `T-${180 + offset}`,
    specU: `U-${190 + offset}`,
  };
};

const makeLot = ({
  lotId,
  lineName,
  machineName,
  queueNo,
  partName,
  productCode,
  specVariant = "A",
  sourceType = "QUEUE",
  processStatus = "WAITING",
  machineStatus = "WAIT",
  plannedQty = 50000,
  inputQty = "",
  outputQty = "",
  stopCode = "",
  lotStatus = "RELEASE",
  comment = "",
  startHoursAgo = null,
  inputDaysAgo = 0,
  operatorId = "",
}) => {
  const inputDate = toLocalDate(relativeDate(inputDaysAgo));
  const isCurrent = sourceType === "CURRENT";
  const previousLot = isCurrent
    ? {
        lotId: `PREV-${lotId}`,
        partName,
        ...buildSpecs(specVariant),
      }
    : null;

  return {
    lotId,
    lineName,
    machineName,
    queueMachine: machineName,
    actualMachine: machineName,
    displayMachine: machineName,
    originalMachine: machineName,
    targetMachine: "",
    moveStatus: "NORMAL",
    queueNo,
    // Queue position is not a status group: queue #3 may still be WAITING.
    // Keep the demo's group 3 exclusive to actual PLANNED lots.
    sortGroup:
      processStatus === "PLANNED" ? 3 : sourceType === "CURRENT" ? 1 : 2,
    sortNo: queueNo,
    manualSequence: "",
    sourceType,
    processStatus,
    statusDescription: processStatus,
    machineStatus,
    productCode,
    partName,
    unitName: `DEMO-UNIT-${partName.slice(-1)}`,
    trackingNo: `TRK-${lotId.slice(-3)}`,
    plannedQty,
    inputQty,
    outputQty,
    inputDate,
    queueInputDate: inputDate,
    lotStatus,
    comment,
    stopCode,
    operatorId,
    startTime:
      startHoursAgo === null
        ? ""
        : toLocalDateTime(relativeDate(0, startHoursAgo)),
    previousLot,
    ...buildSpecs(specVariant),
  };
};

export const initialMachines = [
  {
    machineName: "DEMO-MC-A01",
    lineName: "LINE-A",
    lots: [
      makeLot({
        lotId: "LOT-DEMO-001",
        lineName: "LINE-A",
        machineName: "DEMO-MC-A01",
        queueNo: 1,
        partName: "PART-DEMO-A",
        productCode: "PROD-A",
        specVariant: "A",
        sourceType: "CURRENT",
        processStatus: "ACTIVE",
        machineStatus: "RUN",
        inputQty: 48000,
        outputQty: 23500,
        operatorId: "EMP-DEMO-001",
        startHoursAgo: 4,
        inputDaysAgo: 1,
      }),
      makeLot({
        lotId: "LOT-DEMO-002",
        lineName: "LINE-A",
        machineName: "DEMO-MC-A01",
        queueNo: 2,
        partName: "PART-DEMO-A",
        productCode: "PROD-A",
        specVariant: "A",
        inputDaysAgo: 1,
      }),
      makeLot({
        lotId: "LOT-DEMO-003",
        lineName: "LINE-A",
        machineName: "DEMO-MC-A01",
        queueNo: 3,
        partName: "PART-DEMO-B",
        productCode: "PROD-B",
        specVariant: "B",
        lotStatus: "REVIEWED",
        comment: "Synthetic review scenario",
        inputDaysAgo: 2,
      }),
    ],
  },
  {
    machineName: "DEMO-MC-A02",
    lineName: "LINE-A",
    lots: [
      makeLot({
        lotId: "LOT-DEMO-004",
        lineName: "LINE-A",
        machineName: "DEMO-MC-A02",
        queueNo: 1,
        partName: "PART-DEMO-C",
        productCode: "PROD-C",
        specVariant: "C",
        sourceType: "CURRENT",
        processStatus: "ACTIVE",
        machineStatus: "STOP",
        inputQty: 52000,
        outputQty: 12000,
        stopCode: "DEMO-S1",
        operatorId: "EMP-DEMO-002",
        startHoursAgo: 7,
        inputDaysAgo: 1,
      }),
      makeLot({
        lotId: "LOT-DEMO-005",
        lineName: "LINE-A",
        machineName: "DEMO-MC-A02",
        queueNo: 2,
        partName: "PART-DEMO-C",
        productCode: "PROD-C",
        specVariant: "D",
        inputDaysAgo: 3,
      }),
    ],
  },
  {
    machineName: "DEMO-MC-B01",
    lineName: "LINE-B",
    lots: [
      makeLot({
        lotId: "LOT-DEMO-006",
        lineName: "LINE-B",
        machineName: "DEMO-MC-B01",
        queueNo: 1,
        partName: "PART-DEMO-A",
        productCode: "PROD-A",
        specVariant: "A",
        sourceType: "CURRENT",
        processStatus: "ACTIVE",
        machineStatus: "RUN",
        inputQty: 50000,
        outputQty: 41000,
        operatorId: "EMP-DEMO-003",
        startHoursAgo: 8,
        inputDaysAgo: 0,
      }),
      makeLot({
        lotId: "LOT-DEMO-007",
        lineName: "LINE-B",
        machineName: "DEMO-MC-B01",
        queueNo: 2,
        partName: "PART-DEMO-D",
        productCode: "PROD-D",
        specVariant: "E",
        lotStatus: "BLOCKED",
        comment: "Synthetic hold scenario",
        inputDaysAgo: 4,
      }),
    ],
  },
  {
    machineName: "DEMO-MC-B02",
    lineName: "LINE-B",
    lots: [
      makeLot({
        lotId: "LOT-DEMO-008",
        lineName: "LINE-B",
        machineName: "DEMO-MC-B02",
        queueNo: 1,
        partName: "PART-DEMO-E",
        productCode: "PROD-E",
        specVariant: "F",
        sourceType: "QUEUE",
        processStatus: "WAITING",
        machineStatus: "WAIT",
        inputDaysAgo: 5,
      }),
      makeLot({
        lotId: "LOT-DEMO-009",
        lineName: "LINE-B",
        machineName: "DEMO-MC-B02",
        queueNo: 2,
        partName: "PART-DEMO-A",
        productCode: "PROD-A",
        specVariant: "B",
        inputDaysAgo: 6,
      }),
    ],
  },
  {
    machineName: "DEMO-MC-C01",
    lineName: "LINE-C",
    lots: [
      makeLot({
        lotId: "LOT-DEMO-010",
        lineName: "LINE-C",
        machineName: "DEMO-MC-C01",
        queueNo: 1,
        partName: "PART-DEMO-F",
        productCode: "PROD-F",
        specVariant: "G",
        sourceType: "CURRENT",
        processStatus: "ACTIVE",
        machineStatus: "RUN",
        inputQty: 47000,
        outputQty: 6500,
        operatorId: "EMP-DEMO-004",
        startHoursAgo: 2,
        inputDaysAgo: 0,
      }),
      makeLot({
        lotId: "LOT-DEMO-011",
        lineName: "LINE-C",
        machineName: "DEMO-MC-C01",
        queueNo: 2,
        partName: "PART-DEMO-F",
        productCode: "PROD-F",
        specVariant: "G",
        inputDaysAgo: 2,
      }),
      makeLot({
        lotId: "LOT-DEMO-012",
        lineName: "LINE-C",
        machineName: "DEMO-MC-C01",
        queueNo: 3,
        partName: "PART-DEMO-G",
        productCode: "PROD-G",
        specVariant: "H",
        inputDaysAgo: 7,
      }),
    ],
  },
  {
    machineName: "DEMO-MC-C02",
    lineName: "LINE-C",
    lots: [],
  },
];

export const initialMoveHistory = [
  {
    id: "MOVE-DEMO-001",
    lotId: "LOT-DEMO-009",
    partName: "PART-DEMO-A",
    fromMachine: "DEMO-MC-A01",
    toMachine: "DEMO-MC-B02",
    reason: "Balance workload",
    etc: "Synthetic demo history",
    emp: "DEMO-OP01",
    name: "Demo Operator One",
    line: "DEMO",
    dateTime: toLocalDateTime(relativeDate(2)),
  },
];

export const initialReturnHistory = [
  {
    id: "RETURN-DEMO-001",
    lotId: "LOT-DEMO-005",
    issueReason: "Planned demonstration check",
    reportedBy: "DEMO-OP01",
    reportedByName: "Demo Operator One",
    lineName: "DEMO",
    createdAt: toLocalDateTime(relativeDate(1)),
  },
];

export const initialStopHistory = [
  {
    id: "HOLD-DEMO-001",
    lotId: "LOT-DEMO-007",
    holdReason: "Synthetic quality review",
    createdBy: "DEMO-OP01",
    createdByName: "Demo Operator One",
    createdAt: toLocalDateTime(relativeDate(1)),
    active: true,
  },
];

export const initialActivityLogs = [
  {
    id: "LOG-DEMO-001",
    date: toLocalDate(relativeDate(0)),
    time: new Date().toISOString(),
    type: "ACTIVITY",
    level: "INFO",
    userId: "DEMO-ADMIN",
    userName: "Demo Administrator",
    page: "Dashboard",
    action: "OPEN_PAGE",
    machine: "DEMO-MC-A01",
    lot: "LOT-DEMO-001",
    result: "SUCCESS",
    message: "Synthetic demo activity",
    meta: {},
  },
];

export const clone = (value) => JSON.parse(JSON.stringify(value));
