// All guide text and diagrams in Academic Demo are synthetic, never production screenshots.
const item = (key, index, title, summary, icon = "select", tone = "cyan") => ({
  title, shortTitle: title, description: summary, icon, tone,
  image: `/user-guides/demo/${key}-${index + 1}.svg`,
  imageAlt: `Synthetic academic demonstration: ${title}`,
});
const make = (key, rows) => rows.map(([title, summary, icon, tone], index) => item(key, index, title, summary, icon, tone));
export const demoGuideSteps = {
  returnLot: make("return", [
    ["กรอก LOT NO และเหตุผล", "ใส่รหัส Lot จำลองและเลือกเหตุผลที่ตรงกับสถานการณ์", "select", "cyan"],
    ["ตรวจสอบและกด Save", "ตรวจ Lot และเหตุผลก่อนกดบันทึก", "save", "violet"],
    ["ยืนยัน Demo User", "ระบุ Demo User ID ให้ตรงกับบัญชีที่เข้าสู่ระบบ", "verify", "amber"],
    ["บันทึกสำเร็จ", "ดูข้อความยืนยันและรายการที่เพิ่มในประวัติ", "success", "emerald"],
  ]),
  moveLot: make("move", [
    ["ตรวจ Machine Queue", "เลือกเครื่องจำลองเพื่อดูคิวและ Lot ก่อนย้าย ไม่ต้องสลับหน้า", "select", "cyan"],
    ["ค้นหา Lot", "ใส่ LOT-DEMO-xxx และกด Search ตรวจต้นทาง/สถานะ", "search", "violet"],
    ["กำหนดปลายทางและเหตุผล", "เลือก Demo Machine อีกเครื่องหนึ่งและเหตุผลการย้าย", "select", "amber"],
    ["ตรวจข้อมูลและ Save", "ทวน Lot ต้นทาง ปลายทางและเหตุผล", "save", "violet"],
    ["ยืนยัน Demo User", "ใช้ Demo User ID ในหน้าต่างยืนยัน", "verify", "cyan"],
    ["บันทึกสำเร็จ", "ดูผลจำลองจากระบบ", "success", "emerald"],
    ["ตรวจ Queue ปลายทาง", "เลือกเครื่องปลายทางเพื่อดู Lot ที่ย้ายเข้ามา", "list", "emerald"],
  ]),
  sequence: make("sequence", [
    ["เลือกเครื่องจักร", "ระบุ Demo Machine ที่ต้องการจัดลำดับ", "select", "cyan"],
    ["กรอกหรือดึง Lot จาก Queue", "พิมพ์รหัส LOT-DEMO-xxx หรือกดดึงรายการจากคิว", "pull", "violet"],
    ["ยืนยันการดึง Lot", "อ่านข้อความแจ้งผล แล้วกดตกลง", "success", "emerald"],
    ["ตรวจสอบ Lot ที่กรอก", "ใช้ปุ่มตรวจสอบก่อนจัดลำดับ", "search", "cyan"],
    ["เรียงลำดับและ Save", "ใช้ลูกศรขึ้นลงหรือลบรายการที่ไม่ต้องการ; Lot ที่กำลังผลิตอยู่ลำดับแรก", "reorder", "violet"],
    ["ยืนยันการบันทึก", "ตรวจลำดับและกรอก Demo User ID ให้ถูกต้อง", "verify", "amber"],
    ["บันทึกสำเร็จ", "ดูข้อความยืนยันการจัดลำดับ", "success", "emerald"],
  ]),
  hold: make("hold", [
    ["กรอก Lot และเลือกเหตุผล", "เลือก Lot จำลองที่รอผลิต และระบุเหตุผลการพัก", "select", "cyan"],
    ["กด Save", "ตรวจ Lot และเหตุผลก่อนบันทึก", "save", "violet"],
    ["ยืนยัน Demo User", "กรอก Demo User ID และกดยืนยัน", "verify", "amber"],
    ["พัก Lot สำเร็จ", "Lot จะถูกซ่อนจากคิวการผลิตจำลองชั่วคราว", "success", "emerald"],
    ["กด Clear เพื่อคืน Lot", "ใช้ Clear ยกเลิกการพัก ไม่ใช่ลบ Lot; Lot จะกลับไปอยู่ในคิว", "clear", "cyan"],
  ]),
};
