import { useMemo, useState } from "react";
import {
  formatDisplayMachineName,
  getSetupInfo,
  getStatusInfo,
  sortLotsByQueue,
} from "../utils/machineQueueUtils";
import { formatDateOnly } from "../utils/displayFormat";

const displayValue = (value) => {
  const text = String(value ?? "").trim();

  if (
    text === "" ||
    text === "-" ||
    text.toLowerCase() === "null" ||
    text.toLowerCase() === "undefined"
  ) {
    return "-";
  }

  return text;
};

const displayMachineValue = (value) => {
  const text = displayValue(value);

  if (text === "-") {
    return "-";
  }

  return formatDisplayMachineName(text);
};

const getLotNo = (lot) =>
  displayValue(lot?.lotId || lot?.lotId || lot?.lotId);

const hasMoveLot = (lot) =>
  displayValue(lot?.targetMachine || lot?.targetMachine) !== "-";

const getMoveStatusText = (lot) => {
  if (hasMoveLot(lot)) return "ย้ายงาน";
  return displayValue(lot?.moveStatus) === "-" ? "ปกติ" : lot.moveStatus;
};

const getMoveFromMachine = (lot) =>
  displayMachineValue(
    lot?.originalMachine ||
      lot?.originalMachine ||
      lot?.actualMachine ||
      lot?.queueMachine ||
      lot?.lineName ||
      lot?.machineName,
  );

const getMoveToMachine = (lot) =>
  displayMachineValue(
    lot?.targetMachine ||
      lot?.targetMachine ||
      lot?.displayMachine,
  );

const formatQuantity = (value) => {
  if (value === null || value === undefined || String(value).trim() === "") {
    return "-";
  }

  const number = Number(value);
  return Number.isFinite(number) ? number.toFixed(2) : displayValue(value);
};

const normalizeLotStatus = (lot) =>
  String(lot?.lotStatus ?? "")
    .trim()
    .toUpperCase()
    .replace(/\s+/g, " ");

const isBlockedLotStatus = (lot) => {
  const status = normalizeLotStatus(lot);
  return status === "BLOCKED" || status === "HOLD";
};

const isResolvedNcrLotStatus = (lot) =>
  normalizeLotStatus(lot) === "REVIEWED";

export default function MachineQueueTable({
  lots = [],
  machineName = "",
  loading = false,
  emptyMessage = "ไม่พบข้อมูลคิวงาน",
}) {
  const [selectedSetupDetail, setSelectedSetupDetail] = useState(null);

  const { sortedLots, firstWaitingLotKey } = useMemo(() => {
    const baseLots = sortLotsByQueue(lots);

    // Waiting ตัวแรกเท่านั้นที่แสดงเป็น "รอผลิต"
    const firstWaitingLot = baseLots.find((lot) => {
      const source = String(lot.sourceType || "")
        .trim()
        .toUpperCase();

      const process = String(lot.processStatus || "")
        .trim()
        .toUpperCase();

      return source !== "CURRENT" && process !== "PLANNED";
    });

    return {
      sortedLots: baseLots,
      firstWaitingLotKey: firstWaitingLot ? getLotNo(firstWaitingLot) : null,
    };
  }, [lots]);

  if (loading) {
    return (
      <div className="p-12 text-center text-sm font-bold text-slate-500 dark:text-slate-400">
        กำลังโหลดข้อมูลคิวงาน...
      </div>
    );
  }

  if (sortedLots.length === 0) {
    return (
      <div className="p-12 text-center text-sm font-bold text-slate-500 dark:text-slate-400">
        {emptyMessage}
      </div>
    );
  }

  return (
    <>
      <style>{`
        .machine-queue-scrollbar::-webkit-scrollbar {
          height: 6px;
        }

        .machine-queue-scrollbar::-webkit-scrollbar-track {
          background: transparent;
        }

        .machine-queue-scrollbar::-webkit-scrollbar-thumb {
          background-color: #e2e8f0;
          border-radius: 9999px;
        }

        .machine-queue-scrollbar::-webkit-scrollbar-thumb:hover {
          background-color: #cbd5e1;
        }

        .dark .machine-queue-scrollbar::-webkit-scrollbar-thumb {
          background-color: #475569;
        }
      `}</style>

      <div className="machine-queue-scrollbar relative overflow-x-auto">
        <table className="w-full min-w-max whitespace-nowrap text-left text-sm text-slate-600 dark:text-slate-400">
          <thead className="border-b border-slate-200 bg-slate-50/80 text-xs uppercase text-slate-500 dark:border-slate-800 dark:bg-slate-950 dark:text-slate-400">
            <tr>
              <th className="px-4 py-4 text-center">Queue</th>
              <th className="px-4 py-4 text-center">Status</th>
              <th className="px-4 py-4">Lot No</th>
              <th className="px-4 py-4">สถานะการย้าย</th>
              <th className="px-4 py-4">Product Code</th>
              <th className="px-4 py-4">Setup Compare</th>
              <th className="px-4 py-4">Stop Code</th>
              <th className="px-4 py-4 text-center">ลำดับงานเข้าเครื่อง</th>
              <th className="px-4 py-4">Part Name</th>
              <th className="px-4 py-4">Unit Name</th>
              <th className="px-4 py-4">Input Date</th>
              <th className="px-4 py-3">Status Process</th>
              <th className="px-4 py-3">Machine เดิม</th>
              <th className="px-4 py-3">Machine ใหม่</th>
              <th className="px-4 py-3">Tracking No</th>
              <th className="px-4 py-4">Qty</th>
              <th className="px-4 py-4">Input Qty</th>
              <th className="px-4 py-4">Output Qty</th>
              <th className="px-4 py-4">%งานผลิตปัจจุบัน</th>
              <th className="px-4 py-4">Lot Status</th>
              <th className="px-4 py-4">Comment</th>
              <th className="px-4 py-4">specA</th>
              <th className="px-4 py-4">Spec B</th>
              <th className="px-4 py-4">specC</th>
              <th className="px-4 py-4">specD</th>
              <th className="px-4 py-4">specE</th>
              <th className="px-4 py-4">Spec F</th>
              <th className="px-4 py-4">Spec G</th>
              <th className="px-4 py-4">specH</th>
              <th className="px-4 py-4">Spec I</th>
              <th className="px-4 py-4">specJ</th>
              <th className="px-4 py-4">specK</th>
              <th className="px-4 py-4">Spec L</th>
              <th className="px-4 py-4">specM</th>
              <th className="px-4 py-4">Spec N</th>
              <th className="px-4 py-4">Spec O</th>
              <th className="px-4 py-4">Spec P</th>
              <th className="px-4 py-4">Spec Q</th>
              <th className="px-4 py-4">Spec R</th>
              <th className="px-4 py-4">Spec S</th>
              <th className="px-4 py-4">Spec T</th>
              <th className="px-4 py-4">specU</th>
              <th className="px-4 py-4">Operator ID</th>
              <th className="px-4 py-4">Start Date</th>
            </tr>
          </thead>

          <tbody>
            {sortedLots.map((lot, index) => {
              const previousLot =
                index > 0
                  ? sortedLots[index - 1]
                  : lot?.previousLot || null;

              const setupInfo = getSetupInfo(previousLot, lot);
              const baseStatusInfo = getStatusInfo(lot);

              const isCurrentMachineLot =
                String(lot.sourceType || "")
                  .trim()
                  .toUpperCase() === "CURRENT";

              const isFirstWaitingLot =
                !isCurrentMachineLot && getLotNo(lot) === firstWaitingLotKey;

              const isInputLot =
                String(lot.processStatus || "")
                  .trim()
                  .toUpperCase() === "PLANNED";

              const statusInfo = isCurrentMachineLot
                ? {
                    label: "กำลังผลิต",
                    colors:
                      "bg-emerald-600 text-white ring-1 ring-emerald-600 dark:bg-emerald-600 dark:text-white",
                  }
                : isInputLot
                  ? baseStatusInfo
                  : isFirstWaitingLot
                    ? {
                        label: "รอผลิต",
                        colors:
                          "bg-amber-500 text-white ring-1 ring-amber-600 dark:bg-amber-600 dark:text-white",
                      }
                    : {
                        label: "รอหน้าเครื่อง",
                        colors:
                          "bg-red-600 text-white ring-1 ring-red-600 dark:bg-red-600 dark:text-white",
                      };

              const shouldHighlightLot = isBlockedLotStatus(lot);
              const shouldHighlightResolvedNcr = isResolvedNcrLotStatus(lot);

              const inputQty = Number.parseFloat(lot.inputQty) || 0;
              const outputQty = Number.parseFloat(lot.outputQty) || 0;

              const rawProgressPercent =
                inputQty > 0 ? Math.round((outputQty / inputQty) * 100) : 0;

              const progressBarPercent = Math.max(
                0,
                Math.min(rawProgressPercent, 100),
              );

              const progressText =
                inputQty > 0 ? `${rawProgressPercent}%` : "-";

              return (
                <tr
                  key={`${getLotNo(lot)}-${lot.queueNo ?? index}`}
                  className={`border-b transition ${
                    shouldHighlightResolvedNcr
                      ? "border-emerald-200 bg-emerald-100/90 hover:bg-emerald-200/90 dark:border-emerald-900/60 dark:bg-emerald-950/30 dark:hover:bg-emerald-900/40"
                      : shouldHighlightLot
                        ? "border-yellow-200 bg-yellow-100/90 hover:bg-yellow-200/90 dark:border-yellow-900/60 dark:bg-yellow-950/30 dark:hover:bg-yellow-900/40"
                        : "border-slate-100 hover:bg-slate-50 dark:border-slate-800 dark:hover:bg-slate-800/50"
                  }`}
                >
                  <td className="px-4 py-3 text-center font-bold text-slate-700 dark:text-slate-300">
                    {lot.queueNo ?? index + 1}
                  </td>

                    <td className="px-4 py-3 text-center">
                      <span
                        className={`rounded-lg px-2.5 py-1 text-[11px] font-bold uppercase tracking-wider ${statusInfo.colors}`}
                      >
                        {statusInfo.label}
                      </span>
                    </td>

                    <td className="px-4 py-3 font-semibold text-slate-900 dark:text-slate-100">
                      {getLotNo(lot)}
                    </td>

                    <td className="px-4 py-3">
                      <span
                        className={`inline-flex rounded-full px-3 py-1 text-xs font-black ${
                          hasMoveLot(lot)
                            ? "bg-amber-100 text-amber-700 ring-1 ring-amber-200 dark:bg-amber-950/40 dark:text-amber-300 dark:ring-amber-900/60"
                            : "bg-slate-100 text-slate-600 ring-1 ring-slate-200 dark:bg-slate-800 dark:text-slate-300 dark:ring-slate-700"
                        }`}
                      >
                        {getMoveStatusText(lot)}
                      </span>
                    </td>

                    <td className="px-4 py-3 text-center text-slate-600 dark:text-slate-400">
                      {displayValue(lot.productCode)}
                    </td>

                    <td className="px-4 py-3 text-center">
                      <button
                        type="button"
                        onClick={() =>
                          setSelectedSetupDetail({
                            lot,
                            previousLot,
                            setupInfo,
                            queueNo: lot.queueNo ?? index + 1,
                            machineName,
                          })
                        }
                        className={
                          setupInfo.code === "CHANGE"
                            ? "font-black text-red-600 underline decoration-red-400 underline-offset-4 hover:text-red-700"
                            : setupInfo.hasPreviousLot
                              ? "font-bold text-emerald-700 underline decoration-emerald-400 underline-offset-4 hover:text-emerald-800 dark:text-emerald-300"
                              : "font-bold text-slate-400 underline decoration-slate-300 underline-offset-4 hover:text-slate-500 dark:text-slate-500"
                        }
                        title={
                          setupInfo.hasPreviousLot
                            ? "กดเพื่อดูรายละเอียด Technical setup"
                            : "ยังไม่พบ Lot ก่อนหน้าที่บันทึกไว้ จึงยังไม่สรุป Setup Compare"
                        }
                      >
                        {setupInfo.code}
                      </button>
                    </td>

                    <td
                      className={`px-4 py-3 font-medium ${
                        displayValue(lot.stopCode) !== "-"
                          ? "text-rose-600 dark:text-rose-400"
                          : "text-slate-500"
                      }`}
                    >
                      {displayValue(lot.stopCode)}
                    </td>

                    <td className="px-4 py-3 text-center">
                      {lot.manualSequence ? (
                        <span className="inline-flex min-w-9 items-center justify-center rounded-lg bg-cyan-100 px-2.5 py-1 text-xs font-black text-cyan-700 ring-1 ring-cyan-200 dark:bg-cyan-950/40 dark:text-cyan-300 dark:ring-cyan-900/60">
                          {lot.manualSequence}
                        </span>
                      ) : (
                        <span className="text-slate-400 dark:text-slate-500">
                          -
                        </span>
                      )}
                    </td>

                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.partName || lot.partName)}
                    </td>

                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.unitName)}
                    </td>

                    <td className="px-4 py-3 text-slate-500 dark:text-slate-400">
                      {formatDateOnly(lot.inputDate || lot.inputDate)}
                    </td>

                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.processStatus)}
                    </td>

                    <td className="px-4 py-3 font-bold text-slate-700 dark:text-slate-200">
                      {getMoveFromMachine(lot)}
                    </td>

                    <td className="px-4 py-3">
                      {hasMoveLot(lot) ? (
                        <span className="inline-flex rounded-full bg-emerald-100 px-3 py-1 text-xs font-black text-emerald-700 ring-1 ring-emerald-200 dark:bg-emerald-950/40 dark:text-emerald-300 dark:ring-emerald-900/60">
                          {getMoveToMachine(lot)}
                        </span>
                      ) : (
                        <span className="text-slate-400 dark:text-slate-500">
                          -
                        </span>
                      )}
                    </td>

                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.trackingNo || lot.trackingNo || lot.trackingNo)}
                    </td>

                    <td className="px-4 py-3 text-right font-semibold text-cyan-600 dark:text-cyan-400">
                      {formatQuantity(lot.plannedQty)}
                    </td>

                    <td className="px-4 py-3 text-right text-slate-600 dark:text-slate-400">
                      {displayValue(lot.inputQty)}
                    </td>

                    <td className="px-4 py-3 text-right text-slate-600 dark:text-slate-400">
                      {displayValue(lot.outputQty)}
                    </td>

                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      <div className="flex min-w-[130px] items-center gap-2">
                        <div className="h-2 w-20 overflow-hidden rounded-full bg-slate-200 dark:bg-slate-800">
                          <div
                            className={`h-full rounded-full transition-all duration-500 ${
                              rawProgressPercent >= 100
                                ? "bg-cyan-500"
                                : "bg-emerald-500"
                            }`}
                            style={{ width: `${progressBarPercent}%` }}
                          />
                        </div>

                        <span className="w-10 text-right font-bold text-slate-700 dark:text-slate-300">
                          {progressText}
                        </span>
                      </div>
                    </td>

                    <td
                      className={`px-4 py-3 ${
                        shouldHighlightResolvedNcr
                          ? "font-bold text-emerald-700 dark:text-emerald-300"
                          : "text-slate-600 dark:text-slate-400"
                      }`}
                    >
                      {displayValue(lot.lotStatus)}
                    </td>

                    <td
                      className="max-w-[250px] truncate px-4 py-3 text-slate-500 dark:text-slate-400"
                      title={displayValue(lot.comment)}
                    >
                      {displayValue(lot.comment)}
                    </td>

                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.specA)}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.specB)}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.specC)}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.specD)}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.specE)}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {lot.specF !== null &&
                      lot.specF !== undefined &&
                      String(lot.specF).trim() !== ""
                        ? Number(lot.specF).toFixed(1)
                        : "-"}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.specG)}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.specH)}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.specI)}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.specJ)}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.specK)}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.specL)}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.specM)}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.specN)}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.specO)}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.specP)}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.specQ)}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.specR)}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.specS)}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.specT)}
                    </td>
                    <td className="px-4 py-3 text-slate-600 dark:text-slate-400">
                      {displayValue(lot.specU)}
                    </td>
                    <td className="px-4 py-3 text-slate-500 dark:text-slate-400">
                      {displayValue(lot.operatorId)}
                    </td>
                    <td className="px-4 py-3 text-slate-500 dark:text-slate-400">
                      {displayValue(lot.startTime)}
                    </td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </div>

      {selectedSetupDetail ? (
        <div className="fixed inset-0 z-[120] flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-sm">
          <div className="flex max-h-[90vh] w-full max-w-lg flex-col overflow-hidden rounded-lg bg-white shadow-2xl dark:bg-slate-950">
            <div className="flex items-center justify-between bg-amber-500 px-5 py-4 text-slate-900">
              <div>
                <h3 className="text-base font-bold">
                  เครื่องมือที่ต้องเปลี่ยน
                </h3>
                <p className="mt-1 text-xs font-semibold text-slate-800">
                  {formatDisplayMachineName(selectedSetupDetail.machineName)} /
                  Queue {selectedSetupDetail.queueNo} /{" "}
                  {getLotNo(selectedSetupDetail.lot)}
                </p>
              </div>

              <button
                type="button"
                onClick={() => setSelectedSetupDetail(null)}
                className="text-xl font-black text-slate-700 hover:text-slate-950"
                aria-label="ปิดรายละเอียด Technical setup"
              >
                ×
              </button>
            </div>

            <div className="border-b border-amber-200 bg-amber-50 px-5 py-3 text-center dark:border-amber-900/60 dark:bg-amber-950/30">
              <p className="text-sm font-black text-amber-900 dark:text-amber-200">
                {selectedSetupDetail.setupInfo.code === "CHANGE"
                  ? "มีรายการที่ต้อง Setup / เปลี่ยนค่า"
                  : selectedSetupDetail.setupInfo.hasPreviousLot
                    ? "Spec เหมือนคิวก่อนหน้า ไม่ต้อง Setup เพิ่ม"
                    : "ยังไม่พบ Lot ก่อนหน้าที่บันทึกไว้ จึงยังไม่สรุป Setup Compare"}
              </p>
            </div>

            <div className="flex-1 overflow-y-auto">
              <section className="bg-yellow-50 px-7 py-5 dark:bg-yellow-950/20">
                <h4 className="mb-4 pb-1 text-center font-black text-yellow-900 dark:text-yellow-200">
                  เปลี่ยนสำหรับช่าง
                </h4>

                <div className="space-y-3 text-md">
                  {selectedSetupDetail.setupInfo.details
                    .filter((item) => item.group === "technician")
                    .map((item) => (
                      <p
                        key={item.key}
                        className={
                          item.isDifferent
                            ? "font-bold text-red-600 dark:text-red-400"
                            : "text-slate-700 dark:text-slate-200"
                        }
                        title={
                          item.isDifferent
                            ? `ก่อนหน้า: ${item.previousDisplay} | ปัจจุบัน: ${item.currentDisplay}`
                            : item.currentDisplay
                        }
                      >
                        {item.label}: {item.currentDisplay}
                      </p>
                    ))}
                </div>
              </section>

              <section className="border-t border-slate-200 bg-orange-50/50 px-7 py-5 dark:border-slate-800 dark:bg-orange-950/10">
                <h4 className="mb-4 pb-2 text-center font-black text-orange-900 dark:text-orange-200">
                  เปลี่ยนสำหรับพนักงาน
                </h4>

                <div className="space-y-3 text-md">
                  {selectedSetupDetail.setupInfo.details
                    .filter((item) => item.group === "operator")
                    .map((item) => (
                      <p
                        key={item.key}
                        className={
                          item.isDifferent
                            ? "font-bold text-red-600 dark:text-red-400"
                            : "text-slate-700 dark:text-slate-200"
                        }
                        title={
                          item.isDifferent
                            ? `ก่อนหน้า: ${item.previousDisplay} | ปัจจุบัน: ${item.currentDisplay}`
                            : item.currentDisplay
                        }
                      >
                        {item.label}: {item.currentDisplay}
                      </p>
                    ))}
                </div>
              </section>
            </div>

            <div className="flex justify-end border-t border-slate-200 bg-white px-5 py-4 dark:border-slate-800 dark:bg-slate-950">
              <button
                type="button"
                onClick={() => setSelectedSetupDetail(null)}
                className="rounded-lg bg-slate-600 px-5 py-2.5 font-bold text-white transition hover:bg-slate-700"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      ) : null}
    </>
  );
}
