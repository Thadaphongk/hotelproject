import React from "react";

export default function DateModeFilter({
  dateMode,
  onDateModeChange,
  dateFrom,
  onDateFromChange,
  dateTo,
  onDateToChange,
  helperText = "",
  rightContent = null,
  actions = null,
}) {
  return (
    <div className="w-full rounded-3xl border border-slate-200 bg-slate-50/80 p-4 dark:border-slate-800 dark:bg-slate-950/40">
      <div className="flex flex-wrap items-center gap-6">
        <label className="flex cursor-pointer items-center gap-2 text-sm font-black text-slate-700 dark:text-slate-200">
          <input
            type="radio"
            name="dateMode"
            checked={dateMode === "single"}
            onChange={() => onDateModeChange("single")}
            className="h-4 w-4 accent-cyan-600"
          />
          เลือก 1 วัน
        </label>

        <label className="flex cursor-pointer items-center gap-2 text-sm font-black text-slate-700 dark:text-slate-200">
          <input
            type="radio"
            name="dateMode"
            checked={dateMode === "range"}
            onChange={() => onDateModeChange("range")}
            className="h-4 w-4 accent-cyan-600"
          />
          เลือกหลายวัน
        </label>
      </div>

      <div
        className={[
          "mt-4 grid gap-4",
          rightContent ? "xl:grid-cols-[minmax(0,1fr)_340px] xl:items-end" : "",
        ].join(" ")}
      >
        <div>
          {dateMode === "single" ? (
            <div className="w-full sm:w-[300px]">
              <label className="mb-1 block text-sm font-black text-slate-500 dark:text-slate-400">
                วันที่
              </label>

              <input
                type="date"
                value={dateFrom}
                onChange={(event) => onDateFromChange(event.target.value)}
                className="h-12 w-full rounded-2xl border border-slate-300 bg-white px-4 text-sm font-bold text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
              />
            </div>
          ) : (
            <div className="flex flex-wrap items-end gap-3">
              <div className="w-full sm:w-[300px]">
                <label className="mb-1 block text-sm font-black text-slate-500 dark:text-slate-400">
                  จากวันที่
                </label>

                <input
                  type="date"
                  value={dateFrom}
                  max={dateTo || undefined}
                  onChange={(event) => onDateFromChange(event.target.value)}
                  className="h-12 w-full rounded-2xl border border-slate-300 bg-white px-4 text-sm font-bold text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
                />
              </div>

              <div className="hidden pb-3 text-sm font-black text-slate-500 dark:text-slate-400 sm:block">
                ถึง
              </div>

              <div className="w-full sm:w-[300px]">
                <label className="mb-1 block text-sm font-black text-slate-500 dark:text-slate-400">
                  ถึงวันที่
                </label>

                <input
                  type="date"
                  value={dateTo}
                  min={dateFrom || undefined}
                  onChange={(event) => onDateToChange(event.target.value)}
                  className="h-12 w-full rounded-2xl border border-slate-300 bg-white px-4 text-sm font-bold text-slate-900 outline-none transition focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-100"
                />
              </div>
            </div>
          )}
        </div>

        {rightContent ? <div>{rightContent}</div> : null}
      </div>

      {helperText || actions ? (
        <div className="mt-4 space-y-3">
          {helperText ? (
            <p className="text-sm font-black text-slate-500 dark:text-slate-400">
              {helperText}
            </p>
          ) : null}

          {actions ? (
            <div className="flex flex-wrap justify-start gap-3">{actions}</div>
          ) : null}
        </div>
      ) : null}
    </div>
  );
}
