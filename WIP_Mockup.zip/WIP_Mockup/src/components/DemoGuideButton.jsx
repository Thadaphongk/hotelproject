import { useState } from "react";
import { BookOpen } from "lucide-react";
import UserGuideModal from "./UserGuideModal";
import { demoGuideSteps } from "../demo/guideSteps";
export default function DemoGuideButton({ kind, className = "" }) {
  const [open, setOpen] = useState(false);
  return <>
    <button type="button" onClick={() => setOpen(true)} className={`inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-cyan-200 bg-white px-4 text-sm font-black text-cyan-700 shadow-sm hover:bg-cyan-50 dark:border-cyan-800 dark:bg-slate-900 dark:text-cyan-300 ${className}`}><BookOpen size={18}/> วิธีใช้งาน</button>
    <UserGuideModal open={open} onClose={() => setOpen(false)} title="วิธีใช้งาน (Academic Demo)" subtitle="ภาพประกอบเป็นข้อมูลจำลองทั้งหมด" steps={demoGuideSteps[kind] || []}/>
  </>;
}
