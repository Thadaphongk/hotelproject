import React from "react";

export default function PagePlaceholder({ title }) {
  return (
    <div className="rounded-2xl border border-slate-200 bg-white p-6 shadow-sm dark:border-slate-700 dark:bg-slate-900">
      <h3 className="text-2xl font-bold text-slate-900 dark:text-slate-100">{title}</h3>
      <p className="mt-2 text-slate-500 dark:text-slate-400">
        หน้านี้ยังเป็น placeholder สำหรับจัด layout ก่อน
      </p>

      <div className="mt-6 grid gap-4 md:grid-cols-2">
        <div className="h-40 rounded-2xl bg-slate-100 dark:bg-slate-800" />
        <div className="h-40 rounded-2xl bg-slate-100 dark:bg-slate-800" />
      </div>
    </div>
  );
}