import React, { useEffect, useRef, useState } from "react";
import {
  EMPLOYEE_VERIFICATION_TTL_MS,
  clearEmployeeVerification,
  getEmployeeVerification,
  normalizeEmployeeCode,
  rememberEmployeeVerification,
} from "../utils/employeeVerification";

const variantConfig = {
  danger: {
    header: "bg-rose-500",
    button: "bg-rose-600 hover:bg-rose-700",
  },
  warning: {
    header: "bg-amber-500",
    button: "bg-amber-600 hover:bg-amber-700",
  },
  success: {
    header: "bg-emerald-500",
    button: "bg-emerald-600 hover:bg-emerald-700",
  },
  info: {
    header: "bg-cyan-600",
    button: "bg-cyan-600 hover:bg-cyan-700",
  },
};

const formatRemainingTime = (seconds) => {
  const safeSeconds = Math.max(0, Number(seconds) || 0);
  const minutes = Math.floor(safeSeconds / 60);
  const remainingSeconds = Math.floor(safeSeconds % 60);

  return `${String(minutes).padStart(2, "0")}:${String(remainingSeconds).padStart(2, "0")}`;
};

export default function CenterAlert({
  open,
  title = "แจ้งเตือน",
  message = "",
  variant = "danger",
  confirmText = "ตกลง",
  cancelText = "",
  onClose,
  onConfirm,

  requireEmployeeCode = false,
  expectedEmployeeCode = "",
}) {
  const employeeInputRef = useRef(null);
  const [employeeCodeInput, setEmployeeCodeInput] = useState("");
  const [rememberVerification, setRememberVerification] = useState(true);
  const [hasCachedVerification, setHasCachedVerification] = useState(false);
  const [remainingSeconds, setRemainingSeconds] = useState(0);

  const expectedCode = normalizeEmployeeCode(expectedEmployeeCode);
  const inputCode = normalizeEmployeeCode(employeeCodeInput);

  useEffect(() => {
    if (!open) return;

    setRememberVerification(true);
    setHasCachedVerification(false);
    setRemainingSeconds(0);

    if (!requireEmployeeCode || !expectedCode) {
      setEmployeeCodeInput("");
      return;
    }

    const cachedVerification = getEmployeeVerification(expectedCode);

    if (cachedVerification) {
      setEmployeeCodeInput(expectedCode);
      setHasCachedVerification(true);
      setRemainingSeconds(
        Math.max(1, Math.ceil(cachedVerification.remainingMs / 1000)),
      );
      return;
    }

    setEmployeeCodeInput("");
  }, [open, requireEmployeeCode, expectedCode]);

  useEffect(() => {
    if (
      !open ||
      !requireEmployeeCode ||
      !expectedCode ||
      !hasCachedVerification
    ) {
      return undefined;
    }

    const updateRemainingTime = () => {
      const cachedVerification = getEmployeeVerification(expectedCode);

      if (!cachedVerification) {
        setHasCachedVerification(false);
        setRemainingSeconds(0);
        setEmployeeCodeInput((currentValue) =>
          normalizeEmployeeCode(currentValue) === expectedCode
            ? ""
            : currentValue,
        );
        return;
      }

      setRemainingSeconds(
        Math.max(1, Math.ceil(cachedVerification.remainingMs / 1000)),
      );
    };

    updateRemainingTime();
    const intervalId = window.setInterval(updateRemainingTime, 1000);

    return () => window.clearInterval(intervalId);
  }, [open, requireEmployeeCode, expectedCode, hasCachedVerification]);

  const isEmployeeVerified =
    !requireEmployeeCode ||
    (Boolean(expectedCode) && inputCode === expectedCode);

  if (!open) return null;

  const config = variantConfig[variant] || variantConfig.danger;
  const hasCancel = Boolean(cancelText);

  const handleEmployeeCodeChange = (event) => {
    if (hasCachedVerification) {
      clearEmployeeVerification();
      setHasCachedVerification(false);
      setRemainingSeconds(0);
    }

    setEmployeeCodeInput(event.target.value.toUpperCase());
  };

  const handleRememberVerificationChange = (event) => {
    const shouldRemember = event.target.checked;
    setRememberVerification(shouldRemember);

    if (!shouldRemember && hasCachedVerification) {
      clearEmployeeVerification();
      setHasCachedVerification(false);
      setRemainingSeconds(0);
    }
  };

  const handleEnterEmployeeCodeAgain = () => {
    clearEmployeeVerification();
    setHasCachedVerification(false);
    setRemainingSeconds(0);
    setEmployeeCodeInput("");

    window.setTimeout(() => employeeInputRef.current?.focus(), 0);
  };

  const handleConfirm = () => {
    if (!isEmployeeVerified) return;

    if (requireEmployeeCode && expectedCode) {
      if (rememberVerification) {
        rememberEmployeeVerification(
          expectedCode,
          EMPLOYEE_VERIFICATION_TTL_MS,
        );
      } else {
        clearEmployeeVerification();
      }
    }

    (onConfirm || onClose)?.();
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center bg-slate-900/60 p-4 backdrop-blur-sm">
      <div className="w-full max-w-md overflow-hidden rounded-3xl bg-white shadow-2xl ring-1 ring-slate-200 dark:bg-slate-950 dark:ring-slate-800">
        <div className={`${config.header} px-6 py-4 text-white`}>
          <h3 className="text-lg font-black">{title}</h3>
        </div>

        <div className="px-6 py-6">
          <div className="whitespace-pre-line text-center text-base font-bold text-slate-800 dark:text-slate-100">
            {message}
            {requireEmployeeCode ? (
              <div className="mt-5 text-left">
                <label className="mb-2 block text-sm font-black text-slate-700 dark:text-slate-200">
                  กรอกรหัสพนักงานเพื่อยืนยัน
                </label>

                <input
                  ref={employeeInputRef}
                  type="text"
                  value={employeeCodeInput}
                  onChange={handleEmployeeCodeChange}
                  placeholder="กรอกรหัสพนักงานของคุณ"
                  autoComplete="off"
                  autoFocus={!hasCachedVerification}
                  className={`h-12 w-full rounded-xl border px-4 text-center text-base font-black outline-none transition ${
                    employeeCodeInput && !isEmployeeVerified
                      ? "border-rose-400 bg-rose-50 text-rose-700 focus:ring-2 focus:ring-rose-200 dark:bg-rose-950/30"
                      : isEmployeeVerified && employeeCodeInput
                        ? "border-emerald-400 bg-emerald-50 text-emerald-700 focus:ring-2 focus:ring-emerald-200 dark:bg-emerald-950/30"
                        : "border-slate-300 bg-white text-slate-800 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-900 dark:text-white"
                  }`}
                />

                <p
                  className={`mt-2 text-center text-xs font-bold ${
                    hasCachedVerification
                      ? "text-emerald-600"
                      : employeeCodeInput
                        ? isEmployeeVerified
                          ? "text-emerald-600"
                          : "text-rose-600"
                        : "text-slate-400"
                  }`}
                >
                  {hasCachedVerification
                    ? `ยืนยันรหัสไว้แล้ว • ใช้ได้อีก ${formatRemainingTime(remainingSeconds)}`
                    : employeeCodeInput
                      ? isEmployeeVerified
                        ? "รหัสพนักงานถูกต้อง"
                        : "รหัสพนักงานไม่ตรงกับบัญชีที่ Login"
                      : "กรุณากรอกรหัสเดียวกับที่ใช้ Login"}
                </p>

                {hasCachedVerification ? (
                  <div className="mt-2 text-center">
                    <button
                      type="button"
                      onClick={handleEnterEmployeeCodeAgain}
                      className="text-xs font-black text-cyan-700 underline decoration-cyan-300 underline-offset-4 transition hover:text-cyan-900 dark:text-cyan-300 dark:hover:text-cyan-100"
                    >
                      กรอกรหัสใหม่
                    </button>
                  </div>
                ) : null}

                <label className="mt-4 flex cursor-pointer items-center justify-center gap-2 rounded-xl bg-slate-50 px-3 py-2.5 text-xs font-bold text-slate-600 ring-1 ring-slate-200 dark:bg-slate-900 dark:text-slate-300 dark:ring-slate-700">
                  <input
                    type="checkbox"
                    checked={rememberVerification}
                    onChange={handleRememberVerificationChange}
                    className="h-4 w-4 accent-cyan-600"
                  />
                  <span>กดเพื่อจำรหัสพนักงาน</span>
                </label>
              </div>
            ) : null}
          </div>
        </div>

        <div className="flex justify-center gap-3 border-t border-slate-200 px-6 py-4 dark:border-slate-800">
          {hasCancel ? (
            <button
              type="button"
              onClick={onClose}
              className="rounded-2xl bg-slate-600 px-8 py-2.5 text-sm font-black text-white transition hover:bg-slate-700"
            >
              {cancelText}
            </button>
          ) : null}

          <button
            type="button"
            onClick={handleConfirm}
            disabled={!isEmployeeVerified}
            className={`rounded-2xl px-8 py-2.5 text-sm font-black text-white transition disabled:cursor-not-allowed disabled:opacity-40 ${config.button}`}
          >
            {confirmText}
          </button>
        </div>
      </div>
    </div>
  );
}
