import { useCallback, useEffect, useState } from "react";
import { Factory, RefreshCw } from "lucide-react";
import { getMachines } from "../services/api";
import MachineQueueTable from "./MachineQueueTable";
export default function DemoMachineQueuePanel() {
 const [machines, setMachines] = useState([]);
 const [selected, setSelected] = useState("");
 const [loading, setLoading] = useState(false);
 const [error, setError] = useState("");
 const reload = useCallback(async () => {
   setLoading(true); setError("");
   try { const result = await getMachines({ force: true, includeTechnical: true, includeMoveLot: true }); setMachines(Array.isArray(result) ? result : []); }
   catch (err) { setError(err.message || "ไม่สามารถโหลด Demo Queue ได้"); }
   finally { setLoading(false); }
 }, []);
 useEffect(() => { reload(); const onChange = () => reload(); window.addEventListener("wip-demo-queue-updated", onChange);return () => window.removeEventListener("wip-demo-queue-updated",onChange); }, [reload]);
 const machine = machines.find((m) => String(m.machineName || m.Machine) === selected);
 return <section className="overflow-hidden rounded-[2rem] border border-slate-300 bg-white shadow-md dark:border-slate-700 dark:bg-slate-900">
   <div className="flex flex-col gap-4 border-b border-slate-200 p-5 sm:flex-row sm:items-center sm:justify-between dark:border-slate-800">
     <div className="flex items-center gap-3"><span className="rounded-xl bg-cyan-100 p-3 text-cyan-700"><Factory size={22}/></span><div><h2 className="text-xl font-black">Machine Queue</h2><p className="text-sm text-slate-500">เลือกเครื่องจำลองเพื่อตรวจสอบ Queue ก่อนย้าย Lot</p></div></div>
     <div className="flex flex-wrap items-center gap-2"><label className="text-sm font-bold">เลือกเครื่องจักร <select value={selected} onChange={e=>setSelected(e.target.value)} className="mt-1 block h-11 min-w-48 rounded-xl border border-slate-300 bg-slate-50 px-3 dark:border-slate-600 dark:bg-slate-800"><option value="">กรุณาเลือกเครื่องจักร</option>{machines.map(m => <option key={m.machineName || m.Machine} value={m.machineName || m.Machine}>{m.machineName || m.Machine}</option>)}</select></label><button type="button" onClick={reload} disabled={loading} className="self-end rounded-xl border border-slate-300 px-4 py-3 text-sm font-bold hover:bg-cyan-50"><RefreshCw size={16} className="inline mr-2"/>Refresh</button></div>
   </div>
   {error ? <p className="px-5 py-5 text-rose-600">{error}</p> : !selected ? <p className="px-5 py-14 text-center font-semibold text-slate-500">กรุณาเลือกเครื่องจักรเพื่อดู Queue</p> : <><div className="flex justify-between bg-slate-50 px-5 py-3 text-sm font-bold dark:bg-slate-800">Queue Details: {selected}<span className="text-cyan-700">{machine?.lots?.length || 0} Lot</span></div><MachineQueueTable machineName={selected} lots={machine?.lots || []} loading={loading}/></>}
 </section>;
}
