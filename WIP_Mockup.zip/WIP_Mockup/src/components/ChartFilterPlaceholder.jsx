import React from "react";

export default function ChartFilterPlaceholder({
  title = "กรุณากดเลือกวันที่เพื่อดูกราฟ",
  description = "เลือกช่วงวันที่เพื่อแสดงกราฟสรุปข้อมูล",
}) {
  return (
    <div className="flex min-h-[220px] items-center justify-center rounded-[1.75rem] border border-dashed border-slate-300 bg-slate-50/80 p-8 text-center dark:border-slate-700 dark:bg-slate-950/50">
      <div>
        <p className="text-2xl font-black text-slate-700 dark:text-slate-100">
          {title}
        </p>

        <p className="mt-3 text-sm font-bold text-slate-500 dark:text-slate-400">
          {description}
        </p>
      </div>
    </div>
  );
}