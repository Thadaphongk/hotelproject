import React from "react";

const defaultPalette = [
  "#06b6d4",
  "#10b981",
  "#f59e0b",
  "#ef4444",
  "#8b5cf6",
  "#ec4899",
  "#3b82f6",
  "#84cc16",
  "#f97316",
  "#14b8a6",
];

const getStableColorIndex = (label, paletteLength) => {
  const text = String(label || "");
  let hash = 0;

  for (let index = 0; index < text.length; index += 1) {
    hash = text.charCodeAt(index) + ((hash << 5) - hash);
  }

  return Math.abs(hash) % paletteLength;
};

const getItemColor = (item, index, palette, colorMode) => {
  if (item?.color) return item.color;

  if (colorMode === "rank") {
    return palette[index % palette.length];
  }

  return palette[getStableColorIndex(item?.label, palette.length)];
};

const formatNumber = (value) => {
  return Number(value || 0).toLocaleString("en-US");
};

export default function DonutChart({
  title,
  subtitle,
  items = [],
  emptyText = "ยังไม่มีข้อมูลสำหรับแสดงกราฟ",
  maxItems = 8,
  colorPalette = defaultPalette,
  colorMode = "label",
  headerRightText = "",
  onItemMouseEnter,
  onItemMouseLeave,
  onItemClick,
}) {
  const palette = colorPalette.length > 0 ? colorPalette : defaultPalette;
  const hasInteraction = Boolean(onItemMouseEnter || onItemClick);

  const visibleItems = [...items]
    .filter((item) => item.label && Number(item.value) > 0)
    .sort((a, b) => Number(b.value) - Number(a.value))
    .slice(0, maxItems)
    .map((item, index) => ({
      ...item,
      value: Number(item.value) || 0,
      color: getItemColor(item, index, palette, colorMode),
    }));

  const total = visibleItems.reduce((sum, item) => sum + item.value, 0);

  const radius = 58;
  const strokeWidth = 24;
  const circumference = 2 * Math.PI * radius;

  let cumulative = 0;

  const slices = visibleItems.map((item) => {
    const percent = total > 0 ? item.value / total : 0;
    const dashLength = percent * circumference;
    const dashOffset = cumulative * circumference;

    cumulative += percent;

    return {
      ...item,
      percent,
      dashLength,
      dashOffset,
    };
  });

  return (
    <div className="rounded-[1.75rem] border border-slate-200 bg-slate-50/80 p-5 shadow-sm dark:border-slate-800 dark:bg-slate-950/45">
      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h4 className="text-lg font-black text-slate-950 dark:text-white">
            {title}
          </h4>

          {subtitle ? (
            <p className="mt-1 text-sm font-bold text-slate-500 dark:text-slate-400">
              {subtitle}
            </p>
          ) : null}
        </div>

        {headerRightText ? (
          <div className="shrink-0 rounded-full bg-slate-100 px-4 py-2 text-xs font-black text-slate-600 ring-1 ring-slate-200 dark:bg-slate-900 dark:text-slate-300 dark:ring-slate-800">
            {headerRightText}
          </div>
        ) : null}
      </div>

      {visibleItems.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-6 text-center text-sm font-bold text-slate-500 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-400">
          {emptyText}
        </div>
      ) : (
        <div className="grid gap-5 lg:grid-cols-[240px_1fr] lg:items-center">
          <div className="flex justify-center">
            <div className="relative h-60 w-60">
              <svg
                viewBox="0 0 160 160"
                className="h-full w-full -rotate-90"
                role="img"
                aria-label={title}
              >
                <circle
                  cx="80"
                  cy="80"
                  r={radius}
                  fill="none"
                  stroke="currentColor"
                  strokeWidth={strokeWidth}
                  className="text-slate-200 dark:text-slate-800"
                />

                {slices.map((slice) => (
                  <circle
                    key={slice.label}
                    cx="80"
                    cy="80"
                    r={radius}
                    fill="none"
                    stroke={slice.color}
                    strokeWidth={slice.active ? strokeWidth + 3 : strokeWidth}
                    strokeDasharray={`${slice.dashLength} ${
                      circumference - slice.dashLength
                    }`}
                    strokeDashoffset={-slice.dashOffset}
                    strokeLinecap="butt"
                    className="transition-all duration-300"
                    onMouseEnter={() => onItemMouseEnter?.(slice)}
                    onMouseLeave={() => onItemMouseLeave?.(slice)}
                    onClick={() => onItemClick?.(slice)}
                    style={{
                      opacity: slice.dimmed ? 0.18 : 1,
                      cursor: hasInteraction ? "pointer" : "default",
                      filter: slice.active
                        ? "drop-shadow(0 6px 10px rgba(15, 23, 42, 0.25))"
                        : "none",
                    }}
                  />
                ))}
              </svg>

              <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center text-center">
                <p className="text-4xl font-black text-slate-950 dark:text-white">
                  {formatNumber(total)}
                </p>
                <p className="mt-1 text-xs font-black uppercase tracking-[0.18em] text-slate-500 dark:text-slate-400">
                  Total
                </p>
              </div>
            </div>
          </div>

          <div className="space-y-3">
            {visibleItems.map((item) => {
              const percent = total > 0 ? (item.value / total) * 100 : 0;
              const displayLabel = item.displayLabel || item.label;

              return (
                <button
                  key={item.label}
                  type="button"
                  onMouseEnter={() => onItemMouseEnter?.(item)}
                  onMouseLeave={() => onItemMouseLeave?.(item)}
                  onClick={() => onItemClick?.(item)}
                  className={[
                    "flex w-full items-center justify-between gap-3 rounded-2xl bg-white px-4 py-3 text-left ring-1 ring-slate-200 transition duration-200 dark:bg-slate-900 dark:ring-slate-800",
                    item.active
                      ? "scale-[1.01] ring-2 ring-cyan-400"
                      : "scale-100",
                    item.dimmed ? "opacity-25" : "opacity-100",
                    hasInteraction ? "cursor-pointer hover:scale-[1.01]" : "",
                  ].join(" ")}
                >
                  <div className="flex min-w-0 items-center gap-3">
                    <span
                      className="h-3.5 w-3.5 shrink-0 rounded-full shadow-sm ring-2 ring-white dark:ring-slate-900"
                      style={{ backgroundColor: item.color }}
                    />

                    <p
                      className="truncate text-sm font-black text-slate-700 dark:text-slate-200"
                      title={displayLabel}
                    >
                      {displayLabel}
                    </p>
                  </div>

                  <div className="shrink-0 text-right">
                    <p className="text-sm font-black text-slate-950 dark:text-white">
                      {formatNumber(item.value)}
                    </p>
                    <p className="text-xs font-bold text-slate-400 dark:text-slate-500">
                      {percent.toFixed(1)}%
                    </p>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}