import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";
import {
  Check,
  ChevronDown,
  RotateCcw,
  Rows3,
  Type,
  X,
} from "lucide-react";

export const DEFAULT_DISPLAY_SETTINGS = {
  fontFamily: "sarabun",
  fontSize: "normal",
  tableDensity: "normal",
};

const FONT_GROUP_LABELS = {
  recommended: "แนะนำสำหรับระบบงาน",
  general: "อ่านง่าย / ใช้งานทั่วไป",
  style: "ฟอนต์สไตล์ / เน้นเอกลักษณ์",
};

const FONT_OPTIONS = [
  {
    value: "sarabun",
    label: "Sarabun",
    group: "recommended",
    description: "ค่าเริ่มต้นที่แนะนำ อ่านภาษาไทยง่าย สุภาพ และเหมาะกับตารางข้อมูล",
    previewFont:
      '"Sarabun", "Noto Sans Thai", "Leelawadee UI", "Segoe UI", Tahoma, Arial, sans-serif',
  },
  {
    value: "bai-jamjuree",
    label: "Bai Jamjuree",
    group: "recommended",
    description: "ตัวอักษรและตัวเลขชัด เหมาะกับตารางและข้อมูลการผลิต",
    previewFont:
      '"Bai Jamjuree", "Noto Sans Thai", "Leelawadee UI", "Segoe UI", sans-serif',
  },
  {
    value: "noto-sans-thai",
    label: "Noto Sans Thai",
    group: "recommended",
    description: "อ่านสบาย ตัวไทยและตัวเลขสมดุล เหมาะกับการใช้งานต่อเนื่อง",
    previewFont:
      '"Noto Sans Thai", "Leelawadee UI", "Segoe UI", Tahoma, Arial, sans-serif',
  },
  {
    value: "ibm-plex-sans-thai",
    label: "IBM Plex Sans Thai",
    group: "recommended",
    description: "โทน Professional และ Industrial เหมาะกับ Dashboard และข้อมูล Technical",
    previewFont:
      '"IBM Plex Sans Thai", "Noto Sans Thai", "Leelawadee UI", "Segoe UI", sans-serif',
  },
  {
    value: "leelawadee",
    label: "Leelawadee UI",
    group: "general",
    description: "ฟอนต์ Windows ภาษาไทย อ่านง่ายและไม่ต้องโหลดจาก Internet",
    previewFont:
      '"Leelawadee UI", "Noto Sans Thai", "Segoe UI", Tahoma, Arial, sans-serif',
  },
  {
    value: "tahoma",
    label: "Tahoma",
    group: "general",
    description: "ตัวอักษรกระชับและคม เหมาะกับตารางที่มีข้อมูลจำนวนมาก",
    previewFont:
      'Tahoma, "Leelawadee UI", "Segoe UI", Arial, sans-serif',
  },
  {
    value: "system",
    label: "Segoe UI / System",
    group: "general",
    description: "ฟอนต์มาตรฐาน Windows เด่นด้านภาษาอังกฤษและตัวเลข",
    previewFont:
      '"Segoe UI Variable", "Segoe UI", "Leelawadee UI", Tahoma, Arial, sans-serif',
  },
  {
    value: "prompt",
    label: "Prompt",
    group: "general",
    description: "รูปทรงทันสมัย ชัดเจน เหมาะกับ Dashboard และหัวข้อ",
    previewFont:
      '"Prompt", "Noto Sans Thai", "Leelawadee UI", "Segoe UI", Tahoma, Arial, sans-serif',
  },
  {
    value: "kanit",
    label: "Kanit",
    group: "general",
    description: "ตัวอักษรชัดและมีน้ำหนัก เหมาะกับหัวข้อหรือจอ Monitor ระยะไกล",
    previewFont:
      '"Kanit", "Noto Sans Thai", "Leelawadee UI", "Segoe UI", Tahoma, Arial, sans-serif',
  },
  {
    value: "mitr",
    label: "Mitr",
    group: "general",
    description: "ปลายมนและเป็นมิตร ดูผ่อนคลายแต่ยังอ่านข้อมูลได้ชัด",
    previewFont:
      '"Mitr", "Noto Sans Thai", "Leelawadee UI", "Segoe UI", sans-serif',
  },
  {
    value: "athiti",
    label: "Athiti",
    group: "general",
    description: "โปร่งและเบา ให้ความรู้สึกสบายตาและมีพื้นที่หายใจ",
    previewFont:
      '"Athiti", "Noto Sans Thai", "Leelawadee UI", "Segoe UI", sans-serif',
  },
  {
    value: "trirong",
    label: "Trirong (มีเชิง)",
    group: "style",
    description: "ฟอนต์ไทยแบบมีเชิง ให้บุคลิกเป็นทางการและแตกต่างจาก Sans Serif อย่างชัดเจน",
    previewFont:
      '"Trirong", "Sarabun", "Noto Sans Thai", serif',
  },
  {
    value: "itim",
    label: "Itim (ลายมือ)",
    group: "style",
    description: "สไตล์ลายมือ เป็นกันเอง เหมาะกับผู้ใช้ที่ต้องการรูปแบบเฉพาะตัว",
    previewFont:
      '"Itim", "Noto Sans Thai", "Leelawadee UI", sans-serif',
  },
  {
    value: "pattaya",
    label: "Pattaya (Display)",
    group: "style",
    description: "ฟอนต์ Display ที่มีจังหวะตัวอักษรเด่น เหมาะกับการทดลองสไตล์มากกว่าตารางข้อมูล",
    previewFont:
      '"Pattaya", "Noto Sans Thai", "Leelawadee UI", sans-serif',
  },
  {
    value: "chonburi",
    label: "Chonburi (Display)",
    group: "style",
    description: "ฟอนต์ Display เอกลักษณ์สูง เหมาะกับหัวข้อและงานที่ต้องการความโดดเด่น",
    previewFont:
      '"Chonburi", "Noto Sans Thai", "Leelawadee UI", sans-serif',
  },
];

const FONT_SIZE_OPTIONS = [
  { value: "small", label: "เล็ก", hint: "ข้อมูลแน่นขึ้น" },
  { value: "normal", label: "ปกติ", hint: "แนะนำ" },
  { value: "large", label: "ใหญ่", hint: "อ่านสบายขึ้น" },
];

const DENSITY_OPTIONS = [
  { value: "compact", label: "กระชับ", hint: "เห็นหลายแถว" },
  { value: "normal", label: "ปกติ", hint: "สมดุล" },
  { value: "comfortable", label: "อ่านสบาย", hint: "ระยะห่างมากขึ้น" },
];

export default function DisplaySettingsModal({
  open,
  settings,
  onChange,
  onReset,
  onClose,
}) {
  const [fontMenuOpen, setFontMenuOpen] = useState(false);
  const fontMenuRef = useRef(null);

  useEffect(() => {
    if (!open) {
      setFontMenuOpen(false);
      return undefined;
    }

    const previousBodyOverflow = document.body.style.overflow;

    const handleKeyDown = (event) => {
      if (event.key === "Escape") {
        if (fontMenuOpen) {
          setFontMenuOpen(false);
          return;
        }

        onClose?.();
      }
    };

    // ป้องกันหน้าด้านหลังเลื่อนในขณะที่เปิดหน้าต่างตั้งค่า
    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", handleKeyDown);

    return () => {
      document.body.style.overflow = previousBodyOverflow;
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [open, onClose, fontMenuOpen]);

  useEffect(() => {
    if (!open || !fontMenuOpen) return undefined;

    const handlePointerDown = (event) => {
      if (
        fontMenuRef.current &&
        !fontMenuRef.current.contains(event.target)
      ) {
        setFontMenuOpen(false);
      }
    };

    document.addEventListener("mousedown", handlePointerDown);

    return () => {
      document.removeEventListener("mousedown", handlePointerDown);
    };
  }, [open, fontMenuOpen]);

  if (!open) return null;

  const selectedFont =
    FONT_OPTIONS.find((option) => option.value === settings.fontFamily) ||
    FONT_OPTIONS.find(
      (option) => option.value === DEFAULT_DISPLAY_SETTINGS.fontFamily,
    ) ||
    FONT_OPTIONS[0];

  return createPortal(
    <div
      className="fixed inset-0 z-[9999] flex items-start justify-center overflow-y-auto bg-slate-950/45 p-4 backdrop-blur-sm sm:items-center sm:p-6"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) {
          onClose?.();
        }
      }}
    >
      <section
        role="dialog"
        aria-modal="true"
        aria-labelledby="display-settings-title"
        className="my-auto max-h-[calc(100dvh-2rem)] w-full max-w-2xl overflow-y-auto rounded-3xl border border-slate-200 bg-white shadow-2xl sm:max-h-[calc(100dvh-3rem)] dark:border-slate-700 dark:bg-slate-900"
      >
        <div className="flex items-start justify-between gap-4 border-b border-slate-200 px-5 py-4 sm:px-6 dark:border-slate-700">
          <div>
            <h2
              id="display-settings-title"
              className="text-xl font-black text-slate-900 dark:text-white"
            >
              ตั้งค่าการแสดงผล
            </h2>
            <p className="mt-1 text-sm font-medium text-slate-500 dark:text-slate-400">
              การตั้งค่านี้จะถูกจำไว้เฉพาะอุปกรณ์และเบราว์เซอร์นี้
            </p>
          </div>

          <button
            type="button"
            onClick={() => {
              setFontMenuOpen(false);
              onClose?.();
            }}
            aria-label="ปิดการตั้งค่า"
            className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-slate-50 text-slate-600 transition hover:bg-slate-100 hover:text-slate-900 dark:border-slate-700 dark:bg-slate-800 dark:text-slate-300 dark:hover:bg-slate-700 dark:hover:text-white"
          >
            <X size={19} />
          </button>
        </div>

        <div className="space-y-7 px-5 py-5 sm:px-6">
          <div>
            <div className="mb-3 flex items-center gap-2">
              <Type size={18} className="text-cyan-600 dark:text-cyan-400" />
              <h3 className="font-black text-slate-800 dark:text-slate-100">
                แบบอักษร
              </h3>
            </div>

            <div className="space-y-3">
              <div ref={fontMenuRef} className="relative">
                <button
                  type="button"
                  onClick={() => setFontMenuOpen((current) => !current)}
                  aria-haspopup="listbox"
                  aria-expanded={fontMenuOpen}
                  className="flex h-12 w-full items-center justify-between gap-3 rounded-2xl border border-slate-300 bg-white px-4 text-left text-base font-bold text-slate-900 outline-none transition hover:border-cyan-400 focus:border-cyan-500 focus:ring-2 focus:ring-cyan-100 dark:border-slate-700 dark:bg-slate-900 dark:text-white dark:hover:border-cyan-600 dark:focus:border-cyan-500 dark:focus:ring-cyan-950"
                  style={{ fontFamily: selectedFont.previewFont }}
                >
                  <span className="truncate">{selectedFont.label}</span>
                  <ChevronDown
                    size={18}
                    className={`shrink-0 text-slate-400 transition-transform ${
                      fontMenuOpen ? "rotate-180" : ""
                    }`}
                  />
                </button>

                {fontMenuOpen ? (
                  <div
                    role="listbox"
                    aria-label="รายการแบบอักษร"
                    className="absolute left-0 right-0 top-[calc(100%+0.5rem)] z-50 max-h-60 overflow-y-auto rounded-2xl border border-slate-200 bg-white p-1.5 shadow-2xl dark:border-slate-700 dark:bg-slate-900"
                  >
                    {FONT_OPTIONS.map((option, index) => {
                      const selected = option.value === selectedFont.value;
                      const showGroupLabel =
                        index === 0 ||
                        FONT_OPTIONS[index - 1]?.group !== option.group;

                      return (
                        <div key={option.value}>
                          {showGroupLabel ? (
                            <div
                              role="presentation"
                              className="px-3 pb-1 pt-2 text-[11px] font-black uppercase tracking-wide text-slate-400 first:pt-1 dark:text-slate-500"
                            >
                              {FONT_GROUP_LABELS[option.group]}
                            </div>
                          ) : null}

                          <button
                            type="button"
                            role="option"
                            aria-selected={selected}
                            onClick={() => {
                              onChange?.({
                                ...settings,
                                fontFamily: option.value,
                              });
                              setFontMenuOpen(false);
                            }}
                            className={`flex w-full items-center justify-between gap-3 rounded-xl px-3 py-2.5 text-left transition ${
                              selected
                                ? "bg-cyan-50 text-cyan-800 dark:bg-cyan-950/40 dark:text-cyan-200"
                                : "text-slate-700 hover:bg-slate-50 dark:text-slate-200 dark:hover:bg-slate-800"
                            }`}
                            style={{ fontFamily: option.previewFont }}
                          >
                            <span className="flex min-w-0 items-center gap-2">
                              <span className="truncate font-bold">
                                {option.label}
                              </span>

                              {option.value === "sarabun" ? (
                                <span className="shrink-0 rounded-full bg-emerald-100 px-2 py-0.5 text-[10px] font-black text-emerald-700 dark:bg-emerald-950/50 dark:text-emerald-300">
                                  แนะนำ
                                </span>
                              ) : null}
                            </span>

                            {selected ? (
                              <Check
                                size={17}
                                className="shrink-0 text-cyan-600 dark:text-cyan-400"
                              />
                            ) : null}
                          </button>
                        </div>
                      );
                    })}
                  </div>
                ) : null}

                <p className="mt-1.5 text-[11px] font-semibold text-slate-400 dark:text-slate-500">
                  เลื่อนภายในรายการเพื่อดูฟอนต์เพิ่มเติม
                </p>
              </div>

              <div className="rounded-xl border border-cyan-100 bg-cyan-50/70 px-4 py-3 dark:border-cyan-900/60 dark:bg-cyan-950/20">
                <div
                  className="text-base font-bold text-slate-900 dark:text-white"
                  style={{ fontFamily: selectedFont.previewFont }}
                >
                  {selectedFont.label} — ภาษาไทย ABC 123
                </div>
                <p className="mt-1 text-xs font-medium text-slate-500 dark:text-slate-400">
                  {selectedFont.description}
                </p>
              </div>
            </div>
          </div>

          <div>
            <div className="mb-3 flex items-center gap-2">
              <Type size={18} className="text-violet-600 dark:text-violet-400" />
              <h3 className="font-black text-slate-800 dark:text-slate-100">
                ขนาดตัวอักษร
              </h3>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {FONT_SIZE_OPTIONS.map((option) => {
                const selected = settings.fontSize === option.value;

                return (
                  <button
                    key={option.value}
                    type="button"
                    onClick={() =>
                      onChange?.({
                        ...settings,
                        fontSize: option.value,
                      })
                    }
                    className={`rounded-2xl border px-3 py-3 text-center transition ${
                      selected
                        ? "border-violet-400 bg-violet-50 text-violet-800 ring-2 ring-violet-100 dark:border-violet-500 dark:bg-violet-950/30 dark:text-violet-200 dark:ring-violet-950"
                        : "border-slate-200 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
                    }`}
                  >
                    <div className="font-black">{option.label}</div>
                    <div className="mt-0.5 text-[11px] font-semibold opacity-70">
                      {option.hint}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div>
            <div className="mb-3 flex items-center gap-2">
              <Rows3 size={18} className="text-amber-600 dark:text-amber-400" />
              <h3 className="font-black text-slate-800 dark:text-slate-100">
                ความหนาแน่นของตาราง
              </h3>
            </div>

            <div className="grid grid-cols-3 gap-2">
              {DENSITY_OPTIONS.map((option) => {
                const selected = settings.tableDensity === option.value;

                return (
                  <button
                    key={option.value}
                    type="button"
                    onClick={() =>
                      onChange?.({
                        ...settings,
                        tableDensity: option.value,
                      })
                    }
                    className={`rounded-2xl border px-3 py-3 text-center transition ${
                      selected
                        ? "border-amber-400 bg-amber-50 text-amber-900 ring-2 ring-amber-100 dark:border-amber-500 dark:bg-amber-950/30 dark:text-amber-200 dark:ring-amber-950"
                        : "border-slate-200 bg-white text-slate-700 hover:bg-slate-50 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:bg-slate-800"
                    }`}
                  >
                    <div className="font-black">{option.label}</div>
                    <div className="mt-0.5 text-[11px] font-semibold opacity-70">
                      {option.hint}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          <div className="rounded-2xl border border-slate-200 bg-slate-50 p-4 dark:border-slate-700 dark:bg-slate-800/70">
            <p className="mb-2 text-xs font-black uppercase tracking-wide text-slate-500 dark:text-slate-400">
              ตัวอย่าง
            </p>
            <div
              className="font-bold text-slate-900 dark:text-white"
              style={{ fontFamily: selectedFont.previewFont }}
            >
              DEMO-MC-A01 — กำลังผลิต — LOT-DEMO-001
            </div>
            <div
              className="mt-1 text-sm font-medium text-slate-600 dark:text-slate-300"
              style={{ fontFamily: selectedFont.previewFont }}
            >
              ข้อมูลการผลิตและสถานะเครื่องจักร • รอผลิต • รอหน้าเครื่อง
            </div>
          </div>
        </div>

        <div className="flex flex-col-reverse gap-2 border-t border-slate-200 px-5 py-4 sm:flex-row sm:items-center sm:justify-between sm:px-6 dark:border-slate-700">
          <button
            type="button"
            onClick={() => {
              setFontMenuOpen(false);
              onReset?.();
            }}
            className="inline-flex h-11 items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-4 text-sm font-bold text-slate-600 transition hover:bg-slate-50 hover:text-slate-900 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-white"
          >
            <RotateCcw size={17} />
            คืนค่าเริ่มต้น
          </button>

          <button
            type="button"
            onClick={() => {
              setFontMenuOpen(false);
              onClose?.();
            }}
            className="h-11 rounded-xl bg-cyan-600 px-7 text-sm font-black text-white transition hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-cyan-500/30"
          >
            เสร็จสิ้น
          </button>
        </div>
      </section>
    </div>,
    document.body,
  );
}
