import { useEffect, useState } from "react";
import {
  ArrowRightLeft,
  Bug,
  CirclePause,
  CircleUserRound,
  ClipboardCheck,
  FileText,
  LayoutDashboard,
  ListOrdered,
  Search,
  ShieldCheck,
  TriangleAlert,
  Table2,
  ListChecks,
  Waypoints,
} from "lucide-react";

import {
  APP_VERSION,
  APP_BUILD_LABEL,
} from "../../config/appInfo";
import { getPendingPermissionRequests } from "../../services/api";
import { canAccessPage } from "../../utils/accessControl";

export default function Sidebar({
  active,
  setActive,
  isSidebarOpen,
  setIsSidebarOpen,
  user,
  isLoggedIn,
}) {
  // MainLayout ใช้ Guest object สำหรับ Navbar แต่ Sidebar ต้องตรวจ Permission
  // จาก User ที่ Login จริงเท่านั้น
  const accessUser = isLoggedIn ? user : null;
  const canAccessAdmin = canAccessPage(accessUser, "admin");

  const [pendingPermissionCount, setPendingPermissionCount] = useState(0);

  useEffect(() => {
    if (!canAccessAdmin) {
      setPendingPermissionCount(0);
      return undefined;
    }

    let cancelled = false;

    const loadPendingPermissionCount = async () => {
      const rows = await getPendingPermissionRequests();
      if (!cancelled) {
        setPendingPermissionCount(rows.length);
      }
    };

    loadPendingPermissionCount();
    const intervalId = window.setInterval(loadPendingPermissionCount, 30000);

    return () => {
      cancelled = true;
      window.clearInterval(intervalId);
    };
  }, [canAccessAdmin]);

  const menuItems = [
    ...(canAccessPage(accessUser, "queue")
      ? [
          {
            key: "queue",
            label: "WIP Monitor",
            icon: ListOrdered,
            section: "เมนูหลัก",
          },
        ]
      : []),

    ...(canAccessPage(accessUser, "partGroup")
      ? [
          {
            key: "partGroup",
            label: "WIP By Part Name",
            icon: Table2,
          },
        ]
      : []),

    ...(canAccessPage(accessUser, "dashboard")
      ? [
          {
            key: "dashboard",
            label: "Dashboard",
            icon: LayoutDashboard,
            section: canAccessPage(accessUser, "queue") ? undefined : "เมนูหลัก",
          },
        ]
      : []),

    ...(canAccessPage(accessUser, "machines")
      ? [
          {
            key: "machines",
            label: "LOT Search",
            icon: Search,
          },
        ]
      : []),

    ...(canAccessPage(accessUser, "lineInfo")
      ? [
          {
            key: "lineInfo",
            label: "Line Information",
            icon: Waypoints,
            section: "ข้อมูลอ้างอิง",
          },
        ]
      : []),

    ...(canAccessPage(accessUser, "returnLot")
      ? [
          {
            key: "returnLot",
            label: "แจ้งปัญหา/ข้าม Lot",
            icon: TriangleAlert,
            section: "จัดการ LOT",
          },
        ]
      : []),

    ...(canAccessPage(accessUser, "moveLot")
      ? [
          {
            key: "moveLot",
            label: "ย้าย Lot งาน",
            icon: ArrowRightLeft,
            section: canAccessPage(accessUser, "returnLot") ? undefined : "จัดการ LOT",
          },
        ]
      : []),

    ...(canAccessPage(accessUser, "sequence")
      ? [
          {
            key: "sequence",
            label: "จัดลำดับงาน",
            icon: ListChecks,
            section:
              canAccessPage(accessUser, "returnLot") ||
              canAccessPage(accessUser, "moveLot")
                ? undefined
                : "จัดการ LOT",
          },
        ]
      : []),

    ...(canAccessPage(accessUser, "hold")
      ? [
          {
            key: "hold",
            label: "พักงาน",
            icon: CirclePause,
            section:
              canAccessPage(accessUser, "returnLot") ||
              canAccessPage(accessUser, "moveLot") ||
              canAccessPage(accessUser, "sequence")
                ? undefined
                : "จัดการ LOT",
          },
        ]
      : []),

    ...(canAccessPage(accessUser, "dailyCheck")
      ? [
          {
            key: "dailyCheck",
            label: "Daily Check",
            icon: ClipboardCheck,
            section: "เครื่องมือพัฒนา",
          },
        ]
      : []),

    ...(canAccessPage(accessUser, "machineDebug")
      ? [
          {
            key: "machineDebug",
            label: "Machine Debug",
            icon: Bug,
            section: canAccessPage(accessUser, "dailyCheck")
              ? undefined
              : "เครื่องมือพัฒนา",
          },
        ]
      : []),

    ...(canAccessPage(accessUser, "logs")
      ? [
          {
            key: "logs",
            label: "Logs",
            icon: FileText,
            section:
              canAccessPage(accessUser, "dailyCheck") ||
              canAccessPage(accessUser, "machineDebug")
                ? undefined
                : "เครื่องมือพัฒนา",
          },
        ]
      : []),

    {
      key: "profile",
      label: "My Profile",
      icon: CircleUserRound,
      section: "บัญชีผู้ใช้งาน",
    },

    ...(canAccessAdmin
      ? [
          {
            key: "admin",
            label: "Admin Console",
            icon: ShieldCheck,
            badge: pendingPermissionCount,
          },
        ]
      : []),
  ];

  return (
    <>
      {/* Mobile overlay */}
      <div
        className={`fixed inset-0 z-30 bg-black/40 transition-opacity md:hidden ${
          isSidebarOpen
            ? "opacity-100"
            : "pointer-events-none opacity-0"
        }`}
        onClick={() => setIsSidebarOpen(false)}
      />

      {/* Sidebar */}
      <aside
        className={`fixed left-0 top-0 z-40 flex h-screen w-[250px] transform flex-col border-r border-slate-200 bg-gradient-to-b from-slate-50 to-slate-100/80 shadow-xl shadow-slate-900/5 transition-transform duration-300 dark:border-slate-700 dark:from-slate-950 dark:to-slate-900 ${
          isSidebarOpen
            ? "translate-x-0"
            : "-translate-x-full"
        }`}
      >
        {/* Header */}
        <div className="border-b border-slate-200/80 p-3 dark:border-slate-700">
          <div className="flex h-14 items-center gap-3 rounded-2xl bg-white px-4 shadow-sm ring-1 ring-slate-200/80 dark:bg-slate-800 dark:ring-slate-700">
            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-blue-600 text-white shadow-sm shadow-blue-600/30">
              <ListOrdered
                size={20}
                strokeWidth={2.2}
              />
            </div>

            <div className="min-w-0">
              <p className="truncate text-base font-extrabold text-slate-900 dark:text-white">
                WIP Monitor
              </p>

              <p className="truncate text-[11px] font-medium text-slate-500 dark:text-slate-400">
                Academic Demo
              </p>
            </div>
          </div>
        </div>

        {/* Menu */}
        <nav className="sidebar-scrollbar flex-1 overflow-y-auto px-2.5 py-3 pb-20">
          {menuItems.map((item) => {
            const isActive =
              active === item.key;

            const Icon = item.icon;

            return (
              <div key={item.key}>
                {item.section && (
                  <div className="px-3 pb-1 pt-3 text-[10px] font-bold uppercase tracking-[0.12em] text-slate-400 dark:text-slate-500">
                    {item.section}
                  </div>
                )}

                <button
                  type="button"
                  aria-current={
                    isActive
                      ? "page"
                      : undefined
                  }
                  title={item.label}
                  onClick={() => {
                    setActive(item.key);

                    if (
                      window.innerWidth < 769
                    ) {
                      setIsSidebarOpen(
                        false,
                      );
                    }
                  }}
                  className={`group relative mb-1 flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-[15px] font-semibold transition-all duration-200 ${
                    isActive
                      ? "bg-blue-600 text-white shadow-md shadow-blue-600/20"
                      : "text-slate-700 hover:bg-white hover:text-slate-950 hover:shadow-sm dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-white"
                  }`}
                >
                  <span
                    className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg transition-colors ${
                      isActive
                        ? "bg-white/15 text-white"
                        : "bg-slate-200/70 text-slate-500 group-hover:bg-blue-50 group-hover:text-blue-600 dark:bg-slate-800 dark:text-slate-400 dark:group-hover:bg-slate-700 dark:group-hover:text-blue-400"
                    }`}
                  >
                    <Icon
                      size={20}
                      strokeWidth={2.1}
                    />
                  </span>

                  <span className="min-w-0 flex-1 truncate">
                    {item.label}
                  </span>

                  {item.badge > 0 ? (
                    <span
                      className={`inline-flex min-w-6 shrink-0 items-center justify-center rounded-full px-2 py-0.5 text-[11px] font-black ${
                        isActive
                          ? "bg-white text-blue-700"
                          : "bg-rose-500 text-white"
                      }`}
                      title={`${item.badge} คำขอสิทธิ์รอตรวจสอบ`}
                    >
                      {item.badge > 99 ? "99+" : item.badge}
                    </span>
                  ) : null}
                </button>
              </div>
            );
          })}
        </nav>

        {/* Version */}
        <div className="pointer-events-none absolute bottom-3 right-3 rounded-full bg-white/90 px-2.5 py-1 text-[10px] font-bold text-slate-500 shadow-sm ring-1 ring-slate-200 dark:bg-slate-800/90 dark:text-slate-400 dark:ring-slate-700">
          {APP_BUILD_LABEL} {APP_VERSION}
        </div>
      </aside>
    </>
  );
}