import Sidebar from "./Sidebar";
import Navbar from "./Navbar";

export default function MainLayout({
  active,
  setActive,
  isSidebarOpen,
  setIsSidebarOpen,
  title,
  user,
  isLoggedIn,
  onLogout,
  theme,
  onThemeToggle,
  displaySettings,
  onDisplaySettingsChange,
  onDisplaySettingsReset,
  children,
}) {
  return (
    <div className="app-bg min-h-screen text-slate-950 dark:text-slate-50">
      {/* ย้าย Navbar มาไว้บนสุด เพื่อให้กว้างเต็มหน้าจอและทับ Sidebar */}
      <Navbar
        title={title}
        onMenuToggle={setIsSidebarOpen}
        user={user}
        isLoggedIn={isLoggedIn}
        onLogout={onLogout}
        theme={theme}
        onThemeToggle={onThemeToggle}
        displaySettings={displaySettings}
        onDisplaySettingsChange={onDisplaySettingsChange}
        onDisplaySettingsReset={onDisplaySettingsReset}
      />

      <Sidebar
        active={active}
        setActive={setActive}
        isSidebarOpen={isSidebarOpen}
        setIsSidebarOpen={setIsSidebarOpen}
        user={user}
        isLoggedIn={isLoggedIn}
      />

      <div
        className={`flex flex-1 min-w-0 flex-col transition-all duration-300 pt-20 ${
          isSidebarOpen ? "md:ml-[250px]" : "md:pl-0"
        }`}
      >
        {/* Main Content Area: เปลี่ยนให้เป็น flex-1 และกำหนด scroll เริ่มต้น */}
        <main className="flex flex-1 flex-col p-3 md:p-6 lg:p-8">
          {children}
        </main>
      </div>
    </div>
  );
}