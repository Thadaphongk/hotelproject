import { useState } from "react";
import {
  LogIn,
  LogOut,
  Menu,
  Moon,
  Settings,
  Sun,
} from "lucide-react";
import DisplaySettingsModal, {
  DEFAULT_DISPLAY_SETTINGS,
} from "./DisplaySettingsModal";

export default function Navbar({
  title = "Machine Queue",
  onMenuToggle,
  user,
  isLoggedIn,
  onLogout,
  theme,
  onThemeToggle,
  displaySettings = DEFAULT_DISPLAY_SETTINGS,
  onDisplaySettingsChange,
  onDisplaySettingsReset,
}) {
  const [showDisplaySettings, setShowDisplaySettings] = useState(false);

  const roleLabel = user?.isAdmin
    ? "ADMIN"
    : isLoggedIn
      ? "USER"
      : "GUEST";

  const displayName = isLoggedIn
    ? user?.name || "User"
    : "Guest";

  return (
    <header className="fixed inset-x-0 top-0 z-50 border-b border-slate-200/80 bg-white/90 shadow-sm backdrop-blur-xl dark:border-slate-700 dark:bg-slate-950/90">
      <div className="grid h-20 grid-cols-[1fr_auto_1fr] items-center px-4 md:px-8">
        {/* Left: Menu and logo */}
        <div className="flex min-w-0 items-center gap-3">
          <button
            type="button"
            aria-label="เปิดหรือปิดเมนู"
            title="เปิดหรือปิดเมนู"
            onClick={() =>
              onMenuToggle?.((prev) => !prev)
            }
            className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-slate-50 text-slate-700 transition hover:border-blue-200 hover:bg-blue-50 hover:text-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500/30 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:border-slate-600 dark:hover:bg-slate-800"
          >
            <Menu size={21} strokeWidth={2.2} />
          </button>

          <img
            src="/images/demo-logo.svg"
            alt="WIP Demo"
            className="h-9 w-auto object-contain sm:h-10 lg:h-11"
          />
        </div>

        {/* Center: System and current page title */}
        <div className="hidden min-w-0 flex-col items-center text-center md:flex">
          <h1 className="whitespace-nowrap text-2xl font-bold leading-none tracking-tight text-slate-900 lg:text-3xl dark:text-white">
            WIP Academic Demo
          </h1>

          <p className="mt-1.5 max-w-[320px] truncate text-xs font-medium text-slate-500 dark:text-slate-400">
            {title}
          </p>
        </div>

        {/* Right: Display settings, theme, user and login/logout */}
        <div className="flex min-w-0 items-center justify-self-end gap-2 sm:gap-3">
          <button
            type="button"
            onClick={() => setShowDisplaySettings(true)}
            aria-label="ตั้งค่าการแสดงผล"
            title="ตั้งค่าการแสดงผล"
            className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-slate-50 text-slate-600 transition hover:border-cyan-200 hover:bg-cyan-50 hover:text-cyan-700 focus:outline-none focus:ring-2 focus:ring-cyan-500/30 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300 dark:hover:border-slate-600 dark:hover:bg-slate-800 dark:hover:text-cyan-300"
          >
            <Settings size={19} strokeWidth={2.1} />
          </button>

          <button
            type="button"
            onClick={onThemeToggle}
            aria-label={
              theme === "dark"
                ? "เปลี่ยนเป็นโหมดสว่าง"
                : "เปลี่ยนเป็นโหมดมืด"
            }
            title={
              theme === "dark"
                ? "Light Mode"
                : "Dark Mode"
            }
            className="inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-slate-50 text-slate-600 transition hover:border-blue-200 hover:bg-blue-50 hover:text-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500/30 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300 dark:hover:border-slate-600 dark:hover:bg-slate-800 dark:hover:text-amber-300"
          >
            {theme === "dark" ? (
              <Sun size={19} strokeWidth={2.1} />
            ) : (
              <Moon size={19} strokeWidth={2.1} />
            )}
          </button>

          {user && (
            <div className="hidden min-w-0 items-center gap-2 rounded-xl border border-slate-100 bg-slate-50 px-2.5 py-2 md:flex dark:border-slate-800 dark:bg-slate-900">
              <span
                className={`rounded-lg px-2.5 py-1 text-xs font-bold ${
                  user.isAdmin
                    ? "bg-cyan-100 text-cyan-700 dark:bg-cyan-950 dark:text-cyan-300"
                    : isLoggedIn
                      ? "bg-blue-100 text-blue-700 dark:bg-blue-950 dark:text-blue-300"
                      : "bg-slate-200 text-slate-600 dark:bg-slate-800 dark:text-slate-300"
                }`}
              >
                {roleLabel}
              </span>

              <span
                className="hidden max-w-[180px] truncate text-sm font-semibold text-slate-700 xl:inline dark:text-slate-200"
                title={displayName}
              >
                {displayName}
              </span>
            </div>
          )}

          {onLogout && (
            <button
              type="button"
              onClick={onLogout}
              className="inline-flex h-10 items-center justify-center gap-2 rounded-xl border border-slate-200 bg-white px-3 text-sm font-semibold text-slate-700 transition hover:border-blue-200 hover:bg-blue-50 hover:text-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500/30 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-200 dark:hover:border-slate-600 dark:hover:bg-slate-800"
            >
              {isLoggedIn ? (
                <LogOut
                  size={17}
                  strokeWidth={2.1}
                />
              ) : (
                <LogIn
                  size={17}
                  strokeWidth={2.1}
                />
              )}

              <span className="hidden sm:inline">
                {isLoggedIn ? "Logout" : "Login"}
              </span>
            </button>
          )}
        </div>
      </div>

      <DisplaySettingsModal
        open={showDisplaySettings}
        settings={displaySettings}
        onChange={onDisplaySettingsChange}
        onReset={onDisplaySettingsReset}
        onClose={() => setShowDisplaySettings(false)}
      />
    </header>
  );
}
