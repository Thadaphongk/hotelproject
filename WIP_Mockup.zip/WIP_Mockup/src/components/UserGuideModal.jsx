import React, { useEffect } from "react";
import {
  AlertTriangle,
  CheckCircle2,
  CircleHelp,
  Database,
  Info,
  Lightbulb,
  ListChecks,
  MousePointerClick,
  RotateCcw,
  Save,
  Search,
  X,
} from "lucide-react";

const STEP_ICON_MAP = {
  select: MousePointerClick,
  search: Search,
  save: Save,
  verify: CheckCircle2,
  success: CheckCircle2,
  pull: Database,
  list: ListChecks,
  reorder: ListChecks,
  clear: RotateCcw,
};

const STEP_TONE = {
  cyan: {
    icon: "bg-cyan-600 text-white shadow-cyan-600/20",
    label: "text-cyan-700 dark:text-cyan-300",
    ring: "ring-cyan-200 dark:ring-cyan-900/70",
    chip: "bg-cyan-50 text-cyan-800 ring-cyan-200 dark:bg-cyan-950/35 dark:text-cyan-200 dark:ring-cyan-900/70",
  },
  violet: {
    icon: "bg-violet-600 text-white shadow-violet-600/20",
    label: "text-violet-700 dark:text-violet-300",
    ring: "ring-violet-200 dark:ring-violet-900/70",
    chip: "bg-violet-50 text-violet-800 ring-violet-200 dark:bg-violet-950/35 dark:text-violet-200 dark:ring-violet-900/70",
  },
  amber: {
    icon: "bg-amber-500 text-white shadow-amber-500/20",
    label: "text-amber-700 dark:text-amber-300",
    ring: "ring-amber-200 dark:ring-amber-900/70",
    chip: "bg-amber-50 text-amber-800 ring-amber-200 dark:bg-amber-950/35 dark:text-amber-200 dark:ring-amber-900/70",
  },
  emerald: {
    icon: "bg-emerald-600 text-white shadow-emerald-600/20",
    label: "text-emerald-700 dark:text-emerald-300",
    ring: "ring-emerald-200 dark:ring-emerald-900/70",
    chip: "bg-emerald-50 text-emerald-800 ring-emerald-200 dark:bg-emerald-950/35 dark:text-emerald-200 dark:ring-emerald-900/70",
  },
  rose: {
    icon: "bg-rose-600 text-white shadow-rose-600/20",
    label: "text-rose-700 dark:text-rose-300",
    ring: "ring-rose-200 dark:ring-rose-900/70",
    chip: "bg-rose-50 text-rose-800 ring-rose-200 dark:bg-rose-950/35 dark:text-rose-200 dark:ring-rose-900/70",
  },
};

const NOTE_STYLE = {
  tip: {
    Icon: Lightbulb,
    box: "border-amber-200 bg-amber-50 text-amber-900 dark:border-amber-900/70 dark:bg-amber-950/30 dark:text-amber-100",
    icon: "text-amber-600 dark:text-amber-300",
    label: "เคล็ดลับ",
  },
  warning: {
    Icon: AlertTriangle,
    box: "border-rose-200 bg-rose-50 text-rose-900 dark:border-rose-900/70 dark:bg-rose-950/30 dark:text-rose-100",
    icon: "text-rose-600 dark:text-rose-300",
    label: "ข้อควรระวัง",
  },
  success: {
    Icon: CheckCircle2,
    box: "border-emerald-200 bg-emerald-50 text-emerald-900 dark:border-emerald-900/70 dark:bg-emerald-950/30 dark:text-emerald-100",
    icon: "text-emerald-600 dark:text-emerald-300",
    label: "สำเร็จ",
  },
  info: {
    Icon: Info,
    box: "border-sky-200 bg-sky-50 text-sky-900 dark:border-sky-900/70 dark:bg-sky-950/30 dark:text-sky-100",
    icon: "text-sky-600 dark:text-sky-300",
    label: "หมายเหตุ",
  },
};

export default function UserGuideModal({
  open,
  onClose,
  title,
  subtitle,
  steps = [],
}) {
  useEffect(() => {
    if (!open) return undefined;

    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = "hidden";

    const handleKeyDown = (event) => {
      if (event.key === "Escape") onClose?.();
    };

    window.addEventListener("keydown", handleKeyDown);

    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [open, onClose]);

  if (!open) return null;

  return (
    <div
      className="fixed inset-0 z-[220] flex items-center justify-center bg-slate-950/70 p-2 backdrop-blur-sm sm:p-4"
      role="presentation"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose?.();
      }}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label={title || "วิธีใช้งาน"}
        className="flex max-h-[94vh] w-full max-w-6xl flex-col overflow-hidden rounded-[1.75rem] border border-slate-200 bg-white shadow-2xl dark:border-slate-700 dark:bg-slate-950"
      >
        <div className="flex shrink-0 items-start justify-between gap-4 border-b border-slate-200 bg-gradient-to-r from-cyan-50 via-white to-sky-50 px-5 py-4 sm:px-6 sm:py-5 dark:border-slate-800 dark:from-cyan-950/35 dark:via-slate-950 dark:to-sky-950/30">
          <div className="flex min-w-0 items-start gap-3">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-cyan-600 text-white shadow-lg shadow-cyan-600/20">
              <CircleHelp size={25} />
            </div>
            <div className="min-w-0">
              <h2 className="text-xl font-black text-slate-950 sm:text-2xl dark:text-white">
                {title || "วิธีใช้งาน"}
              </h2>
              {subtitle ? (
                <p className="mt-1 text-sm font-semibold text-slate-500 sm:text-base dark:text-slate-400">
                  {subtitle}
                </p>
              ) : null}
            </div>
          </div>

          <button
            type="button"
            onClick={onClose}
            className="inline-flex h-11 w-11 shrink-0 items-center justify-center rounded-xl border border-slate-200 bg-white text-slate-500 shadow-sm transition hover:bg-slate-100 hover:text-slate-950 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-300 dark:hover:bg-slate-800 dark:hover:text-white"
            aria-label="ปิดวิธีใช้งาน"
            title="ปิด"
          >
            <X size={22} />
          </button>
        </div>

        <div className="overflow-y-auto px-4 py-5 sm:px-6 sm:py-6">
          {steps.length > 0 ? (
            <div className="mb-5 rounded-2xl border border-cyan-200 bg-cyan-50/80 p-4 dark:border-cyan-900/70 dark:bg-cyan-950/25">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <p className="text-xs font-black uppercase tracking-[0.16em] text-cyan-700 dark:text-cyan-300">
                    Quick Flow
                  </p>
                  <p className="mt-1 text-sm font-semibold text-slate-600 dark:text-slate-300">
                    ทำตามลำดับจากซ้ายไปขวา โดยรูปประกอบเป็นสถานการณ์จำลองสำหรับการเรียนรู้
                  </p>
                </div>
                <span className="rounded-full bg-white px-3 py-1.5 text-xs font-black text-cyan-700 shadow-sm ring-1 ring-cyan-200 dark:bg-slate-900 dark:text-cyan-300 dark:ring-cyan-900/70">
                  {steps.length} ขั้นตอน
                </span>
              </div>

              <div className="mt-3 flex flex-wrap items-center gap-2">
                {steps.map((step, index) => {
                  const Icon = STEP_ICON_MAP[step.icon] || CircleHelp;
                  const tone = STEP_TONE[step.tone] || STEP_TONE.cyan;

                  return (
                    <React.Fragment key={`flow-${step.title}-${index}`}>
                      <span
                        className={`inline-flex items-center gap-2 rounded-xl px-3 py-2 text-sm font-black shadow-sm ring-1 ${tone.chip}`}
                      >
                        <Icon size={16} />
                        {index + 1}. {step.shortTitle || step.title}
                      </span>
                      {index < steps.length - 1 ? (
                        <span className="font-black text-cyan-500">→</span>
                      ) : null}
                    </React.Fragment>
                  );
                })}
              </div>
            </div>
          ) : null}

          <div className="space-y-6">
            {steps.map((step, index) => {
              const StepIcon = STEP_ICON_MAP[step.icon] || CircleHelp;
              const tone = STEP_TONE[step.tone] || STEP_TONE.cyan;
              const noteStyle = step.note
                ? NOTE_STYLE[step.note.type] || NOTE_STYLE.info
                : null;
              const NoteIcon = noteStyle?.Icon;

              return (
                <section
                  key={`${step.title}-${index}`}
                  className={`overflow-hidden rounded-[1.5rem] border border-slate-200 bg-white shadow-sm ring-1 ${tone.ring} dark:border-slate-700 dark:bg-slate-900`}
                >
                  <div className="flex items-start gap-4 border-b border-slate-200 bg-slate-50 px-4 py-4 sm:px-5 dark:border-slate-800 dark:bg-slate-900/80">
                    <div
                      className={`flex h-11 w-11 shrink-0 items-center justify-center rounded-xl shadow-lg ${tone.icon}`}
                      aria-hidden="true"
                    >
                      <StepIcon size={21} />
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-2">
                        <span className={`text-xs font-black uppercase tracking-[0.14em] ${tone.label}`}>
                          ขั้นตอนที่ {index + 1}
                        </span>
                        {step.badge ? (
                          <span className={`rounded-full px-2.5 py-1 text-xs font-black ring-1 ${tone.chip}`}>
                            {step.badge}
                          </span>
                        ) : null}
                      </div>
                      <h3 className="mt-1 text-lg font-black text-slate-950 sm:text-xl dark:text-white">
                        {step.title}
                      </h3>
                      {step.description ? (
                        <div className="mt-1.5 text-sm font-semibold leading-7 text-slate-600 sm:text-base dark:text-slate-300">
                          {step.description}
                        </div>
                      ) : null}

                      {step.note && noteStyle && NoteIcon ? (
                        <div className={`mt-3 flex items-start gap-2 rounded-xl border px-3 py-2.5 text-sm font-semibold leading-6 ${noteStyle.box}`}>
                          <NoteIcon size={18} className={`mt-0.5 shrink-0 ${noteStyle.icon}`} />
                          <div>
                            <span className="font-black">
                              {step.note.title || noteStyle.label}:
                            </span>{" "}
                            {step.note.text}
                          </div>
                        </div>
                      ) : null}
                    </div>
                  </div>

                  {step.image ? (
                    <div className="bg-slate-100 p-2 sm:p-3 dark:bg-slate-950/60">
                      <img
                        src={step.image}
                        alt={step.imageAlt || `ขั้นตอนที่ ${index + 1}: ${step.title}`}
                        loading={index === 0 ? "eager" : "lazy"}
                        draggable={false}
                        className="mx-auto block max-h-[72vh] w-full rounded-xl object-contain shadow-sm ring-1 ring-slate-200 dark:ring-slate-700"
                      />
                    </div>
                  ) : null}
                </section>
              );
            })}
          </div>

          <div className="mt-6 flex justify-center">
            <button
              type="button"
              onClick={onClose}
              className="inline-flex h-12 min-w-[150px] items-center justify-center gap-2 rounded-2xl bg-cyan-600 px-6 font-black text-white transition hover:bg-cyan-700"
            >
              <CheckCircle2 size={20} />
              เข้าใจแล้ว
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
