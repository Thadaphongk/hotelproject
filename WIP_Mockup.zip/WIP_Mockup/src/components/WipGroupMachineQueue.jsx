import { Table2 } from "lucide-react";
import MachineQueueTable from "./MachineQueueTable";

/**
 * Queue detail block for WIP Group by Part Name.
 *
 * Reuse the same MachineQueueTable as WIP Monitor so that:
 * - column order is identical
 * - values/formatting are identical
 * - Manual Sequence, Move status, Setup Compare and technical columns stay in sync
 */
export default function WipGroupMachineQueue({
  machineName = "",
  lots = [],
  loading = false,
}) {
  const safeLots = Array.isArray(lots) ? lots : [];

  return (
    <section className="overflow-hidden rounded-[2rem] border border-slate-300 bg-white shadow-sm dark:border-slate-700 dark:bg-slate-900">
      <div className="border-b border-slate-200 px-5 py-4 dark:border-slate-700">
        <h3 className="inline-flex items-center gap-2 text-xl font-black text-slate-900 dark:text-white">
          <Table2 size={21} className="text-cyan-600 dark:text-cyan-300" />
          Queue Details: {machineName || "-"}
        </h3>

        <p className="mt-1 text-sm font-bold text-cyan-600 dark:text-cyan-400">
          จำนวนคิวทั้งหมด: {safeLots.length} รายการ
        </p>
      </div>

      <MachineQueueTable
        lots={safeLots}
        machineName={machineName}
        loading={loading}
        emptyMessage={
          machineName
            ? `ไม่พบข้อมูลคิวของ ${machineName}`
            : "ไม่พบข้อมูลคิวงาน"
        }
      />
    </section>
  );
}
