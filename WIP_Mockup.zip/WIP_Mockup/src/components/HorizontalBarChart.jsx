import React from "react";

const defaultPalette = [
  "#06b6d4",
  "#10b981",
  "#f59e0b",
  "#ef4444",
  "#8b5cf6",
  "#ec4899",
  "#3b82f6",
  "#84cc16",
  "#f97316",
  "#14b8a6",
];

const getStableColorIndex = (label, paletteLength) => {
  const text = String(label || "");
  let hash = 0;

  for (let index = 0; index < text.length; index += 1) {
    hash = text.charCodeAt(index) + ((hash << 5) - hash);
  }

  return Math.abs(hash) % paletteLength;
};

const getBarColor = (item, index, palette, colorMode) => {
  if (item?.color) return item.color;

  if (colorMode === "rank") {
    return palette[index % palette.length];
  }

  const stableIndex = getStableColorIndex(item?.label, palette.length);
  return palette[stableIndex];
};

const getNiceAxis = (maxValue) => {
  const rawMax = Math.max(1, Number(maxValue) || 1);
  const targetTickCount = 5;

  const rawStep = rawMax / targetTickCount;
  const magnitude = 10 ** Math.floor(Math.log10(rawStep));
  const normalized = rawStep / magnitude;

  let niceStep = 1;

  if (normalized <= 1) niceStep = 1;
  else if (normalized <= 2) niceStep = 2;
  else if (normalized <= 5) niceStep = 5;
  else niceStep = 10;

  let step = niceStep * magnitude;

  if (step < 1) step = 1;

  const axisMax = Math.ceil(rawMax / step) * step;

  const ticks = [];
  for (let tick = 0; tick <= axisMax; tick += step) {
    ticks.push(tick);
  }

  return {
    axisMax,
    ticks,
  };
};

const formatNumber = (value) => {
  return Number(value || 0).toLocaleString("en-US");
};

export default function HorizontalBarChart({
  title,
  subtitle,
  items = [],
  emptyText = "ยังไม่มีข้อมูลสำหรับแสดงกราฟ",
  maxItems = 8,
  colorPalette = defaultPalette,
  colorMode = "label",
  labelWidth = "140px",
  wrapLabels = false,
  showValues = false,
  headerRightText = "",
  onItemMouseEnter,
  onItemMouseLeave,
  onItemClick,
}) {
  const palette = colorPalette.length > 0 ? colorPalette : defaultPalette;
  const hasInteraction = Boolean(onItemMouseEnter || onItemClick);

  const visibleItems = [...items]
    .filter((item) => item.label && Number(item.value) > 0)
    .sort((a, b) => Number(b.value) - Number(a.value))
    .slice(0, maxItems);

  const maxValue = visibleItems.reduce((max, item) => {
    return Math.max(max, Number(item.value) || 0);
  }, 0);

  const { axisMax, ticks } = getNiceAxis(maxValue);

  const chartGridStyle = {
    gridTemplateColumns: `${labelWidth} minmax(0, 1fr)`,
  };

  return (
    <div className="rounded-[1.75rem] border border-slate-200 bg-slate-50/80 p-5 shadow-sm dark:border-slate-800 dark:bg-slate-950/45">
      <div className="mb-5 flex flex-col gap-3 sm:flex-row sm:items-start sm:justify-between">
        <div>
          <h4 className="text-lg font-black text-slate-950 dark:text-white">
            {title}
          </h4>

          {subtitle ? (
            <p className="mt-1 text-sm font-bold text-slate-500 dark:text-slate-400">
              {subtitle}
            </p>
          ) : null}
        </div>

        {headerRightText ? (
          <div className="shrink-0 rounded-full bg-slate-100 px-4 py-2 text-xs font-black text-slate-600 ring-1 ring-slate-200 dark:bg-slate-900 dark:text-slate-300 dark:ring-slate-800">
            {headerRightText}
          </div>
        ) : null}
      </div>

      {visibleItems.length === 0 ? (
        <div className="rounded-2xl border border-dashed border-slate-300 bg-white p-6 text-center text-sm font-bold text-slate-500 dark:border-slate-700 dark:bg-slate-900 dark:text-slate-400">
          {emptyText}
        </div>
      ) : (
        <div className="w-full">
          <div className="space-y-3">
            {visibleItems.map((item, index) => {
              const displayLabel = item.displayLabel || item.label;
              const value = Number(item.value) || 0;
              const percent =
                axisMax > 0 ? Math.max((value / axisMax) * 100, 2) : 0;

              const barColor = getBarColor(item, index, palette, colorMode);

              return (
                <div
                  key={`${item.label}-${index}`}
                  role={onItemClick ? "button" : undefined}
                  tabIndex={onItemClick ? 0 : undefined}
                  onMouseEnter={() => onItemMouseEnter?.(item)}
                  onMouseLeave={() => onItemMouseLeave?.(item)}
                  onClick={() => onItemClick?.(item)}
                  onKeyDown={(event) => {
                    if (!onItemClick) return;

                    if (event.key === "Enter" || event.key === " ") {
                      event.preventDefault();
                      onItemClick(item);
                    }
                  }}
                  className={[
                    "grid items-center gap-2 rounded-2xl px-1 py-1 outline-none transition duration-200",
                    item.active ? "bg-white/70 dark:bg-slate-900/70" : "",
                    item.dimmed ? "opacity-25" : "opacity-100",
                    hasInteraction
                      ? "cursor-pointer hover:scale-[1.005] focus:ring-2 focus:ring-cyan-400"
                      : "",
                  ].join(" ")}
                  style={chartGridStyle}
                >
                  <div
                    className={[
                      "flex min-w-0 gap-2",
                      wrapLabels ? "items-start" : "items-center",
                    ].join(" ")}
                  >
                    <span
                      className="mt-1 h-3 w-3 shrink-0 rounded-full shadow-sm ring-2 ring-white dark:ring-slate-900"
                      style={{ backgroundColor: barColor }}
                    />

                    <p
                      className={[
                        "min-w-0 text-sm font-black text-slate-700 dark:text-slate-200",
                        wrapLabels
                          ? "whitespace-normal break-words leading-snug"
                          : "truncate",
                      ].join(" ")}
                      title={`${displayLabel}: ${formatNumber(value)}`}
                    >
                      {displayLabel}
                    </p>
                  </div>

                  <div
                    className="relative h-8 overflow-hidden rounded-xl bg-white/70 dark:bg-slate-900/70"
                    title={`${displayLabel}: ${formatNumber(value)}`}
                  >
                    <div className="absolute inset-0">
                      {ticks.map((tick) => {
                        const tickPercent =
                          axisMax > 0 ? (tick / axisMax) * 100 : 0;

                        return (
                          <span
                            key={tick}
                            className="absolute top-0 h-full border-l border-slate-200 dark:border-slate-800"
                            style={{ left: `${tickPercent}%` }}
                          />
                        );
                      })}
                    </div>

                    <div
                      className={[
                        "absolute left-0 top-1/2 h-4 -translate-y-1/2 rounded-l-md rounded-r-full shadow-sm transition-all duration-500",
                        item.active
                          ? "ring-2 ring-slate-900 ring-offset-2 dark:ring-white dark:ring-offset-slate-950"
                          : "",
                      ].join(" ")}
                      style={{
                        width: `${percent}%`,
                        backgroundColor: barColor,
                      }}
                    />

                    {showValues ? (
                      <span
                        className={[
                          "absolute top-1/2 z-10 rounded-full px-2 py-0.5 text-[12px] font-black transition-all duration-500",
                          percent >= 18
                            ? "text-white"
                            : "bg-white/95 text-slate-700 ring-1 ring-slate-200 dark:bg-slate-950/95 dark:text-slate-200 dark:ring-slate-700",
                        ].join(" ")}
                        style={
                          percent >= 18
                            ? {
                                left: `${percent}%`,
                                transform: "translate(calc(-100% - 6px), -50%)",
                              }
                            : {
                                left: `${percent}%`,
                                transform: "translate(8px, -50%)",
                              }
                        }
                      >
                        {formatNumber(value)}
                      </span>
                    ) : null}
                  </div>
                </div>
              );
            })}
          </div>

          <div className="mt-3 grid gap-2" style={chartGridStyle}>
            <div />

            <div className="relative h-8 border-t border-slate-300 dark:border-slate-700">
              {ticks.map((tick) => {
                const tickPercent = axisMax > 0 ? (tick / axisMax) * 100 : 0;

                const transform =
                  tickPercent === 0
                    ? "translateX(0)"
                    : tickPercent === 100
                      ? "translateX(-100%)"
                      : "translateX(-50%)";

                return (
                  <span
                    key={tick}
                    className="absolute top-0 whitespace-nowrap"
                    style={{
                      left: `${tickPercent}%`,
                      transform,
                    }}
                  >
                    <span className="block h-2 border-l border-slate-400 dark:border-slate-600" />
                    <span className="mt-1 block text-xs font-black text-slate-500 dark:text-slate-400">
                      {formatNumber(tick)}
                    </span>
                  </span>
                );
              })}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
