// Academic/Demo version: self-host the selectable Thai fonts through npm.
// Vite bundles these font assets into dist/, so the demo does not request
// Google Fonts or any external font service at runtime.
import "@fontsource/athiti";
import "@fontsource/bai-jamjuree";
import "@fontsource/chonburi";
import "@fontsource/ibm-plex-sans-thai";
import "@fontsource/itim";
import "@fontsource/kanit";
import "@fontsource/mitr";
import "@fontsource/noto-sans-thai";
import "@fontsource/pattaya";
import "@fontsource/prompt";
import "@fontsource/sarabun";
import "@fontsource/trirong";
