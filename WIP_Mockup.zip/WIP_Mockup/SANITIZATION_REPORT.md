# Academic Version Sanitization Report

## 1. Audit result

This folder is a standalone copy created for academic demonstration. The operational project is not modified by this copy.

### Original architecture identified

```text
Frontend
  -> Operational backend/API
  -> Operational database and persistent data/configuration
```

### Sensitive categories found during audit

**Critical**
- Database/network credentials and environment configuration
- Operational database connection code
- Internal server/network configuration

**High**
- SQL queries and operational database object references
- Operational API/data routes and persistent backend records
- Internal mapping/configuration data

**Medium**
- Production machine/line/lot/product identifiers
- User/employee records and operational history
- Operational comments, logs, guides, and branding assets

**Low**
- Generic frontend layout, icons, component structure, animations, charts, filters, and responsive styling

## 2. Sanitization architecture

The academic copy now uses:

```text
React + Vite Frontend
        ->
Local Express Demo REST API
        ->
Synthetic In-Memory Data
```

Reasons for this approach:
- Preserves the full-stack/REST architecture for the project examination.
- Keeps search, filters, charts, permissions, validation, queue actions, modal flows, and mock write operations interactive.
- Removes every dependency on an operational database, internal network, VPN, account, or server.
- Mock changes reset when the local demo backend restarts.

## 3. Main code changes

### Added / replaced
- `src/demo/demoData.js` - synthetic machines, lines, lots, users, permissions, histories, and technical specs.
- `src/services/server.js` - local-only demo REST API using in-memory state.
- `src/services/api.js` and client services - relative `/api` calls only.
- Frontend pages/components - operational data field names and identifiers replaced with generic demo fields/values while preserving UX/UI.
- `public/images/demo-logo.svg` - neutral academic branding.
- `public/move-lot-guide.svg` - synthetic move-lot guide.
- `README.md`, `PROJECT_CONTEXT.md`, `start-demo.bat` - standalone demo instructions.

### Removed from the academic copy
- Operational environment/config files.
- Operational SQL/data-access implementation.
- Operational route/data-storage folders that contained internal records or integrations.
- Operational mapping/configuration files.
- Old operational documentation/startup files.
- Company branding and operational guide assets.
- Unused assets that were not required for the academic UI.
- Old build artifacts/source maps, if present in the reference copy, are not included in this academic package.

## 4. Synthetic data conventions

- Machines: `DEMO-MC-A01`, `DEMO-MC-B01`, etc.
- Lines: `LINE-A`, `LINE-B`, `LINE-C`.
- Lots: `LOT-DEMO-001`, `LOT-DEMO-002`, etc.
- Users: `DEMO-ADMIN`, `DEMO-OP01`, etc.
- Products/parts: `PROD-A`, `PART-DEMO-A`, etc.
- Technical fields: generic `Spec A` through `Spec U`.

The dataset contains multiple machines, running/waiting/stopped states, an empty-machine case, review/hold scenarios, different dates/specs, access roles, and synthetic history so the UI can demonstrate filters, search, tables, charts, permissions, and action flows.

## 5. Demo write behavior

The following actions are simulated in local memory only:
- Move Lot
- Return/Issue Lot
- Hold/Clear Lot
- Manual Sequence save/clear
- Daily verification save
- Access request/approve/reject/update
- Activity logging

No write is sent to an operational system.

## 6. Security/sensitive-data verification

### Exact-reference scan
PASS - a scan generated from sensitive identifiers found in the reference project checked hundreds of original sensitive tokens against this academic copy and found no exact matches in the demo source/documentation set.

### Source-level connection scan
PASS - no private IP, operational hostname, database connection string, SQL integration, database driver, credential, token, or operational API endpoint remains in the demo source.

### Runtime endpoint design
PASS (source level) - frontend data calls are relative local `/api` requests. The demo server binds to `127.0.0.1:3000`.

### Source maps / old build
PASS - no source map or old `dist`/`build` artifact is included in this package.

## 7. Tests completed in this environment

- JavaScript/JSX parser check: **PASS**
- Relative import resolution check: **PASS**
- Node syntax check for demo backend/data/service modules: **PASS**
- Synthetic data/queue/status/setup logic checks: **PASS**
- Exact sensitive-token scan against the reference project: **PASS**
- Private network / SQL / credential source scan: **PASS**
- Asset review and metadata stripping for retained raster assets: **PASS**

## 8. Tests that still need local verification

### Build Result
**NEED REVIEW** - dependency installation in the current execution environment timed out, so a complete `npm run build` could not be executed here.

### Browser Runtime / Network Request Check
**NEED REVIEW** - because the frontend could not be built and launched in this environment, DevTools Network inspection was not performed here. Source-level inspection shows only localhost/relative runtime endpoints.

After copying the project to the examination machine, run:

```bash
npm install
npm run build
npm start
```

Then open `http://127.0.0.1:3000` and verify DevTools Network contains only localhost/static requests.

## 9. Academic Version Summary

### Frontend
Original layout, navigation, responsive design, tables, charts, filters, search, modals, validation, themes, and main workflows are retained as much as possible.

### Backend
Operational data access was replaced by a local Express REST API with in-memory business logic.

### Database
No operational database is used or required. The academic version uses synthetic in-memory data.

### Removed Sensitive Information
- Internal database configuration
- Internal database/query implementation
- Internal API/server/network references
- Production records and identifiers
- Operational user/authorization records
- Operational logs/history/configuration
- Company branding and operational guide assets

### Sensitive Data Scan
**PASS (source/static scan)**

### External/Internal Connection Check
**PASS (source design) / NEED REVIEW (browser runtime inspection)**


## 23 October 2026 update

The new UI and demo business workflows are documented in `ACADEMIC_SYNC_REPORT.md`. All new manuals and the animated criteria guide use newly generated synthetic illustrations instead of original operational screenshots. Full build/browser/network verification remains required on the destination machine.
